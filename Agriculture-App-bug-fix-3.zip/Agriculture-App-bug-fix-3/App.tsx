/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React, { useEffect } from 'react';
import { StatusBar, useColorScheme, View, StyleSheet } from 'react-native';
import AuthAwareNavigator from './src/navigation/AuthAwareNavigator';
import SupabaseDatabaseManager from './src/api/SupabaseDatabaseManager';
import SupabaseDatabaseSeeder from './src/api/SupabaseDatabaseSeeder';
import { AppInfoProvider } from './src/contexts/AppInfoContext';
import { AuthProvider } from './src/contexts/AuthContext';
import { ToastProvider } from './src/contexts/ToastContext';
import MessageRealtimeListener from './src/components/messaging/MessageRealtimeListener';
import { MessageNotificationProvider } from './src/contexts/MessageNotificationContext';

const App = () => {
  const isDarkMode = useColorScheme() === 'dark';

  useEffect(() => {
    // Initialize app in background to avoid blocking UI
    setTimeout(() => {
      initializeApp();
    }, 0);
  }, []);

  const initializeApp = async () => {
    try {
      console.log('Initializing AgriSmart App with Supabase...');
      // Get the database instance first
      const dbManager = SupabaseDatabaseManager.getInstance();
      // Initialize the database connection
      await dbManager.initializeDatabase();
      // Seed the database with initial data
      await SupabaseDatabaseSeeder.seedAll();
      console.log('AgriSmart App initialized successfully with Supabase');
    } catch (error) {
      console.error('Failed to initialize AgriSmart App:', error);
    }
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
      <AppInfoProvider>
        <AuthProvider>
          <MessageNotificationProvider>
            <ToastProvider>
              <MessageRealtimeListener />
              <AuthAwareNavigator />
            </ToastProvider>
          </MessageNotificationProvider>
        </AuthProvider>
      </AppInfoProvider>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
