# AgriApp

A modular, scalable, and responsive React Native mobile app using TypeScript.

## Structure

- `src/App.tsx`: Main app entry point
- `src/api`: API integration (e.g., Supabase)
- `src/screens`: App screens
- `src/contexts`: React contexts for state management
- `src/features`: Feature-based modules
- `src/components`: Shared UI components
- `src/navigation`: Navigation setup
- `src/utils`: Utility functions
- `src/assets`: Images, fonts, etc.
- `src/config`: App configuration

## Development

- TypeScript for type safety
- ESLint & Prettier for code quality
- React Navigation for navigation
- Supabase for backend services

## Getting Started

1. Install dependencies: `npm install`
2. Run on Android: `npx react-native run-android`
3. Run on iOS: `npx react-native run-ios`

## Linting & Formatting

- Lint: `npm run lint`
- Format: `npm run format`

## Testing

- Run tests: `npm test`

## Deployment

### Build and Deploy Android APK

1. **Generate a release APK:**

```sh
cd android
./gradlew assembleRelease
```

The APK will be generated at `android/app/build/outputs/apk/release/app-release.apk`.

2. **Sign the APK (optional for production):**

- Create a keystore if you don't have one:
  ```sh
  keytool -genkey -v -keystore my-release-key.keystore -alias my-key-alias -keyalg RSA -keysize 2048 -validity 10000
  ```
- Update `android/app/build.gradle` with your keystore info.

3. **Install the APK on a device:**

```sh
adb install android/app/build/outputs/apk/release/app-release.apk
```

4. **Distribute the APK:**

- Share the APK directly or upload to Google Play (requires AAB format).

### Build Android App Bundle (AAB) for Play Store

1. **Generate AAB:**

```sh
cd android
./gradlew bundleRelease
```

The AAB will be at `android/app/build/outputs/bundle/release/app-release.aab`.

2. **Upload to Google Play Console:**

- Sign in to Google Play Console.
- Create a new release and upload the `.aab` file.

### iOS Deployment

- Archive and upload via Xcode (see official React Native docs for details).
