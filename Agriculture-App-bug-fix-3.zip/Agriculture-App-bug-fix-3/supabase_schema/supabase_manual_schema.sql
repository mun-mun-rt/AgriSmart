-- Supabase Complete Migration Schema for AgriApp
-- This file contains everything needed to set up your Supabase database:
-- 1. All table schemas with proper relationships and constraints
-- 2. Row Level Security (RLS) policies for data protection
-- 3. Complete user deletion function with auth.users cleanup
-- 4. Default data and permissions
--
-- Run this ONCE in your Supabase SQL Editor to set up everything
--
-- IMPORTANT: This includes the delete_user_and_data function that can delete
-- users from both public tables AND auth.users (requires SECURITY DEFINER privileges)

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Enable Row Level Security by default
ALTER DATABASE postgres SET row_security = on;

-- Users table (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.users (
  id UUID REFERENCES auth.users(id) PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE, -- Used as contact email (can be different from auth.users email)
  phone TEXT,
  role TEXT NULL CHECK (role IN ('guest', 'farmer', 'consumer', 'admin')),

  -- Address Information
  address_line1 TEXT,
  address_line2 TEXT,
  city TEXT,
  state TEXT,
  postal_code TEXT,
  country TEXT DEFAULT 'Bangladesh',

  -- Profile Information
  date_of_birth DATE,
  gender TEXT CHECK (gender IN ('male', 'female', 'other')),
  profile_image_url TEXT,
  bio TEXT,

  -- Professional Information (for farmers)
  farm_name TEXT,
  farm_size DECIMAL(10,2), -- in acres
  farming_experience INTEGER, -- years of experience
  specialization TEXT, -- crop specialization

  -- Mobile Banking Information (per provider)
  mobile_banking_bkash TEXT,
  mobile_banking_nagad TEXT,
  mobile_banking_rocket TEXT,

  -- System fields
  is_active BOOLEAN NOT NULL DEFAULT true,
  wallet_balance DECIMAL(10,2) DEFAULT 0.0,
  onboarding_completed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- App info table
CREATE TABLE IF NOT EXISTS public.app_info (
  id SERIAL PRIMARY KEY,
  app_name TEXT NOT NULL,
  app_logo_url TEXT,
  welcome_message TEXT,
  contact_email TEXT,
  version TEXT,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.system_payment_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  method TEXT NOT NULL CHECK (method IN ('bank', 'mobile_banking')),
  provider TEXT,
  label TEXT NOT NULL,
  account_name TEXT,
  account_number TEXT NOT NULL,
  bank_name TEXT,
  branch_name TEXT,
  instructions TEXT,
  is_primary BOOLEAN NOT NULL DEFAULT false,
  is_active BOOLEAN NOT NULL DEFAULT true,
  updated_by UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Product categories table
CREATE TABLE IF NOT EXISTS public.product_categories (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  icon TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Products table
CREATE TABLE IF NOT EXISTS public.products (
  id SERIAL PRIMARY KEY,
  farmer_id UUID NOT NULL REFERENCES public.users(id),
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  -- Delivery fee per product (used in cart/orders snapshots)
  delivery_fee DECIMAL(10,2) DEFAULT 0.0,
  quantity INTEGER,
  min_purchase_quantity INTEGER NOT NULL DEFAULT 1,
  max_purchase_quantity INTEGER,
  stock INTEGER,
  unit TEXT DEFAULT 'kg',
  category TEXT NOT NULL,
  category_id INTEGER REFERENCES public.product_categories(id),
  image_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  CONSTRAINT products_min_purchase_guard CHECK (min_purchase_quantity >= 1),
  CONSTRAINT products_max_purchase_guard CHECK (
    max_purchase_quantity IS NULL OR max_purchase_quantity >= min_purchase_quantity
  )
);

-- Orders table (no FK constraint on product_id, uses snapshots)
CREATE TABLE IF NOT EXISTS public.orders (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.users(id),
  product_id INTEGER, -- Reference only, no FK constraint
  unit TEXT DEFAULT 'kg',
  farmer_id UUID NOT NULL REFERENCES public.users(id),
  quantity INTEGER NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  payment_method TEXT DEFAULT 'Cash on Delivery',
  payment_method_key TEXT,
  mobile_banking_provider TEXT CHECK (
    mobile_banking_provider IS NULL OR mobile_banking_provider IN ('bkash', 'nagad', 'rocket')
  ),
  mobile_banking_transaction_id TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  refunded BOOLEAN NOT NULL DEFAULT false,

  -- Product snapshot fields (stored at order creation)
  product_name TEXT,
  product_description TEXT,
  product_price DECIMAL(10,2),
  product_delivery_fee DECIMAL(10,2),
  product_unit TEXT,
  product_category TEXT,
  product_image_url TEXT,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Vault ledger to keep track of amounts owed to owners when payments are routed through system accounts
CREATE TABLE IF NOT EXISTS public.system_vault_transactions (
  id BIGSERIAL PRIMARY KEY,
  owner_id UUID NOT NULL REFERENCES public.users(id),
  order_id INTEGER NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  amount DECIMAL(12,2) NOT NULL,
  payment_method TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'released', 'refunded', 'cancelled')),
  notes TEXT,
  released_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(order_id, owner_id)
);

-- Aggregated vault balances per owner (farmer)
CREATE TABLE IF NOT EXISTS public.system_vault_balances (
  owner_id UUID PRIMARY KEY REFERENCES public.users(id),
  pending_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  released_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  currency TEXT NOT NULL DEFAULT 'BDT',
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Leases table
CREATE TABLE IF NOT EXISTS public.leases (
  id SERIAL PRIMARY KEY,
  owner_id UUID NOT NULL REFERENCES public.users(id),
  title TEXT NOT NULL,
  image_url TEXT,
  multiple_image_url TEXT[],
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  duration INTEGER NOT NULL,
  location TEXT NOT NULL,
  area DECIMAL(10,2),
  soil_type TEXT,
  water_source TEXT,
  crop_suitability TEXT,
  distance DECIMAL(10,2),
  rating DECIMAL(3,2) DEFAULT 4.5,
  status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'unavailable', 'booked', 'maintenance')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Lease applications table (no FK constraint on lease_id, uses snapshots)
-- applicant_id: the user who is applying for the lease
-- owner_id: the owner of the land (from lease snapshot)
CREATE TABLE IF NOT EXISTS public.lease_applications (
  id SERIAL PRIMARY KEY,
  lease_id INTEGER, -- Reference only, no FK constraint
  applicant_id UUID NOT NULL REFERENCES public.users(id),
  owner_id UUID NOT NULL REFERENCES public.users(id),
  offered_price DECIMAL(10,2) NOT NULL,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'pending',

  -- Lease snapshot fields (stored at application creation)
  lease_title TEXT,
  lease_description TEXT,
  lease_location TEXT,
  lease_price DECIMAL(10,2),
  lease_duration INTEGER,
  lease_area DECIMAL(10,2),
  lease_soil_type TEXT,
  lease_water_source TEXT,
  lease_crop_suitability TEXT,
  lease_distance DECIMAL(10,2),
  lease_rating DECIMAL(3,2),
  lease_image_url TEXT,
  multiple_image_url TEXT[],

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.lease_contracts (
  id SERIAL PRIMARY KEY,
  lease_id INTEGER, -- Reference only, no FK constraint
  tenant_id UUID NOT NULL REFERENCES public.users(id),
  owner_id UUID NOT NULL REFERENCES public.users(id),
  contract_amount DECIMAL(10,2) NOT NULL,
  start_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(), -- Start date of the lease
  end_date DATE NOT NULL, -- End date of the lease (add the duration in months from the start date)
  terms_conditions TEXT, -- The message column from the lease_application table
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'terminated', 'expired')),


  -- Lease snapshot fields (stored at contract creation)
  lease_title TEXT,
  lease_description TEXT,
  lease_duration INTEGER,
  lease_location TEXT,
  lease_area DECIMAL(10,2),
  lease_soil_type TEXT,
  lease_water_source TEXT,
  lease_crop_suitability TEXT,
  lease_distance DECIMAL(10,2),
  lease_rating DECIMAL(3,2),
  lease_image_url TEXT,
  multiple_image_url TEXT[],

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);


-- Fertilizer guides table
CREATE TABLE IF NOT EXISTS public.fertilizer_guides (
  id SERIAL PRIMARY KEY,
  crop_name TEXT NOT NULL,
  fertilizer_type TEXT NOT NULL,
  amount TEXT NOT NULL,
  timing TEXT NOT NULL,
  instructions TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(crop_name, fertilizer_type)
);

-- Fertilizer guide products table
CREATE TABLE IF NOT EXISTS public.fertilizer_guide_products (
  id SERIAL PRIMARY KEY,
  fertilizer_guide_id INTEGER NOT NULL REFERENCES public.fertilizer_guides(id) ON DELETE CASCADE,
  product_id INTEGER NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(fertilizer_guide_id, product_id)
);

CREATE TABLE IF NOT EXISTS public.messages (
  id SERIAL PRIMARY KEY,
  sender_id UUID NOT NULL REFERENCES public.users(id),
  receiver_id UUID NOT NULL REFERENCES public.users(id),
  content TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);


-- Followers table
CREATE TABLE IF NOT EXISTS public.followers (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.users(id),
  follower_id UUID NOT NULL REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, follower_id)
);

-- Shopping cart table (no FK constraint on product_id, uses snapshots)
CREATE TABLE IF NOT EXISTS public.shopping_cart (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.users(id),
  product_id INTEGER, -- Reference only, no FK constraint
  quantity INTEGER NOT NULL DEFAULT 1,

  -- Product snapshot fields (stored when added to cart)
  product_name TEXT,
  product_description TEXT,
  product_price DECIMAL(10,2),
  product_delivery_fee DECIMAL(10,2),
  product_unit TEXT,
  product_category TEXT,
  product_image_url TEXT,
  product_min_purchase_quantity INTEGER,
  product_max_purchase_quantity INTEGER,

  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, product_id)
);

-- Ensure purchase constraint columns exist on legacy databases
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'products'
      AND column_name = 'min_purchase_quantity'
  ) THEN
    ALTER TABLE public.products
      ADD COLUMN min_purchase_quantity INTEGER NOT NULL DEFAULT 1;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'products'
      AND column_name = 'max_purchase_quantity'
  ) THEN
    ALTER TABLE public.products
      ADD COLUMN max_purchase_quantity INTEGER;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_schema = 'public'
      AND constraint_name = 'products_min_purchase_guard'
  ) THEN
    ALTER TABLE public.products
      ADD CONSTRAINT products_min_purchase_guard
      CHECK (min_purchase_quantity >= 1);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_schema = 'public'
      AND constraint_name = 'products_max_purchase_guard'
  ) THEN
    ALTER TABLE public.products
      ADD CONSTRAINT products_max_purchase_guard
      CHECK (
        max_purchase_quantity IS NULL OR max_purchase_quantity >= min_purchase_quantity
      );
  END IF;
END;
$$;

ALTER TABLE public.shopping_cart
  ADD COLUMN IF NOT EXISTS product_min_purchase_quantity INTEGER;

ALTER TABLE public.shopping_cart
  ADD COLUMN IF NOT EXISTS product_max_purchase_quantity INTEGER;

-- Wallet transactions table
CREATE TABLE IF NOT EXISTS public.wallet_transactions (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.users(id),
  amount DECIMAL(10,2) NOT NULL,
  transaction_type TEXT NOT NULL CHECK (transaction_type IN ('deposit', 'withdrawal', 'payment', 'refund', 'payment_received')),
  description TEXT,
  related_order_id INTEGER REFERENCES public.orders(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON public.products FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_shopping_cart_updated_at BEFORE UPDATE ON public.shopping_cart FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_system_payment_accounts_updated_at BEFORE UPDATE ON public.system_payment_accounts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_system_vault_transactions_updated_at BEFORE UPDATE ON public.system_vault_transactions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_system_vault_balances_updated_at BEFORE UPDATE ON public.system_vault_balances FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


-- Row Level Security Policies
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lease_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lease_contracts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.shopping_cart ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.followers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_payment_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_vault_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_vault_balances ENABLE ROW LEVEL SECURITY;



-- Only the owner of the land lease can update lease applications
CREATE POLICY "Only owner can update lease applications"
ON public.lease_applications
FOR UPDATE
TO authenticated
USING (
  auth.uid() = owner_id
);


-- Anyone can insert lease applications
CREATE POLICY "Anyone can insert lease applications"
ON public.lease_applications
FOR INSERT
TO authenticated
WITH CHECK (true);

-- Anyone can view lease applications
CREATE POLICY "Anyone can view lease applications"
ON public.lease_applications
FOR SELECT
TO authenticated
USING (true);

-- Allow applicants and owners to delete lease applications
CREATE POLICY "Applicants and owners can delete lease applications"
ON public.lease_applications
FOR DELETE
TO authenticated
USING (
  auth.uid() = applicant_id OR auth.uid() = owner_id
);

-- Allow users to delete applications for leases they own (for account deletion)
CREATE POLICY "Lease owners can delete all applications for their leases"
ON public.lease_applications
FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.leases
    WHERE leases.id = lease_applications.lease_id
      AND leases.owner_id = auth.uid()
  )
);


CREATE POLICY "Owner or tenant can insert lease contracts"
ON public.lease_contracts
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = owner_id OR auth.uid() = tenant_id
);

CREATE POLICY "Owner or tenant can view lease contracts"
ON public.lease_contracts
FOR SELECT
TO authenticated
USING (
  auth.uid() = owner_id OR auth.uid() = tenant_id
);

CREATE POLICY "Owner or tenant can update lease contracts"
ON public.lease_contracts
FOR UPDATE
TO authenticated
USING (
  auth.uid() = owner_id OR auth.uid() = tenant_id
);

-- RLS policy: Allow sender or receiver to insert messages
CREATE POLICY "Sender or receiver can insert messages"
ON public.messages
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = sender_id OR auth.uid() = receiver_id
);

-- RLS policy: Allow sender or receiver to view messages
CREATE POLICY "Sender or receiver can view messages"
ON public.messages
FOR SELECT
TO authenticated
USING (
  auth.uid() = sender_id OR auth.uid() = receiver_id
);


-- Basic RLS policies (you can modify these based on your requirements)
-- Users can read their own data
CREATE POLICY "Users can view own data" ON public.users FOR SELECT USING (auth.uid() = id);

-- Allow all authenticated users to view public user info
CREATE POLICY "Authenticated users can view public user info"
ON public.users
FOR SELECT
TO authenticated
USING (true);

-- Allow farmers to view buyers of their product orders
CREATE POLICY "Farmers can view buyers of their product orders"
ON public.users
FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.orders
    WHERE public.orders.user_id = users.id
      AND public.orders.farmer_id = auth.uid()
  )
);
CREATE POLICY "Users can update own data" ON public.users FOR UPDATE USING (auth.uid() = id);

-- Allow users to insert their profile during onboarding
CREATE POLICY "Users can insert own profile during onboarding" ON public.users FOR INSERT
WITH CHECK (auth.uid() = id);

-- Restrict access to main app features until onboarding is complete
-- Products are publicly readable, but only to users with completed onboarding
CREATE POLICY "Products are publicly readable to onboarded users" ON public.products FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()
    AND (role IS NOT NULL AND onboarding_completed = true)
  )
);
CREATE POLICY "Farmers can manage own products" ON public.products FOR ALL USING (
  farmer_id = auth.uid() AND
  EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()
    AND role = 'farmer'
    AND onboarding_completed = true
  )
);

-- Orders are private to users
CREATE POLICY "Users can view own orders" ON public.orders FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users can create orders" ON public.orders FOR INSERT WITH CHECK (user_id = auth.uid());

-- Allow farmers to update order status for their own products

-- Allow both the buyer and the farmer to update the order
CREATE POLICY "Buyer or Farmer can update order status"
ON public.orders
FOR UPDATE
USING (
  user_id = auth.uid()
  OR farmer_id = auth.uid()
);

-- Allow buyers and farmers to delete their own orders
CREATE POLICY "Buyers and farmers can delete their own orders"
ON public.orders
FOR DELETE
TO authenticated
USING (
  user_id = auth.uid()
  OR farmer_id = auth.uid()
);

-- Allow farmers to delete all orders for their products (for account deletion)
CREATE POLICY "Farmers can delete all orders for their products"
ON public.orders
FOR DELETE
TO authenticated
USING (
  farmer_id = auth.uid()
);

-- Allow farmers to view orders for their own products
CREATE POLICY "Farmers can view their product orders"
ON public.orders
FOR SELECT
USING (
  farmer_id = auth.uid()
);

-- Allow authenticated users to follow others (insert)
CREATE POLICY "Authenticated users can follow others"
ON public.followers
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = follower_id
);

-- Allow authenticated users to unfollow (delete their own follows)
CREATE POLICY "Authenticated users can unfollow others"
ON public.followers
FOR DELETE
TO authenticated
USING (
  auth.uid() = follower_id
);

-- (Optional) Allow users to see who they follow and who follows them
CREATE POLICY "Authenticated users can view their followers"
ON public.followers
FOR SELECT
TO authenticated
USING (
  auth.uid() = user_id OR auth.uid() = follower_id
);


-- Helper function to return total follower count for any user
CREATE OR REPLACE FUNCTION public.get_follower_count(target_user_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    follower_total INTEGER;
BEGIN
    SELECT COUNT(*) INTO follower_total
    FROM public.followers
    WHERE user_id = target_user_id;

    RETURN COALESCE(follower_total, 0);
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_follower_count(UUID) TO authenticated;




-- Leases are publicly readable, owners can manage their own
CREATE POLICY "Leases are publicly readable" ON public.leases FOR SELECT TO authenticated USING (true);
CREATE POLICY "Owners can manage own leases" ON public.leases FOR ALL USING (owner_id = auth.uid());

-- Allow public (unauthenticated) users to view products
CREATE POLICY "Public can view products"
ON public.products
FOR SELECT
TO public
USING (true);

-- Allow public (unauthenticated) users to view land leases
CREATE POLICY "Public can view land leases"
ON public.leases
FOR SELECT
TO public
USING (true);

-- Shopping cart is private to users
CREATE POLICY "Users can manage own cart" ON public.shopping_cart FOR ALL USING (user_id = auth.uid());

-- Wallet transactions are private to users

CREATE POLICY "Users can view own transactions" ON public.wallet_transactions FOR SELECT USING (user_id = auth.uid());

-- Allow authenticated users to insert their own wallet transactions

CREATE POLICY "Users can insert own wallet transactions"
ON public.wallet_transactions
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own wallet transactions"
ON public.wallet_transactions
FOR UPDATE
TO authenticated
USING (user_id = auth.uid());

-- System payment account visibility and admin management
CREATE POLICY "Authenticated users can view payment accounts"
ON public.system_payment_accounts
FOR SELECT
TO authenticated
USING (
  is_active = true
  OR EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()
    AND role = 'admin'
  )
);

CREATE POLICY "Admins manage system payment accounts"
ON public.system_payment_accounts
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()
    AND role = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()
    AND role = 'admin'
  )
);

-- Vault ledger visibility (insert/update handled via security definer functions)
CREATE POLICY "Admins can view vault transactions"
ON public.system_vault_transactions
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()
    AND role = 'admin'
  )
);

CREATE POLICY "Owners can view their vault transactions"
ON public.system_vault_transactions
FOR SELECT
TO authenticated
USING (owner_id = auth.uid());

CREATE POLICY "Admins can view vault balances"
ON public.system_vault_balances
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid()
    AND role = 'admin'
  )
);

CREATE POLICY "Owners can view own vault balances"
ON public.system_vault_balances
FOR SELECT
TO authenticated
USING (owner_id = auth.uid());

-- Utility function to record vault entries after order creation
CREATE OR REPLACE FUNCTION public.record_order_vault_entry(p_order_id INTEGER)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_order RECORD;
  v_amount DECIMAL(12,2);
BEGIN
  SELECT o.id,
         o.farmer_id,
         COALESCE(o.total_price, 0) AS total_price,
         COALESCE(o.payment_method, '') AS payment_method
  INTO v_order
  FROM public.orders o
  WHERE o.id = p_order_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Order % not found', p_order_id;
  END IF;

  -- Skip cash-on-delivery and AgriWallet since funds are not routed through the system vault
  IF lower(v_order.payment_method) IN ('cash on delivery', 'agriwallet') THEN
    RETURN;
  END IF;

  v_amount := v_order.total_price;

  INSERT INTO public.system_vault_transactions (owner_id, order_id, amount, payment_method)
  VALUES (v_order.farmer_id, v_order.id, v_amount, v_order.payment_method)
  ON CONFLICT (order_id, owner_id) DO NOTHING;

  INSERT INTO public.system_vault_balances (owner_id, pending_amount)
  VALUES (v_order.farmer_id, v_amount)
  ON CONFLICT (owner_id)
  DO UPDATE SET
    pending_amount = public.system_vault_balances.pending_amount + EXCLUDED.pending_amount,
    updated_at = NOW();
END;
$$;

GRANT EXECUTE ON FUNCTION public.record_order_vault_entry(INTEGER) TO authenticated;

-- Function to settle vault transactions and optionally release funds
CREATE OR REPLACE FUNCTION public.process_vault_settlement(
  p_order_id INTEGER,
  p_owner_id UUID,
  p_new_status TEXT,
  p_recipient_id UUID DEFAULT NULL,
  p_wallet_transaction_type TEXT DEFAULT NULL,
  p_wallet_description TEXT DEFAULT NULL,
  p_note TEXT DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tx RECORD;
BEGIN
  IF p_new_status NOT IN ('released', 'refunded', 'cancelled') THEN
    RAISE EXCEPTION 'Unsupported vault settlement status: %', p_new_status;
  END IF;

  SELECT id, status, amount
  INTO v_tx
  FROM public.system_vault_transactions
  WHERE owner_id = p_owner_id
    AND order_id = p_order_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Vault transaction not found for owner %, order %', p_owner_id, p_order_id;
  END IF;

  IF v_tx.status = p_new_status THEN
    UPDATE public.system_vault_transactions
    SET
      notes = COALESCE(p_note, notes),
      updated_at = NOW()
    WHERE id = v_tx.id;
    RETURN;
  END IF;

  IF v_tx.status <> 'pending' THEN
    RAISE EXCEPTION 'Vault transaction already settled with status %', v_tx.status;
  END IF;

  -- Ensure a balance row exists for the owner
  INSERT INTO public.system_vault_balances (owner_id)
  VALUES (p_owner_id)
  ON CONFLICT (owner_id) DO NOTHING;

  IF p_new_status = 'cancelled' THEN
    UPDATE public.system_vault_balances
    SET
      pending_amount = GREATEST(pending_amount - v_tx.amount, 0),
      updated_at = NOW()
    WHERE owner_id = p_owner_id;
  ELSE
    IF p_recipient_id IS NULL THEN
      RAISE EXCEPTION 'Recipient is required when settling vault transaction as %', p_new_status;
    END IF;

    IF p_wallet_transaction_type IS NULL THEN
      RAISE EXCEPTION 'Wallet transaction type is required when settling vault transaction as %', p_new_status;
    END IF;

    UPDATE public.system_vault_balances
    SET
      pending_amount = GREATEST(pending_amount - v_tx.amount, 0),
      released_amount = released_amount + v_tx.amount,
      updated_at = NOW()
    WHERE owner_id = p_owner_id;

    PERFORM public.update_user_wallet_balance(p_recipient_id, v_tx.amount, 'add');

    PERFORM public.create_wallet_transaction(
      p_recipient_id,
      v_tx.amount,
      p_wallet_transaction_type,
      COALESCE(
        p_wallet_description,
        CASE p_new_status
          WHEN 'refunded' THEN 'Vault refund processed'
          ELSE 'Vault payout released'
        END
      ),
      p_order_id
    );
  END IF;

  UPDATE public.system_vault_transactions
  SET
    status = p_new_status,
    released_at = CASE WHEN p_new_status IN ('released', 'refunded') THEN NOW() ELSE NULL END,
    notes = COALESCE(p_note, notes),
    updated_at = NOW()
  WHERE id = v_tx.id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.process_vault_settlement(
  INTEGER,
  UUID,
  TEXT,
  UUID,
  TEXT,
  TEXT,
  TEXT
) TO authenticated;

-- Function to create wallet transaction with elevated privileges
-- This bypasses RLS to allow system operations like refunds and payments
CREATE OR REPLACE FUNCTION public.create_wallet_transaction(
  p_user_id UUID,
  p_amount DECIMAL(12,2),
  p_transaction_type TEXT,
  p_description TEXT,
  p_related_order_id INTEGER DEFAULT NULL
)
RETURNS BIGINT
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_transaction_id BIGINT;
BEGIN
  INSERT INTO public.wallet_transactions (
    user_id,
    amount,
    transaction_type,
    description,
    related_order_id
  ) VALUES (
    p_user_id,
    p_amount,
    p_transaction_type,
    p_description,
    p_related_order_id
  ) RETURNING id INTO v_transaction_id;

  RETURN v_transaction_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.create_wallet_transaction(UUID, DECIMAL, TEXT, TEXT, INTEGER) TO authenticated;

-- Function to update user wallet balance with elevated privileges
-- This bypasses RLS to allow system operations like refunds and payments
CREATE OR REPLACE FUNCTION public.update_user_wallet_balance(
  p_user_id UUID,
  p_amount DECIMAL(12,2),
  p_operation TEXT  -- 'add' or 'subtract'
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_current_balance DECIMAL(12,2);
  v_new_balance DECIMAL(12,2);
BEGIN
  -- Get current balance
  SELECT wallet_balance INTO v_current_balance
  FROM public.users
  WHERE id = p_user_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'User % not found', p_user_id;
  END IF;

  -- Calculate new balance
  IF p_operation = 'add' THEN
    v_new_balance := COALESCE(v_current_balance, 0) + p_amount;
  ELSIF p_operation = 'subtract' THEN
    v_new_balance := COALESCE(v_current_balance, 0) - p_amount;
  ELSE
    RAISE EXCEPTION 'Invalid operation: %. Must be "add" or "subtract"', p_operation;
  END IF;

  -- Update balance
  UPDATE public.users
  SET wallet_balance = v_new_balance
  WHERE id = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.update_user_wallet_balance(UUID, DECIMAL, TEXT) TO authenticated;


-- Admin helper to retrieve vault balances along with owner details
CREATE OR REPLACE FUNCTION public.admin_get_vault_balances()
RETURNS TABLE (
  owner_id UUID,
  owner_name TEXT,
  owner_email TEXT,
  pending_amount DECIMAL(12,2),
  released_amount DECIMAL(12,2),
  total_amount DECIMAL(12,2),
  updated_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: admin privileges required';
  END IF;

  RETURN QUERY
  SELECT
    b.owner_id,
    COALESCE(u.name, 'Unknown User') AS owner_name,
    COALESCE(u.email, '') AS owner_email,
    COALESCE(b.pending_amount, 0)::DECIMAL(12,2) AS pending_amount,
    COALESCE(b.released_amount, 0)::DECIMAL(12,2) AS released_amount,
    (COALESCE(b.pending_amount, 0) + COALESCE(b.released_amount, 0))::DECIMAL(12,2) AS total_amount,
    b.updated_at
  FROM public.system_vault_balances b
  LEFT JOIN public.users u ON u.id = b.owner_id
  ORDER BY COALESCE(b.pending_amount, 0) DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_get_vault_balances() TO authenticated;

-- Admin helper to retrieve vault transactions with buyer/owner details
CREATE OR REPLACE FUNCTION public.admin_get_vault_transactions()
RETURNS TABLE (
  id BIGINT,
  order_id INTEGER,
  owner_id UUID,
  owner_name TEXT,
  owner_email TEXT,
  buyer_id UUID,
  buyer_name TEXT,
  buyer_email TEXT,
  amount DECIMAL(12,2),
  status TEXT,
  payment_method TEXT,
  created_at TIMESTAMP WITH TIME ZONE,
  released_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: admin privileges required';
  END IF;

  RETURN QUERY
  SELECT
    t.id,
    t.order_id,
    t.owner_id,
    COALESCE(owner.name, 'Unknown Farmer') AS owner_name,
    COALESCE(owner.email, '') AS owner_email,
    ord.user_id AS buyer_id,
    COALESCE(buyer.name, 'Unknown Buyer') AS buyer_name,
    COALESCE(buyer.email, '') AS buyer_email,
    COALESCE(t.amount, 0)::DECIMAL(12,2) AS amount,
    t.status,
    t.payment_method,
    t.created_at,
    t.released_at
  FROM public.system_vault_transactions t
  LEFT JOIN public.orders ord ON ord.id = t.order_id
  LEFT JOIN public.users owner ON owner.id = t.owner_id
  LEFT JOIN public.users buyer ON buyer.id = ord.user_id
  ORDER BY t.created_at DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_get_vault_transactions() TO authenticated;


-- Allow authenticated users to view fertilizer guides
CREATE POLICY "Authenticated users can view fertilizer guides"
ON public.fertilizer_guides
FOR SELECT
TO authenticated
USING (true);

-- Allow authenticated users to view fertilizer guide products
CREATE POLICY "Authenticated users can view fertilizer guide products"
ON public.fertilizer_guide_products
FOR SELECT
TO authenticated
USING (true);

-- (You already have a similar policy for products)

-- Grant permissions
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated;

-- Insert default categories
INSERT INTO public.product_categories (name, description, icon) VALUES
('Vegetables', 'Fresh vegetables and greens', '🥬'),
('Fruits', 'Fresh seasonal fruits', '🍎'),
('Grains', 'Rice, wheat, and other grains', '🌾'),
('Dairy', 'Milk and dairy products', '🥛'),
('Meat', 'Fresh meat and poultry', '🍖'),
('Spices', 'Herbs and spices', '🌶️'),
('Seeds', 'Seeds for planting', '🌱'),
('Fertilizers', 'Organic and chemical fertilizers', '🧪'),
('Tools', 'Farming tools and equipment', '🔧'),
('Others', 'Other agricultural products', '📦')
ON CONFLICT (name) DO NOTHING;

-- Insert default app info
INSERT INTO public.app_info (app_name, welcome_message, contact_email, version) VALUES
('AgriSmart Bangladesh', 'Welcome to AgriSmart Bangladesh - Your farming companion', 'support@AgriSmart.bd', '1.0.0')
ON CONFLICT DO NOTHING;

-- Function to delete user and all related data (including auth.users)
CREATE OR REPLACE FUNCTION delete_user_and_data(user_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth
AS $$
DECLARE
    result_json JSON;
    error_occurred BOOLEAN := FALSE;
    error_message TEXT := '';
BEGIN
    -- Start transaction
    BEGIN
        -- Log the deletion attempt
        RAISE NOTICE 'Starting deletion for user: %', user_id;

        -- Delete wallet transactions
        DELETE FROM public.wallet_transactions WHERE user_id = delete_user_and_data.user_id;
        RAISE NOTICE 'Deleted wallet transactions';

        -- Delete messages (sent and received)
        DELETE FROM public.messages WHERE sender_id = delete_user_and_data.user_id OR receiver_id = delete_user_and_data.user_id;
        RAISE NOTICE 'Deleted messages';

        -- Delete followers
        DELETE FROM public.followers WHERE user_id = delete_user_and_data.user_id OR follower_id = delete_user_and_data.user_id;
        RAISE NOTICE 'Deleted followers';

        -- Delete shopping cart items for user
        DELETE FROM public.shopping_cart WHERE user_id = delete_user_and_data.user_id;

        -- Delete shopping cart items for user-owned products
        DELETE FROM public.shopping_cart WHERE product_id IN (
            SELECT id FROM public.products WHERE farmer_id = delete_user_and_data.user_id
        );
        RAISE NOTICE 'Deleted shopping cart items';

        -- Delete lease contracts (user as tenant or owner)
        DELETE FROM public.lease_contracts WHERE tenant_id = delete_user_and_data.user_id OR owner_id = delete_user_and_data.user_id;

        -- Delete lease contracts for user-owned leases
        DELETE FROM public.lease_contracts WHERE lease_id IN (
            SELECT id FROM public.leases WHERE owner_id = delete_user_and_data.user_id
        );
        RAISE NOTICE 'Deleted lease contracts';

        -- Delete lease applications (user as applicant or owner)
        DELETE FROM public.lease_applications WHERE applicant_id = delete_user_and_data.user_id OR owner_id = delete_user_and_data.user_id;

        -- Delete lease applications for user-owned leases
        DELETE FROM public.lease_applications WHERE lease_id IN (
            SELECT id FROM public.leases WHERE owner_id = delete_user_and_data.user_id
        );
        RAISE NOTICE 'Deleted lease applications';

        -- Delete orders (user as buyer or farmer)
        DELETE FROM public.orders WHERE user_id = delete_user_and_data.user_id OR farmer_id = delete_user_and_data.user_id;

        -- Delete orders for user-owned products
        DELETE FROM public.orders WHERE product_id IN (
            SELECT id FROM public.products WHERE farmer_id = delete_user_and_data.user_id
        );
        RAISE NOTICE 'Deleted orders';

        -- Delete fertilizer guide products for user-owned products
        DELETE FROM public.fertilizer_guide_products WHERE product_id IN (
            SELECT id FROM public.products WHERE farmer_id = delete_user_and_data.user_id
        );
        RAISE NOTICE 'Deleted fertilizer guide products';

        -- Delete leases owned by user
        DELETE FROM public.leases WHERE owner_id = delete_user_and_data.user_id;
        RAISE NOTICE 'Deleted leases';

        -- Delete products owned by user
        DELETE FROM public.products WHERE farmer_id = delete_user_and_data.user_id;
        RAISE NOTICE 'Deleted products';

        -- Delete user profile from public.users
        DELETE FROM public.users WHERE id = delete_user_and_data.user_id;
        RAISE NOTICE 'Deleted user profile';

        -- Delete user from auth.users (this requires SECURITY DEFINER)
        DELETE FROM auth.users WHERE id = delete_user_and_data.user_id;
        RAISE NOTICE 'Deleted auth user';

        -- If we get here, everything succeeded
        result_json := json_build_object(
            'success', true,
            'message', 'User and all related data deleted successfully',
            'deleted_from_auth', true
        );

    EXCEPTION WHEN others THEN
        -- Log the error
        error_occurred := TRUE;
        error_message := SQLERRM;
        RAISE NOTICE 'Error during deletion: %', error_message;

        -- Rollback will happen automatically
        result_json := json_build_object(
            'success', false,
            'message', 'Error during deletion: ' || error_message,
            'deleted_from_auth', false
        );
    END;

    RETURN result_json;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION delete_user_and_data(UUID) TO authenticated;

-- =============================================================================
-- SETUP COMPLETE
-- =============================================================================
-- Your AgriApp database is now fully configured with:
-- ✅ All tables with proper relationships and foreign key constraints
-- ✅ Row Level Security policies for data protection
-- ✅ Complete user deletion function (including auth.users cleanup)
-- ✅ Default permissions and sample data
--
-- The delete_user_and_data() function can be called from your app to:
-- - Delete all user data from public tables
-- - Delete user from auth.users table (complete account removal)
-- - Handle foreign key constraints properly
-- - Provide detailed success/error responses
--
-- Your React Native app is ready to use account deletion with full cleanup!