#!/bin/bash

# AgriSmart Bangladesh - Complete Setup and Build Script
# This script handles installing dependencies, running the app, and building signed/unsigned APKs

echo "🌾 AgriSmart Bangladesh - Complete Setup and Build Script"
echo "=========================================================="

# Step 1: Install Dependencies
echo "📦 Step 1: Installing dependencies..."
npm install
if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi
echo "✅ Dependencies installed successfully"

# Step 2: TypeScript Compilation Check
echo "🔧 Step 2: Running TypeScript compilation check..."
npx tsc --noEmit
if [ $? -ne 0 ]; then
    echo "❌ TypeScript compilation failed"
    exit 1
fi
echo "✅ TypeScript compilation successful"

# Step 3: Run Linting
echo "🧹 Step 3: Running ESLint checks..."
npx eslint src --ext .ts,.tsx --max-warnings 0
if [ $? -ne 0 ]; then
    echo "⚠️ Linting warnings detected (continuing...)"
fi
echo "✅ Linting completed"

# Step 4: Start Metro Bundler
echo "🚀 Step 4: Starting Metro bundler..."
npx react-native start &
METRO_PID=$!
echo "✅ Metro bundler started (PID: $METRO_PID)"

# Step 5: Run App on Android
echo "📱 Step 5: Running app on Android..."
npx react-native run-android
if [ $? -ne 0 ]; then
    echo "❌ Failed to run app on Android"
    kill $METRO_PID 2>/dev/null
    exit 1
fi
echo "✅ App running on Android"

# Step 6: Build Unsigned APK (Debug)
echo "🔨 Step 6: Building unsigned APK (debug)..."
cd android
./gradlew assembleDebug
if [ $? -ne 0 ]; then
    echo "❌ Failed to build debug APK"
    cd ..
    kill $METRO_PID 2>/dev/null
    exit 1
fi
cd ..
echo "✅ Unsigned APK built: android/app/build/outputs/apk/debug/app-debug.apk"

# Step 7: Build Signed APK (Release)
echo "🔐 Step 7: Building signed APK (release)..."
echo "   Note: Ensure keystore is configured in android/gradle.properties"
echo "   Required properties:"
echo "   - MYAPP_UPLOAD_STORE_FILE=../keystore.jks"
echo "   - MYAPP_UPLOAD_KEY_ALIAS=upload"
echo "   - MYAPP_UPLOAD_STORE_PASSWORD=store_password"
echo "   - MYAPP_UPLOAD_KEY_PASSWORD=key_password"

cd android
./gradlew assembleRelease
if [ $? -ne 0 ]; then
    echo "❌ Failed to build release APK"
    cd ..
    kill $METRO_PID 2>/dev/null
    exit 1
fi
cd ..
echo "✅ Signed APK built: android/app/build/outputs/apk/release/app-release.apk"

# Cleanup
echo "🧹 Cleaning up..."
kill $METRO_PID 2>/dev/null

echo ""
echo "🎉 All steps completed successfully!"
echo "📱 Unsigned APK: android/app/build/outputs/apk/debug/app-debug.apk"
echo "🔐 Signed APK: android/app/build/outputs/apk/release/app-release.apk"
echo "🌾 AgriSmart Bangladesh is ready! 🇧🇩"
