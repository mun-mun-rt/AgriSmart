<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This is a modular React Native project using TypeScript. Use best practices for scalable, maintainable, and responsive mobile app development. Organize code by features, shared components, navigation, utilities, assets, and configuration. Use TypeScript, ESLint, Prettier, and include basic testing setup. Prioritize responsive design and modularity.
