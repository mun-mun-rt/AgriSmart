### 📱 App Launch Sequence

1. **Welcome Page**
   Initial splash/onboarding screen shown on app load. Displays app intro, branding, and two options:

   - **Login** → Redirects to the Login screen.
   - **Continue as Guest** → Proceeds to the **Menu Page** with limited access.

2. **Login Screen**
   Users sign in with email and password. During signup/login, the user selects a role: **Farmer** or **Consumer**.

   - On successful login, redirect to the **Menu Page** with full access.
   - User session is stored locally using SQLite.

3. **Menu Page (Home/Dashboard)**
   The central hub that shows all app features as clickable options:

   - **E-commerce** → Requires login to view dashboard. Guest users can only browse products.
   - **Weather Forecast**
   - **Land Lease** → Requires login to view dashboard. Guest users can only view listings.
   - **Fertilizer Recommendation**
   - **Farmer to Consumer** → Browse farmers (Consumers) or consumers (Farmers).
