import { User } from '../types';

/**
 * Checks if a user needs to complete onboarding
 * @param user - The user object
 * @returns true if user needs onboarding, false otherwise
 */
export const needsOnboarding = (user: User | null): boolean => {
  if (!user) return false;

  // User needs onboarding if:
  // 1. They don't have a role set, OR
  // 2. onboarding_completed is explicitly false
  return !user.role || user.onboarding_completed === false;
};

/**
 * Checks if a user has completed onboarding and can access main app features
 * @param user - The user object
 * @returns true if user can access main features, false otherwise
 */
export const canAccessMainFeatures = (user: User | null): boolean => {
  if (!user) return false;

  // User can access main features if:
  // 1. They have a role set, AND
  // 2. onboarding_completed is true (or undefined for backward compatibility)
  return (
    !!user.role &&
    (user.onboarding_completed === true ||
      user.onboarding_completed === undefined)
  );
};

/**
 * Gets the appropriate dashboard route based on user role
 * @param role - The user's role
 * @returns The navigation route name
 */
export const getDashboardRoute = (role: string): string => {
  switch (role) {
    case 'farmer':
      return 'FarmerDashboard';
    case 'consumer':
      return 'ConsumerDashboard';
    case 'admin':
      return 'AdminDashboard';
    default:
      return 'Menu';
  }
};

/**
 * Safely gets the display name for a user role
 * @param role - The user's role (can be undefined)
 * @returns The formatted role name
 */
export const getRoleDisplayName = (role?: string): string => {
  if (!role) return 'Guest';

  switch (role) {
    case 'farmer':
      return 'Farmer';
    case 'consumer':
      return 'Consumer';
    case 'admin':
      return 'Admin';
    case 'guest':
      return 'Guest';
    default:
      return role.charAt(0).toUpperCase() + role.slice(1);
  }
};
