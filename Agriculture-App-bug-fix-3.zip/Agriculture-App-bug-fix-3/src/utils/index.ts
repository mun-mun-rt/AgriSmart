// Utility functions

/**
 * Gets display name for user role
 * @param role - The user's role
 * @returns Display name for the role
 */
export const getRoleDisplayName = (role?: string | null): string => {
  switch (role) {
    case 'farmer':
      return 'Farmer';
    case 'consumer':
      return 'Consumer';
    case 'admin':
      return 'Administrator';
    case 'guest':
      return 'Guest';
    default:
      return 'Not Set';
  }
};

/**
 * Builds a consistent room identifier for two participants irrespective of id type.
 */
export const buildRoomId = (
  userA: string | number,
  userB: string | number,
): string => {
  const idA = String(userA);
  const idB = String(userB);
  const numA = Number(idA);
  const numB = Number(idB);

  if (!Number.isNaN(numA) && !Number.isNaN(numB)) {
    const [low, high] = numA <= numB ? [numA, numB] : [numB, numA];
    return `${low}_${high}`;
  }

  return [idA, idB]
    .sort((first, second) => {
      if (first < second) return -1;
      if (first > second) return 1;
      return 0;
    })
    .join('_');
};

// Re-export from authUtils for convenience
export * from './authUtils';
