import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl =
  process.env.EXPO_PUBLIC_SUPABASE_URL ||
  'https://fjuaaoeqbeqtauxrfxgd.supabase.co';
const supabaseAnonKey =
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZqdWFhb2VxYmVxdGF1eHJmeGdkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMyMDc4MDcsImV4cCI6MjA2ODc4MzgwN30.pP6XyD-VEu7ViSwrQW8OL4oRvquuTzSOSHAoQQiwciA';

// Service role key for admin operations (DEVELOPMENT ONLY - NOT FOR PRODUCTION)
const supabaseServiceKey =
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZqdWFhb2VxYmVxdGF1eHJmeGdkIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1MzIwNzgwNywiZXhwIjoyMDY4NzgzODA3fQ.U8nqIcIb562bnHj4XP8jlb_w3CQJJdH0NUTY8Lxrywg';

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

// Regular client for normal operations
const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Admin client for account deletion (DEVELOPMENT ONLY)
// WARNING: This exposes service role key in client code - NOT FOR PRODUCTION
const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

export { supabase, supabaseAdmin };

/**
 * Resolve a stored path or full URL to a publicly accessible URL.
 * If the value is already an http(s) URL, it is returned as-is.
 * Otherwise, attempts to call Supabase storage to get a public URL
 * from a likely bucket name ('images' or 'public').
 */
export async function getPublicUrlForPath(pathOrUrl?: string | null) {
  if (!pathOrUrl) return null;
  const trimmed = String(pathOrUrl).trim();
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    return trimmed;
  }

  // Try common buckets
  const buckets = ['images', 'public', 'avatars'];
  for (const b of buckets) {
    try {
      const res = await supabase.storage.from(b).getPublicUrl(trimmed);
      if (res && res.data && typeof res.data.publicUrl === 'string') {
        return res.data.publicUrl;
      }
    } catch (err) {
      // ignore and try next
      continue;
    }
  }

  // As a last resort return the original string
  return trimmed;
}
