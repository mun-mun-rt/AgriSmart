import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { useAuth } from '../contexts/AuthContext';
import ModernLoading from '../components/ModernLoading';

// Auth Screens
import WelcomeScreen from '../screens/main/WelcomeScreen';
import SignUpScreen from '../screens/auth/SignUpScreen';
import SignInScreen from '../screens/auth/SignInScreen';
import OnboardingScreen from '../screens/auth/OnboardingScreen';

// Dashboard Screens
import Dashboard from '../screens/dashboards/Dashboard';
import FarmerDashboardScreen from '../screens/dashboards/FarmerDashboardScreen';
import ConsumerDashboardScreen from '../screens/dashboards/ConsumerDashboardScreen';
import AdminDashboardScreen from '../screens/dashboards/AdminDashboardScreen';

// Feature Screens
import HomeScreen from '../screens/main/HomeScreen';
import ECommerceScreen from '../screens/features/ecom/ECommerceScreen';
import CartScreen from '../screens/features/ecom/CartScreen';
import WeatherForecastScreen from '../screens/features/WeatherForecastScreen';
import LandLeaseScreen from '../screens/features/landLease/LandLeaseScreen';
import LandLeaseDetailsScreen from '../screens/features/landLease/LandLeaseDetailsScreen';
import FertilizerRecommendationScreen from '../screens/features/FertilizerRecommendationScreen';
import AppSettingsScreen from '../screens/features/AppSettingsScreen';
import FertilizerManagementScreen from '../screens/features/adminManage/FertilizerManagementScreen';
import UserManagementScreen from '../screens/features/adminManage/UserManagementScreen';
import SystemPaymentAccountsScreen from '../screens/features/adminManage/SystemPaymentAccountsScreen';
import VaultManagementScreen from '../screens/dashboards/VaultManagementScreen';
import ProductManagementScreen from '../screens/features/ecom/ProductManagementScreen';
import LandLeaseManagementScreen from '../screens/features/landLease/LandLeaseManagementScreen';
import InventoryManagementScreen from '../screens/features/ecom/InventoryManagementScreen';
import MyOrdersScreen from '../screens/features/ecom/MyOrdersScreen';
import OrdersManagementScreen from '../screens/features/ecom/OrdersManagementScreen';
import PaymentScreen from '../screens/features/ecom/PaymentScreen';
import WalletScreen from '../screens/features/ecom/WalletScreen';
import MarketAnalysisScreen from '../screens/features/ecom/MarketAnalysisScreen';
import ProductDetailsScreen from '../screens/features/ecom/ProductDetailsScreen';
import FollowingListScreen from '../screens/features/social/FollowingListScreen';
import FollowersListScreen from '../screens/features/social/FollowersListScreen';
import ChatListScreen from '../screens/features/social/ChatListScreen';
import ChatRoomScreen from '../screens/features/social/ChatRoomScreen';
import BrowseFarmersScreen from '../screens/features/social/BrowseFarmersScreen';
import BrowseConsumersScreen from '../screens/features/social/BrowseConsumersScreen';
import FarmersToConsumersScreen from '../screens/features/social/FarmersToConsumersScreen';
import LeaseApplicationsScreen from '../screens/features/landLease/LeaseApplicationsScreen';
import MyContractsScreen from '../screens/features/landLease/MyContractsScreen';
import ContractDetailsScreen from '../screens/features/landLease/ContractDetailsScreen';
import UserProfileScreen from '../screens/features/UserProfileScreen';

import { RootStackParamList } from '../types';

const Stack = createStackNavigator<RootStackParamList>();

const AuthNavigator = () => (
  <Stack.Navigator
    initialRouteName="Welcome"
    screenOptions={{ headerShown: false }}
  >
    <Stack.Screen name="Welcome" component={WelcomeScreen} />
    <Stack.Screen name="Menu" component={HomeScreen} />
    <Stack.Screen name="SignUp" component={SignUpScreen} />
    <Stack.Screen name="SignIn" component={SignInScreen} />
    <Stack.Screen
      name="FertilizerRecommendation"
      component={FertilizerRecommendationScreen}
    />
    <Stack.Screen name="WeatherForecast" component={WeatherForecastScreen} />
    <Stack.Screen name="LandLease" component={LandLeaseScreen} />
    <Stack.Screen name="ECommerce" component={ECommerceScreen} />
  </Stack.Navigator>
);

const OnboardingNavigator = () => (
  <Stack.Navigator
    initialRouteName="Onboarding"
    screenOptions={{ headerShown: false }}
  >
    <Stack.Screen name="Onboarding" component={OnboardingScreen} />
    <Stack.Screen name="SignUp" component={SignUpScreen} />
    <Stack.Screen name="SignIn" component={SignInScreen} />
  </Stack.Navigator>
);

const MainNavigator = () => (
  <Stack.Navigator
    initialRouteName="Dashboard"
    screenOptions={{ headerShown: false }}
  >
    <Stack.Screen name="SignUp" component={SignUpScreen} />
    <Stack.Screen name="SignIn" component={SignInScreen} />
    <Stack.Screen name="Dashboard" component={Dashboard} />
    <Stack.Screen name="ECommerce" component={ECommerceScreen} />
    <Stack.Screen name="Cart" component={CartScreen} />
    <Stack.Screen name="MyOrders" component={MyOrdersScreen} />
    <Stack.Screen name="OrdersManagement" component={OrdersManagementScreen} />
    <Stack.Screen name="Payment" component={PaymentScreen} />
    <Stack.Screen name="Wallet" component={WalletScreen} />
    <Stack.Screen name="MarketAnalysis" component={MarketAnalysisScreen} />
    <Stack.Screen name="FarmerDashboard" component={FarmerDashboardScreen} />
    <Stack.Screen
      name="ConsumerDashboard"
      component={ConsumerDashboardScreen}
    />
    <Stack.Screen name="WeatherForecast" component={WeatherForecastScreen} />
    <Stack.Screen name="LandLease" component={LandLeaseScreen} />
    <Stack.Screen name="LandLeaseDetails" component={LandLeaseDetailsScreen} />
    <Stack.Screen
      name="FertilizerRecommendation"
      component={FertilizerRecommendationScreen}
    />
    <Stack.Screen name="AdminDashboard" component={AdminDashboardScreen} />
    <Stack.Screen
      name="FertilizerManagement"
      component={FertilizerManagementScreen}
    />
    <Stack.Screen name="UserManagement" component={UserManagementScreen} />
    <Stack.Screen
      name="SystemPaymentAccounts"
      component={SystemPaymentAccountsScreen}
    />
    <Stack.Screen name="VaultManagement" component={VaultManagementScreen} />
    <Stack.Screen
      name="ProductManagement"
      component={ProductManagementScreen}
    />
    <Stack.Screen
      name="LandLeaseManagement"
      component={LandLeaseManagementScreen}
    />
    <Stack.Screen
      name="InventoryManagement"
      component={InventoryManagementScreen}
    />
    <Stack.Screen name="ProductDetails" component={ProductDetailsScreen} />
    <Stack.Screen name="FollowingList" component={FollowingListScreen} />
    <Stack.Screen name="FollowersList" component={FollowersListScreen} />
    <Stack.Screen name="ChatList" component={ChatListScreen} />
    <Stack.Screen name="ChatRoom" component={ChatRoomScreen} />
    <Stack.Screen name="BrowseFarmers" component={BrowseFarmersScreen} />
    <Stack.Screen name="BrowseConsumers" component={BrowseConsumersScreen} />
    <Stack.Screen
      name="FarmersToConsumers"
      component={FarmersToConsumersScreen}
    />
    <Stack.Screen
      name="LeaseApplicationList"
      component={LeaseApplicationsScreen}
    />

    <Stack.Screen name="UserProfile" component={UserProfileScreen} />
    <Stack.Screen name="MyContracts" component={MyContractsScreen} />
    <Stack.Screen name="ContractDetails" component={ContractDetailsScreen} />
    <Stack.Screen name="AppSettings" component={AppSettingsScreen} />
    <Stack.Screen name="Menu" component={HomeScreen} />
    <Stack.Screen name="Welcome" component={WelcomeScreen} />
  </Stack.Navigator>
);

const AppNavigator = () => {
  const { isLoading, isAuthenticated, needsOnboarding } = useAuth();

  console.log('🧭 AuthAwareNavigator state:', {
    isLoading,
    isAuthenticated,
    needsOnboarding,
  });

  if (isLoading) {
    console.log('🧭 Showing loading screen');
    return <ModernLoading visible={true} message="Loading..." />;
  }

  return (
    <NavigationContainer>
      {!isAuthenticated ? (
        <>
          {console.log('🧭 User not authenticated - showing AuthNavigator')}
          <AuthNavigator />
        </>
      ) : needsOnboarding ? (
        <>
          {console.log(
            '🧭 User authenticated but needs onboarding - showing OnboardingNavigator',
          )}
          <OnboardingNavigator />
        </>
      ) : (
        <>
          {console.log(
            '🧭 User authenticated and onboarded - showing MainNavigator',
          )}
          <MainNavigator />
        </>
      )}
    </NavigationContainer>
  );
};

export default AppNavigator;
