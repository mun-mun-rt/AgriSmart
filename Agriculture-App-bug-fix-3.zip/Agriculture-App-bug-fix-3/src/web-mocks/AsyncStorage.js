// Web fallback for AsyncStorage
const AsyncStorage = {
  getItem: (key) => {
    return Promise.resolve(localStorage.getItem(key));
  },
  setItem: (key, value) => {
    return Promise.resolve(localStorage.setItem(key, value));
  },
  removeItem: (key) => {
    return Promise.resolve(localStorage.removeItem(key));
  },
  clear: () => {
    return Promise.resolve(localStorage.clear());
  },
  getAllKeys: () => {
    return Promise.resolve(Object.keys(localStorage));
  }
};

export default AsyncStorage;
