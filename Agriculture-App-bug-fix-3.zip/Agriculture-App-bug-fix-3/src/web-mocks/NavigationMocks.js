// Web fallback for React Navigation components that don't work on web
import React from 'react';

export const MaskedView = ({ children, ...props }) => {
  return React.createElement('div', props, children);
};

export const GestureHandler = ({ children, ...props }) => {
  return React.createElement('div', props, children);
};

export default {
  MaskedView,
  GestureHandler
};
