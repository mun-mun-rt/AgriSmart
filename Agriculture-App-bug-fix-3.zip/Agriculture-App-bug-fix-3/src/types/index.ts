// Clean, simplified interfaces matching the database schema
export interface User {
  id?: number;
  name: string;
  email?: string; // Contact email (can be different from auth email)
  phone?: string;
  password?: string;
  role?: 'guest' | 'farmer' | 'consumer' | 'admin';

  // Address Information
  address_line1?: string;
  address_line2?: string;
  city?: string;
  state?: string;
  postal_code?: string;
  country?: string;

  // Profile Information
  date_of_birth?: string;
  gender?: 'male' | 'female' | 'other';
  profile_image_url?: string;
  bio?: string;

  // Professional Information (for farmers)
  farm_name?: string;
  farm_size?: number;
  farming_experience?: number;
  specialization?: string;

  // Mobile banking payout information (captured during onboarding)
  mobile_banking_bkash?: string | null;
  mobile_banking_nagad?: string | null;
  mobile_banking_rocket?: string | null;

  // System fields
  is_active?: boolean;
  wallet_balance?: number;
  onboarding_completed?: boolean;
  created_at?: string;
}

export interface Product {
  id?: number;
  farmer_id: number;
  name: string;
  description?: string;
  price: number;
  quantity: number;
  stock?: number;
  unit: string;
  category: string;
  category_id?: number;
  image_url?: string;
  delivery_fee?: number;
  min_purchase_quantity?: number;
  max_purchase_quantity?: number | null;
  created_at?: string;
  updated_at?: string;
  farmer_name?: string; // For joined queries
}

// Snapshot of a product captured at order/application time to preserve historical data
export interface ProductSnapshot {
  id?: number;
  name?: string;
  description?: string;
  price?: number;
  unit?: string;
  image_url?: string;
  farmer_name?: string;
}

export interface ProductCategory {
  id?: number;
  name: string;
  description?: string;
  icon?: string;
  created_at?: string;
}

export interface Order {
  id?: number;
  user_id: number;
  product_id: number;
  quantity: number;
  total_price: number;
  status: string;
  payment_method_key?: string;
  created_at?: string;

  // Product snapshot fields (stored at order creation)
  product_name?: string;
  product_description?: string;
  product_price?: number;
  product_unit?: string;
  product_category?: string;
  product_image_url?: string;
  // Snapshot of product delivery fee
  product_delivery_fee?: number;

  // Additional flags for handling deleted products
  productDeleted?: boolean;
}

export type PaymentMethodKey = 'cod' | 'bank' | 'mobile-banking' | 'wallet';

export interface SystemPaymentAccount {
  id: string;
  method: 'bank' | 'mobile_banking';
  provider?: string | null;
  label: string;
  account_name?: string | null;
  account_number: string;
  bank_name?: string | null;
  branch_name?: string | null;
  instructions?: string | null;
  is_primary?: boolean;
  is_active?: boolean;
  updated_by?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface SystemVaultTransaction {
  id?: number;
  owner_id: string;
  order_id: number;
  amount: number;
  payment_method: string;
  status?: 'pending' | 'released' | 'refunded' | 'cancelled';
  notes?: string | null;
  released_at?: string | null;
  created_at?: string;
  updated_at?: string;
}

export interface SystemVaultBalance {
  owner_id: string;
  pending_amount: number;
  released_amount: number;
  currency: string;
  updated_at?: string;
}

export interface Lease {
  id?: number;
  owner_id: number;
  title: string;
  description?: string;
  price: number;
  duration: number;
  location: string;
  status: string;
  created_at?: string;
}

// Snapshot of a lease captured at application/contract time to preserve historical state
export interface LeaseSnapshot {
  id?: number;
  title?: string;
  description?: string;
  price?: number;
  duration?: number;
  location?: string;
  image_url?: string;
  owner_id?: number;
}

export interface LeaseApplication {
  id?: number;
  lease_id: number;
  applicant_id: string;
  owner_id: string;
  offered_price?: number;
  message?: string;
  status: string;
  created_at?: string;

  // Lease snapshot fields (stored at application creation)
  lease_title?: string;
  lease_description?: string;
  lease_location?: string;
  lease_price?: number;
  lease_duration?: number;
  lease_area?: number;
  lease_soil_type?: string;
  lease_water_source?: string;
  lease_crop_suitability?: string;
  lease_distance?: number;
  lease_rating?: number;
  lease_image_url?: string;

  // Additional flags for handling deleted leases
  leaseDeleted?: boolean;
}

export interface LeaseContract {
  id?: number;
  lease_id: number;
  tenant_id: number;
  owner_id: number;
  contract_amount: number;
  start_date: string;
  end_date: string;
  terms?: string;
  status: 'active' | 'completed' | 'terminated' | 'expired';
  signed_date?: string;
  created_at?: string;

  // Lease snapshot fields (stored at contract creation)
  lease_title?: string;
  lease_description?: string;
  lease_location?: string;
  lease_area?: number;
  lease_soil_type?: string;
  lease_water_source?: string;
  lease_crop_suitability?: string;
  lease_distance?: number;
  lease_rating?: number;
  lease_image_url?: string;

  // Joined fields for display (backward compatibility)
  tenant_name?: string;
  tenant_email?: string;
  owner_name?: string;
  owner_email?: string;
  location?: string; // alias for lease_location
  description?: string; // alias for lease_description

  // Additional flags for handling deleted leases
  leaseDeleted?: boolean;
}
export interface ShoppingCartItem {
  id?: number;
  user_id: number;
  product_id: number;
  quantity: number;
  created_at?: string;
  updated_at?: string;

  // Product snapshot fields (stored when added to cart)
  product_name?: string;
  product_description?: string;
  product_price?: number;
  product_unit?: string;
  product_category?: string;
  product_image_url?: string;
  // Snapshot of product delivery fee
  product_delivery_fee?: number;
  product_min_purchase_quantity?: number | null;
  product_max_purchase_quantity?: number | null;

  // Additional display fields
  farmer_id?: string | null;
  farmer_name?: string;
  // Current available stock for the product (optional)
  product_stock?: number;

  // Additional flags for handling deleted products
  productDeleted?: boolean;
}

export interface WalletTransaction {
  id?: number;
  user_id: number;
  amount: number;
  transaction_type:
    | 'deposit'
    | 'withdrawal'
    | 'payment'
    | 'refund'
    | 'payment_received';
  description?: string;
  related_order_id?: number;
  created_at?: string;
}

export interface FertilizerGuide {
  id?: number;
  crop_name: string;
  fertilizer_type: string;
  amount: string;
  timing: string;
  instructions?: string;
  created_at?: string;
  related_products?: Product[];
}

export interface FertilizerGuideProduct {
  id?: number;
  fertilizer_guide_id: number;
  product_id: number;
  created_at?: string;
}

export interface WeatherCache {
  id?: number;
  location: string;
  temperature: number;
  humidity: number;
  description: string;
  expires_at: string;
  created_at?: string;
}

export interface Message {
  id?: number;
  sender_id: number;
  receiver_id: number;
  content: string;
  timestamp: string;
  created_at?: string;
}

export interface Follower {
  id?: number;
  user_id: number;
  follower_id: number;
  created_at?: string;
}

// Guest user interface
export interface GuestUser {
  id: string;
  name: string;
  role: 'guest';
}

// Auth and Sign Up interfaces
export interface SignUpData {
  name: string;
  email: string;
  password: string;
  confirmPassword?: string;
  role?: 'farmer' | 'consumer';
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  user?: User;
  token?: string;
}

// Navigation types
export type RootStackParamList = {
  Welcome: undefined;
  Menu: undefined;
  SignIn: undefined;
  SignUp: undefined;
  Onboarding: undefined;
  Dashboard: { role: 'farmer' | 'consumer' | 'admin' };
  FarmerDashboard: undefined;
  ConsumerDashboard: undefined;
  AdminDashboard: undefined;
  ECommerce: undefined;
  Cart: undefined;
  Orders: undefined;
  LandLease: undefined;
  LandLeaseDetails: {
    leaseId: string;
    fromMyLeases?: boolean;
    applicationId?: string;
  };
  LeaseApplication: { leaseId: number };
  LeaseApplicationList: undefined;
  LeaseContract: { contractId: number };
  MyContracts: undefined;
  CreateContract: { leaseId: number; applicantId: number };
  ContractDetails: { contractId: number };
  FertilizerManagement: undefined;
  FertilizerRecommendation: undefined;
  Weather: undefined;
  WeatherForecast: undefined;
  Chat: undefined;
  Social: undefined;
  Notifications: undefined;
  Profile: undefined;
  Settings: undefined;
  AppSettings: undefined;
  SystemPaymentAccounts: undefined;
  VaultManagement: undefined;
  Friends: undefined;
  Help: undefined;
  About: undefined;
  ContactUs: undefined;
  CropMonitoring: undefined;
  IrrigationManagement: undefined;
  PestManagement: undefined;
  ProductManagement: undefined;
  InventoryManagement: undefined;
  OrderManagement: undefined;
  LeaseManagement: undefined;
  LandLeaseManagement: undefined;
  MyApplications: undefined;
  MyOrders: undefined;
  MyLeases: undefined;
  MyProducts: undefined;
  OrdersManagement: undefined;
  Payment: undefined;
  Wallet: undefined;
  MarketAnalysis: undefined;
  UserManagement: undefined;
  ContentManagement: undefined;
  SystemSettings: undefined;
  Analytics: undefined;
  Reports: undefined;
  Marketplace: undefined;
  ProductDetails: { productId: number };
  FarmerProducts: { farmerId: string };
  FollowingList: undefined;
  FollowersList: undefined;
  OrderDetails: { orderId: number };
  LeaseDetails: { leaseId: number };
  UserProfile: { userId: string };
  VideoCall: { userId: string };
  ChatRoom: { roomId: string; otherUserId: string; otherUserName: string };
  ChatList: undefined;
  BrowseFarmers: undefined;
  BrowseConsumers: undefined;
  FarmersToConsumers: undefined;
  LanguageSettings: undefined;
  ThemeSettings: undefined;
  NotificationSettings: undefined;
  PrivacySettings: undefined;
  SecuritySettings: undefined;
  BackupSettings: undefined;
  DataManagement: undefined;
  AccountSettings: undefined;
  BillingSettings: undefined;
  SubscriptionSettings: undefined;
  RoleSelection: undefined;
};

// Bangladesh districts for location
export const BangladeshDistricts = [
  'Dhaka',
  'Chittagong',
  'Rajshahi',
  'Khulna',
  'Barishal',
  'Sylhet',
  'Rangpur',
  'Mymensingh',
  'Comilla',
  'Narayanganj',
  'Gazipur',
  'Tangail',
  'Bogra',
  'Pabna',
  'Sirajganj',
  'Kushtia',
  'Jessore',
  'Faridpur',
  'Manikganj',
  'Gopalganj',
  'Madaripur',
  'Shariatpur',
  'Rajbari',
  'Narsingdi',
  'Brahmanbaria',
  'Chandpur',
  'Lakshmipur',
  'Feni',
  'Noakhali',
  'Coxs Bazar',
  'Chittagong Hill Tracts',
  'Bandarban',
  'Rangamati',
  'Khagrachhari',
  'Patuakhali',
  'Pirojpur',
  'Jhalokati',
  'Barguna',
  'Bhola',
  'Habiganj',
  'Moulvibazar',
  'Sunamganj',
  'Dinajpur',
  'Thakurgaon',
  'Panchagarh',
  'Nilphamari',
  'Lalmonirhat',
  'Kurigram',
  'Gaibandha',
  'Jamalpur',
  'Sherpur',
  'Netrakona',
  'Kishoreganj',
  'Meherpur',
  'Narail',
  'Chuadanga',
  'Jhenaidah',
  'Magura',
  'Satkhira',
  'Bagerhat',
] as const;

export type BangladeshDistrict = (typeof BangladeshDistricts)[number];

// Crop types common in Bangladesh
export const BangladeshCrops = [
  'Rice',
  'Wheat',
  'Corn',
  'Jute',
  'Sugarcane',
  'Potato',
  'Sweet Potato',
  'Onion',
  'Garlic',
  'Ginger',
  'Turmeric',
  'Chili',
  'Tomato',
  'Eggplant',
  'Cabbage',
  'Cauliflower',
  'Spinach',
  'Lettuce',
  'Cucumber',
  'Pumpkin',
  'Watermelon',
  'Mango',
  'Jackfruit',
  'Banana',
  'Coconut',
  'Papaya',
  'Guava',
  'Lemon',
  'Orange',
  'Lychee',
  'Blackberry',
  'Strawberry',
  'Tea',
  'Tobacco',
  'Cotton',
  'Sesame',
  'Mustard',
  'Lentil',
  'Chickpea',
  'Black Gram',
  'Mung Bean',
  'Pigeon Pea',
  'Groundnut',
  'Soybean',
] as const;

export type BangladeshCrop = (typeof BangladeshCrops)[number];

export interface AppInfo {
  id?: number;
  app_name: string;
  app_logo_url?: string;
  welcome_message: string;
  contact_email: string;
  version: string;
  updated_at?: string;
}

// Status types
export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'shipped'
  | 'delivered'
  | 'cancelled';
export type LeaseStatus = 'available' | 'occupied' | 'pending' | 'expired';
export type ApplicationStatus =
  | 'pending'
  | 'approved'
  | 'rejected'
  | 'cancelled';
export type UserRole = 'guest' | 'farmer' | 'consumer' | 'admin';

// Common utility types
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface SearchParams {
  query?: string;
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  location?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

// Screen props helper types
export interface ScreenProps {
  navigation: any;
  route: any;
}

// Form validation types
export interface ValidationError {
  field: string;
  message: string;
}

export interface FormState<T> {
  data: T;
  errors: Partial<T>;
  isSubmitting: boolean;
  isValid: boolean;
}

// Common component props
export interface ButtonProps {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  loading?: boolean;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'small' | 'medium' | 'large';
  icon?: string;
}

export interface InputProps {
  label?: string;
  placeholder?: string;
  value: string;
  onChangeText: (text: string) => void;
  error?: string;
  disabled?: boolean;
  secureTextEntry?: boolean;
  multiline?: boolean;
  numberOfLines?: number;
  keyboardType?: 'default' | 'numeric' | 'email-address' | 'phone-pad';
}

export interface CardProps {
  title?: string;
  subtitle?: string;
  content?: string;
  image?: string;
  actions?: ButtonProps[];
  onPress?: () => void;
  style?: any;
}

export interface HeaderProps {
  title: string;
  subtitle?: string;
  leftAction?: () => void;
  rightAction?: () => void;
  leftIcon?: string;
  rightIcon?: string;
  showBack?: boolean;
}

export interface LoadingProps {
  visible: boolean;
  text?: string;
  overlay?: boolean;
}

export interface ModalProps {
  visible: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  animationType?: 'slide' | 'fade' | 'none';
  transparent?: boolean;
}

// App state types
export interface AppState {
  user: User | null;
  isAuthenticated: boolean;
  theme: 'light' | 'dark';
  language: 'en' | 'bn';
  loading: boolean;
  error: string | null;
}

// Notification types
export interface NotificationData {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  timestamp: string;
  read: boolean;
  data?: any;
}

// Bangladesh specific location types
export interface BangladeshLocation {
  division: string;
  district: string;
  upazila?: string;
  union?: string;
  village?: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
}

// Settings types
export interface AppSettings {
  theme: 'light' | 'dark' | 'auto';
  language: 'en' | 'bn';
  notifications: {
    enabled: boolean;
    sound: boolean;
    vibration: boolean;
    badges: boolean;
    inApp: boolean;
    push: boolean;
  };
  privacy: {
    analytics: boolean;
    crashReporting: boolean;
    locationSharing: boolean;
    contactSync: boolean;
  };
  display: {
    fontSize: 'small' | 'medium' | 'large';
    animations: boolean;
    reducedMotion: boolean;
  };
  backup: {
    enabled: boolean;
    frequency: 'daily' | 'weekly' | 'monthly';
    includeMedia: boolean;
  };
}

// Weather interface
export interface WeatherData {
  current: {
    temperature: number;
    condition: string;
    humidity: number;
    windSpeed: number;
    icon: string;
  };
  forecast: Array<{
    day: string;
    high: number;
    low: number;
    condition: string;
    icon: string;
    rainChance: number;
  }>;
}
