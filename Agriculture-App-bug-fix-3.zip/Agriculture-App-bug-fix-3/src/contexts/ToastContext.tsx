import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  Animated,
  Easing,
  Platform,
  StyleSheet,
  Text,
  View,
} from 'react-native';

export type ToastType = 'info' | 'success' | 'warning' | 'error';

interface ToastOptions {
  type?: ToastType;
  duration?: number;
}

interface ToastMessage extends ToastOptions {
  id: number;
  message: string;
}

interface ToastContextValue {
  showToast: (message: string, options?: ToastOptions) => void;
  hideToast: () => void;
}

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

const DEFAULT_DURATION = 3500;

export const ToastProvider: React.FC<React.PropsWithChildren> = ({
  children,
}) => {
  const [queue, setQueue] = useState<ToastMessage[]>([]);
  const [currentToast, setCurrentToast] = useState<ToastMessage | null>(null);
  const animation = useRef(new Animated.Value(0)).current;
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const isVisibleRef = useRef(false);

  useEffect(() => {
    if (!currentToast && queue.length > 0) {
      setCurrentToast(queue[0]);
      setQueue(prev => prev.slice(1));
    }
  }, [currentToast, queue]);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, []);

  const hideToast = useCallback(() => {
    if (!isVisibleRef.current) {
      return;
    }
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }

    Animated.timing(animation, {
      toValue: 0,
      duration: 200,
      easing: Easing.out(Easing.ease),
      useNativeDriver: true,
    }).start(() => {
      isVisibleRef.current = false;
      setCurrentToast(null);
    });
  }, [animation]);

  useEffect(() => {
    if (!currentToast) {
      return;
    }

    if (!isVisibleRef.current) {
      Animated.timing(animation, {
        toValue: 1,
        duration: 220,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      }).start(() => {
        isVisibleRef.current = true;
      });
    }

    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }

    timerRef.current = setTimeout(() => {
      hideToast();
    }, currentToast.duration ?? DEFAULT_DURATION);
  }, [animation, currentToast, hideToast]);

  const showToast = useCallback((message: string, options?: ToastOptions) => {
    setQueue(prev => [
      ...prev,
      {
        id: Date.now() + Math.floor(Math.random() * 1000),
        message,
        type: options?.type ?? 'info',
        duration: options?.duration ?? DEFAULT_DURATION,
      },
    ]);
  }, []);

  const contextValue = useMemo<ToastContextValue>(() => {
    return {
      showToast,
      hideToast,
    };
  }, [hideToast, showToast]);

  const translateY = animation.interpolate({
    inputRange: [0, 1],
    outputRange: [-80, 0],
  });

  const opacity = animation.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 1],
  });

  const backgroundColor = getToastColor(currentToast?.type ?? 'info');

  return (
    <ToastContext.Provider value={contextValue}>
      {children}
      {currentToast ? (
        <View pointerEvents="none" style={StyleSheet.absoluteFill}>
          <View style={styles.overlay}>
            <Animated.View
              style={[
                styles.toast,
                {
                  backgroundColor,
                  opacity,
                  transform: [{ translateY }],
                },
              ]}
            >
              <Text style={styles.toastText}>{currentToast.message}</Text>
            </Animated.View>
          </View>
        </View>
      ) : null}
    </ToastContext.Provider>
  );
};

export const useToast = (): ToastContextValue => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};

const getToastColor = (type: ToastType): string => {
  switch (type) {
    case 'success':
      return '#2E7D32';
    case 'warning':
      return '#F9A825';
    case 'error':
      return '#D32F2F';
    default:
      return '#1565C0';
  }
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  toast: {
    marginTop: Platform.select({ ios: 60, android: 40, default: 50 }),
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 14,
    minWidth: '60%',
    maxWidth: 420,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 6,
  },
  toastText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
});
