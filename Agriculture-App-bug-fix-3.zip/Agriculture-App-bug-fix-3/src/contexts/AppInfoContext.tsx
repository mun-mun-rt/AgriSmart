import React, {
  createContext,
  useState,
  useContext,
  useEffect,
  ReactNode,
} from 'react';
import { AppInfo } from '../types';
import SupabaseDatabaseManager from '../api/SupabaseDatabaseManager';

interface AppInfoContextType {
  appInfo: AppInfo;
  refreshAppInfo: () => Promise<void>;
  isLoading: boolean;
}

const defaultAppInfo: AppInfo = {
  app_name: 'AgriSmart Bangladesh',
  app_logo_url: '', // Will use local fallback logo when empty
  welcome_message: 'Welcome to AgriSmart Bangladesh',
  contact_email: 'support@AgriSmart.bd',
  version: '1.0.0',
};

const AppInfoContext = createContext<AppInfoContextType>({
  appInfo: defaultAppInfo,
  refreshAppInfo: async () => {},
  isLoading: true,
});

export const useAppInfo = () => useContext(AppInfoContext);

interface AppInfoProviderProps {
  children: ReactNode;
}

export const AppInfoProvider: React.FC<AppInfoProviderProps> = ({
  children,
}) => {
  const [appInfo, setAppInfo] = useState<AppInfo>(defaultAppInfo);
  const [isLoading, setIsLoading] = useState(true);

  const loadAppInfo = async () => {
    try {
      setIsLoading(true);
      const dbManager = SupabaseDatabaseManager.getInstance();

      // get app info from database with proper error handling and timeout
      let appInfoFromDb = null;
      try {
        // Add timeout to prevent hanging if database is not ready
        const dbPromise = (dbManager as any).getAppInfo();
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Database timeout')), 5000),
        );

        appInfoFromDb = await Promise.race([dbPromise, timeoutPromise]);
      } catch (dbError: any) {
        console.warn(
          'Database error when loading app info:',
          dbError?.message || dbError,
        );

        // Check if it's a table not found error or similar database structure error
        const errorMessage = dbError?.message || '';
        if (
          errorMessage.includes('no such table') ||
          errorMessage.includes('table') ||
          errorMessage.includes('SQL') ||
          errorMessage.includes('database') ||
          errorMessage.includes('timeout')
        ) {
          console.log(
            'AppInfo table not found, database not ready, or timeout - using default data',
          );
        }

        // Don't throw here, just use null and fall back to default
        appInfoFromDb = null;
      }

      if (appInfoFromDb && appInfoFromDb.app_name) {
        console.log(
          'AppInfoContext loaded app info from database:',
          appInfoFromDb,
        );
        setAppInfo(appInfoFromDb);
      } else {
        console.log(
          'AppInfoContext using default app info (no data from database)',
        );
        setAppInfo(defaultAppInfo);
      }
    } catch (error) {
      console.error('Error in AppInfoContext loadAppInfo:', error);
      // Always fall back to default app info on any error
      console.log(
        'AppInfoContext falling back to default app info due to error',
      );
      setAppInfo(defaultAppInfo);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Load app info with error handling
    const initializeAppInfo = async () => {
      try {
        await loadAppInfo();
      } catch (error) {
        console.error('Failed to initialize app info:', error);
        // Ensure we have fallback data even if initialization fails
        setAppInfo(defaultAppInfo);
        setIsLoading(false);
      }
    };

    initializeAppInfo();
  }, []);

  const refreshAppInfo = async () => {
    try {
      await loadAppInfo();
    } catch (error) {
      console.error('Error refreshing app info:', error);
      // Ensure we always have default data even if refresh fails
      setAppInfo(defaultAppInfo);
      setIsLoading(false);
    }
  };

  return (
    <AppInfoContext.Provider value={{ appInfo, refreshAppInfo, isLoading }}>
      {children}
    </AppInfoContext.Provider>
  );
};

export default AppInfoContext;
