import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  ReactNode,
} from 'react';
import { Alert } from 'react-native';
import SupabaseAuthManager from '../api/SupabaseAuthManager';
import { User } from '../types';

interface AuthContextType {
  // Auth state
  isLoading: boolean;
  isAuthenticated: boolean;
  authUser: any; // Supabase auth user
  profileUser: User | null; // Our app user profile

  // Auth actions
  signIn: (
    email: string,
    password: string,
  ) => Promise<{ success: boolean; error?: string; user?: User }>;
  signUp: (
    name: string,
    email: string,
    password: string,
  ) => Promise<{ success: boolean; error?: string }>;
  signOut: () => Promise<void>;
  updateProfile: (profileData: Partial<User>) => Promise<boolean>;
  refreshUser: () => Promise<void>;

  // Onboarding state
  needsOnboarding: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const authManager = SupabaseAuthManager.getInstance();

  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authUser, setAuthUser] = useState<any>(null);
  const [profileUser, setProfileUser] = useState<User | null>(null);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);

  // Check if user needs onboarding
  const checkOnboardingStatus = (profile: User | null): boolean => {
    if (!profile) {
      console.log('No profile found - needs onboarding');
      return true; // No profile = needs onboarding
    }

    // Check if user has completed onboarding
    const hasRole = profile.role && profile.role !== 'guest';
    const onboardingCompleted = profile.onboarding_completed === true;
    const hasRequiredFields =
      profile.phone && profile.address_line1 && profile.city && profile.state;

    console.log('Onboarding check:', {
      hasRole,
      onboardingCompleted,
      hasRequiredFields,
      role: profile.role,
      onboarding_completed: profile.onboarding_completed,
    });

    // User needs onboarding if they don't have a role, onboarding isn't completed, or missing required fields
    const needsOnboarding =
      !hasRole || !onboardingCompleted || !hasRequiredFields;

    console.log('User needs onboarding:', needsOnboarding);
    return needsOnboarding;
  };

  // Load user session on app start
  useEffect(() => {
    loadUserSession();
  }, []);

  const loadUserSession = async () => {
    try {
      setIsLoading(true);

      // Check if there's an active auth session
      const session = await authManager.getSession();

      if (session?.user) {
        setAuthUser(session.user);
        setIsAuthenticated(true);

        // Try to load profile from public.users
        try {
          const profile = await authManager.getCurrentUser(true); // Force fresh data on app start
          console.log('Profile loaded on app start:', profile);
          setProfileUser(profile);
          setNeedsOnboarding(checkOnboardingStatus(profile));
        } catch (profileError) {
          console.log('No profile found, user needs onboarding');
          setProfileUser(null);
          setNeedsOnboarding(true);
        }
      } else {
        // No active session
        console.log('No active session found');
        setIsAuthenticated(false);
        setAuthUser(null);
        setProfileUser(null);
        setNeedsOnboarding(false);
      }
    } catch (error) {
      console.error('Error loading user session:', error);
      setIsAuthenticated(false);
      setAuthUser(null);
      setProfileUser(null);
      setNeedsOnboarding(false);
    } finally {
      setIsLoading(false);
    }
  };

  const signIn = async (
    email: string,
    password: string,
  ): Promise<{ success: boolean; error?: string; user?: User }> => {
    try {
      // Don't set global loading state during sign in attempts
      // Let the UI components handle their own loading states

      const response = await authManager.signIn({ email, password });

      if (response.success && response.user) {
        // Set auth state based on successful auth.users login
        setIsAuthenticated(true);

        // Extract auth user info from the session
        const session = await authManager.getSession();
        setAuthUser(session?.user);

        // Set profile user - may be null if profile doesn't exist yet
        setProfileUser(response.user);
        setNeedsOnboarding(checkOnboardingStatus(response.user));

        return { success: true, user: response.user };
      } else {
        // Don't change auth state on failed login - keep current state
        // Don't show alert - let the calling component handle the error
        return { success: false, error: response.message || 'Sign in failed' };
      }
    } catch (error) {
      console.error('Sign in error:', error);
      // Don't change auth state on error - keep current state
      return { success: false, error: 'Something went wrong during sign in' };
    }
    // Don't modify global loading state here
  };

  const signUp = async (
    name: string,
    email: string,
    password: string,
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      // Don't set global loading state during sign up attempts
      // Let the UI components handle their own loading states

      const response = await authManager.signUp({ name, email, password });

      if (response.success) {
        // After successful signup, user should be logged in automatically
        // but they'll need onboarding
        await loadUserSession(); // Reload session to get the auth user
        return { success: true };
      } else {
        return { success: false, error: response.message || 'Sign up failed' };
      }
    } catch (error) {
      console.error('Sign up error:', error);
      return { success: false, error: 'Something went wrong during sign up' };
    }
    // Don't modify global loading state here
  };

  const signOut = async (): Promise<void> => {
    try {
      await authManager.signOut();
      setIsAuthenticated(false);
      setAuthUser(null);
      setProfileUser(null);
      setNeedsOnboarding(false);
    } catch (error) {
      console.error('Sign out error:', error);
      Alert.alert('Error', 'Failed to sign out');
    }
  };

  const updateProfile = async (
    profileData: Partial<User>,
  ): Promise<boolean> => {
    try {
      setIsLoading(true);
      console.log('Updating profile with data:', profileData);

      const response = await authManager.updateProfile(profileData);

      if (response.success) {
        console.log('Profile update successful, refreshing user...');
        // Refresh user profile
        await refreshUser();
        console.log('User refreshed after profile update');
        return true;
      } else {
        console.error('Profile update failed:', response.message);
        Alert.alert('Update Failed', response.message);
        return false;
      }
    } catch (error) {
      console.error('Profile update error:', error);
      Alert.alert('Error', 'Failed to update profile');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const refreshUser = async (): Promise<void> => {
    try {
      // get the current user with fresh data from Supabase
      const profile = await authManager.getCurrentUser(true); // Force fresh data

      // Check if we have a valid session
      const session = await authManager.getSession();

      if (session?.user && profile) {
        // User is authenticated and has a profile
        console.log('User authenticated with profile:', {
          role: profile.role,
          onboarding_completed: profile.onboarding_completed,
        });
        setIsAuthenticated(true);
        setAuthUser(session.user);
        setProfileUser(profile);
        setNeedsOnboarding(checkOnboardingStatus(profile));
      } else if (session?.user && !profile) {
        // User is authenticated but no profile (needs onboarding)
        console.log('User authenticated but no profile - needs onboarding');
        setIsAuthenticated(true);
        setAuthUser(session.user);
        setProfileUser(null);
        setNeedsOnboarding(true);
      } else {
        // No valid session
        console.log('No valid session found');
        setIsAuthenticated(false);
        setAuthUser(null);
        setProfileUser(null);
        setNeedsOnboarding(false);
      }
    } catch (error) {
      console.error('Error refreshing user:', error);
      // On error, check session to determine auth state
      try {
        const session = await authManager.getSession();
        if (!session?.user) {
          setIsAuthenticated(false);
          setAuthUser(null);
          setProfileUser(null);
          setNeedsOnboarding(false);
        }
      } catch (sessionError) {
        console.error('Error checking session:', sessionError);
        setIsAuthenticated(false);
        setAuthUser(null);
        setProfileUser(null);
        setNeedsOnboarding(false);
      }
    }
  };

  const contextValue: AuthContextType = {
    isLoading,
    isAuthenticated,
    authUser,
    profileUser,
    signIn,
    signUp,
    signOut,
    updateProfile,
    refreshUser,
    needsOnboarding,
  };

  return (
    <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
