import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { AppState, AppStateStatus } from 'react-native';
import { RealtimeChannel } from '@supabase/supabase-js';
import SupabaseDatabaseManager from '../api/SupabaseDatabaseManager';
import { supabase } from '../utils/supabase';
import { useAuth } from './AuthContext';

interface MessageNotificationContextValue {
  hasUnread: boolean;
  unreadRooms: string[];
  registerUnread: (roomId: string) => Promise<void>;
  markRoomRead: (roomId: string) => Promise<void>;
  setActiveRoom: (roomId: string | null) => void;
  activeRoomId: string | null;
  refreshUnread: () => Promise<void>;
}

const MessageNotificationContext = createContext<
  MessageNotificationContextValue | undefined
>(undefined);

export const MessageNotificationProvider: React.FC<React.PropsWithChildren> = ({
  children,
}) => {
  const { authUser } = useAuth();
  const [unreadRooms, setUnreadRooms] = useState<string[]>([]);
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const dbManagerRef = useRef(SupabaseDatabaseManager.getInstance());
  const subscriptionRef = useRef<RealtimeChannel | null>(null);
  const refreshTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const optimisticUnreadRef = useRef<Map<string, number>>(new Map());

  const OPTIMISTIC_UNREAD_TTL_MS = 5000;

  const refreshUnread = useCallback(async () => {
    const userId = authUser?.id ? String(authUser.id) : null;
    if (!userId) {
      setUnreadRooms([]);
      optimisticUnreadRef.current.clear();
      return;
    }

    const unreadStates = await dbManagerRef.current.getUnreadRoomStatuses(
      userId,
    );
    const roomsWithUnread = unreadStates
      .filter(state => (state.unread_count ?? 0) > 0)
      .map(state => state.room_id);
    const serverRoomSet = new Set(roomsWithUnread);
    const now = Date.now();

    optimisticUnreadRef.current.forEach((timestamp, roomId) => {
      if (serverRoomSet.has(roomId)) {
        optimisticUnreadRef.current.delete(roomId);
        return;
      }

      if (now - timestamp < OPTIMISTIC_UNREAD_TTL_MS) {
        serverRoomSet.add(roomId);
      } else {
        optimisticUnreadRef.current.delete(roomId);
      }
    });

    setUnreadRooms(Array.from(serverRoomSet));
  }, [authUser?.id]);

  useEffect(() => {
    refreshUnread().catch(error => {
      console.warn('MessageNotificationProvider: refresh failed', error);
    });
    setActiveRoomId(null);
  }, [refreshUnread]);

  useEffect(() => {
    const userId = authUser?.id ? String(authUser.id) : null;

    if (!userId) {
      if (subscriptionRef.current) {
        supabase.removeChannel(subscriptionRef.current);
        subscriptionRef.current = null;
      }
      return;
    }

    if (subscriptionRef.current) {
      supabase.removeChannel(subscriptionRef.current);
      subscriptionRef.current = null;
    }

    const channel = supabase.channel(`message-unread-counters-${userId}`);
    channel.on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'message_unread_counters',
        filter: `participant_id=eq.${userId}`,
      },
      () => {
        refreshUnread().catch(error => {
          console.warn(
            'MessageNotificationProvider: realtime refresh failed',
            error,
          );
        });
      },
    );

    channel.subscribe(status => {
      if (status === 'CHANNEL_ERROR') {
        console.warn('MessageNotificationProvider: channel error');
      }
    });

    subscriptionRef.current = channel;

    return () => {
      if (subscriptionRef.current) {
        supabase.removeChannel(subscriptionRef.current);
        subscriptionRef.current = null;
      }
    };
  }, [authUser?.id, refreshUnread]);

  const markRoomRead = useCallback(
    async (roomId: string) => {
      const userId = authUser?.id ? String(authUser.id) : null;
      if (!roomId || !userId) return;

      setUnreadRooms(prev => prev.filter(id => id !== roomId));
      optimisticUnreadRef.current.delete(roomId);

      try {
        await dbManagerRef.current.markRoomRead(roomId, userId);
      } catch (error) {
        console.warn('MessageNotificationProvider: markRoomRead error', error);
      } finally {
        refreshUnread().catch(err =>
          console.warn('MessageNotificationProvider: sync unread failed', err),
        );
      }
    },
    [authUser?.id, refreshUnread],
  );

  const registerUnread = useCallback(
    async (roomId: string) => {
      if (!roomId) return;
      if (roomId === activeRoomId) {
        await markRoomRead(roomId);
        return;
      }
      let added = false;
      setUnreadRooms(prev => {
        if (prev.includes(roomId)) {
          return prev;
        }
        added = true;
        return [...prev, roomId];
      });
      if (added) {
        optimisticUnreadRef.current.set(roomId, Date.now());
      }

      if (refreshTimeoutRef.current) {
        clearTimeout(refreshTimeoutRef.current);
      }
      refreshTimeoutRef.current = setTimeout(() => {
        refreshUnread().catch(error =>
          console.warn(
            'MessageNotificationProvider: register refresh failed',
            error,
          ),
        );
        refreshTimeoutRef.current = null;
      }, 400);
    },
    [activeRoomId, markRoomRead, refreshUnread],
  );

  const setActiveRoom = useCallback(
    (roomId: string | null) => {
      setActiveRoomId(roomId);
      if (roomId) {
        markRoomRead(roomId).catch(error => {
          console.warn(
            'MessageNotificationProvider: mark active room read failed',
            error,
          );
        });
      }
    },
    [markRoomRead],
  );

  const contextValue = useMemo<MessageNotificationContextValue>(
    () => ({
      hasUnread: unreadRooms.length > 0,
      unreadRooms,
      registerUnread,
      markRoomRead,
      setActiveRoom,
      activeRoomId,
      refreshUnread,
    }),
    [
      activeRoomId,
      markRoomRead,
      refreshUnread,
      registerUnread,
      setActiveRoom,
      unreadRooms,
    ],
  );

  useEffect(() => {
    const handleAppState = (nextState: AppStateStatus) => {
      if (nextState === 'active') {
        refreshUnread().catch(error =>
          console.warn(
            'MessageNotificationProvider: app active refresh failed',
            error,
          ),
        );
      }
    };

    const subscription = AppState.addEventListener('change', handleAppState);
    return () => {
      if (refreshTimeoutRef.current) {
        clearTimeout(refreshTimeoutRef.current);
        refreshTimeoutRef.current = null;
      }
      optimisticUnreadRef.current.clear();
      subscription.remove();
    };
  }, [refreshUnread]);

  return (
    <MessageNotificationContext.Provider value={contextValue}>
      {children}
    </MessageNotificationContext.Provider>
  );
};

export const useMessageNotifications = (): MessageNotificationContextValue => {
  const context = useContext(MessageNotificationContext);
  if (!context) {
    throw new Error(
      'useMessageNotifications must be used within a MessageNotificationProvider',
    );
  }
  return context;
};
