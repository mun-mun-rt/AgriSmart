import React, { useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ViewStyle,
  TextStyle,
} from 'react-native';
import MaterialIcon from 'react-native-vector-icons/MaterialIcons';

export interface ModernInputProps {
  label?: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  secureTextEntry?: boolean;
  keyboardType?: 'default' | 'email-address' | 'numeric' | 'phone-pad';
  multiline?: boolean;
  numberOfLines?: number;
  editable?: boolean;
  error?: string;
  helperText?: string;
  leftIcon?: string;
  rightIcon?: string;
  // New: vector icon name from MaterialIcons (e.g. 'visibility')
  rightIconName?: string;
  onRightIconPress?: () => void;
  rightIconColor?: string;
  rightIconSize?: number;
  style?: ViewStyle;
  inputStyle?: TextStyle;
  variant?: 'default' | 'outlined' | 'filled';
}

const ModernInput: React.FC<ModernInputProps> = ({
  label,
  value,
  onChangeText,
  placeholder,
  secureTextEntry = false,
  keyboardType = 'default',
  multiline = false,
  numberOfLines = 1,
  editable = true,
  error,
  helperText,
  leftIcon,
  rightIcon,
  rightIconName,
  onRightIconPress,
  rightIconColor,
  rightIconSize,
  style,
  inputStyle,
  variant = 'default',
}) => {
  // Ensure MaterialIcons font is loaded (fixes blank/unsupported icons at runtime)
  useEffect(() => {
    try {
      if (typeof (MaterialIcon as any)?.loadFont === 'function') {
        (MaterialIcon as any).loadFont();
      }
    } catch (e) {
      // ignore
    }
  }, []);
  const getInputContainerStyles = (): ViewStyle => {
    const baseStyles: ViewStyle = styles.inputContainer;

    if (error) {
      return { ...baseStyles, ...styles.errorContainer };
    }

    switch (variant) {
      case 'outlined':
        return { ...baseStyles, ...styles.outlinedContainer };
      case 'filled':
        return { ...baseStyles, ...styles.filledContainer };
      default:
        return { ...baseStyles, ...styles.defaultContainer };
    }
  };

  return (
    <View style={[styles.container, style]}>
      {label && <Text style={styles.label}>{label}</Text>}

      <View style={getInputContainerStyles()}>
        {leftIcon && (
          <View style={styles.leftIconContainer}>
            <Text style={styles.iconText}>{leftIcon}</Text>
          </View>
        )}

        <TextInput
          style={[styles.input, inputStyle]}
          value={value}
          onChangeText={onChangeText}
          placeholder={placeholder}
          placeholderTextColor="#9E9E9E"
          secureTextEntry={secureTextEntry}
          keyboardType={keyboardType}
          multiline={multiline}
          numberOfLines={numberOfLines}
          editable={editable}
          textAlignVertical={multiline ? 'top' : 'center'}
        />

        {rightIconName ? (
          <TouchableOpacity
            style={styles.rightIconContainer}
            onPress={onRightIconPress}
          >
            <MaterialIcon
              name={rightIconName}
              size={rightIconSize || 20}
              color={rightIconColor || '#757575'}
            />
          </TouchableOpacity>
        ) : rightIcon ? (
          <TouchableOpacity
            style={styles.rightIconContainer}
            onPress={onRightIconPress}
          >
            <Text style={styles.iconText}>{rightIcon}</Text>
          </TouchableOpacity>
        ) : null}
      </View>

      {error && <Text style={styles.errorText}>{error}</Text>}
      {helperText && !error && (
        <Text style={styles.helperText}>{helperText}</Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#212121',
    marginBottom: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFFFF',
  },
  defaultContainer: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  outlinedContainer: {
    borderWidth: 2,
    borderColor: '#4CAF50',
  },
  filledContainer: {
    backgroundColor: '#F5F5F5',
    borderWidth: 0,
  },
  errorContainer: {
    borderColor: '#F44336',
    borderWidth: 2,
  },
  input: {
    flex: 1,
    fontSize: 16,
    color: '#212121',
    padding: 0,
    margin: 0,
  },
  leftIconContainer: {
    marginRight: 12,
  },
  rightIconContainer: {
    marginLeft: 12,
  },
  iconText: {
    fontSize: 16,
    color: '#757575',
  },
  errorText: {
    fontSize: 14,
    color: '#F44336',
    marginTop: 4,
  },
  helperText: {
    fontSize: 14,
    color: '#757575',
    marginTop: 4,
  },
});

export default ModernInput;
