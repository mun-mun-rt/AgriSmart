import React from 'react';
import {
  View,
  Text,
  ActivityIndicator,
  StyleSheet,
  Modal,
  Dimensions,
} from 'react-native';

const { width } = Dimensions.get('window');

export interface ModernLoadingProps {
  visible: boolean;
  message?: string;
  overlay?: boolean;
  size?: 'small' | 'large';
  color?: string;
}

const ModernLoading: React.FC<ModernLoadingProps> = ({
  visible,
  message = 'Loading...',
  overlay = true,
  size = 'large',
  color = '#4CAF50',
}) => {
  if (!visible) return null;

  const content = (
    <View style={styles.container}>
      <View style={styles.loadingBox}>
        <ActivityIndicator size={size} color={color} />
        <Text style={styles.loadingText}>{message}</Text>
      </View>
    </View>
  );

  if (overlay) {
    return (
      <Modal
        transparent
        animationType="fade"
        visible={visible}
        statusBarTranslucent
      >
        {content}
      </Modal>
    );
  }

  return content;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  loadingBox: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    minWidth: width * 0.3,
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#212121',
    textAlign: 'center',
  },
});

export default ModernLoading;
