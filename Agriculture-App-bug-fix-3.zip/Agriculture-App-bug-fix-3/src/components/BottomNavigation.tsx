import React, { useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, User, GuestUser } from '../types/index';
import { useMessageNotifications } from '../contexts/MessageNotificationContext';

export interface BottomNavigationProps {
  user: User | GuestUser | null;
  activeTab?: 'home' | 'dashboard' | 'settings' | 'social' | 'chat';
}

interface NavItem {
  id: string;
  label: string;
  iconName: string;
  route: keyof RootStackParamList;
  requiresAuth: boolean;
  guestRoute?: keyof RootStackParamList;
}

const BottomNavigation: React.FC<BottomNavigationProps> = ({
  user,
  activeTab = 'home',
}) => {
  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
  const isGuest = user?.role === 'guest';
  const { hasUnread, refreshUnread } = useMessageNotifications();

  useEffect(() => {
    refreshUnread().catch(error =>
      console.warn('BottomNavigation: unread refresh failed', error),
    );
  }, [refreshUnread]);

  const navItems: NavItem[] = [
    {
      id: 'home',
      label: 'Home',
      iconName: 'home',
      route: 'Menu',
      requiresAuth: false,
    },
    {
      id: 'dashboard',
      label: 'Dashboard',
      iconName: 'view-dashboard',
      route: 'Dashboard',
      requiresAuth: true,
      guestRoute: 'SignIn',
    },
    // {
    //   id: 'social',
    //   label: 'Social',
    //   iconName: 'account-group',
    //   route: 'Social',
    //   requiresAuth: true,
    //   guestRoute: 'SignIn',
    // },
    {
      id: 'chat',
      label: 'Chat',
      iconName: 'message-text',
      route: 'ChatList',
      requiresAuth: true,
      guestRoute: 'SignIn',
    },
    {
      id: 'settings',
      label: 'Settings',
      iconName: 'cog',
      route: 'AppSettings',
      requiresAuth: true,
      guestRoute: 'SignIn',
    },
  ];

  const handleNavPress = (item: NavItem) => {
    if (
      item.requiresAuth &&
      (!user || user.role === 'guest') &&
      item.guestRoute
    ) {
      navigation.navigate(item.guestRoute as any);
    } else if (item.route === 'Dashboard' && user && user.role !== 'guest') {
      // Navigate to specific dashboard based on user role
      const role = user.role;
      if (role === 'farmer') {
        navigation.navigate('FarmerDashboard');
      } else if (role === 'consumer') {
        navigation.navigate('ConsumerDashboard');
      } else if (role === 'admin') {
        navigation.navigate('AdminDashboard');
      } else {
        // Fallback to generic dashboard with role parameter
        navigation.navigate('Dashboard', {
          role: (role || 'consumer') as 'farmer' | 'consumer' | 'admin',
        });
      }
    } else {
      navigation.navigate(item.route as any);
    }
  };

  const renderNavItem = (item: NavItem) => {
    const isActive = activeTab === item.id;
    const isDisabled = item.requiresAuth && isGuest;
    const showUnreadBadge = item.id === 'chat' && !isDisabled && hasUnread;

    return (
      <TouchableOpacity
        key={item.id}
        style={[
          styles.navItem,
          isActive && styles.activeNavItem,
          isDisabled && styles.disabledNavItem,
        ]}
        onPress={() => handleNavPress(item)}
        activeOpacity={0.7}
      >
        <View
          style={[
            styles.navIconContainer,
            isActive && styles.activeNavIconContainer,
          ]}
        >
          <MaterialCommunityIcons
            name={item.iconName}
            size={24}
            color={isActive ? '#4CAF50' : '#757575'}
          />
          {isDisabled && (
            <View style={styles.lockOverlay}>
              <MaterialCommunityIcons name="lock" size={12} color="#999" />
            </View>
          )}
          {showUnreadBadge && <View style={styles.unreadBadge} />}
        </View>
        <Text
          style={[
            styles.navLabel,
            isActive && styles.activeNavLabel,
            isDisabled && styles.disabledNavLabel,
          ]}
        >
          {item.label}
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.navigationBar}>{navItems.map(renderNavItem)}</View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: -2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 8,
  },
  navigationBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
    backgroundColor: '#FFFFFF',
  },
  navItem: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 4,
    borderRadius: 12,
    position: 'relative',
  },
  activeNavItem: {
    backgroundColor: '#E8F5E8',
  },
  disabledNavItem: {
    opacity: 0.6,
  },
  navIconContainer: {
    position: 'relative',
    marginBottom: 4,
  },
  activeNavIconContainer: {
    transform: [{ scale: 1.1 }],
  },
  unreadBadge: {
    position: 'absolute',
    top: -2,
    right: -6,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#FF3B30',
  },
  navIcon: {
    fontSize: 20,
    color: '#757575',
  },
  activeNavIcon: {
    color: '#2E7D32',
  },
  lockOverlay: {
    position: 'absolute',
    top: -2,
    right: -2,
    backgroundColor: '#FF9800',
    borderRadius: 8,
    width: 16,
    height: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  lockIcon: {
    fontSize: 10,
    color: '#FFFFFF',
  },
  navLabel: {
    fontSize: 11,
    color: '#757575',
    fontWeight: '500',
    textAlign: 'center',
    marginTop: 2,
  },
  activeNavLabel: {
    color: '#2E7D32',
    fontWeight: '600',
  },
  disabledNavLabel: {
    color: '#BDBDBD',
  },
});

export default BottomNavigation;
