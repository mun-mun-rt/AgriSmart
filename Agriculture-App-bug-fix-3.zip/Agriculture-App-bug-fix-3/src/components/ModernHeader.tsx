import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  TouchableOpacity,
  ViewStyle,
  Image,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

export interface ModernHeaderProps {
  title: string;
  subtitle?: string;
  leftIcon?: string;
  rightIcon?: string;
  rightAvatarUrl?: string;
  rightAvatarName?: string;
  onLeftPress?: () => void;
  onRightPress?: () => void;
  backgroundColor?: string;
  textColor?: string;
  style?: ViewStyle;
  variant?: 'default' | 'transparent' | 'gradient';
  leftIconName?: string;
  rightIconName?: string;
  leftIconColor?: string;
  rightIconColor?: string;
  iconSize?: number;
}

const ModernHeader: React.FC<ModernHeaderProps> = ({
  title,
  subtitle,
  leftIcon,
  rightIcon,
  rightAvatarUrl,
  rightAvatarName,
  onLeftPress,
  onRightPress,
  backgroundColor = '#FFFFFF',
  textColor = '#23272F',
  style,
  variant = 'default',
  leftIconName,
  rightIconName,
  leftIconColor,
  rightIconColor,
  iconSize = 20,
}) => {
  const getHeaderStyles = (): ViewStyle => {
    const baseStyles: ViewStyle = {
      ...styles.header,
      backgroundColor,
      borderBottomWidth: 1,
      borderBottomColor: '#F0F0F0',
    };
    switch (variant) {
      case 'transparent':
        return {
          ...baseStyles,
          backgroundColor: 'transparent',
          borderBottomWidth: 0,
        };
      case 'gradient':
        return {
          ...baseStyles,
          backgroundColor: '#4CAF50',
          borderBottomWidth: 0,
        };
      default:
        return baseStyles;
    }
  };

  const renderLeftContent = () => {
    if (leftIconName) {
      return (
        <TouchableOpacity
          style={styles.iconButton}
          onPress={onLeftPress}
          activeOpacity={0.7}
        >
          <MaterialCommunityIcons
            name={leftIconName}
            size={iconSize}
            color={leftIconColor ?? textColor}
          />
        </TouchableOpacity>
      );
    }

    if (leftIcon) {
      return (
        <TouchableOpacity
          style={styles.iconButton}
          onPress={onLeftPress}
          activeOpacity={0.7}
        >
          <Text style={[styles.iconText, { color: textColor }]}>
            {leftIcon}
          </Text>
        </TouchableOpacity>
      );
    }

    return null;
  };

  const renderRightContent = () => {
    if (rightAvatarUrl) {
      return (
        <TouchableOpacity
          style={[styles.iconButton, styles.avatarButton]}
          onPress={onRightPress}
          activeOpacity={0.8}
        >
          <Image source={{ uri: rightAvatarUrl }} style={styles.avatar} />
        </TouchableOpacity>
      );
    }

    if (rightAvatarName) {
      return (
        <TouchableOpacity
          style={[styles.iconButton, styles.avatarButton, styles.initialsBg]}
          onPress={onRightPress}
          activeOpacity={0.8}
        >
          <Text style={[styles.avatarInitials, { color: textColor }]}>
            {rightAvatarName
              .split(' ')
              .map(n => n.charAt(0))
              .slice(0, 2)
              .join('')
              .toUpperCase()}
          </Text>
        </TouchableOpacity>
      );
    }

    if (rightIconName) {
      return (
        <TouchableOpacity
          style={styles.iconButton}
          onPress={onRightPress}
          activeOpacity={0.7}
        >
          <MaterialCommunityIcons
            name={rightIconName}
            size={iconSize}
            color={rightIconColor ?? textColor}
          />
        </TouchableOpacity>
      );
    }

    if (rightIcon) {
      return (
        <TouchableOpacity
          style={styles.iconButton}
          onPress={onRightPress}
          activeOpacity={0.7}
        >
          <Text style={[styles.iconText, { color: textColor }]}>
            {rightIcon}
          </Text>
        </TouchableOpacity>
      );
    }

    return null;
  };

  return (
    <SafeAreaView style={[getHeaderStyles(), style]}>
      <StatusBar
        barStyle={variant === 'transparent' ? 'dark-content' : 'dark-content'}
        backgroundColor={backgroundColor}
      />
      <View style={styles.headerContent}>
        <View style={[styles.sideContainer, styles.sideContainerLeft]}>
          {renderLeftContent()}
        </View>

        <View style={styles.titleContainer}>
          <Text style={[styles.title, { color: textColor }]} numberOfLines={1}>
            {title}
          </Text>
          {subtitle && (
            <Text
              style={[styles.subtitle, { color: textColor }]}
              numberOfLines={1}
            >
              {subtitle}
            </Text>
          )}
        </View>

        <View style={[styles.sideContainer, styles.sideContainerRight]}>
          {renderRightContent()}
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  header: {
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 4,
    backgroundColor: '#FFFFFF',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 56,
  },
  sideContainer: {
    width: 44,
    minHeight: 36,
    justifyContent: 'center',
  },
  sideContainerLeft: {
    alignItems: 'flex-start',
  },
  sideContainerRight: {
    alignItems: 'flex-end',
  },
  iconButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
  },
  iconText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  avatarButton: {
    padding: 0,
    overflow: 'hidden',
  },
  initialsBg: {
    backgroundColor: '#E0E0E0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarInitials: {
    fontSize: 14,
    fontWeight: '700',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 0,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  subtitle: {
    fontSize: 14,
    opacity: 0.8,
    marginTop: 2,
  },
});

export default ModernHeader;
