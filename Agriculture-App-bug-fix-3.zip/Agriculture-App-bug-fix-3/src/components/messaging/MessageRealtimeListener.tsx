import { useEffect, useRef } from 'react';
import { RealtimeChannel } from '@supabase/supabase-js';
import SupabaseDatabaseManager from '../../api/SupabaseDatabaseManager';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { useMessageNotifications } from '../../contexts/MessageNotificationContext';
import { buildRoomId } from '../../utils';
import { supabase } from '../../utils/supabase';

interface MessageRow {
  id?: string | number;
  sender_id?: string | number;
  receiver_id?: string | number;
  content?: string | null;
  created_at?: string;
}

const MessageRealtimeListener: React.FC = () => {
  const { authUser } = useAuth();
  const { showToast } = useToast();
  const { registerUnread } = useMessageNotifications();
  const dbManagerRef = useRef(SupabaseDatabaseManager.getInstance());
  const channelRef = useRef<RealtimeChannel | null>(null);
  const isMountedRef = useRef(true);

  useEffect(() => {
    return () => {
      isMountedRef.current = false;
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const userId = authUser?.id ? String(authUser.id) : null;

    if (!userId) {
      if (channelRef.current) {
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
      return;
    }

    if (channelRef.current) {
      console.log('[MessageRealtimeListener] Removing existing channel');
      supabase.removeChannel(channelRef.current);
      channelRef.current = null;
    }

    console.log('[MessageRealtimeListener] Creating channel for user', userId);
    const channel = supabase.channel(`messages-inbox-${userId}`);

    channel.on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
      },
      payload => {
        console.log('[MessageRealtimeListener] payload received', payload);
        const newMessage = payload.new as MessageRow | null;
        if (!newMessage) {
          console.log('[MessageRealtimeListener] No new message in payload');
          return;
        }
        const receiverId = newMessage.receiver_id
          ? String(newMessage.receiver_id)
          : null;
        const senderId = newMessage.sender_id
          ? String(newMessage.sender_id)
          : null;

        if (!receiverId || receiverId !== userId) {
          console.log(
            '[MessageRealtimeListener] Skipping payload for receiver',
            receiverId,
          );
          return;
        }

        if (!senderId || senderId === userId) {
          console.log('[MessageRealtimeListener] Skipping self message');
          return;
        }

        const roomId = buildRoomId(userId, senderId);

        const rawSnippet = (newMessage.content ?? '').trim();
        const snippet =
          rawSnippet.length > 80 ? `${rawSnippet.slice(0, 77)}...` : rawSnippet;
        const fallbackMessage = snippet || 'Sent you a message';

        registerUnread(roomId).catch(err => {
          console.warn('MessageRealtimeListener: registerUnread failed', err);
        });

        (async () => {
          try {
            const senderName =
              (await dbManagerRef.current.getUserNameById(senderId)) ||
              'Someone';
            if (!isMountedRef.current) {
              return;
            }
            showToast(`New message from ${senderName}: ${fallbackMessage}`, {
              type: 'info',
              duration: 4000,
            });
          } catch (error) {
            console.warn('MessageRealtimeListener: toast error', error);
            if (!isMountedRef.current) {
              return;
            }
            showToast('New message received', {
              type: 'info',
              duration: 3000,
            });
          }
        })().catch(err => {
          console.warn('MessageRealtimeListener: async toast failed', err);
        });
      },
    );

    channel.subscribe(status => {
      console.log('[MessageRealtimeListener] Channel status', userId, status);
      if (status === 'CHANNEL_ERROR') {
        console.warn('MessageRealtimeListener: channel error', userId);
      }
      if (status === 'TIMED_OUT') {
        console.warn('MessageRealtimeListener: channel timed out', userId);
      }
      if (status === 'CLOSED') {
        console.warn('MessageRealtimeListener: channel closed', userId);
      }
    });

    channelRef.current = channel;

    return () => {
      if (channelRef.current) {
        console.log('[MessageRealtimeListener] Cleanup removing channel');
        supabase.removeChannel(channelRef.current);
        channelRef.current = null;
      }
    };
  }, [authUser?.id, registerUnread, showToast]);

  return null;
};

export default MessageRealtimeListener;
