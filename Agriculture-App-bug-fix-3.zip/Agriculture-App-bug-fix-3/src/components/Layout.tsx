import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Dimensions,
  Platform,
  Animated,
  Text,
} from 'react-native';
import { User, GuestUser } from '../types';
import SupabaseAuthManager from '../api/SupabaseAuthManager';
import BottomNavigation from './BottomNavigation';
// import ModernLoading from './ModernLoading';

interface LayoutProps {
  children: React.ReactNode;
  activeTab?: 'home' | 'dashboard' | 'settings' | 'social' | 'chat';
  showBottomNavigation?: boolean;
  backgroundColor?: string;
  barStyle?: 'default' | 'light-content' | 'dark-content';
}

const { width, height } = Dimensions.get('window');
const isTablet = width > 768;

const Layout: React.FC<LayoutProps> = ({
  children,
  activeTab = 'home',
  showBottomNavigation = true,
  backgroundColor = '#FFFFFF',
  barStyle = 'dark-content',
}) => {
  const [user, setUser] = useState<User | GuestUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    const authManager = SupabaseAuthManager.getInstance();
    const loadUser = async () => {
      try {
        const currentUser = await authManager.getCurrentUser();
        if (currentUser) {
          setUser(currentUser);
        } else {
          // Create guest user
          const guestUser: GuestUser = {
            id: 'guest_' + Date.now(),
            name: 'Guest User',
            role: 'guest',
          };
          setUser(guestUser);
        }
      } catch (error) {
        console.error('Error loading user:', error);
        // Create guest user as fallback
        const guestUser: GuestUser = {
          id: 'guest_' + Date.now(),
          name: 'Guest User',
          role: 'guest',
        };
        setUser(guestUser);
      } finally {
        setIsLoading(false);
      }
    };

    loadUser();
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }),
    ]).start();
  }, [fadeAnim, slideAnim]);

  const safeChildren = React.Children.map(children, child => {
    if (typeof child === 'string' || typeof child === 'number') {
      return <Text>{child}</Text>;
    }
    return child;
  });

  if (isLoading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor }]}>
        <StatusBar barStyle={barStyle} backgroundColor={backgroundColor} />
        {/* <ModernLoading visible={true} message="Loading..." /> */}
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor }]}>
      <StatusBar barStyle={barStyle} backgroundColor={backgroundColor} />
      {/* Subtle Background Elements */}
      <View style={styles.backgroundElements}>
        <View style={styles.circle1} />
        <View style={styles.circle2} />
      </View>
      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingHorizontal: isTablet ? width * 0.12 : 0,
            maxWidth: isTablet ? 700 : '100%',
            alignSelf: 'center',
            width: '100%',
            // Add extra top padding for notification bar spacing
            // paddingTop:
            //   Platform.OS === 'ios' ? 32 : Platform.OS === 'android' ? 24 : 20,
            // Make room for bottom navigation when shown
            paddingBottom: showBottomNavigation ? (isTablet ? 100 : 80) : 0,
          },
        ]}
      >
        {safeChildren}
      </Animated.View>

      {showBottomNavigation && (
        <View style={styles.bottomNavWrapper} pointerEvents="box-none">
          <BottomNavigation user={user} activeTab={activeTab} />
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 16,
    backgroundColor: '#FFFFFF',
  },
  backgroundElements: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    pointerEvents: 'none',
    zIndex: 0,
  },
  circle1: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#F1F8E9',
    top: 60,
    right: -30,
    opacity: 0.5,
  },
  circle2: {
    position: 'absolute',
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#E8F5E8',
    bottom: 150,
    left: -20,
    opacity: 0.3,
  },
  content: {
    flex: 1,
    zIndex: 1,
    paddingBottom: 0,
    paddingTop: 0,
  },
  bottomNavWrapper: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 999,
  },
});

export default Layout;
