import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';

export interface ModernCardProps {
  title: string;
  subtitle?: string;
  description?: string;
  imageUrl?: string;
  icon?: string;
  price?: number;
  currency?: string;
  onPress?: () => void;
  rightElement?: React.ReactNode;
  leftElement?: React.ReactNode;
  style?: any;
  variant?: 'default' | 'product' | 'land' | 'fertilizer' | 'user';
}

const ModernCard: React.FC<ModernCardProps> = ({
  title,
  subtitle,
  description,
  imageUrl,
  icon,
  price,
  currency = '৳',
  onPress,
  rightElement,
  leftElement,
  style,
  variant = 'default',
}) => {
  const getVariantStyles = () => {
    switch (variant) {
      case 'product':
        return styles.productCard;
      case 'land':
        return styles.landCard;
      case 'fertilizer':
        return styles.fertilizerCard;
      case 'user':
        return styles.userCard;
      default:
        return styles.defaultCard;
    }
  };

  return (
    <TouchableOpacity
      style={[styles.card, getVariantStyles(), style]}
      onPress={onPress}
      activeOpacity={0.8}
    >
      {leftElement && <View style={styles.leftElement}>{leftElement}</View>}

      {imageUrl && (
        <Image source={{ uri: imageUrl }} style={styles.cardImage} />
      )}

      {icon && !imageUrl && (
        <View style={styles.iconContainer}>
          <Text style={styles.iconText}>{icon}</Text>
        </View>
      )}

      <View style={styles.cardContent}>
        <Text style={styles.cardTitle} numberOfLines={2}>
          {title}
        </Text>

        {subtitle && (
          <Text style={styles.cardSubtitle} numberOfLines={1}>
            {subtitle}
          </Text>
        )}

        {description && (
          <Text style={styles.cardDescription} numberOfLines={3}>
            {description}
          </Text>
        )}

        {price !== undefined && (
          <Text style={styles.cardPrice}>
            {currency}
            {price.toLocaleString()}
          </Text>
        )}
      </View>

      {rightElement && <View style={styles.rightElement}>{rightElement}</View>}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    marginVertical: 8,
    marginHorizontal: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  defaultCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#4CAF50',
  },
  productCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#FF9800',
  },
  landCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#2196F3',
  },
  fertilizerCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#9C27B0',
  },
  userCard: {
    borderLeftWidth: 4,
    borderLeftColor: '#F44336',
  },
  leftElement: {
    marginRight: 12,
  },
  rightElement: {
    marginLeft: 12,
  },
  cardImage: {
    width: 80,
    height: 80,
    borderRadius: 12,
    marginRight: 16,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 12,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  iconText: {
    fontSize: 32,
  },
  cardContent: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 4,
  },
  cardSubtitle: {
    fontSize: 14,
    color: '#757575',
    marginBottom: 4,
  },
  cardDescription: {
    fontSize: 14,
    color: '#616161',
    lineHeight: 20,
    marginBottom: 8,
  },
  cardPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
});

export default ModernCard;
