import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  ViewStyle,
  TextStyle,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

export interface ModernButtonProps {
  title: string;
  onPress: () => void;
  variant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'success';
  size?: 'small' | 'medium' | 'large';
  disabled?: boolean;
  loading?: boolean;
  icon?: string;
  iconName?: string;
  iconColor?: string;
  iconSize?: number;
  iconPosition?: 'left' | 'right';
  style?: ViewStyle;
  textStyle?: TextStyle;
  fullWidth?: boolean;
}

const ModernButton: React.FC<ModernButtonProps> = ({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  disabled = false,
  loading = false,
  icon,
  iconName,
  iconColor,
  iconSize = 20,
  iconPosition = 'left',
  style,
  textStyle,
  fullWidth = false,
}) => {
  const getButtonStyles = (): ViewStyle => {
    const baseStyles: ViewStyle = {
      ...styles.button,
      ...styles[`${size}Button`],
      ...(fullWidth && styles.fullWidth),
    };

    if (disabled || loading) {
      return { ...baseStyles, ...styles.disabledButton };
    }

    switch (variant) {
      case 'secondary':
        return { ...baseStyles, ...styles.secondaryButton };
      case 'outline':
        return { ...baseStyles, ...styles.outlineButton };
      case 'danger':
        return { ...baseStyles, ...styles.dangerButton };
      case 'success':
        return { ...baseStyles, ...styles.successButton };
      default:
        return { ...baseStyles, ...styles.primaryButton };
    }
  };

  const getTextStyles = (): TextStyle => {
    const baseStyles: TextStyle = {
      ...styles.buttonText,
      ...styles[`${size}Text`],
    };

    if (disabled || loading) {
      return { ...baseStyles, ...styles.disabledText };
    }

    switch (variant) {
      case 'outline':
        return { ...baseStyles, ...styles.outlineText };
      default:
        return { ...baseStyles, ...styles.primaryText };
    }
  };

  const resolveIconColor = (): string => {
    if (iconColor) {
      return iconColor;
    }
    if (disabled || loading) {
      return '#BDBDBD';
    }
    return variant === 'outline' ? '#4CAF50' : '#FFFFFF';
  };

  const renderIcon = (position: 'left' | 'right') => {
    if (!iconName && !icon) {
      return null;
    }

    const baseStyle =
      position === 'right' ? styles.buttonIconRight : styles.buttonIconLeft;

    if (iconName) {
      return (
        <MaterialCommunityIcons
          name={iconName}
          size={iconSize}
          color={resolveIconColor()}
          style={baseStyle}
        />
      );
    }

    if (icon) {
      return <Text style={[styles.buttonIconText, baseStyle]}>{icon}</Text>;
    }

    return null;
  };

  return (
    <TouchableOpacity
      style={[getButtonStyles(), style]}
      onPress={onPress}
      disabled={disabled || loading}
      activeOpacity={0.8}
    >
      {loading ? (
        <ActivityIndicator color="#FFFFFF" size="small" />
      ) : (
        <View style={styles.buttonContent}>
          {iconPosition === 'left' && renderIcon('left')}
          <Text style={[getTextStyles(), textStyle]}>{title}</Text>
          {iconPosition === 'right' && renderIcon('right')}
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  fullWidth: {
    width: '100%',
  },
  smallButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  mediumButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  largeButton: {
    paddingHorizontal: 32,
    paddingVertical: 16,
  },
  primaryButton: {
    backgroundColor: '#4CAF50',
  },
  secondaryButton: {
    backgroundColor: '#757575',
  },
  outlineButton: {
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderColor: '#4CAF50',
  },
  dangerButton: {
    backgroundColor: '#F44336',
  },
  successButton: {
    backgroundColor: '#2196F3',
  },
  disabledButton: {
    backgroundColor: '#E0E0E0',
    elevation: 0,
    shadowOpacity: 0,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  buttonIconText: {
    fontSize: 18,
  },
  buttonIconLeft: {
    marginRight: 8,
  },
  buttonIconRight: {
    marginLeft: 8,
  },
  buttonText: {
    fontWeight: '600',
  },
  smallText: {
    fontSize: 14,
  },
  mediumText: {
    fontSize: 16,
  },
  largeText: {
    fontSize: 18,
  },
  primaryText: {
    color: '#FFFFFF',
  },
  outlineText: {
    color: '#4CAF50',
  },
  disabledText: {
    color: '#BDBDBD',
  },
});

export default ModernButton;
