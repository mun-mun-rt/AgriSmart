import { WeatherData } from '../types';

export type BangladeshCity = {
  key: string;
  name: string;
  latitude: number;
  longitude: number;
};

const BANGLADESH_CITIES: BangladeshCity[] = [
  { key: 'bagerhat', name: 'Bagerhat', latitude: 22.656, longitude: 89.787 },
  {
    key: 'bandarban',
    name: 'Bandarban',
    latitude: 22.1953,
    longitude: 92.2184,
  },
  { key: 'barguna', name: 'Barguna', latitude: 22.1592, longitude: 90.1255 },
  { key: 'barishal', name: 'Barishal', latitude: 22.701, longitude: 90.3535 },
  { key: 'bhola', name: 'Bhola', latitude: 22.685, longitude: 90.6485 },
  { key: 'bogura', name: 'Bogura', latitude: 24.8465, longitude: 89.3773 },
  {
    key: 'brahmanbaria',
    name: 'Brahmanbaria',
    latitude: 23.9571,
    longitude: 91.1119,
  },
  { key: 'chandpur', name: 'Chandpur', latitude: 23.2333, longitude: 90.6667 },
  {
    key: 'chapainawabganj',
    name: 'Chapainawabganj',
    latitude: 24.5965,
    longitude: 88.2773,
  },
  {
    key: 'chattogram',
    name: 'Chattogram',
    latitude: 22.3569,
    longitude: 91.7832,
  },
  {
    key: 'chuadanga',
    name: 'Chuadanga',
    latitude: 23.6405,
    longitude: 88.8413,
  },
  {
    key: 'coxs-bazar',
    name: "Cox's Bazar",
    latitude: 21.4272,
    longitude: 92.0058,
  },
  { key: 'cumilla', name: 'Cumilla', latitude: 23.4607, longitude: 91.1809 },
  { key: 'dhaka', name: 'Dhaka', latitude: 23.8103, longitude: 90.4125 },
  { key: 'dinajpur', name: 'Dinajpur', latitude: 25.627, longitude: 88.6332 },
  { key: 'faridpur', name: 'Faridpur', latitude: 23.607, longitude: 89.8429 },
  { key: 'feni', name: 'Feni', latitude: 23.0159, longitude: 91.3976 },
  {
    key: 'gaibandha',
    name: 'Gaibandha',
    latitude: 25.3288,
    longitude: 89.5446,
  },
  { key: 'gazipur', name: 'Gazipur', latitude: 23.9999, longitude: 90.4203 },
  {
    key: 'gopalganj',
    name: 'Gopalganj',
    latitude: 23.0056,
    longitude: 89.8266,
  },
  { key: 'habiganj', name: 'Habiganj', latitude: 24.3735, longitude: 91.4155 },
  { key: 'jamalpur', name: 'Jamalpur', latitude: 24.9204, longitude: 89.9481 },
  { key: 'jashore', name: 'Jashore', latitude: 23.1665, longitude: 89.2081 },
  {
    key: 'jhalokathi',
    name: 'Jhalokathi',
    latitude: 22.6406,
    longitude: 90.1987,
  },
  { key: 'jhenaidah', name: 'Jhenaidah', latitude: 23.5445, longitude: 89.153 },
  {
    key: 'joypurhat',
    name: 'Joypurhat',
    latitude: 25.0968,
    longitude: 89.0227,
  },
  {
    key: 'khagrachhari',
    name: 'Khagrachhari',
    latitude: 23.1193,
    longitude: 91.9847,
  },
  { key: 'khulna', name: 'Khulna', latitude: 22.8456, longitude: 89.5403 },
  {
    key: 'kishoreganj',
    name: 'Kishoreganj',
    latitude: 24.4449,
    longitude: 90.7766,
  },
  { key: 'kurigram', name: 'Kurigram', latitude: 25.8072, longitude: 89.6362 },
  { key: 'kushtia', name: 'Kushtia', latitude: 23.9028, longitude: 89.122 },
  {
    key: 'lakshmipur',
    name: 'Lakshmipur',
    latitude: 22.9423,
    longitude: 90.8413,
  },
  {
    key: 'lalmonirhat',
    name: 'Lalmonirhat',
    latitude: 25.9923,
    longitude: 89.2847,
  },
  { key: 'madaripur', name: 'Madaripur', latitude: 23.1641, longitude: 90.189 },
  { key: 'magura', name: 'Magura', latitude: 23.4854, longitude: 89.4198 },
  {
    key: 'manikganj',
    name: 'Manikganj',
    latitude: 23.8617,
    longitude: 90.0003,
  },
  { key: 'meherpur', name: 'Meherpur', latitude: 23.7622, longitude: 88.6319 },
  {
    key: 'moulvibazar',
    name: 'Moulvibazar',
    latitude: 24.4829,
    longitude: 91.7774,
  },
  { key: 'munshiganj', name: 'Munshiganj', latitude: 23.54, longitude: 90.53 },
  {
    key: 'mymensingh',
    name: 'Mymensingh',
    latitude: 24.7471,
    longitude: 90.4203,
  },
  { key: 'naogaon', name: 'Naogaon', latitude: 24.804, longitude: 88.9488 },
  { key: 'narail', name: 'Narail', latitude: 23.1725, longitude: 89.5129 },
  {
    key: 'narayanganj',
    name: 'Narayanganj',
    latitude: 23.6238,
    longitude: 90.5,
  },
  {
    key: 'narsingdi',
    name: 'Narsingdi',
    latitude: 23.9322,
    longitude: 90.7176,
  },
  { key: 'natore', name: 'Natore', latitude: 24.4206, longitude: 89 },
  { key: 'netrokona', name: 'Netrokona', latitude: 24.881, longitude: 90.728 },
  {
    key: 'nilphamari',
    name: 'Nilphamari',
    latitude: 25.931,
    longitude: 88.856,
  },
  { key: 'noakhali', name: 'Noakhali', latitude: 22.8696, longitude: 91.099 },
  { key: 'pabna', name: 'Pabna', latitude: 24, longitude: 89.25 },
  {
    key: 'panchagarh',
    name: 'Panchagarh',
    latitude: 26.3411,
    longitude: 88.5542,
  },
  {
    key: 'patuakhali',
    name: 'Patuakhali',
    latitude: 22.3596,
    longitude: 90.3313,
  },
  { key: 'pirojpur', name: 'Pirojpur', latitude: 22.579, longitude: 89.975 },
  { key: 'rajbari', name: 'Rajbari', latitude: 23.7572, longitude: 89.644 },
  { key: 'rajshahi', name: 'Rajshahi', latitude: 24.3745, longitude: 88.6042 },
  {
    key: 'rangamati',
    name: 'Rangamati',
    latitude: 22.7324,
    longitude: 92.2985,
  },
  { key: 'rangpur', name: 'Rangpur', latitude: 25.7439, longitude: 89.2752 },
  { key: 'satkhira', name: 'Satkhira', latitude: 22.7185, longitude: 89.0705 },
  {
    key: 'shariatpur',
    name: 'Shariatpur',
    latitude: 23.2423,
    longitude: 90.4348,
  },
  { key: 'sherpur', name: 'Sherpur', latitude: 25.0204, longitude: 90.0144 },
  {
    key: 'sirajganj',
    name: 'Sirajganj',
    latitude: 24.4534,
    longitude: 89.7006,
  },
  { key: 'sunamganj', name: 'Sunamganj', latitude: 25.0658, longitude: 91.395 },
  { key: 'sylhet', name: 'Sylhet', latitude: 24.8949, longitude: 91.8687 },
  { key: 'tangail', name: 'Tangail', latitude: 24.2513, longitude: 89.9167 },
  {
    key: 'thakurgaon',
    name: 'Thakurgaon',
    latitude: 26.033,
    longitude: 88.4687,
  },
];

interface OpenMeteoResponse {
  hourly: {
    time: string[];
    temperature_2m: number[];
    relative_humidity_2m: number[];
    precipitation: number[];
    weathercode: number[];
    cloudcover: number[];
    windspeed_10m: number[];
    windgusts_10m: number[];
    dewpoint_2m: number[];
    soil_temperature_0cm: number[];
    soil_moisture_0_1cm: number[];
    evapotranspiration: number[];
    surface_pressure: number[];
  };
  daily: {
    time: string[];
    temperature_2m_max: number[];
    temperature_2m_min: number[];
    precipitation_sum: number[];
    sunshine_duration: number[];
  };
  current_weather?: {
    temperature: number;
    windspeed: number;
    winddirection: number;
    weathercode: number;
    time: string;
  };
}

class WeatherAPI {
  private static instance: WeatherAPI;
  private readonly baseUrl = 'https://api.open-meteo.com/v1/forecast';
  private readonly bangladeshCities: BangladeshCity[];

  private constructor() {
    this.bangladeshCities = [...BANGLADESH_CITIES].sort((a, b) =>
      a.name.localeCompare(b.name),
    );
  }

  public static getInstance(): WeatherAPI {
    if (!WeatherAPI.instance) {
      WeatherAPI.instance = new WeatherAPI();
    }
    return WeatherAPI.instance;
  }

  public getBangladeshCities(): BangladeshCity[] {
    return [...this.bangladeshCities];
  }

  public getCityByKey(key: string): BangladeshCity | undefined {
    return this.bangladeshCities.find(city => city.key === key);
  }

  // Weather code mapping for Open-Meteo
  private getWeatherDescription(code: number): {
    condition: string;
    icon: string;
  } {
    const weatherCodes: { [key: number]: { condition: string; icon: string } } =
      {
        0: { condition: 'Clear sky', icon: '☀️' },
        1: { condition: 'Mainly clear', icon: '🌤️' },
        2: { condition: 'Partly cloudy', icon: '⛅' },
        3: { condition: 'Overcast', icon: '☁️' },
        45: { condition: 'Fog', icon: '🌫️' },
        48: { condition: 'Depositing rime fog', icon: '🌫️' },
        51: { condition: 'Light drizzle', icon: '🌦️' },
        53: { condition: 'Moderate drizzle', icon: '🌦️' },
        55: { condition: 'Dense drizzle', icon: '🌧️' },
        56: { condition: 'Light freezing drizzle', icon: '🌨️' },
        57: { condition: 'Dense freezing drizzle', icon: '🌨️' },
        61: { condition: 'Slight rain', icon: '🌦️' },
        63: { condition: 'Moderate rain', icon: '🌧️' },
        65: { condition: 'Heavy rain', icon: '🌧️' },
        66: { condition: 'Light freezing rain', icon: '🌨️' },
        67: { condition: 'Heavy freezing rain', icon: '🌨️' },
        71: { condition: 'Slight snow fall', icon: '🌨️' },
        73: { condition: 'Moderate snow fall', icon: '❄️' },
        75: { condition: 'Heavy snow fall', icon: '❄️' },
        77: { condition: 'Snow grains', icon: '🌨️' },
        80: { condition: 'Slight rain showers', icon: '🌦️' },
        81: { condition: 'Moderate rain showers', icon: '🌧️' },
        82: { condition: 'Violent rain showers', icon: '🌧️' },
        85: { condition: 'Slight snow showers', icon: '🌨️' },
        86: { condition: 'Heavy snow showers', icon: '❄️' },
        95: { condition: 'Thunderstorm', icon: '⛈️' },
        96: { condition: 'Thunderstorm with slight hail', icon: '⛈️' },
        99: { condition: 'Thunderstorm with heavy hail', icon: '⛈️' },
      };

    return weatherCodes[code] || { condition: 'Unknown', icon: '❓' };
  }

  // Fetch real weather data from Open-Meteo API
  private async fetchWeatherData(
    latitude: number = 23.8103,
    longitude: number = 90.4125,
  ): Promise<WeatherData> {
    try {
      const url = `${this.baseUrl}?latitude=${latitude}&longitude=${longitude}&hourly=temperature_2m,relative_humidity_2m,precipitation,weathercode,cloudcover,windspeed_10m,windgusts_10m,dewpoint_2m,soil_temperature_0cm,soil_moisture_0_1cm,evapotranspiration,surface_pressure&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,sunshine_duration&timezone=auto&current_weather=true`;

      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(`Weather API request failed: ${response.status}`);
      }

      const data: OpenMeteoResponse = await response.json();

      return this.parseWeatherData(data);
    } catch (error) {
      console.error('Error fetching weather data:', error);
      // Return cached data or fallback mock data
      return this.getFallbackWeatherData();
    }
  }

  // Parse Open-Meteo response into our WeatherData format
  private parseWeatherData(data: OpenMeteoResponse): WeatherData {
    const current = data.current_weather;
    const currentWeather = current
      ? this.getWeatherDescription(current.weathercode)
      : { condition: 'Clear sky', icon: '☀️' };

    // Get current hour data from hourly arrays
    const currentHour = new Date().getHours();
    const currentHumidity = data.hourly.relative_humidity_2m[currentHour] || 60;
    const currentWindSpeed =
      current?.windspeed || data.hourly.windspeed_10m[currentHour] || 10;

    // Process daily forecast
    const forecast: WeatherData['forecast'] = [];
    const days = [
      'Today',
      'Tomorrow',
      'Day 3',
      'Day 4',
      'Day 5',
      'Day 6',
      'Day 7',
    ];

    for (let i = 0; i < Math.min(7, data.daily.time.length); i++) {
      const weatherCode = data.hourly.weathercode[i * 24] || 0; // Use weather code from daily noon hour
      const weather = this.getWeatherDescription(weatherCode);
      const precipitationSum = data.daily.precipitation_sum[i] || 0;
      const rainChance = this.calculateRainChance(precipitationSum);

      forecast.push({
        day: days[i] || `Day ${i + 1}`,
        high: Math.round(data.daily.temperature_2m_max[i] || 25),
        low: Math.round(data.daily.temperature_2m_min[i] || 15),
        condition: weather.condition,
        icon: weather.icon,
        rainChance,
      });
    }

    return {
      current: {
        temperature: Math.round(current?.temperature || 25),
        condition: currentWeather.condition,
        humidity: Math.round(currentHumidity),
        windSpeed: Math.round(currentWindSpeed),
        icon: currentWeather.icon,
      },
      forecast,
    };
  }

  // Calculate rain chance based on precipitation sum
  private calculateRainChance(precipitationSum: number): number {
    if (precipitationSum === 0) return 0;
    if (precipitationSum < 0.1) return 10;
    if (precipitationSum < 1) return 30;
    if (precipitationSum < 5) return 60;
    if (precipitationSum < 10) return 80;
    return 95;
  }

  // Fallback mock data when API fails
  private getFallbackWeatherData(): WeatherData {
    const conditions = ['Sunny', 'Partly Cloudy', 'Cloudy', 'Rainy', 'Stormy'];
    const icons = ['☀️', '⛅', '☁️', '🌧️', '⛈️'];

    const currentCondition =
      conditions[Math.floor(Math.random() * conditions.length)];
    const currentIcon = icons[conditions.indexOf(currentCondition)];

    const forecast: WeatherData['forecast'] = [];
    const days = [
      'Today',
      'Tomorrow',
      'Day 3',
      'Day 4',
      'Day 5',
      'Day 6',
      'Day 7',
    ];

    for (let i = 0; i < 7; i++) {
      const condition =
        conditions[Math.floor(Math.random() * conditions.length)];
      const date = new Date();
      date.setDate(date.getDate() + i);

      forecast.push({
        day: days[i],
        high: Math.floor(Math.random() * 10) + 25, // 25-35°C
        low: Math.floor(Math.random() * 10) + 15, // 15-25°C
        condition,
        icon: icons[conditions.indexOf(condition)],
        rainChance: Math.floor(Math.random() * 100),
      });
    }

    return {
      current: {
        temperature: Math.floor(Math.random() * 15) + 20, // 20-35°C
        condition: currentCondition,
        humidity: Math.floor(Math.random() * 40) + 40,
        windSpeed: Math.floor(Math.random() * 20) + 5,
        icon: currentIcon,
      },
      forecast,
    };
  }

  async getWeatherData(
    latitude?: number,
    longitude?: number,
  ): Promise<WeatherData> {
    try {
      // Use real weather API
      const weatherData = await this.fetchWeatherData(latitude, longitude);
      return weatherData;
    } catch (error) {
      console.error('Error fetching weather data:', error);
      return this.getFallbackWeatherData();
    }
  }

  async getWeatherAlerts(_location: string): Promise<string[]> {
    try {
      const weatherData = await this.getWeatherData();
      const alerts: string[] = [];

      // Check for weather-based farming alerts
      if (weatherData.current.temperature > 35) {
        alerts.push(
          '⚠️ High temperature alert! Consider watering crops more frequently.',
        );
      }

      if (weatherData.current.temperature < 10) {
        alerts.push(
          '🥶 Frost warning! Protect sensitive crops from cold damage.',
        );
      }

      if (weatherData.current.humidity > 80) {
        alerts.push('💧 High humidity! Monitor crops for fungal diseases.');
      }

      if (weatherData.current.windSpeed > 25) {
        alerts.push(
          '💨 Strong winds! Secure greenhouse structures and young plants.',
        );
      }

      // Check forecast for rain
      const rainForecast = weatherData.forecast.filter(
        day => day.rainChance > 70,
      );
      if (rainForecast.length > 0) {
        alerts.push(
          `🌧️ Heavy rain expected in next ${rainForecast.length} days. Plan irrigation accordingly.`,
        );
      }

      // Check for dry spell
      const dryDays = weatherData.forecast.filter(
        day => day.rainChance < 20,
      ).length;
      if (dryDays > 5) {
        alerts.push(
          '☀️ Extended dry period ahead. Ensure adequate water supply for crops.',
        );
      }

      return alerts;
    } catch (error) {
      console.error('Error getting weather alerts:', error);
      return [];
    }
  }

  async getIrrigationRecommendation(
    _location: string,
    _cropType: string,
  ): Promise<{
    shouldIrrigate: boolean;
    reason: string;
    nextIrrigation: string;
  }> {
    try {
      const weatherData = await this.getWeatherData();

      // Simple irrigation logic based on weather
      const rainChanceToday = weatherData.forecast[0]?.rainChance || 0;
      const temperature = weatherData.current.temperature;
      const humidity = weatherData.current.humidity;

      let shouldIrrigate = false;
      let reason = '';
      let nextIrrigation = '';

      if (rainChanceToday > 60) {
        reason = 'Rain expected today, skip irrigation';
        nextIrrigation = 'Check weather tomorrow';
      } else if (temperature > 30 && humidity < 50) {
        shouldIrrigate = true;
        reason = 'Hot and dry conditions require watering';
        nextIrrigation = 'Tomorrow morning';
      } else if (humidity < 40) {
        shouldIrrigate = true;
        reason = 'Low humidity, crops need water';
        nextIrrigation = 'Tomorrow evening';
      } else {
        reason = 'Current conditions are adequate';
        nextIrrigation = 'Check again tomorrow';
      }

      return {
        shouldIrrigate,
        reason,
        nextIrrigation,
      };
    } catch (error) {
      console.error('Error getting irrigation recommendation:', error);
      return {
        shouldIrrigate: false,
        reason: 'Unable to determine irrigation needs',
        nextIrrigation: 'Check again later',
      };
    }
  }
}

export default WeatherAPI;
