import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase, supabaseAdmin } from '../utils/supabase';
import SupabaseDatabaseManager from './SupabaseDatabaseManager';
import {
  User,
  LoginCredentials,
  SignUpData,
  AuthResponse,
} from '../types/index';

class SupabaseAuthManager {
  private static instance: SupabaseAuthManager;
  private readonly TOKEN_KEY = 'auth_token';
  private readonly USER_KEY = 'current_user';
  private dbManager = SupabaseDatabaseManager.getInstance();

  private constructor() {}

  static getInstance(): SupabaseAuthManager {
    if (!SupabaseAuthManager.instance) {
      SupabaseAuthManager.instance = new SupabaseAuthManager();
    }
    return SupabaseAuthManager.instance;
  }

  async signUp(signUpData: SignUpData): Promise<AuthResponse> {
    try {
      // Sign up with Supabase Auth (primary authentication)
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: signUpData.email,
        password: signUpData.password,
      });

      if (authError) {
        return {
          success: false,
          message: authError.message,
        };
      }

      if (!authData.user) {
        return {
          success: false,
          message: 'Failed to create user account',
        };
      }

      // Try to create user profile in users table (onboarding incomplete)
      const { error: profileError } = await supabase.from('users').insert({
        id: authData.user.id,
        name: signUpData.name,
        email: signUpData.email,
        role: null, // Role will be set during onboarding
        is_active: true,
        wallet_balance: 0,
        onboarding_completed: false,
      });

      if (profileError) {
        // Log the error but don't fail - user can complete profile during onboarding
        console.warn(
          'Failed to create initial profile, will be created during onboarding:',
          profileError,
        );
      }

      // Auto sign in after successful signup
      const { data: sessionData, error: sessionError } =
        await supabase.auth.signInWithPassword({
          email: signUpData.email,
          password: signUpData.password,
        });

      if (sessionError || !sessionData.user) {
        return {
          success: false,
          message: 'Account created but failed to sign in automatically',
        };
      }

      // Create user object from auth data (profile may or may not exist)
      const user: User = {
        id: authData.user.id as any, // Supabase uses string UUIDs
        name: signUpData.name,
        email: signUpData.email,
        role: undefined, // Will be set during onboarding
        is_active: true,
        wallet_balance: 0,
        onboarding_completed: false,
        created_at: authData.user.created_at || new Date().toISOString(),
      };

      // Store user data locally
      await this.storeUserData(sessionData.session?.access_token || '', user);

      return {
        success: true,
        message: 'Account created successfully',
        user: user,
        token: sessionData.session?.access_token,
      };
    } catch (error) {
      console.error('Sign up error:', error);
      return {
        success: false,
        message: 'An unexpected error occurred during sign up',
      };
    }
  }

  async signIn(credentials: LoginCredentials): Promise<AuthResponse> {
    try {
      // Sign in with Supabase Auth (primary authentication)
      const { data: sessionData, error: authError } =
        await supabase.auth.signInWithPassword({
          email: credentials.email,
          password: credentials.password,
        });

      if (authError) {
        return {
          success: false,
          message: authError.message,
        };
      }

      if (!sessionData.user || !sessionData.session) {
        return {
          success: false,
          message: 'Invalid credentials',
        };
      }

      // Successfully authenticated with auth.users
      // Now try to get user profile data (this may not exist)
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('id', sessionData.user.id)
        .single();

      // If profile exists, check if user is active
      if (userData && !userData.is_active) {
        return {
          success: false,
          message: 'Your account has been deactivated. Please contact support.',
        };
      }

      // Create user object - profile data may be null if user hasn't completed onboarding
      let user: User;

      if (userData) {
        // Profile exists, create full user object
        user = {
          id: userData.id,
          name: userData.name,
          email: userData.email,
          phone: userData.phone,
          role: userData.role,
          address_line1: userData.address_line1,
          address_line2: userData.address_line2,
          city: userData.city,
          state: userData.state,
          postal_code: userData.postal_code,
          country: userData.country,
          date_of_birth: userData.date_of_birth,
          gender: userData.gender,
          profile_image_url: userData.profile_image_url,
          bio: userData.bio,
          farm_name: userData.farm_name,
          farm_size: userData.farm_size,
          farming_experience: userData.farming_experience,
          specialization: userData.specialization,
          mobile_banking_bkash: userData.mobile_banking_bkash,
          mobile_banking_nagad: userData.mobile_banking_nagad,
          mobile_banking_rocket: userData.mobile_banking_rocket,
          is_active: userData.is_active,
          wallet_balance: userData.wallet_balance,
          onboarding_completed: userData.onboarding_completed,
          created_at: userData.created_at,
        };
      } else {
        // No profile found - create minimal user object from auth data
        user = {
          id: sessionData.user.id as any, // Supabase uses string UUIDs
          name:
            sessionData.user.user_metadata?.name ||
            sessionData.user.email?.split('@')[0] ||
            'User',
          email: sessionData.user.email || '',
          role: undefined, // No role - needs onboarding
          is_active: true,
          wallet_balance: 0,
          onboarding_completed: false,
          created_at: sessionData.user.created_at || new Date().toISOString(),
        };
      }

      // Store user data locally
      await this.storeUserData(sessionData.session.access_token, user);

      return {
        success: true,
        message: 'Sign in successful',
        user: user,
        token: sessionData.session.access_token,
      };
    } catch (error) {
      console.error('Sign in error:', error);
      return {
        success: false,
        message: 'An unexpected error occurred during sign in',
      };
    }
  }

  async signOut(): Promise<void> {
    try {
      // Sign out from Supabase
      await supabase.auth.signOut();

      // Clear local storage
      await AsyncStorage.multiRemove([this.TOKEN_KEY, this.USER_KEY]);
    } catch (error) {
      console.error('Sign out error:', error);
      // Clear local storage even if Supabase signout fails
      await AsyncStorage.multiRemove([this.TOKEN_KEY, this.USER_KEY]);
    }
  }

  async getSession(): Promise<any> {
    try {
      const {
        data: { session },
        error,
      } = await supabase.auth.getSession();

      if (error) {
        console.error('Error getting session:', error);
        return null;
      }

      return session;
    } catch (error) {
      console.error('Error getting session:', error);
      return null;
    }
  }

  async getCurrentUser(forceFresh: boolean = false): Promise<User | null> {
    try {
      // If not forcing fresh data, try to get from local storage first
      if (!forceFresh) {
        const userJson = await AsyncStorage.getItem(this.USER_KEY);
        if (userJson) {
          const localUser = JSON.parse(userJson);

          // Verify with Supabase session
          const {
            data: { session },
          } = await supabase.auth.getSession();
          if (session?.user && session.user.id === localUser.id) {
            console.log('Returning cached user data');
            return localUser;
          }
        }
      }

      console.log('Fetching fresh user data from Supabase...');

      // Get fresh data from Supabase
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session?.user) {
        console.log('No active session found');
        return null;
      }

      console.log('Active session found, fetching user profile...');

      // Get user profile data (may not exist)
      const { data: userData, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', session.user.id)
        .single();

      let user: User;

      if (error || !userData) {
        // No profile found - create minimal user object from auth data
        console.log(
          'No profile found in public.users, creating from auth data',
        );
        user = {
          id: session.user.id as any, // Supabase uses string UUIDs
          name:
            session.user.user_metadata?.name ||
            session.user.email?.split('@')[0] ||
            'User',
          email: session.user.email || '',
          role: undefined, // No role - needs onboarding
          is_active: true,
          wallet_balance: 0,
          onboarding_completed: false,
          created_at: session.user.created_at || new Date().toISOString(),
        };
      } else {
        // Profile exists - use full profile data
        console.log('Profile found in public.users:', {
          role: userData.role,
          onboarding_completed: userData.onboarding_completed,
          phone: userData.phone,
          city: userData.city,
        });
        user = {
          id: userData.id,
          name: userData.name,
          email: userData.email,
          phone: userData.phone,
          role: userData.role,
          address_line1: userData.address_line1,
          address_line2: userData.address_line2,
          city: userData.city,
          state: userData.state,
          postal_code: userData.postal_code,
          country: userData.country,
          date_of_birth: userData.date_of_birth,
          gender: userData.gender,
          profile_image_url: userData.profile_image_url,
          bio: userData.bio,
          farm_name: userData.farm_name,
          farm_size: userData.farm_size,
          farming_experience: userData.farming_experience,
          specialization: userData.specialization,
          mobile_banking_bkash: userData.mobile_banking_bkash,
          mobile_banking_nagad: userData.mobile_banking_nagad,
          mobile_banking_rocket: userData.mobile_banking_rocket,
          is_active: userData.is_active,
          wallet_balance: userData.wallet_balance,
          onboarding_completed: userData.onboarding_completed,
          created_at: userData.created_at,
        };
      }

      // Update local storage
      await this.storeUserData(session.access_token, user);

      return user;
    } catch (error) {
      console.error('Error getting current user:', error);
      return null;
    }
  }

  async isAuthenticated(): Promise<boolean> {
    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      return !!session?.user;
    } catch (error) {
      console.error('Error checking authentication:', error);
      return false;
    }
  }

  async getStoredToken(): Promise<string | null> {
    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      return session?.access_token || null;
    } catch (error) {
      console.error('Error getting stored token:', error);
      return null;
    }
  }

  private async storeUserData(token: string, user: User): Promise<void> {
    try {
      await AsyncStorage.multiSet([
        [this.TOKEN_KEY, token],
        [this.USER_KEY, JSON.stringify(user)],
      ]);
    } catch (error) {
      console.error('Error storing user data:', error);
    }
  }

  // Guest sign in for users who want to browse without creating an account
  async signInAsGuest(): Promise<AuthResponse> {
    try {
      // Create a temporary guest user
      const guestEmail = `guest_${Date.now()}@temporary.local`;
      const guestUser: User = {
        id: Date.now(), // Use timestamp as numeric ID
        name: 'Guest User',
        email: guestEmail,
        role: 'guest',
        is_active: true,
        wallet_balance: 0,
        created_at: new Date().toISOString(),
      };

      // Store guest user data locally (no Supabase auth needed)
      await this.storeUserData('guest_token', guestUser);

      return {
        success: true,
        message: 'Signed in as guest',
        user: guestUser,
        token: 'guest_token',
      };
    } catch (error) {
      console.error('Guest sign in error:', error);
      return {
        success: false,
        message: 'Failed to sign in as guest',
      };
    }
  }

  // Update user profile
  async updateProfile(updates: Partial<User>): Promise<AuthResponse> {
    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session?.user) {
        return {
          success: false,
          message: 'Not authenticated',
        };
      }

      const currentUser = await this.getCurrentUser();
      if (!currentUser) {
        return {
          success: false,
          message: 'Not authenticated',
        };
      }

      if (currentUser.role === 'guest') {
        // For guest users, just update local storage
        const updatedUser = { ...currentUser, ...updates };
        await AsyncStorage.setItem(this.USER_KEY, JSON.stringify(updatedUser));

        return {
          success: true,
          message: 'Profile updated',
          user: updatedUser,
        };
      }

      console.log('Updating user profile in Supabase:', {
        userId: currentUser.id,
        updates,
      });

      // Check if user profile exists in public.users table
      const { data: existingUser, error: checkError } = await supabase
        .from('users')
        .select('id')
        .eq('id', session.user.id)
        .single();

      let result;

      if (checkError && checkError.code === 'PGRST116') {
        // User doesn't exist in public.users, create new record
        console.log('User profile not found, creating new record...');

        const newUserData = {
          id: session.user.id,
          name:
            session.user.user_metadata?.name ||
            session.user.email?.split('@')[0] ||
            'User',
          email: session.user.email,
          role: null,
          is_active: true,
          wallet_balance: 0,
          onboarding_completed: false,
          created_at: session.user.created_at || new Date().toISOString(),
          ...updates, // Apply the updates
        };

        result = await supabase.from('users').insert(newUserData);
      } else if (existingUser) {
        // User exists, update the record
        console.log('User profile found, updating existing record...');
        result = await supabase
          .from('users')
          .update(updates)
          .eq('id', session.user.id);
      } else {
        // Other error occurred
        console.error('Error checking user existence:', checkError);
        return {
          success: false,
          message: `Failed to check user profile: ${checkError?.message}`,
        };
      }

      if (result.error) {
        console.error('Supabase operation error:', result.error);
        return {
          success: false,
          message: `Failed to update profile: ${result.error.message}`,
        };
      }

      console.log(
        'Profile operation successful in Supabase, fetching updated user...',
      );

      // Get updated user data and clear local cache
      await AsyncStorage.removeItem(this.USER_KEY);
      const updatedUser = await this.getCurrentUser(true); // Force fresh data

      console.log('Updated user data:', updatedUser);

      return {
        success: true,
        message: 'Profile updated successfully',
        user: updatedUser || undefined,
      };
    } catch (error) {
      console.error('Update profile error:', error);
      return {
        success: false,
        message: 'An unexpected error occurred',
      };
    }
  }

  // Update auth email and password
  async updateAuthCredentials(
    newEmail?: string,
    newPassword?: string,
  ): Promise<AuthResponse> {
    try {
      const updates: { email?: string; password?: string } = {};

      if (newEmail) {
        updates.email = newEmail;
      }

      if (newPassword) {
        updates.password = newPassword;
      }

      if (Object.keys(updates).length === 0) {
        return {
          success: false,
          message: 'No updates provided',
        };
      }

      const { error } = await supabase.auth.updateUser(updates);

      if (error) {
        return {
          success: false,
          message: error.message,
        };
      }

      return {
        success: true,
        message: 'Authentication credentials updated successfully',
      };
    } catch (error) {
      console.error('Update auth credentials error:', error);
      return {
        success: false,
        message: 'An unexpected error occurred',
      };
    }
  }

  // Password reset
  async resetPassword(email: string): Promise<AuthResponse> {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email);

      if (error) {
        return {
          success: false,
          message: error.message,
        };
      }

      return {
        success: true,
        message: 'Password reset email sent',
      };
    } catch (error) {
      console.error('Password reset error:', error);
      return {
        success: false,
        message: 'Failed to send password reset email',
      };
    }
  }

  // Listen to auth state changes
  setupAuthListener(callback: (user: User | null) => void): () => void {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_OUT' || !session?.user) {
        await AsyncStorage.multiRemove([this.TOKEN_KEY, this.USER_KEY]);
        callback(null);
      } else if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
        const user = await this.getCurrentUser();
        callback(user);
      }
    });

    return () => {
      subscription?.unsubscribe();
    };
  }

  // Complete onboarding process
  async completeOnboarding(
    role: 'farmer' | 'consumer',
    additionalData?: Partial<User>,
  ): Promise<AuthResponse> {
    try {
      const currentUser = await this.getCurrentUser();
      if (!currentUser) {
        return {
          success: false,
          message: 'Not authenticated',
        };
      }

      // Prepare update data
      const updateData: Partial<User> = {
        role: role,
        onboarding_completed: true,
        ...additionalData,
      };

      // Get the current session to ensure we have the auth user ID
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session?.user) {
        return {
          success: false,
          message: 'Not authenticated',
        };
      }

      // Try to update existing profile, or create new one if it doesn't exist
      const { data: existingUser } = await supabase
        .from('users')
        .select('id')
        .eq('id', session.user.id)
        .single();

      if (existingUser) {
        // Update existing profile
        const { error } = await supabase
          .from('users')
          .update(updateData)
          .eq('id', session.user.id);

        if (error) {
          return {
            success: false,
            message: 'Failed to complete onboarding',
          };
        }
      } else {
        // Create new profile with onboarding data
        const newProfile = {
          id: session.user.id,
          name: currentUser.name,
          email: currentUser.email,
          wallet_balance: 0,
          is_active: true,
          ...updateData,
        };

        const { error } = await supabase.from('users').insert(newProfile);

        if (error) {
          return {
            success: false,
            message: 'Failed to create profile during onboarding',
          };
        }
      }

      // Get updated user data
      const updatedUser = await this.getCurrentUser();
      return {
        success: true,
        message: 'Onboarding completed successfully',
        user: updatedUser || undefined,
      };
    } catch (error) {
      console.error('Onboarding completion error:', error);
      return {
        success: false,
        message: 'An unexpected error occurred during onboarding',
      };
    }
  }

  // Additional methods for backward compatibility
  async updateCurrentUser(updates: Partial<User>): Promise<void> {
    const result = await this.updateProfile(updates);
    if (!result.success) {
      throw new Error(result.message);
    }
  }

  async getAllUsers(): Promise<User[]> {
    const dbManager = this.dbManager;
    return await dbManager.getAllUsers();
  }

  // Delete user account and all related data
  async deleteAccount(): Promise<AuthResponse> {
    try {
      const currentUser = await this.getCurrentUser();
      if (!currentUser) {
        return {
          success: false,
          message: 'No user is currently signed in',
        };
      }

      if (currentUser.role === 'guest') {
        return {
          success: false,
          message: 'Guest accounts cannot be deleted',
        };
      }

      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session?.user) {
        return {
          success: false,
          message: 'No active session found',
        };
      }

      const userId = session.user.id;

      console.log('Starting account deletion process for user:', userId);

      // Use admin client to delete all data and auth user
      return await this.deleteAccountWithAdmin(userId);
    } catch (error) {
      console.error('Delete account error:', error);
      return {
        success: false,
        message: 'An unexpected error occurred while deleting account',
      };
    }
  }

  // Admin deletion method using service role
  private async deleteAccountWithAdmin(userId: string): Promise<AuthResponse> {
    try {
      console.log('Starting admin deletion process for user:', userId);

      // Step 1: Delete all application data using admin client
      await this.deleteUserDataWithAdmin(userId);

      // Step 2: Delete from auth.users using admin client
      console.log('Deleting user from auth.users table...');

      // First sign out the user to avoid conflicts
      await supabase.auth.signOut();

      // Wait a moment for the signout to propagate
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Now delete using admin client
      const { error: authDeleteError } =
        await supabaseAdmin.auth.admin.deleteUser(userId);

      if (authDeleteError) {
        console.error('Error deleting user from auth.users:', authDeleteError);

        // Even if auth deletion fails, we still deleted all the data
        // Clear local storage and return partial success
        await AsyncStorage.multiRemove([this.TOKEN_KEY, this.USER_KEY]);

        return {
          success: false,
          message:
            'User data deleted but failed to remove auth account: ' +
            authDeleteError.message,
        };
      }

      console.log('Successfully deleted user from auth.users table');

      // Step 3: Clear local storage (signout already done above)
      console.log('Clearing local storage...');
      await AsyncStorage.multiRemove([this.TOKEN_KEY, this.USER_KEY]);

      return {
        success: true,
        message: 'Account completely deleted including auth record',
      };
    } catch (error) {
      console.error('Admin deletion error:', error);
      return {
        success: false,
        message: 'Failed to delete account: ' + (error as Error).message,
      };
    }
  }

  /**
   * Public helper for admins to delete any user by id using the service role client.
   * This will remove application data and the auth record. Intended for admin users only.
   */
  async deleteUserAsAdmin(targetUserId: string): Promise<AuthResponse> {
    try {
      console.log('Admin requested deletion for user:', targetUserId);

      // Delete application data first
      await this.deleteUserDataWithAdmin(targetUserId);

      // Delete the auth user using the admin client
      const { error: authDeleteError } =
        await supabaseAdmin.auth.admin.deleteUser(targetUserId);

      if (authDeleteError) {
        console.error('Error deleting user from auth.users:', authDeleteError);
        return {
          success: false,
          message:
            'User data deleted but failed to remove auth account: ' +
            authDeleteError.message,
        };
      }

      console.log('Successfully deleted user (admin):', targetUserId);
      return {
        success: true,
        message: 'User deleted successfully',
      };
    } catch (error: any) {
      console.error('deleteUserAsAdmin error:', error);
      return {
        success: false,
        message:
          'Failed to delete user: ' + (error?.message || 'Unknown error'),
      };
    }
  }

  // Delete all user data using admin client
  private async deleteUserDataWithAdmin(userId: string): Promise<void> {
    console.log('Deleting user data with admin privileges...');

    const errors: string[] = [];

    try {
      // Delete in correct order to handle foreign key constraints
      // Step 1: Delete wallet transactions first (they reference orders)
      console.log('Deleting wallet transactions...');
      const { error: walletError } = await supabaseAdmin
        .from('wallet_transactions')
        .delete()
        .eq('user_id', userId);
      if (walletError) {
        console.error('Error deleting wallet transactions:', walletError);
        errors.push(`wallet_transactions: ${walletError.message}`);
      }

      // Step 2: Get user's orders to delete related wallet transactions
      console.log('Getting user orders for wallet cleanup...');
      const { data: userOrders, error: ordersSelectError } = await supabaseAdmin
        .from('orders')
        .select('id')
        .or(`user_id.eq.${userId},farmer_id.eq.${userId}`);

      if (ordersSelectError) {
        console.error('Error selecting user orders:', ordersSelectError);
        errors.push(`orders_select: ${ordersSelectError.message}`);
      } else if (userOrders && userOrders.length > 0) {
        const orderIds = userOrders.map(o => o.id);
        console.log(
          `Found ${orderIds.length} orders, deleting related wallet transactions...`,
        );

        // Delete wallet transactions that reference these orders
        const { error: walletOrderError } = await supabaseAdmin
          .from('wallet_transactions')
          .delete()
          .in('related_order_id', orderIds);
        if (walletOrderError) {
          console.error(
            'Error deleting wallet transactions for orders:',
            walletOrderError,
          );
          errors.push(
            `wallet_transactions_orders: ${walletOrderError.message}`,
          );
        }
      }

      // Step 3: Delete messages
      console.log('Deleting messages...');
      const { error: messagesError } = await supabaseAdmin
        .from('messages')
        .delete()
        .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`);
      if (messagesError) {
        console.error('Error deleting messages:', messagesError);
        errors.push(`messages: ${messagesError.message}`);
      }

      // Step 4: Delete followers
      console.log('Deleting followers...');
      const { error: followersError } = await supabaseAdmin
        .from('followers')
        .delete()
        .or(`user_id.eq.${userId},follower_id.eq.${userId}`);
      if (followersError) {
        console.error('Error deleting followers:', followersError);
        errors.push(`followers: ${followersError.message}`);
      }

      // Step 5: Delete shopping cart items for user
      console.log('Deleting shopping cart items for user...');
      const { error: cartError } = await supabaseAdmin
        .from('shopping_cart')
        .delete()
        .eq('user_id', userId);
      if (cartError) {
        console.error('Error deleting shopping cart:', cartError);
        errors.push(`shopping_cart: ${cartError.message}`);
      }

      // Step 6: Get user's products to handle related data
      console.log('Getting user products...');
      const { data: userProducts, error: productsSelectError } =
        await supabaseAdmin
          .from('products')
          .select('id')
          .eq('farmer_id', userId);

      if (productsSelectError) {
        console.error('Error selecting user products:', productsSelectError);
        errors.push(`products_select: ${productsSelectError.message}`);
      } else if (userProducts && userProducts.length > 0) {
        const productIds = userProducts.map(p => p.id);
        console.log(`Found ${productIds.length} products owned by user`);

        // Delete shopping cart items for user-owned products
        const { error: cartProductError } = await supabaseAdmin
          .from('shopping_cart')
          .delete()
          .in('product_id', productIds);
        if (cartProductError) {
          console.error(
            'Error deleting cart items for products:',
            cartProductError,
          );
          errors.push(`cart_products: ${cartProductError.message}`);
        }

        // Get orders for user-owned products to delete wallet transactions
        const { data: productOrders, error: productOrdersError } =
          await supabaseAdmin
            .from('orders')
            .select('id')
            .in('product_id', productIds);

        if (productOrdersError) {
          console.error(
            'Error selecting orders for products:',
            productOrdersError,
          );
          errors.push(`product_orders_select: ${productOrdersError.message}`);
        } else if (productOrders && productOrders.length > 0) {
          const productOrderIds = productOrders.map(o => o.id);
          console.log(
            `Found ${productOrderIds.length} orders for products, deleting wallet transactions...`,
          );

          // Delete wallet transactions for these product orders
          const { error: walletProductOrderError } = await supabaseAdmin
            .from('wallet_transactions')
            .delete()
            .in('related_order_id', productOrderIds);
          if (walletProductOrderError) {
            console.error(
              'Error deleting wallet transactions for product orders:',
              walletProductOrderError,
            );
            errors.push(
              `wallet_transactions_product_orders: ${walletProductOrderError.message}`,
            );
          }
        }

        // Now delete orders for user-owned products
        const { error: ordersProductError } = await supabaseAdmin
          .from('orders')
          .delete()
          .in('product_id', productIds);
        if (ordersProductError) {
          console.error(
            'Error deleting orders for products:',
            ordersProductError,
          );
          errors.push(`orders_products: ${ordersProductError.message}`);
        }

        // Delete fertilizer guide products
        const { error: fertilizerError } = await supabaseAdmin
          .from('fertilizer_guide_products')
          .delete()
          .in('product_id', productIds);
        if (fertilizerError) {
          console.error(
            'Error deleting fertilizer guide products:',
            fertilizerError,
          );
          errors.push(`fertilizer_guide_products: ${fertilizerError.message}`);
        }
      }

      // Step 7: Get user's leases to handle related data
      console.log('Getting user leases...');
      const { data: userLeases, error: leasesSelectError } = await supabaseAdmin
        .from('leases')
        .select('id')
        .eq('owner_id', userId);

      if (leasesSelectError) {
        console.error('Error selecting user leases:', leasesSelectError);
        errors.push(`leases_select: ${leasesSelectError.message}`);
      } else if (userLeases && userLeases.length > 0) {
        const leaseIds = userLeases.map(l => l.id);
        console.log(`Found ${leaseIds.length} leases owned by user`);

        // Delete lease contracts for user-owned leases
        const { error: contractsLeaseError } = await supabaseAdmin
          .from('lease_contracts')
          .delete()
          .in('lease_id', leaseIds);
        if (contractsLeaseError) {
          console.error('Error deleting lease contracts:', contractsLeaseError);
          errors.push(`lease_contracts_leases: ${contractsLeaseError.message}`);
        }

        // Delete lease applications for user-owned leases
        const { error: applicationsLeaseError } = await supabaseAdmin
          .from('lease_applications')
          .delete()
          .in('lease_id', leaseIds);
        if (applicationsLeaseError) {
          console.error(
            'Error deleting lease applications:',
            applicationsLeaseError,
          );
          errors.push(
            `lease_applications_leases: ${applicationsLeaseError.message}`,
          );
        }
      }

      // Step 8: Delete user-specific lease records
      console.log('Deleting user lease contracts...');
      const { error: contractsUserError } = await supabaseAdmin
        .from('lease_contracts')
        .delete()
        .or(`tenant_id.eq.${userId},owner_id.eq.${userId}`);
      if (contractsUserError) {
        console.error(
          'Error deleting user lease contracts:',
          contractsUserError,
        );
        errors.push(`user_lease_contracts: ${contractsUserError.message}`);
      }

      console.log('Deleting user lease applications...');
      const { error: applicationsUserError } = await supabaseAdmin
        .from('lease_applications')
        .delete()
        .or(`applicant_id.eq.${userId},owner_id.eq.${userId}`);
      if (applicationsUserError) {
        console.error(
          'Error deleting user lease applications:',
          applicationsUserError,
        );
        errors.push(
          `user_lease_applications: ${applicationsUserError.message}`,
        );
      }

      // Step 9: Delete remaining user orders (wallet transactions should already be deleted)
      console.log('Deleting user orders...');
      const { error: ordersUserError } = await supabaseAdmin
        .from('orders')
        .delete()
        .or(`user_id.eq.${userId},farmer_id.eq.${userId}`);
      if (ordersUserError) {
        console.error('Error deleting user orders:', ordersUserError);
        errors.push(`user_orders: ${ordersUserError.message}`);
      }

      // Step 10: Delete user's leases and products
      console.log('Deleting user leases...');
      const { error: leasesError } = await supabaseAdmin
        .from('leases')
        .delete()
        .eq('owner_id', userId);
      if (leasesError) {
        console.error('Error deleting user leases:', leasesError);
        errors.push(`user_leases: ${leasesError.message}`);
      }

      console.log('Deleting user products...');
      const { error: productsError } = await supabaseAdmin
        .from('products')
        .delete()
        .eq('farmer_id', userId);
      if (productsError) {
        console.error('Error deleting user products:', productsError);
        errors.push(`user_products: ${productsError.message}`);
      }

      // Step 11: Finally delete user profile (after all references are removed)
      console.log('Deleting user profile...');
      const { error: userError } = await supabaseAdmin
        .from('users')
        .delete()
        .eq('id', userId);
      if (userError) {
        console.error('Error deleting user profile:', userError);
        errors.push(`user_profile: ${userError.message}`);
      }

      if (errors.length > 0) {
        console.warn(
          `User data deletion completed with ${errors.length} errors:`,
          errors,
        );
      } else {
        console.log('User data deletion completed successfully');
      }
    } catch (error) {
      console.error('Error during user data deletion:', error);
      throw error;
    }
  }
}

export default SupabaseAuthManager;
