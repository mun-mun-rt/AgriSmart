import { supabase } from '../utils/supabase';

export class SupabaseDatabaseSeeder {
  /**
   * Seeds the default app information
   */
  static async seedAppInfo(): Promise<void> {
    try {
      console.log('🌱 Seeding default app information...');

      // Check if app info already exists
      const { data: existingAppInfo } = await supabase
        .from('app_info')
        .select('*')
        .limit(1)
        .single();

      if (existingAppInfo) {
        console.log('ℹ️ App information already exists');
        return;
      }

      // Create default app info
      const { error } = await supabase.from('app_info').insert({
        app_name: 'AgriSmart Bangladesh',
        welcome_message:
          'Welcome to AgriSmart Bangladesh - Your farming companion',
        contact_email: 'support@AgriSmart.bd',
        version: '1.0.0',
      });

      if (error) {
        console.error('❌ Error creating app info:', error);
        return;
      }

      console.log('✅ Default app information created successfully');
    } catch (error) {
      console.error('❌ Error seeding app information:', error);
    }
  }

  /**
   * Main seeding function that runs all seeders
   */
  static async seedAll(): Promise<void> {
    try {
      console.log('🌱 Starting complete database seeding...');

      await SupabaseDatabaseSeeder.seedAppInfo();
      console.log('✅ Database seeding completed successfully');
    } catch (error) {
      console.error('❌ Error in complete database seeding:', error);
    }
  }
}

export default SupabaseDatabaseSeeder;
