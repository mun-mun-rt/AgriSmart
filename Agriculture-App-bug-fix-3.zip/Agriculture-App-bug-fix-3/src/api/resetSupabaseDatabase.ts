import { supabase } from '../utils/supabase';

/**
 * Supabase Database Reset Utility
 * This module provides functions to reset/clear data from Supabase tables
 * Use with caution - this will delete all data!
 */

/**
 * Reset all user data (except admin)
 */
export async function resetUsers(): Promise<void> {
  try {
    console.log('🗑️ Resetting users table...');

    // Delete all users except admin
    const { error } = await supabase
      .from('users')
      .delete()
      .neq('email', 'admin@agriapp.com');

    if (error) {
      console.error('❌ Error resetting users:', error);
      throw error;
    }

    console.log('✅ Users table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset users:', error);
    throw error;
  }
}

/**
 * Reset all products
 */
export async function resetProducts(): Promise<void> {
  try {
    console.log('🗑️ Resetting products table...');

    const { error } = await supabase.from('products').delete().neq('id', 0); // Delete all products

    if (error) {
      console.error('❌ Error resetting products:', error);
      throw error;
    }

    console.log('✅ Products table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset products:', error);
    throw error;
  }
}

/**
 * Reset all orders
 */
export async function resetOrders(): Promise<void> {
  try {
    console.log('🗑️ Resetting orders table...');

    const { error } = await supabase.from('orders').delete().neq('id', 0); // Delete all orders

    if (error) {
      console.error('❌ Error resetting orders:', error);
      throw error;
    }

    console.log('✅ Orders table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset orders:', error);
    throw error;
  }
}

/**
 * Reset all land leases
 */
export async function resetLeases(): Promise<void> {
  try {
    console.log('🗑️ Resetting leases table...');

    const { error } = await supabase.from('leases').delete().neq('id', 0); // Delete all leases

    if (error) {
      console.error('❌ Error resetting leases:', error);
      throw error;
    }

    console.log('✅ Leases table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset leases:', error);
    throw error;
  }
}

/**
 * Reset all lease applications
 */
export async function resetLeaseApplications(): Promise<void> {
  try {
    console.log('🗑️ Resetting lease applications table...');

    const { error } = await supabase
      .from('lease_applications')
      .delete()
      .neq('id', 0); // Delete all lease applications

    if (error) {
      console.error('❌ Error resetting lease applications:', error);
      throw error;
    }

    console.log('✅ Lease applications table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset lease applications:', error);
    throw error;
  }
}

/**
 * Reset all lease contracts
 */
export async function resetLeaseContracts(): Promise<void> {
  try {
    console.log('🗑️ Resetting lease contracts table...');

    const { error } = await supabase
      .from('lease_contracts')
      .delete()
      .neq('id', 0); // Delete all lease contracts

    if (error) {
      console.error('❌ Error resetting lease contracts:', error);
      throw error;
    }

    console.log('✅ Lease contracts table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset lease contracts:', error);
    throw error;
  }
}

/**
 * Reset shopping cart
 */
export async function resetShoppingCart(): Promise<void> {
  try {
    console.log('🗑️ Resetting shopping cart table...');

    const { error } = await supabase
      .from('shopping_cart')
      .delete()
      .neq('id', 0); // Delete all cart items

    if (error) {
      console.error('❌ Error resetting shopping cart:', error);
      throw error;
    }

    console.log('✅ Shopping cart table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset shopping cart:', error);
    throw error;
  }
}

/**
 * Reset wallet transactions
 */
export async function resetWalletTransactions(): Promise<void> {
  try {
    console.log('🗑️ Resetting wallet transactions table...');

    const { error } = await supabase
      .from('wallet_transactions')
      .delete()
      .neq('id', 0); // Delete all transactions

    if (error) {
      console.error('❌ Error resetting wallet transactions:', error);
      throw error;
    }

    console.log('✅ Wallet transactions table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset wallet transactions:', error);
    throw error;
  }
}

/**
 * Reset messages
 */
export async function resetMessages(): Promise<void> {
  try {
    console.log('🗑️ Resetting messages table...');

    const { error } = await supabase.from('messages').delete().neq('id', 0); // Delete all messages

    if (error) {
      console.error('❌ Error resetting messages:', error);
      throw error;
    }

    console.log('✅ Messages table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset messages:', error);
    throw error;
  }
}

/**
 * Reset followers table
 */
export async function resetFollowers(): Promise<void> {
  try {
    console.log('🗑️ Resetting followers table...');

    const { error } = await supabase.from('followers').delete().neq('id', 0); // Delete all follower relationships

    if (error) {
      console.error('❌ Error resetting followers:', error);
      throw error;
    }

    console.log('✅ Followers table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset followers:', error);
    throw error;
  }
}

/**
 * Reset weather cache
 */
export async function resetWeatherCache(): Promise<void> {
  try {
    console.log('🗑️ Resetting weather cache table...');

    const { error } = await supabase
      .from('weather_cache')
      .delete()
      .neq('id', 0); // Delete all cached weather data

    if (error) {
      console.error('❌ Error resetting weather cache:', error);
      throw error;
    }

    console.log('✅ Weather cache table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset weather cache:', error);
    throw error;
  }
}

/**
 * Reset fertilizer guides (use with caution)
 */
export async function resetFertilizerGuides(): Promise<void> {
  try {
    console.log('🗑️ Resetting fertilizer guides table...');

    // First delete guide-product relationships
    const { error: guideProductsError } = await supabase
      .from('fertilizer_guide_products')
      .delete()
      .neq('id', 0);

    if (guideProductsError) {
      console.error(
        '❌ Error resetting fertilizer guide products:',
        guideProductsError,
      );
      throw guideProductsError;
    }

    // Then delete guides
    const { error } = await supabase
      .from('fertilizer_guides')
      .delete()
      .neq('id', 0);

    if (error) {
      console.error('❌ Error resetting fertilizer guides:', error);
      throw error;
    }

    console.log('✅ Fertilizer guides table reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset fertilizer guides:', error);
    throw error;
  }
}

/**
 * Reset all user-generated data (keeps admin, app_info, categories, and fertilizer guides)
 */
export async function resetUserData(): Promise<void> {
  try {
    console.log('🗑️ Starting user data reset...');

    // Reset in order to avoid foreign key constraints
    await resetShoppingCart();
    await resetWalletTransactions();
    await resetMessages();
    await resetFollowers();
    await resetLeaseContracts();
    await resetLeaseApplications();
    await resetLeases();
    await resetOrders();
    await resetProducts();
    await resetUsers();
    await resetWeatherCache();

    console.log('✅ All user data reset successfully');
  } catch (error) {
    console.error('❌ Failed to reset user data:', error);
    throw error;
  }
}

/**
 * Complete database reset (use with extreme caution!)
 */
export async function resetAllData(): Promise<void> {
  try {
    console.log('🗑️ Starting complete database reset...');
    console.warn(
      '⚠️ This will delete ALL data including admin user and guides!',
    );

    // Reset everything
    await resetUserData();
    await resetFertilizerGuides();

    // Reset app_info
    const { error: appInfoError } = await supabase
      .from('app_info')
      .delete()
      .neq('id', 0);

    if (appInfoError) {
      console.error('❌ Error resetting app info:', appInfoError);
      throw appInfoError;
    }

    console.log('✅ Complete database reset successful');
    console.log(
      'ℹ️ You will need to run the seeder again to restore basic data',
    );
  } catch (error) {
    console.error('❌ Failed to reset all data:', error);
    throw error;
  }
}

/**
 * Get database statistics
 */
export async function getDatabaseStats(): Promise<void> {
  try {
    console.log('📊 Database Statistics:');

    const tables = [
      'users',
      'products',
      'orders',
      'leases',
      'lease_applications',
      'lease_contracts',
      'shopping_cart',
      'wallet_transactions',
      'messages',
      'followers',
      'fertilizer_guides',
      'weather_cache',
      'app_info',
      'product_categories',
    ];

    for (const table of tables) {
      try {
        const { count, error } = await supabase
          .from(table)
          .select('*', { count: 'exact', head: true });

        if (error) {
          console.log(`❌ ${table}: Error getting count`);
        } else {
          console.log(`📋 ${table}: ${count} records`);
        }
      } catch (tableError) {
        console.log(`❌ ${table}: Error accessing table`);
      }
    }
  } catch (error) {
    console.error('❌ Failed to get database stats:', error);
  }
}

// Export default function for easy import
export default {
  resetUsers,
  resetProducts,
  resetOrders,
  resetLeases,
  resetLeaseApplications,
  resetLeaseContracts,
  resetShoppingCart,
  resetWalletTransactions,
  resetMessages,
  resetFollowers,
  resetWeatherCache,
  resetFertilizerGuides,
  resetUserData,
  resetAllData,
  getDatabaseStats,
};
