import { supabase, supabaseAdmin } from '../utils/supabase';
import { buildRoomId } from '../utils';
import {
  User,
  FertilizerGuide,
  AppInfo,
  ShoppingCartItem,
  ProductCategory,
  WalletTransaction,
  Message, // Add Message type import
  SystemPaymentAccount,
  SystemVaultTransaction,
  SystemVaultBalance,
  PaymentMethodKey,
} from '../types/index';

export interface FarmerAggregateStats {
  productCount: number;
  leaseCount: number;
  followerCount: number;
  followingCount: number;
  totalSoldQuantity: number;
  topProductName: string | null;
  topProductQuantity: number;
}

export interface ConsumerAggregateStats {
  orderCount: number;
  totalSpent: number;
  leaseApplicationCount: number;
  leaseContractCount: number;
  followingCount: number;
  followerCount: number;
  topProductName: string | null;
  topProductQuantity: number;
}

const DEFAULT_APP_INFO_VALUES = {
  app_name: 'AgriSmart Bangladesh',
  app_logo_url: '',
  welcome_message: 'Welcome to AgriSmart Bangladesh',
  contact_email: 'support@AgriSmart.bd',
  version: '1.0.0',
} as const;

export type CartConstraintReason = 'min' | 'max' | 'stock';

export interface CartConstraintDetails {
  reason: CartConstraintReason;
  minPurchase: number;
  maxPurchase: number | null;
  availableStock?: number | null;
}

export interface AddToCartResult {
  quantity: number;
  minPurchase: number;
  maxPurchase: number | null;
  adjustedToMin: boolean;
  adjustedToMax: boolean;
  adjustedToStock: boolean;
}

export interface UpdateCartQuantityResult {
  quantity: number;
  minPurchase: number;
  maxPurchase: number | null;
  availableStock: number | null;
}

export class CartConstraintError extends Error {
  public readonly details: CartConstraintDetails;

  constructor(details: CartConstraintDetails, message?: string) {
    super(message ?? CartConstraintError.buildMessage(details));
    this.name = 'CartConstraintError';
    this.details = details;
  }

  private static buildMessage(details: CartConstraintDetails): string {
    switch (details.reason) {
      case 'min':
        return `Minimum purchase requirement is ${details.minPurchase}`;
      case 'max':
        return details.maxPurchase !== null
          ? `Maximum purchase per order is ${details.maxPurchase}`
          : 'Maximum purchase limit reached';
      case 'stock':
      default:
        if (typeof details.availableStock === 'number') {
          return `Only ${details.availableStock} item(s) are currently available`;
        }
        return 'Insufficient stock to complete this action';
    }
  }
}

const parseNumeric = (value: unknown): number | null => {
  if (typeof value === 'number' && !Number.isNaN(value)) {
    return value;
  }
  if (typeof value === 'string') {
    const parsed = Number(value);
    if (!Number.isNaN(parsed)) {
      return parsed;
    }
  }
  return null;
};

const resolveMinPurchase = (value: unknown): number => {
  const parsed = parseNumeric(value);
  const floored = parsed !== null ? Math.floor(parsed) : 1;
  return floored >= 1 ? floored : 1;
};

const resolveMaxPurchase = (
  value: unknown,
  minPurchase: number,
): number | null => {
  const parsed = parseNumeric(value);
  if (parsed === null) {
    return null;
  }
  const floored = Math.floor(parsed);
  if (Number.isNaN(floored)) {
    return null;
  }
  return floored < minPurchase ? minPurchase : floored;
};

const resolveAvailableStock = (product: any): number | null => {
  const stockOptions = [product?.stock, product?.quantity];
  for (const option of stockOptions) {
    const parsed = parseNumeric(option);
    if (parsed !== null) {
      return Math.floor(parsed);
    }
  }
  return null;
};

class SupabaseDatabaseManager {
  /**
   * Call this function after updating an order's status to 'cancelled' or 'approved'.
   * Example usage in your order management logic:
   *
   *   // After updating order status to 'cancelled':
   *   await dbManager.handleOrderWalletUpdate(orderId, 'cancelled');
   *
   *   // After updating order status to 'approved':
   *   await dbManager.handleOrderWalletUpdate(orderId, 'approved');
   *
   * This will automatically refund the buyer or pay the owner as needed.
   */
  /**
   * Handles wallet updates for order status changes with vault support.
   * - If order is cancelled:
   *   - For vault payments (bank/mobile banking): releases pending amount from vault to buyer's wallet
   *   - For AgriWallet payments: refunds amount to buyer's wallet
   * - If order is approved:
   *   - For vault payments (bank/mobile banking): transfers pending amount from vault to farmer's wallet
   *   - For AgriWallet payments: transfers amount to farmer's wallet
   * - Cash on Delivery: no wallet/vault operations
   *
   * @param orderId - The order ID
   * @param newStatus - The new status ('cancelled' or 'approved')
   * @returns Promise<boolean> - true if wallet/vault updated, false otherwise
   */
  async handleOrderWalletUpdate(
    orderId: number,
    newStatus: 'cancelled' | 'approved',
  ): Promise<boolean> {
    try {
      // Fetch order details including payment_method
      const { data: order, error } = await supabase
        .from('orders')
        .select('id, user_id, farmer_id, total_price, status, payment_method')
        .eq('id', orderId)
        .single();
      if (error || !order) {
        console.error('Order not found or error:', error);
        return false;
      }

      const paymentMethod = (order.payment_method || '').toLowerCase();
      const amount = Number(order.total_price);

      // Skip processing for Cash on Delivery
      if (paymentMethod === 'cash on delivery' || paymentMethod === 'cod') {
        console.log(
          `Order #${orderId} ${newStatus} - No wallet/vault operations for Cash on Delivery`,
        );
        return true;
      }

      // Check if payment was through vault (bank transfer or mobile banking)
      const isVaultPayment =
        paymentMethod.includes('bank') || paymentMethod.includes('mobile');

      if (newStatus === 'cancelled') {
        if (isVaultPayment) {
          // Release from vault to buyer's wallet
          await this.releaseVaultToWallet(
            orderId,
            order.farmer_id,
            order.user_id,
            amount,
            'refund',
          );
          console.log(
            `Order #${orderId} cancelled - Vault refund processed for ${paymentMethod}`,
          );
        } else {
          // Direct wallet refund for AgriWallet
          await this.updateUserWalletBalance(order.user_id, amount, 'add');
          await this.createWalletTransaction({
            user_id: order.user_id,
            amount: amount,
            transaction_type: 'refund',
            description: `Order #${orderId} cancelled refund`,
            related_order_id: orderId,
          });
          console.log(
            `Order #${orderId} cancelled - Wallet refund processed for ${paymentMethod}`,
          );
        }
        return true;
      } else if (newStatus === 'approved') {
        if (isVaultPayment) {
          // Transfer from vault to farmer's wallet
          await this.releaseVaultToWallet(
            orderId,
            order.farmer_id,
            order.farmer_id,
            amount,
            'payment_received',
          );
          console.log(
            `Order #${orderId} approved - Vault payment transferred for ${paymentMethod}`,
          );
        } else {
          // Direct wallet payment for AgriWallet
          await this.updateUserWalletBalance(order.farmer_id, amount, 'add');
          await this.createWalletTransaction({
            user_id: order.farmer_id,
            amount: amount,
            transaction_type: 'payment_received',
            description: `Order #${orderId} payment received`,
            related_order_id: orderId,
          });
          console.log(
            `Order #${orderId} approved - Wallet payment processed for ${paymentMethod}`,
          );
        }
        return true;
      }
      return false;
    } catch (err) {
      console.error('Error in handleOrderWalletUpdate:', err);
      return false;
    }
  }
  private static instance: SupabaseDatabaseManager;

  private constructor() {}

  private sanitizeNullableString(value?: string | null): string | null {
    if (value === undefined || value === null) {
      return null;
    }
    const trimmed = value.trim();
    return trimmed.length > 0 ? trimmed : null;
  }

  private async getCurrentUserId(): Promise<string | null> {
    try {
      const { data, error } = await supabase.auth.getUser();
      if (error) {
        console.warn(
          'Error retrieving current user for system updates:',
          error,
        );
        return null;
      }
      return data?.user?.id ?? null;
    } catch (error) {
      console.warn('Unexpected error retrieving current user:', error);
      return null;
    }
  }

  private async requireAdmin(): Promise<string> {
    const userId = await this.getCurrentUserId();
    if (!userId) {
      throw new Error('Administrator authentication required.');
    }

    try {
      const { data, error } = await supabase
        .from('users')
        .select('id, role')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        throw error;
      }

      if (!data || data.role !== 'admin') {
        throw new Error('Administrator authentication required.');
      }

      return userId;
    } catch (error) {
      console.error('Error verifying admin privileges:', error);
      throw new Error('Administrator authentication required.');
    }
  }

  static getInstance(): SupabaseDatabaseManager {
    if (!SupabaseDatabaseManager.instance) {
      SupabaseDatabaseManager.instance = new SupabaseDatabaseManager();
    }
    return SupabaseDatabaseManager.instance;
  }

  async initializeDatabase(): Promise<void> {
    try {
      console.log('Supabase database connection initialized');
    } catch (error) {
      console.error('Database initialization failed:', error);
      throw error;
    }
  }

  // User Management Methods
  async createUser(userData: {
    name: string;
    email: string;
    role: string;
    password?: string;
    wallet_balance?: number;
  }): Promise<number> {
    try {
      if (userData.email && userData.password) {
        // For users with authentication
        const { data: authData, error: authError } = await supabase.auth.signUp(
          {
            email: userData.email,
            password: userData.password,
          },
        );

        if (authError) throw authError;

        if (authData.user) {
          // Insert user profile data
          const { data, error } = await supabase
            .from('users')
            .insert({
              id: authData.user.id,
              name: userData.name,
              email: userData.email,
              role: userData.role,
              wallet_balance: userData.wallet_balance || 0,
            })
            .select(
              'id, name, email, phone, role, is_active, wallet_balance, created_at, address_line1, address_line2, city, state, postal_code, country, profile_image_url, bio, farm_name, farm_size, farming_experience, specialization, mobile_banking_bkash, mobile_banking_nagad, mobile_banking_rocket',
            )
            .single();
          if (error) throw error;
          return data.id;
        }
      } else {
        // For guest users or system-created users without auth
        const { data, error } = await supabase
          .from('users')
          .insert({
            name: userData.name,
            email: userData.email,
            role: userData.role,
            wallet_balance: userData.wallet_balance || 0,
          })
          .select()
          .single();

        if (error) throw error;
        return data.id;
      }

      throw new Error('Failed to create user');
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }

  /**
   * Fetch multiple users by an array of user IDs (UUIDs). Returns a map of userId to user object.
   */
  async getUsersByIds(userIds: string[]): Promise<Record<string, User>> {
    if (!userIds || userIds.length === 0) return {};
    try {
      // Ensure all IDs are strings (UUIDs)
      const ids = userIds.map(id => String(id));
      const { data, error } = await supabase
        .from('users')
        .select(
          'id, name, email, phone, role, is_active, wallet_balance, created_at, address_line1, address_line2, city, state, postal_code, country, profile_image_url, bio, farm_name, farm_size, farming_experience, specialization',
        )
        .in('id', ids);
      if (error) {
        console.error('Supabase error in getUsersByIds:', error);
        return {};
      }
      if (!data || !Array.isArray(data) || data.length === 0) {
        console.warn('No users found for IDs:', ids);
        return {};
      }
      const userMap: Record<string, User> = {};
      data.forEach((u: any) => {
        userMap[String(u.id)] = {
          id: u.id,
          name: u.name,
          email: u.email,
          phone: u.phone,
          role: u.role,
          is_active: u.is_active,
          wallet_balance: u.wallet_balance,
          created_at: u.created_at,
          // Profile fields
          profile_image_url: u.profile_image_url,
          bio: u.bio,
          mobile_banking_bkash: u.mobile_banking_bkash,
          mobile_banking_nagad: u.mobile_banking_nagad,
          mobile_banking_rocket: u.mobile_banking_rocket,
          // Professional fields
          farm_name: u.farm_name,
          farm_size: u.farm_size,
          farming_experience: u.farming_experience,
          specialization: u.specialization,
          // Address fields
          address_line1: u.address_line1,
          address_line2: u.address_line2,
          city: u.city,
          state: u.state,
          postal_code: u.postal_code,
          country: u.country,
        };
      });
      return userMap;
    } catch (err) {
      console.error('Error fetching users by ids:', err);
      return {};
    }
  }

  async getUserByEmail(email: string): Promise<User | null> {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('email', email)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null; // No rows found
        throw error;
      }

      // Return full user row as User (supabase row should match User interface)
      return data as User;
    } catch (error) {
      console.error('Error getting user by email:', error);
      throw error;
    }
  }

  async getUserById(id: string): Promise<User | null> {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', id)
        .single();
      if (error) {
        console.error('Error getting user by ID:', error);
        return null;
      }
      return data as User;
    } catch (error) {
      console.error('Error getting user by ID:', error);
      return null;
    }
  }

  /**
   * Returns the user's name for a given userId (UUID). Returns null if not found.
   */
  async getUserNameById(userId: string): Promise<string | null> {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('name')
        .eq('id', userId)
        .single();
      if (error || !data) {
        return null;
      }
      return data.name || null;
    } catch (err) {
      console.error('Error fetching user name by id:', err);
      return null;
    }
  }

  async getAllUsers(): Promise<User[]> {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Return rows as User objects
      return data.map((row: any) => row as User);
    } catch (error) {
      console.error('Error getting all users:', error);
      throw error;
    }
  }

  async getUsersByRole(role: string): Promise<User[]> {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('role', role)
        .order('created_at', { ascending: false });

      if (error) throw error;

      return data.map((row: any) => row as User);
    } catch (error) {
      console.error('Error getting users by role:', error);
      throw error;
    }
  }

  async updateUser(userId: number, updateData: Partial<User>): Promise<void> {
    try {
      const { error } = await supabase
        .from('users')
        .update(updateData)
        .eq('id', userId);

      if (error) throw error;
    } catch (error) {
      console.error('Error updating user:', error);
      throw error;
    }
  }

  async deleteUser(userId: number): Promise<void> {
    try {
      const { error } = await supabase.from('users').delete().eq('id', userId);

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting user:', error);
      throw error;
    }
  }

  /**
   * Fetches all products belonging to the current logged-in user (farmer).
   * If a farmerId is provided, fetches products for that farmer.
   * @param farmerId - Optional farmer UUID. If not provided, uses current user.
   */
  async getCurrentUserProducts(farmerId?: string): Promise<any[]> {
    let id = farmerId;
    if (!id) {
      // Get current authenticated user
      const { data, error } = await supabase.auth.getUser();
      if (error || !data?.user?.id) {
        throw new Error('Unable to determine current user');
      }
      id = data.user.id;
    }
    // Query products for this farmer
    const { data: products, error: prodError } = await supabase
      .from('products')
      .select('*')
      .eq('farmer_id', id);
    if (prodError) {
      throw new Error(prodError.message || 'Failed to fetch user products');
    }
    return products || [];
  }
  // (Removed duplicate static instance and constructor)

  /**
   * Updates the stock (quantity) of a product by its productId.
   * @param productId - The id of the product to update
   * @param newStock - The new stock quantity
   */
  async updateProductStock(productId: number, newStock: number): Promise<void> {
    // Updates the 'quantity' field in the products table
    const { error } = await supabase
      .from('products')
      .update({ quantity: newStock, updated_at: new Date().toISOString() })
      .eq('id', productId);
    if (error) {
      throw new Error(error.message || 'Failed to update product stock');
    }
  }

  // Fertilizer Guide Methods
  async createFertilizerGuide(guideData: {
    crop_name: string;
    fertilizer_type: string;
    amount: string;
    timing: string;
    instructions?: string;
  }): Promise<number> {
    try {
      const { data, error } = await supabase
        .from('fertilizer_guides')
        .insert(guideData)
        .select()
        .single();

      if (error) throw error;
      return data.id;
    } catch (error) {
      console.error('Error creating fertilizer guide:', error);
      throw error;
    }
  }

  async getAllFertilizerGuides(): Promise<FertilizerGuide[]> {
    try {
      const { data, error } = await supabase
        .from('fertilizer_guides')
        .select('*')
        .order('crop_name', { ascending: true });

      if (error) throw error;

      return data.map(row => ({
        id: row.id,
        crop_name: row.crop_name,
        fertilizer_type: row.fertilizer_type,
        amount: row.amount,
        timing: row.timing,
        instructions: row.instructions,
        created_at: row.created_at,
      }));
    } catch (error) {
      console.error('Error getting fertilizer guides:', error);
      throw error;
    }
  }

  async getAllFertilizerGuidesWithProducts(): Promise<FertilizerGuide[]> {
    try {
      // Get fertilizer guides with their associated products
      const { data, error } = await supabase
        .from('fertilizer_guides')
        .select(`*, fertilizer_guide_products (product_id, products (*))`)
        .order('crop_name', { ascending: true });

      if (error) throw error;

      return data.map(row => ({
        id: row.id,
        crop_name: row.crop_name,
        fertilizer_type: row.fertilizer_type,
        amount: row.amount,
        timing: row.timing,
        instructions: row.instructions,
        created_at: row.created_at,
        related_products:
          row.fertilizer_guide_products?.map((fgp: any) => fgp.products) || [],
      }));
    } catch (error) {
      console.error('Error getting fertilizer guides with products:', error);
      throw error;
    }
  }

  async getFertilizerGuideById(id: number): Promise<FertilizerGuide | null> {
    try {
      const { data, error } = await supabase
        .from('fertilizer_guides')
        .select('*')
        .eq('id', id)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw error;
      }

      return {
        id: data.id,
        crop_name: data.crop_name,
        fertilizer_type: data.fertilizer_type,
        amount: data.amount,
        timing: data.timing,
        instructions: data.instructions,
        created_at: data.created_at,
      };
    } catch (error) {
      console.error('Error getting fertilizer guide by ID:', error);
      throw error;
    }
  }

  async getFertilizerGuidesByCrop(
    cropName: string,
  ): Promise<FertilizerGuide[]> {
    try {
      const { data, error } = await supabase
        .from('fertilizer_guides')
        .select('*')
        .ilike('crop_name', `%${cropName}%`)
        .order('fertilizer_type', { ascending: true });

      if (error) throw error;

      return data.map(row => ({
        id: row.id,
        crop_name: row.crop_name,
        fertilizer_type: row.fertilizer_type,
        amount: row.amount,
        timing: row.timing,
        instructions: row.instructions,
        created_at: row.created_at,
      }));
    } catch (error) {
      console.error('Error getting fertilizer guides by crop:', error);
      throw error;
    }
  }

  async updateFertilizerGuide(
    id: number,
    updateData: Partial<FertilizerGuide>,
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('fertilizer_guides')
        .update(updateData)
        .eq('id', id);

      if (error) throw error;
    } catch (error) {
      console.error('Error updating fertilizer guide:', error);
      throw error;
    }
  }

  async deleteFertilizerGuide(id: number): Promise<void> {
    try {
      const { error } = await supabase
        .from('fertilizer_guides')
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting fertilizer guide:', error);
      throw error;
    }
  }

  // Fertilizer Guide Products Methods
  async addProductToFertilizerGuide(
    guideId: number,
    productId: number,
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('fertilizer_guide_products')
        .insert({
          fertilizer_guide_id: guideId,
          product_id: productId,
        });

      if (error) throw error;
    } catch (error) {
      console.error('Error adding product to fertilizer guide:', error);
      throw error;
    }
  }

  async removeProductFromFertilizerGuide(
    guideId: number,
    productId: number,
  ): Promise<void> {
    try {
      const { error } = await supabase
        .from('fertilizer_guide_products')
        .delete()
        .eq('fertilizer_guide_id', guideId)
        .eq('product_id', productId);

      if (error) throw error;
    } catch (error) {
      console.error('Error removing product from fertilizer guide:', error);
      throw error;
    }
  }

  async getFertilizerGuideProducts(guideId: number): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('fertilizer_guide_products')
        .select(
          `
          products (*)
        `,
        )
        .eq('fertilizer_guide_id', guideId);

      if (error) throw error;

      return data.map(row => row.products);
    } catch (error) {
      console.error('Error getting fertilizer guide products:', error);
      throw error;
    }
  }

  public async getAvailableProductsForFertilizerGuide(): Promise<any[]> {
    //  fetch all products from the 'products' table
    const { data, error } = await supabase.from('products').select('*');
    if (error) {
      throw error;
    }
    return data || [];
  }

  async updateFertilizerGuideProducts(
    fertilizerGuideId: number,
    productIds: number[],
  ): Promise<void> {
    // Remove existing relations
    await supabase
      .from('fertilizer_guide_products')
      .delete()
      .eq('fertilizer_guide_id', fertilizerGuideId);

    // Insert new relations
    if (productIds.length > 0) {
      const insertData = productIds.map(productId => ({
        fertilizer_guide_id: fertilizerGuideId,
        product_id: productId,
      }));
      await supabase.from('fertilizer_guide_products').insert(insertData);
    }
  }

  // App Info Methods
  async getAppInfo(): Promise<AppInfo | null> {
    try {
      const { data, error } = await supabase
        .from('app_info')
        .select('*')
        .order('updated_at', { ascending: false })
        .order('id', { ascending: true })
        .limit(1)
        .maybeSingle();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw error;
      }

      if (!data) {
        return null;
      }

      return {
        id: data.id,
        app_name: data.app_name,
        app_logo_url: data.app_logo_url,
        welcome_message: data.welcome_message,
        contact_email: data.contact_email,
        version: data.version,
        updated_at: data.updated_at,
      };
    } catch (error) {
      console.error('Error getting app info:', error);
      throw error;
    }
  }

  async updateAppInfo(updateData: Partial<AppInfo>): Promise<void> {
    try {
      const { data: currentRecord, error: fetchError } = await supabase
        .from('app_info')
        .select('*')
        .order('updated_at', { ascending: false })
        .order('id', { ascending: true })
        .limit(1)
        .maybeSingle();

      if (fetchError) {
        throw fetchError;
      }

      const targetId = currentRecord?.id ?? 1;
      const {
        id: _ignoredId,
        updated_at: _ignoredUpdatedAt,
        ...appInfoWithoutId
      } = updateData;

      const payload = {
        id: targetId,
        app_name:
          appInfoWithoutId.app_name ??
          currentRecord?.app_name ??
          DEFAULT_APP_INFO_VALUES.app_name,
        app_logo_url:
          appInfoWithoutId.app_logo_url ??
          currentRecord?.app_logo_url ??
          DEFAULT_APP_INFO_VALUES.app_logo_url,
        welcome_message:
          appInfoWithoutId.welcome_message ??
          currentRecord?.welcome_message ??
          DEFAULT_APP_INFO_VALUES.welcome_message,
        contact_email:
          appInfoWithoutId.contact_email ??
          currentRecord?.contact_email ??
          DEFAULT_APP_INFO_VALUES.contact_email,
        version:
          appInfoWithoutId.version ??
          currentRecord?.version ??
          DEFAULT_APP_INFO_VALUES.version,
        updated_at: new Date().toISOString(),
      };

      const { error: upsertError } = await supabase
        .from('app_info')
        .upsert(payload, { onConflict: 'id' });

      if (upsertError) {
        throw upsertError;
      }

      const { error: cleanupError } = await supabase
        .from('app_info')
        .delete()
        .neq('id', targetId);

      if (cleanupError) {
        console.warn('Warning cleaning duplicate app_info rows:', cleanupError);
      }
    } catch (error) {
      console.error('Error updating app info:', error);
      throw error;
    }
  }

  // System Payment & Vault Methods
  async getSystemPaymentAccounts(
    includeInactive = false,
  ): Promise<SystemPaymentAccount[]> {
    try {
      const query = supabase
        .from('system_payment_accounts')
        .select(
          'id, method, provider, label, account_name, account_number, bank_name, branch_name, instructions, is_primary, is_active, updated_by, created_at, updated_at',
        )
        .order('is_primary', { ascending: false })
        .order('updated_at', { ascending: false });

      if (!includeInactive) {
        query.eq('is_active', true);
      }

      const { data, error } = await query;
      if (error) {
        console.error('Error fetching system payment accounts:', error);
        return [];
      }
      return (data || []) as SystemPaymentAccount[];
    } catch (error) {
      console.error('Error fetching system payment accounts:', error);
      return [];
    }
  }

  async getSystemPaymentAccountById(
    id: string,
  ): Promise<SystemPaymentAccount | null> {
    if (!id) {
      return null;
    }
    try {
      const { data, error } = await supabase
        .from('system_payment_accounts')
        .select(
          'id, method, provider, label, account_name, account_number, bank_name, branch_name, instructions, is_primary, is_active, updated_by, created_at, updated_at',
        )
        .eq('id', id)
        .maybeSingle();

      if (error) {
        console.error('Error fetching system payment account by id:', error);
        return null;
      }

      return (data as SystemPaymentAccount) || null;
    } catch (error) {
      console.error('Error fetching system payment account by id:', error);
      return null;
    }
  }

  async createSystemPaymentAccount(account: {
    method: SystemPaymentAccount['method'];
    provider?: string | null;
    label: string;
    account_name?: string | null;
    account_number: string;
    bank_name?: string | null;
    branch_name?: string | null;
    instructions?: string | null;
    is_primary?: boolean;
    is_active?: boolean;
  }): Promise<SystemPaymentAccount | null> {
    try {
      const adminUserId = await this.requireAdmin();
      const label = account.label?.trim();
      const accountNumber = account.account_number?.trim();

      if (!label) {
        throw new Error('Account label is required.');
      }
      if (!accountNumber) {
        throw new Error('Account number is required.');
      }

      const payload = {
        method: account.method,
        provider: this.sanitizeNullableString(account.provider),
        label,
        account_name: this.sanitizeNullableString(account.account_name),
        account_number: accountNumber,
        bank_name: this.sanitizeNullableString(account.bank_name),
        branch_name: this.sanitizeNullableString(account.branch_name),
        instructions: this.sanitizeNullableString(account.instructions),
        is_primary: Boolean(account.is_primary),
        is_active: account.is_active ?? true,
        updated_by: adminUserId,
      };

      const client = supabaseAdmin ?? supabase;

      const { data, error } = await client
        .from('system_payment_accounts')
        .insert(payload)
        .select(
          'id, method, provider, label, account_name, account_number, bank_name, branch_name, instructions, is_primary, is_active, updated_by, created_at, updated_at',
        )
        .single();

      if (error) {
        console.error('Error creating system payment account:', error);
        return null;
      }

      const createdAccount = data as SystemPaymentAccount;

      if (payload.is_primary) {
        await this.setPrimarySystemPaymentAccount(
          createdAccount.id,
          createdAccount.method,
          adminUserId,
        );
        return this.getSystemPaymentAccountById(createdAccount.id);
      }

      return createdAccount;
    } catch (error) {
      console.error('Error creating system payment account:', error);
      return null;
    }
  }

  async updateSystemPaymentAccount(
    id: string,
    updates: Partial<{
      method: SystemPaymentAccount['method'];
      provider: string | null;
      label: string;
      account_name: string | null;
      account_number: string;
      bank_name: string | null;
      branch_name: string | null;
      instructions: string | null;
      is_primary: boolean;
      is_active: boolean;
    }>,
  ): Promise<SystemPaymentAccount | null> {
    if (!id) {
      return null;
    }

    try {
      const adminUserId = await this.requireAdmin();
      const sanitizedUpdates: Record<string, any> = {};

      if (updates.method !== undefined) {
        sanitizedUpdates.method = updates.method;
      }

      if (updates.provider !== undefined) {
        sanitizedUpdates.provider = this.sanitizeNullableString(
          updates.provider,
        );
      }

      if (updates.label !== undefined) {
        const trimmed = updates.label?.trim() ?? '';
        if (!trimmed) {
          throw new Error('Account label cannot be empty.');
        }
        sanitizedUpdates.label = trimmed;
      }

      if (updates.account_name !== undefined) {
        sanitizedUpdates.account_name = this.sanitizeNullableString(
          updates.account_name,
        );
      }

      if (updates.account_number !== undefined) {
        const trimmedNumber = updates.account_number?.trim() ?? '';
        if (!trimmedNumber) {
          throw new Error('Account number cannot be empty.');
        }
        sanitizedUpdates.account_number = trimmedNumber;
      }

      if (updates.bank_name !== undefined) {
        sanitizedUpdates.bank_name = this.sanitizeNullableString(
          updates.bank_name,
        );
      }

      if (updates.branch_name !== undefined) {
        sanitizedUpdates.branch_name = this.sanitizeNullableString(
          updates.branch_name,
        );
      }

      if (updates.instructions !== undefined) {
        sanitizedUpdates.instructions = this.sanitizeNullableString(
          updates.instructions,
        );
      }

      if (updates.is_primary !== undefined) {
        sanitizedUpdates.is_primary = updates.is_primary;
      }

      if (updates.is_active !== undefined) {
        sanitizedUpdates.is_active = updates.is_active;
      }

      sanitizedUpdates.updated_by = adminUserId;

      const client = supabaseAdmin ?? supabase;

      const { data, error } = await client
        .from('system_payment_accounts')
        .update(sanitizedUpdates)
        .eq('id', id)
        .select(
          'id, method, provider, label, account_name, account_number, bank_name, branch_name, instructions, is_primary, is_active, updated_by, created_at, updated_at',
        )
        .single();

      if (error) {
        console.error('Error updating system payment account:', error);
        return null;
      }

      const updatedAccount = data as SystemPaymentAccount;

      if (sanitizedUpdates.is_primary) {
        await this.setPrimarySystemPaymentAccount(
          id,
          updatedAccount.method,
          adminUserId,
        );
        return this.getSystemPaymentAccountById(id);
      }

      return updatedAccount;
    } catch (error) {
      console.error('Error updating system payment account:', error);
      return null;
    }
  }

  async setPrimarySystemPaymentAccount(
    id: string,
    method: SystemPaymentAccount['method'],
    actorId?: string,
  ): Promise<boolean> {
    if (!id || !method) {
      return false;
    }

    try {
      const adminUserId = actorId ?? (await this.requireAdmin());
      const baseUpdate: Record<string, any> = {
        is_primary: false,
        updated_by: adminUserId,
      };

      const client = supabaseAdmin ?? supabase;

      const { error: clearError } = await client
        .from('system_payment_accounts')
        .update(baseUpdate)
        .eq('method', method)
        .neq('id', id);

      if (clearError) {
        console.error(
          'Error clearing existing primary system payment accounts:',
          clearError,
        );
        return false;
      }

      const promoteUpdate: Record<string, any> = {
        is_primary: true,
        updated_by: adminUserId,
      };

      const { error: promoteError } = await client
        .from('system_payment_accounts')
        .update(promoteUpdate)
        .eq('id', id);

      if (promoteError) {
        console.error(
          'Error assigning primary system payment account:',
          promoteError,
        );
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error setting primary system payment account:', error);
      return false;
    }
  }

  async deleteSystemPaymentAccount(id: string): Promise<boolean> {
    if (!id) {
      return false;
    }

    try {
      await this.requireAdmin();
      const client = supabaseAdmin ?? supabase;

      const { error } = await client
        .from('system_payment_accounts')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting system payment account:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Error deleting system payment account:', error);
      return false;
    }
  }

  async getVaultBalance(ownerId: string): Promise<SystemVaultBalance | null> {
    if (!ownerId) {
      return null;
    }
    try {
      const { data, error } = await supabase
        .from('system_vault_balances')
        .select(
          'owner_id, pending_amount, released_amount, currency, updated_at',
        )
        .eq('owner_id', ownerId)
        .maybeSingle();

      if (error) {
        if (error.code === 'PGRST116') {
          return null;
        }
        console.error('Error fetching vault balance:', error);
        return null;
      }
      return (data as SystemVaultBalance) || null;
    } catch (error) {
      console.error('Error fetching vault balance:', error);
      return null;
    }
  }

  async getVaultTransactionsForOwner(
    ownerId: string,
  ): Promise<SystemVaultTransaction[]> {
    if (!ownerId) {
      return [];
    }
    try {
      const { data, error } = await supabase
        .from('system_vault_transactions')
        .select(
          'id, owner_id, order_id, amount, payment_method, status, notes, created_at, updated_at',
        )
        .eq('owner_id', ownerId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching vault transactions:', error);
        return [];
      }

      return (data || []) as SystemVaultTransaction[];
    } catch (error) {
      console.error('Error fetching vault transactions:', error);
      return [];
    }
  }

  // Product Methods
  async createProduct(productData: {
    farmer_id: string;
    name: string;
    description?: string;
    price: number;
    quantity?: number;
    stock?: number;
    unit?: string;
    delivery_fee?: number;
    category: string;
    category_id?: number;
    image_url?: string;
    image?: string;
    min_purchase_quantity?: number;
    max_purchase_quantity?: number | null;
  }): Promise<number> {
    try {
      const minPurchase = resolveMinPurchase(productData.min_purchase_quantity);
      const maxPurchase = resolveMaxPurchase(
        productData.max_purchase_quantity,
        minPurchase,
      );

      const payload = {
        ...productData,
        min_purchase_quantity: minPurchase,
        max_purchase_quantity: maxPurchase,
      };

      const { data, error } = await supabase
        .from('products')
        .insert(payload)
        .select()
        .single();

      if (error) throw error;
      return data.id;
    } catch (error) {
      console.error('Error creating product:', error);
      throw error;
    }
  }

  async getAllProducts(): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('products')
        .select(
          `
          *,
          users (name, email)
        `,
        )
        .order('created_at', { ascending: false });

      if (error) throw error;

      return data.map(row => ({
        ...row,
        farmer_name: row.users?.name,
        farmer_email: row.users?.email,
      }));
    } catch (error) {
      console.error('Error getting all products:', error);
      throw error;
    }
  }

  async getAllFarmerProducts(farmerId: string): Promise<any[]> {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('farmer_id', farmerId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error getting farmer products:', error);
      throw error;
    }
  }

  public async getOrderDetails(orderId: number): Promise<any | null> {
    // Since we removed FK constraints, we can't use foreign key joins anymore
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .single();

    if (error) {
      console.error('Error fetching order details:', error);
      return null;
    }

    return {
      ...data,
      // Use snapshot data first, with fallbacks
      unit_price: data.product_price || 0,
      product_unit: data.product_unit || data.unit || 'kg',
      product_name: data.product_name || 'Product (deleted)',
      product_description: data.product_description || null,
      product_category: data.product_category || null,
      product_image_url: data.product_image_url || null,
      productDeleted: !data.product_name,
      product: null, // No longer available since we don't join
    };
  }

  async getProductById(productId: number): Promise<any | null> {
    try {
      const { data, error } = await supabase
        .from('products')
        .select(
          `
          *,
          users (name, email)
        `,
        )
        .eq('id', productId)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw error;
      }

      return {
        ...data,
        farmer_name: data.users?.name,
        farmer_email: data.users?.email,
      };
    } catch (error) {
      console.error('Error getting product by ID:', error);
      throw error;
    }
  }

  async updateProduct(productId: number, updateData: any): Promise<void> {
    try {
      const { error } = await supabase
        .from('products')
        .update(updateData)
        .eq('id', productId);

      if (error) throw error;
    } catch (error) {
      console.error('Error updating product:', error);
      throw error;
    }
  }

  async deleteProduct(productId: number): Promise<void> {
    try {
      // Since we removed FK constraints and use references only,
      // we can safely delete the product while preserving historical
      // orders and cart items as records with their snapshot data
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', productId);

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting product:', error);
      throw error;
    }
  }

  // Product Categories Methods
  async getAllProductCategories(): Promise<ProductCategory[]> {
    try {
      const { data, error } = await supabase
        .from('product_categories')
        .select('*')
        .order('name', { ascending: true });

      if (error) throw error;

      return data.map(row => ({
        id: row.id,
        name: row.name,
        description: row.description,
        icon: row.icon,
        created_at: row.created_at,
      }));
    } catch (error) {
      console.error('Error getting product categories:', error);
      throw error;
    }
  }

  async getProductCategoryById(
    categoryId: number,
  ): Promise<ProductCategory | null> {
    try {
      const { data, error } = await supabase
        .from('product_categories')
        .select('*')
        .eq('id', categoryId)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw error;
      }

      return {
        id: data.id,
        name: data.name,
        description: data.description,
        icon: data.icon,
        created_at: data.created_at,
      };
    } catch (error) {
      console.error('Error getting product category by ID:', error);
      throw error;
    }
  }

  // Order Methods
  async recordVaultEntryForOrder(orderId: number): Promise<void> {
    try {
      if (!orderId) {
        return;
      }
      const { error } = await supabase.rpc('record_order_vault_entry', {
        p_order_id: orderId,
      });
      if (error) {
        console.warn(
          'record_order_vault_entry RPC error for order',
          orderId,
          error,
        );
      }
    } catch (error) {
      console.warn('recordVaultEntryForOrder error:', error);
    }
  }

  /**
   * Releases funds from system vault to user wallet.
   * This is called when an order is approved (transfer to farmer) or cancelled (refund to buyer).
   *
   * @param orderId - The order ID
   * @param ownerId - The farmer/owner ID whose vault balance to deduct from
   * @param recipientId - The user ID to receive funds in their wallet
   * @param amount - The amount to transfer
   * @param transactionType - 'payment_received' for farmer or 'refund' for buyer
   */
  async releaseVaultToWallet(
    orderId: number,
    ownerId: string,
    recipientId: string,
    amount: number,
    transactionType: 'payment_received' | 'refund',
  ): Promise<void> {
    try {
      const settlementStatus =
        transactionType === 'refund' ? 'refunded' : 'released';
      const description =
        transactionType === 'refund'
          ? `Order #${orderId} cancelled refund from vault`
          : `Order #${orderId} payment from vault`;

      const { error } = await supabase.rpc('process_vault_settlement', {
        p_order_id: orderId,
        p_owner_id: ownerId,
        p_new_status: settlementStatus,
        p_recipient_id: recipientId,
        p_wallet_transaction_type: transactionType,
        p_wallet_description: description,
      });

      if (error) {
        console.error('Failed to process vault settlement:', error);
        throw error;
      }

      console.log(
        `Processed vault settlement (${settlementStatus}) for order #${orderId}; owner: ${ownerId}; recipient: ${recipientId}; amount: ${amount}`,
      );
    } catch (error) {
      console.error('Error in releaseVaultToWallet:', error);
      throw error;
    }
  }

  async cancelVaultTransaction(
    orderId: number,
    ownerId: string,
    note?: string,
  ): Promise<void> {
    try {
      const { error } = await supabase.rpc('process_vault_settlement', {
        p_order_id: orderId,
        p_owner_id: ownerId,
        p_new_status: 'cancelled',
        p_recipient_id: null,
        p_wallet_transaction_type: null,
        p_wallet_description: null,
        p_note: note || null,
      });

      if (error) {
        console.error('Failed to cancel vault transaction:', error);
        throw error;
      }

      console.log(
        `Marked vault transaction as cancelled for order #${orderId}; owner: ${ownerId}`,
      );
    } catch (error) {
      console.error('Error cancelling vault transaction:', error);
      throw error;
    }
  }

  async createOrder(orderData: {
    user_id: string;
    product_id: number;
    quantity: number;
    total_price: number;
    payment_method_key?: PaymentMethodKey;
    payment_method?: string;
    status?: string;
    farmer_id?: string; // Optional for backward compatibility
    product_delivery_fee?: number;
    mobile_banking_provider?: string | null;
    mobile_banking_transaction_id?: string | null;
  }): Promise<number> {
    try {
      let finalOrderData = { ...orderData };

      const productQuery = await supabase
        .from('products')
        .select(
          'farmer_id, name, description, price, unit, category, image_url, delivery_fee, stock, quantity, min_purchase_quantity, max_purchase_quantity',
        )
        .eq('id', orderData.product_id)
        .single();

      if (productQuery.error || !productQuery.data) {
        throw (
          productQuery.error ||
          new Error('Product not found for order creation')
        );
      }

      const product = productQuery.data;
      const minPurchase = resolveMinPurchase(product.min_purchase_quantity);
      const maxPurchase = resolveMaxPurchase(
        product.max_purchase_quantity,
        minPurchase,
      );
      const availableStock = resolveAvailableStock(product);

      const normalizedQuantity = Math.max(
        1,
        Math.floor(parseNumeric(orderData.quantity) || 1),
      );

      if (typeof availableStock === 'number' && availableStock < minPurchase) {
        throw new CartConstraintError({
          reason: 'stock',
          minPurchase,
          maxPurchase,
          availableStock,
        });
      }

      if (normalizedQuantity < minPurchase) {
        throw new CartConstraintError({
          reason: 'min',
          minPurchase,
          maxPurchase,
          availableStock,
        });
      }

      if (maxPurchase !== null && normalizedQuantity > maxPurchase) {
        throw new CartConstraintError({
          reason: 'max',
          minPurchase,
          maxPurchase,
          availableStock,
        });
      }

      if (
        typeof availableStock === 'number' &&
        normalizedQuantity > availableStock
      ) {
        throw new CartConstraintError({
          reason: 'stock',
          minPurchase,
          maxPurchase,
          availableStock,
        });
      }

      finalOrderData.quantity = normalizedQuantity;

      // If farmer_id is not provided, fetch it from the product
      if (!finalOrderData.farmer_id) {
        finalOrderData.farmer_id = product.farmer_id;
      }

      (finalOrderData as any).product_name = product.name;
      (finalOrderData as any).product_description = product.description;
      (finalOrderData as any).product_price = product.price;
      (finalOrderData as any).product_unit = product.unit;
      (finalOrderData as any).product_category = product.category;
      (finalOrderData as any).product_image_url = product.image_url;
      (finalOrderData as any).product_delivery_fee =
        parseNumeric(product.delivery_fee) ?? 0;
      if (product.unit) {
        (finalOrderData as any).unit = product.unit;
      }

      if (
        typeof (finalOrderData as any).mobile_banking_transaction_id ===
          'string' &&
        (finalOrderData as any).mobile_banking_transaction_id
      ) {
        const trimmed = (finalOrderData as any).mobile_banking_transaction_id
          .trim()
          .toUpperCase();
        (finalOrderData as any).mobile_banking_transaction_id =
          trimmed.length > 0 ? trimmed : null;
      }

      if ((finalOrderData as any).payment_method_key) {
        (finalOrderData as any).payment_method_key = String(
          (finalOrderData as any).payment_method_key,
        ).toLowerCase();
      }

      if ((finalOrderData as any).mobile_banking_provider) {
        (finalOrderData as any).mobile_banking_provider = String(
          (finalOrderData as any).mobile_banking_provider,
        ).toLowerCase();
      }

      // Log payload for debugging
      console.log('createOrder: inserting order payload:', finalOrderData);

      // Use array form for clearer Supabase responses
      // Ensure the buyer exists in public.users (foreign key constraint)
      try {
        const { data: buyerProfile, error: buyerErr } = await supabase
          .from('users')
          .select('id')
          .eq('id', finalOrderData.user_id)
          .single();
        if (buyerErr || !buyerProfile) {
          // Try to get current auth user info to seed a minimal profile
          try {
            const { data: authData } = await supabase.auth.getUser();
            const authUser = authData?.user;
            const seedName = (
              authUser?.email ||
              finalOrderData.user_id ||
              'User'
            ).split('@')[0];
            const insertProfile = {
              id: finalOrderData.user_id,
              name: seedName,
              email: authUser?.email || null,
              created_at: new Date().toISOString(),
            } as any;
            const { error: insertErr } = await supabase
              .from('users')
              .insert([insertProfile]);
            if (insertErr) {
              console.warn(
                'Failed to seed buyer profile before order insert:',
                insertErr,
              );
            } else {
              console.log(
                'Seeded minimal buyer profile for user',
                finalOrderData.user_id,
              );
            }
          } catch (seedErr) {
            console.warn('Error seeding buyer profile:', seedErr);
          }
        }
      } catch (checkErr) {
        console.warn('Error checking buyer profile existence:', checkErr);
      }

      const attemptInsert = async (payload: any) => {
        return await supabase
          .from('orders')
          .insert([payload])
          .select()
          .single();
      };

      let insertResult = await attemptInsert(finalOrderData);
      if (insertResult.error) {
        const err = insertResult.error as any;
        const errStr = (err.message || JSON.stringify(err) || '').toString();
        const missingUnit =
          err.code === 'PGRST204' ||
          errStr.includes("Could not find the 'unit' column");

        if (missingUnit && (finalOrderData as any).unit) {
          console.warn(
            "Orders table appears to be missing the 'unit' column in the hosted DB. Retrying insert without 'unit'.",
          );
          console.warn(
            "Please run the migration: ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS unit TEXT DEFAULT 'kg'; in your Supabase SQL editor.",
          );

          const payloadNoUnit = { ...finalOrderData } as any;
          delete payloadNoUnit.unit;

          const retryResult = await attemptInsert(payloadNoUnit);
          if (retryResult.error) {
            try {
              console.error(
                'Supabase insert error (orders) after retry:',
                JSON.stringify(retryResult.error),
              );
            } catch (e) {
              console.error(
                'Supabase insert error (orders) after retry:',
                retryResult.error,
              );
            }
            throw new Error(
              'Supabase insert error: ' +
                (retryResult.error.message ||
                  JSON.stringify(retryResult.error)),
            );
          }
          console.log('createOrder: inserted id=', retryResult.data?.id);
          return retryResult.data.id;
        }

        try {
          console.error('Supabase insert error (orders):', JSON.stringify(err));
        } catch (e) {
          console.error('Supabase insert error (orders):', err);
        }
        throw new Error(
          'Supabase insert error: ' + (err.message || JSON.stringify(err)),
        );
      }

      console.log('createOrder: inserted id=', insertResult.data?.id);
      const insertedId = insertResult.data.id;

      try {
        await this.recordVaultEntryForOrder(insertedId);
      } catch (vaultErr) {
        console.warn(
          'createOrder: failed to record vault entry for order',
          insertedId,
          vaultErr,
        );
      }

      // If payment method is AgriWallet, attempt to deduct buyer wallet
      // and create a per-order wallet transaction. Failures here should
      // not prevent order creation, so we catch and log errors.
      try {
        const pm = (finalOrderData as any).payment_method || '';
        if (String(pm).toLowerCase() === 'agriwallet') {
          const amount = Number((finalOrderData as any).total_price || 0);
          const userId = String((finalOrderData as any).user_id || '');
          if (userId && amount > 0) {
            // Deduct from user's wallet
            await this.updateUserWalletBalance(userId, amount, 'subtract');
            // Create wallet transaction linked to this order
            await this.createWalletTransaction({
              user_id: userId,
              amount,
              transaction_type: 'payment',
              description: `Order #${insertedId} payment`,
              related_order_id: insertedId,
            });
            console.log(
              `createOrder: AgriWallet payment recorded for order ${insertedId}`,
            );
          }
        }
      } catch (walletErr) {
        console.warn(
          'createOrder: failed to record AgriWallet payment for order',
          insertResult.data?.id,
          walletErr,
        );
      }

      return insertedId;
    } catch (error) {
      console.error('Error creating order:', error);
      throw error;
    }
  }

  async getUserOrders(userId: string): Promise<any[]> {
    try {
      // Since we removed FK constraints, we can't use foreign key joins anymore
      // Just select orders directly and rely on snapshot data
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Map orders to use snapshot data first, with robust fallbacks
      return (data || []).map(order => {
        return {
          ...order,
          // Use snapshot data first, with fallbacks for deleted products
          product_name: order.product_name || 'Product Deleted',
          product_description: order.product_description || null,
          product_price: order.product_price || 0,
          product_unit: order.product_unit || order.unit || 'kg',
          product_category: order.product_category || null,
          product_image_url: order.product_image_url || null,

          // Additional display fields
          unit_price: order.product_price || 0,

          // Flag to indicate if product was deleted (no snapshot data means it was deleted before snapshots were implemented)
          productDeleted: !order.product_name,
        };
      });
    } catch (error) {
      console.error('Error getting user orders:', error);
      throw error;
    }
  }

  async getFarmerOrders(farmerId: string): Promise<any[]> {
    try {
      console.log('getFarmerOrders DEBUG: farmerId =', farmerId);

      // Since we removed FK constraints and use snapshot data,
      // we can directly query orders by farmer_id without needing to check products table
      const { data, error } = await supabase
        .from('orders')
        .select(
          `
          *,
          users:user_id (
            id, name, email, address_line1, address_line2, city, state, postal_code, country
          )
        `,
        )
        .eq('farmer_id', farmerId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      console.log('getFarmerOrders DEBUG: raw supabase data =', data);

      if (!data || data.length === 0) {
        console.log('getFarmerOrders DEBUG: No orders found for this farmer.');
        return [];
      }

      // Batch fetch current product records for any product_id referenced in orders
      const productIds = Array.from(
        new Set(
          data
            .map((o: any) =>
              o.product_id !== undefined ? Number(o.product_id) : null,
            )
            .filter(Boolean),
        ),
      );

      let productsMap: Record<string, any> = {};
      if (productIds.length > 0) {
        try {
          const { data: products, error: prodErr } = await supabase
            .from('products')
            .select(`*, users (name, email)`)
            .in('id', productIds);
          if (prodErr) {
            console.warn('getFarmerOrders: failed to fetch products:', prodErr);
          } else if (products && Array.isArray(products)) {
            products.forEach((p: any) => {
              productsMap[String(p.id)] = {
                ...p,
                farmer_name: p.users?.name,
                farmer_email: p.users?.email,
              };
            });
          }
        } catch (prodFetchErr) {
          console.warn(
            'getFarmerOrders: error fetching products:',
            prodFetchErr,
          );
        }
      }

      const result = data.map((order: any) => {
        const pid =
          order.product_id !== undefined ? String(order.product_id) : '';
        const currentProduct =
          pid && productsMap[pid] ? productsMap[pid] : null;

        return {
          ...order,
          // keep buyer under 'buyer' for UI convenience
          buyer: order.users || null,

          // Attach the live product object when available (UI expects order.products)
          products: currentProduct,

          // Use snapshot data first, fallback to defaults for deleted products
          product_name:
            order.product_name ||
            (currentProduct ? currentProduct.name : 'Product (deleted)'),
          product_description:
            order.product_description ||
            (currentProduct ? currentProduct.description : null),
          product_price:
            order.product_price || (currentProduct ? currentProduct.price : 0),
          product_unit:
            order.product_unit ||
            order.unit ||
            (currentProduct ? currentProduct.unit : 'kg'),
          product_category:
            order.product_category ||
            (currentProduct ? currentProduct.category : null),
          product_image_url:
            order.product_image_url ||
            (currentProduct ? currentProduct.image_url : null),

          // Flag to indicate if product was deleted or snapshot missing
          productDeleted: !order.product_name && !currentProduct,
        };
      });

      console.log(
        'getFarmerOrders DEBUG: returning',
        result.length,
        'orders:',
        result,
      );
      return result;
    } catch (error) {
      console.error('Error getting farmer orders:', error);
      throw error;
    }
  }

  async updateOrderStatus(orderId: number, status: string): Promise<void> {
    try {
      // Since we removed FK constraints and use snapshot data,
      // we only need to verify the order exists, not the product
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .select('id')
        .eq('id', orderId)
        .single();
      if (orderError || !order) {
        throw new Error('Order not found');
      }

      const statusLower = status.toLowerCase();
      const { data, error } = await supabase
        .from('orders')
        .update({ status: statusLower })
        .eq('id', orderId)
        .select();

      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error(
          'Order status update failed: No rows updated. Check order ID and RLS policies.',
        );
      }
    } catch (error) {
      throw error;
    }
  }

  /**
   * Updates the refunded status of an order.
   * @param orderId The ID of the order to update.
   * @param refunded The refunded status to set (true/false).
   */
  async updateOrderRefunded(orderId: number, refunded: boolean): Promise<void> {
    try {
      const { data, error } = await supabase
        .from('orders')
        .update({ refunded })
        .eq('id', orderId)
        .select();

      if (error) throw error;
      if (!data || data.length === 0) {
        throw new Error(
          'Order refund update failed: No rows updated. Check order ID and RLS policies.',
        );
      }
    } catch (error) {
      throw error;
    }
  }

  // Shopping Cart Methods
  async addToCart(cartData: {
    user_id: string;
    product_id: number;
    quantity: number;
  }): Promise<AddToCartResult> {
    try {
      const normalizedQuantity = Math.max(
        1,
        Math.floor(parseNumeric(cartData.quantity) || 1),
      );

      const productQuery = await supabase
        .from('products')
        .select(
          'name, description, price, unit, category, image_url, delivery_fee, stock, quantity, min_purchase_quantity, max_purchase_quantity',
        )
        .eq('id', cartData.product_id)
        .single();

      if (productQuery.error || !productQuery.data) {
        throw productQuery.error || new Error('Product not found');
      }

      const product = productQuery.data;
      const minPurchase = resolveMinPurchase(product.min_purchase_quantity);
      const maxPurchase = resolveMaxPurchase(
        product.max_purchase_quantity,
        minPurchase,
      );
      const availableStock = resolveAvailableStock(product);

      if (typeof availableStock === 'number' && availableStock < minPurchase) {
        throw new CartConstraintError({
          reason: 'stock',
          minPurchase,
          maxPurchase,
          availableStock,
        });
      }

      const finalCartData: Record<string, any> = { ...cartData };
      finalCartData.product_name = product.name;
      finalCartData.product_description = product.description;
      finalCartData.product_price = product.price;
      finalCartData.product_unit = product.unit;
      finalCartData.product_category = product.category;
      finalCartData.product_image_url = product.image_url;
      finalCartData.product_delivery_fee =
        parseNumeric(product.delivery_fee) ?? 0;
      finalCartData.product_min_purchase_quantity = minPurchase;
      finalCartData.product_max_purchase_quantity = maxPurchase;

      let existingQty = 0;
      try {
        const existingRes = await supabase
          .from('shopping_cart')
          .select('quantity')
          .eq('user_id', cartData.user_id)
          .eq('product_id', cartData.product_id)
          .maybeSingle();

        if (
          !existingRes.error &&
          existingRes.data &&
          existingRes.data.quantity !== undefined &&
          existingRes.data.quantity !== null
        ) {
          const parsedExisting = parseNumeric(existingRes.data.quantity);
          if (parsedExisting !== null) {
            existingQty = Math.max(0, Math.floor(parsedExisting));
          }
        }
      } catch (lookupErr) {
        console.warn(
          'addToCart: failed to load existing cart quantity',
          lookupErr,
        );
      }

      if (maxPurchase !== null && existingQty >= maxPurchase) {
        throw new CartConstraintError({
          reason: 'max',
          minPurchase,
          maxPurchase,
          availableStock,
        });
      }

      let desiredQty = existingQty + normalizedQuantity;
      let adjustedToMin = false;
      let adjustedToMax = false;
      let adjustedToStock = false;

      if (desiredQty < minPurchase) {
        desiredQty = minPurchase;
        adjustedToMin = true;
      }

      if (maxPurchase !== null && desiredQty > maxPurchase) {
        desiredQty = maxPurchase;
        adjustedToMax = true;
      }

      if (typeof availableStock === 'number' && desiredQty > availableStock) {
        desiredQty = availableStock;
        adjustedToStock = true;
      }

      if (desiredQty <= existingQty) {
        const reason: CartConstraintReason =
          maxPurchase !== null && existingQty >= maxPurchase ? 'max' : 'stock';
        throw new CartConstraintError({
          reason,
          minPurchase,
          maxPurchase,
          availableStock,
        });
      }

      finalCartData.quantity = desiredQty;

      const { error } = await supabase
        .from('shopping_cart')
        .upsert(finalCartData, {
          onConflict: 'user_id,product_id',
        });

      if (error) throw error;

      return {
        quantity: desiredQty,
        minPurchase,
        maxPurchase,
        adjustedToMin,
        adjustedToMax,
        adjustedToStock,
      };
    } catch (error) {
      console.error('Error adding to cart:', error);
      throw error;
    }
  }

  async getUserCart(userId: string): Promise<ShoppingCartItem[]> {
    try {
      const resp = await supabase
        .from('shopping_cart')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });
      if (resp.error) throw resp.error;
      const data: any[] = resp.data || [];

      // fetch product records
      // so we can determine farmer_id for each cart row.
      const productIds = Array.from(
        new Set(
          (data || [])
            .map((r: any) =>
              r && r.product_id !== undefined ? Number(r.product_id) : null,
            )
            .filter(Boolean),
        ),
      );

      const productMap: Record<number, any> = {};
      if (productIds.length > 0) {
        try {
          const { data: prodRows, error: prodErr } = await supabase
            .from('products')
            .select(
              'id, farmer_id, stock, quantity, name, image_url, min_purchase_quantity, max_purchase_quantity',
            )
            .in('id', productIds);
          if (!prodErr && Array.isArray(prodRows)) {
            prodRows.forEach((p: any) => {
              productMap[Number(p.id)] = p;
            });
          }
        } catch (e) {
          console.warn('getUserCart: failed to fetch product farmer_ids', e);
        }
      }

      // Collect farmer IDs to batch-fetch missing farmer names
      const farmerIdSet = new Set<string>();
      (data || []).forEach((row: any) => {
        const fid =
          row.products?.farmer_id ||
          row.farmer_id ||
          productMap[row.product_id]?.farmer_id;
        if (fid) farmerIdSet.add(String(fid));
      });

      const farmerIds = Array.from(farmerIdSet);
      let farmerMap: Record<string, any> = {};
      if (farmerIds.length > 0) {
        try {
          farmerMap = await this.getUsersByIds(farmerIds);
        } catch (e) {
          console.warn('getUserCart: failed to batch fetch farmer names', e);
          farmerMap = {};
        }
      }

      return (data || []).map((row: any) => {
        // Resolve farmer name from joined data (users may be returned as an array)
        let joinedFarmerName: string | null = null;
        try {
          const usersField = row.products?.users;
          if (Array.isArray(usersField)) {
            joinedFarmerName = usersField[0]?.name || null;
          } else if (usersField && typeof usersField === 'object') {
            joinedFarmerName = usersField.name || null;
          }
        } catch (e) {
          joinedFarmerName = null;
        }

        const resolvedFarmerId =
          row.products?.farmer_id ||
          row.farmer_id ||
          productMap[row.product_id]?.farmer_id ||
          null;
        const farmerIdKey = resolvedFarmerId ? String(resolvedFarmerId) : null;
        const farmerNameFromMap =
          farmerIdKey && farmerMap[farmerIdKey]
            ? farmerMap[farmerIdKey].name
            : null;

        const farmerName =
          joinedFarmerName ||
          row.farmer_name ||
          farmerNameFromMap ||
          row.products?.farmer_name ||
          'Unknown Farmer';

        const minFromProduct = parseNumeric(
          productMap[row.product_id]?.min_purchase_quantity,
        );
        const minFromSnapshot = parseNumeric(row.product_min_purchase_quantity);
        const resolvedMinRaw =
          minFromProduct !== null ? minFromProduct : minFromSnapshot;
        const resolvedMin = Math.max(
          1,
          resolvedMinRaw !== null ? Math.floor(resolvedMinRaw) : 1,
        );

        const maxFromProduct = parseNumeric(
          productMap[row.product_id]?.max_purchase_quantity,
        );
        const maxFromSnapshot = parseNumeric(row.product_max_purchase_quantity);
        let resolvedMax: number | null =
          maxFromProduct !== null ? maxFromProduct : maxFromSnapshot;
        if (resolvedMax !== null) {
          const floored = Math.floor(resolvedMax);
          resolvedMax = Number.isNaN(floored)
            ? null
            : floored < resolvedMin
            ? resolvedMin
            : floored;
        }

        return {
          id: row.id,
          user_id: row.user_id,
          product_id: row.product_id,
          quantity: row.quantity,
          created_at: row.created_at,
          updated_at: row.updated_at,

          // Use snapshot data first, with fallbacks for deleted products
          product_name: row.product_name || 'Product Deleted',
          product_description: row.product_description || null,
          product_price: row.product_price || 0,
          product_unit: row.product_unit || 'kg',
          product_category: row.product_category || null,
          product_image_url: row.product_image_url || null,
          product_delivery_fee:
            typeof row.product_delivery_fee === 'number'
              ? row.product_delivery_fee
              : 0,
          product_min_purchase_quantity: resolvedMin,
          product_max_purchase_quantity: resolvedMax,

          // Current stock from products table when available
          product_stock:
            productMap[row.product_id] &&
            typeof productMap[row.product_id].stock === 'number'
              ? productMap[row.product_id].stock
              : undefined,

          farmer_id: farmerIdKey,
          farmer_name: farmerName,

          // Flag to indicate if product was deleted (no snapshot data means it was deleted before snapshots were implemented)
          productDeleted: !row.product_name,
        } as ShoppingCartItem;
      });
    } catch (error) {
      console.error('Error getting user cart:', error);
      throw error;
    }
  }

  async updateCartQuantity(
    userId: string,
    productId: number,
    quantity: number,
  ): Promise<UpdateCartQuantityResult> {
    try {
      const normalizedQuantity = Math.max(
        1,
        Math.floor(parseNumeric(quantity) || 1),
      );

      const productQuery = await supabase
        .from('products')
        .select('quantity, stock, min_purchase_quantity, max_purchase_quantity')
        .eq('id', productId)
        .single();

      if (productQuery.error || !productQuery.data) {
        throw productQuery.error || new Error('Product not found');
      }

      const product = productQuery.data;
      const minPurchase = resolveMinPurchase(product.min_purchase_quantity);
      const maxPurchase = resolveMaxPurchase(
        product.max_purchase_quantity,
        minPurchase,
      );
      const available = resolveAvailableStock(product);

      if (normalizedQuantity < minPurchase) {
        throw new CartConstraintError({
          reason: 'min',
          minPurchase,
          maxPurchase,
          availableStock: available,
        });
      }

      if (maxPurchase !== null && normalizedQuantity > maxPurchase) {
        throw new CartConstraintError({
          reason: 'max',
          minPurchase,
          maxPurchase,
          availableStock: available,
        });
      }

      if (typeof available === 'number' && normalizedQuantity > available) {
        throw new CartConstraintError({
          reason: 'stock',
          minPurchase,
          maxPurchase,
          availableStock: available,
        });
      }

      if (typeof available === 'number' && available < minPurchase) {
        throw new CartConstraintError({
          reason: 'stock',
          minPurchase,
          maxPurchase,
          availableStock: available,
        });
      }

      const updatePayload = {
        quantity: normalizedQuantity,
        product_min_purchase_quantity: minPurchase,
        product_max_purchase_quantity: maxPurchase,
      } as Record<string, any>;

      const { error } = await supabase
        .from('shopping_cart')
        .update(updatePayload)
        .eq('user_id', userId)
        .eq('product_id', productId);

      if (error) throw error;

      return {
        quantity: normalizedQuantity,
        minPurchase,
        maxPurchase,
        availableStock: available,
      };
    } catch (error) {
      console.error('Error updating cart quantity:', error);
      throw error;
    }
  }

  async removeFromCart(userId: string, productId: number): Promise<void> {
    try {
      const { error } = await supabase
        .from('shopping_cart')
        .delete()
        .eq('user_id', userId)
        .eq('product_id', productId);

      if (error) throw error;
    } catch (error) {
      console.error('Error removing from cart:', error);
      throw error;
    }
  }

  async clearUserCart(userId: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('shopping_cart')
        .delete()
        .eq('user_id', userId);

      if (error) throw error;
    } catch (error) {
      console.error('Error clearing cart:', error);
      throw error;
    }
  }

  public async getCartItemCount(userId: string): Promise<number> {
    try {
      const { count, error } = await supabase
        .from('shopping_cart')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', userId);

      if (error) {
        console.error('Error fetching cart item count:', error);
        return 0;
      }

      return count ?? 0;
    } catch (error) {
      console.error('Unexpected error fetching cart item count:', error);
      return 0;
    }
  }

  // Land Lease Methods
  // Land Lease Methods
  async createLandLease(leaseData: {
    owner_id: string;
    title: string;
    description?: string;
    price: number;
    duration: number;
    location: string;
    area?: number;
    soil_type?: string;
    water_source?: string;
    crop_suitability?: string;
    distance?: number;
    rating?: number;
    status?: string;
  }): Promise<number> {
    try {
      const { data, error } = await supabase
        .from('leases')
        .insert(leaseData)
        .select()
        .single();

      if (error) throw error;
      return data.id;
    } catch (error) {
      console.error('Error creating land lease:', error);
      throw error;
    }
  }

  async getLandLeases(ownerId?: string | null): Promise<any[]> {
    try {
      let query = supabase
        .from('leases')
        .select(
          `
          *,
          users (name, email)
        `,
        )
        .order('created_at', { ascending: false });

      // owner_id in the DB is a UUID (string).
      if (ownerId) {
        query = query.eq('owner_id', ownerId);
      }

      const { data, error } = await query;
      if (error) throw error;

      return data.map(row => ({
        ...row,
        owner_name: row.users?.name,
        owner_email: row.users?.email,
      }));
    } catch (error) {
      console.error('Error getting land leases:', error);
      throw error;
    }
  }

  async getLandLeaseById(leaseId: number): Promise<any | null> {
    try {
      const { data, error } = await supabase
        .from('leases')
        .select(
          `
          *,
          users (name, email)
        `,
        )
        .eq('id', leaseId)
        .single();
      if (error) {
        // If no row found, return a safe fallback so UI can show "deleted" message
        if (error.code === 'PGRST116') {
          return {
            id: leaseId,
            title: 'Deleted land',
            description: 'This land has been removed',
            location: 'Deleted',
            owner_name: null,
            owner_email: null,
            leaseDeleted: true,
          };
        }
        throw error;
      }

      return {
        ...data,
        owner_name: data.users?.name,
        owner_email: data.users?.email,
        leaseDeleted: data.status === 'deleted' || false,
      };
    } catch (error) {
      console.error('Error getting land lease by ID:', error);
      throw error;
    }
  }

  async updateLandLease(leaseId: number, updateData: any): Promise<void> {
    try {
      const { error } = await supabase
        .from('leases')
        .update(updateData)
        .eq('id', leaseId);

      if (error) throw error;
    } catch (error) {
      console.error('Error updating land lease:', error);
      throw error;
    }
  }

  async deleteLandLease(leaseId: number): Promise<void> {
    try {
      // Since we removed FK constraints and use references only,
      // we can safely delete the lease while preserving historical
      // applications and contracts as records with their snapshot data
      const { error } = await supabase
        .from('leases')
        .delete()
        .eq('id', leaseId);

      if (error) throw error;
    } catch (error) {
      // Normalize and rethrow a clear Error so callers can display diagnostics
      console.error('Error deleting land lease:', error);
      const normalized =
        (error as any)?.message ||
        (error as any)?.details ||
        JSON.stringify(error);
      throw new Error(`deleteLandLease failed: ${normalized}`);
    }
  }

  // Lease Application Methods
  async applyForLease(applicationData: {
    lease_id: number;
    applicant_id: string;
    offered_price: number;
    message?: string;
    status?: string;
  }): Promise<number> {
    try {
      const { data, error } = await supabase
        .from('lease_applications')
        .insert(applicationData)
        .select()
        .single();

      if (error) throw error;
      return data.id;
    } catch (error) {
      console.error('Error applying for lease:', error);
      throw error;
    }
  }

  async createLeaseApplication(
    leaseId: number,
    userId: string,
    offeredPrice: number,
    message: string,
  ): Promise<any> {
    // Fetch lease to get owner_id and snapshot data
    const lease = await this.getLandLeaseById(leaseId);
    if (!lease) throw new Error('Lease not found');

    // Debug: log IDs and session user
    try {
      const { data: sessionUser } = await supabase.auth.getUser();
      console.log('[DEBUG] createLeaseApplication:', {
        leaseId,
        applicant_id: userId,
        owner_id: lease.owner_id,
        offeredPrice,
        message,
        sessionUserId: sessionUser?.user?.id,
      });
    } catch (debugErr) {
      console.warn(
        '[DEBUG] Could not fetch session user for lease application:',
        debugErr,
      );
    }

    let leaseSnapshot: Record<string, any> = {};
    try {
      const { data: leaseData, error: leaseError } = await supabase
        .from('leases')
        .select(
          'title, description, location, price, duration, area, soil_type, water_source, crop_suitability, distance, rating, image_url, multiple_image_url',
        )
        .eq('id', leaseId)
        .single();

      if (!leaseError && leaseData) {
        leaseSnapshot = {
          lease_title: leaseData.title,
          lease_description: leaseData.description,
          lease_location: leaseData.location,
          lease_price: leaseData.price,
          lease_duration: leaseData.duration,
          lease_area: leaseData.area,
          lease_soil_type: leaseData.soil_type,
          lease_water_source: leaseData.water_source,
          lease_crop_suitability: leaseData.crop_suitability,
          lease_distance: leaseData.distance,
          lease_rating: leaseData.rating,
          lease_image_url: leaseData.image_url || null,
          // store multiple images array (TEXT[] in DB) - ensure array fallback
          multiple_image_url: Array.isArray(leaseData.multiple_image_url)
            ? leaseData.multiple_image_url
            : leaseData.multiple_image_url
            ? [leaseData.multiple_image_url]
            : [],
        };
      }
    } catch (e) {
      console.warn('Failed to capture lease snapshot for application:', e);
    }

    const { data, error } = await supabase
      .from('lease_applications')
      .insert([
        {
          lease_id: leaseId,
          applicant_id: userId,
          owner_id: lease.owner_id,
          offered_price: offeredPrice,
          message: message,
          status: 'pending',
          created_at: new Date().toISOString(),
          ...leaseSnapshot,
        },
      ])
      .select()
      .single();

    if (error) {
      console.error('[DEBUG] Supabase insert error:', error);
      throw error;
    }
    return data;
  }

  async getLeaseApplications(
    leaseId?: number,
    applicantId?: string,
    ownerId?: string,
  ): Promise<any[]> {
    try {
      let query = supabase
        .from('lease_applications')
        .select(
          `
          *,
          applicant:users!lease_applications_applicant_id_fkey (name, email),
          owner:users!lease_applications_owner_id_fkey (name, email)
        `,
        )
        .order('created_at', { ascending: false });

      // If ownerId is provided, always filter by owner_id (for owner view)
      if (ownerId) {
        query = query.eq('owner_id', ownerId);
      } else if (applicantId) {
        // Otherwise, filter by applicant_id (for applicant view)
        query = query.eq('applicant_id', applicantId);
      }
      if (leaseId) {
        query = query.eq('lease_id', leaseId);
      }

      const { data, error } = await query;
      if (error) throw error;

      // Return raw application rows and let the UI decide how to present missing snapshot fields.
      return data.map((row: any) => ({
        ...row,
        // Flag to indicate if lease snapshot title is missing
        leaseDeleted: !row.lease_title,
      }));
    } catch (error) {
      console.error('Error getting lease applications:', error);
      throw error;
    }
  }

  /**
   * Fetch a single lease application by its id and return the raw row (snapshot fields included).
   */
  async getLeaseApplicationById(applicationId: number): Promise<any | null> {
    try {
      const { data, error } = await supabase
        .from('lease_applications')
        .select(
          `*, applicant:users!lease_applications_applicant_id_fkey (name, email)`,
        )
        .eq('id', applicationId)
        .limit(1)
        .single();
      if (error) {
        console.error('Error fetching lease application by id:', error);
        return null;
      }
      return data ? { ...data, leaseDeleted: !data.lease_title } : null;
    } catch (err) {
      console.error('Exception in getLeaseApplicationById:', err);
      return null;
    }
  }
  /**
   * Returns all lease applications for leases owned by the given ownerId.
   * Each application includes lease and applicant info.
   */
  async getOwnerLeaseApplications(ownerId: string): Promise<any[]> {
    try {
      // Since we removed FK constraints, we can't use foreign key joins anymore
      // Just select lease applications directly and rely on snapshot data
      const { data, error } = await supabase
        .from('lease_applications')
        .select(
          `*, applicant:users!lease_applications_applicant_id_fkey (name, email)`,
        )
        .eq('owner_id', ownerId)
        .order('created_at', { ascending: false });
      if (error) throw error;

      // Return raw rows and include a leaseDeleted flag. UI should format fallback strings.
      return data.map((row: any) => ({
        ...row,
        leaseDeleted: !row.lease_title,
      }));
    } catch (error) {
      console.error('Error getting owner lease applications:', error);
      throw error;
    }
  }

  async updateLeaseApplicationStatus(
    applicationId: number,
    status: string,
  ): Promise<void> {
    try {
      // Fetch the application
      const { data: app, error: appError } = await supabase
        .from('lease_applications')
        .select('*')
        .eq('id', applicationId)
        .single();
      if (appError || !app)
        throw appError || new Error('Application not found');

      // If approving, create contract first and update land lease status
      if (status === 'approved') {
        // Fetch lease details
        const lease = await this.getLandLeaseById(app.lease_id);
        if (!lease) throw new Error('Lease not found for contract creation');

        // Check if contract already exists for this lease and applicant
        const { data: existingContracts, error: contractCheckError } =
          await supabase
            .from('lease_contracts')
            .select('id')
            .eq('lease_id', app.lease_id)
            .eq('tenant_id', app.applicant_id);
        if (contractCheckError) throw contractCheckError;
        if (existingContracts && existingContracts.length > 0) {
          // Contract already exists, just update status
          const { error: updateError } = await supabase
            .from('lease_applications')
            .update({ status })
            .eq('id', applicationId);
          if (updateError) throw updateError;
          // Also update the land lease status to 'booked'
          const { error: leaseUpdateError } = await supabase
            .from('leases')
            .update({ status: 'booked' })
            .eq('id', app.lease_id);
          if (leaseUpdateError) throw leaseUpdateError;
          // Cancel all other applications for this lease
          const { error: cancelOthersError } = await supabase
            .from('lease_applications')
            .update({ status: 'rejected' })
            .eq('lease_id', app.lease_id)
            .neq('id', applicationId);
          if (cancelOthersError) throw cancelOthersError;
          return;
        }

        // Create contract with proper date calculations
        // Helper function to get current date in Bangladesh timezone (UTC+6)
        const getBangladeshDate = () => {
          // Create a new Date in Bangladesh timezone
          const now = new Date();
          // Convert to Bangladesh timezone (UTC+6)
          const bangladeshTime = new Date(now.getTime() + 6 * 60 * 60 * 1000);
          return bangladeshTime;
        };

        // Start date: current date in Bangladesh timezone
        const startDate = getBangladeshDate();
        console.log(
          '[DEBUG] Start date:',
          startDate.toISOString(),
          'Bangladesh time',
        );

        // End date: add duration months to start date (safe month addition)
        const endDate = new Date(startDate);
        const duration = lease.duration || app.lease_duration;
        console.log('[DEBUG] Duration months:', duration);

        if (duration && duration > 0 && !isNaN(duration)) {
          // Use setMonth() for accurate month addition
          const originalDate = endDate.getDate();
          endDate.setMonth(endDate.getMonth() + duration);

          // Handle edge case where the target month has fewer days]
          if (endDate.getDate() !== originalDate) {
            endDate.setDate(0); // Go to last day of previous month
          }
        }

        console.log(
          '[DEBUG] End date:',
          endDate.toISOString(),
          'Bangladesh time',
        );

        // Format dates as ISO date strings (YYYY-MM-DD) in Bangladesh timezone
        const formatDate = (d: Date) => {
          // Validate date before formatting
          if (isNaN(d.getTime())) {
            throw new Error('Invalid date generated during contract creation');
          }
          // Format as YYYY-MM-DD using Bangladesh timezone
          const year = d.getFullYear();
          const month = String(d.getMonth() + 1).padStart(2, '0');
          const day = String(d.getDate()).padStart(2, '0');
          return `${year}-${month}-${day}`;
        };

        // Debug: log session user, owner_id, tenant_id
        try {
          const { data: sessionUser } = await supabase.auth.getUser();
          console.log('[DEBUG] Creating lease contract:', {
            sessionUserId: sessionUser?.user?.id,
            owner_id: app.owner_id,
            tenant_id: app.applicant_id,
            lease_id: app.lease_id,
            contract_amount: app.offered_price || lease.price,
            start_date: formatDate(startDate),
            end_date: formatDate(endDate),
          });
        } catch (debugErr) {
          console.warn(
            '[DEBUG] Could not fetch session user for contract creation:',
            debugErr,
          );
        }

        try {
          await this.createLeaseContract({
            lease_id: app.lease_id,
            tenant_id: app.applicant_id,
            owner_id: app.owner_id,
            contract_amount: app.offered_price || lease.price,
            start_date: formatDate(startDate),
            end_date: formatDate(endDate),
            terms_conditions: app.message || lease.description || '',
            status: 'active',
          });
        } catch (contractError) {
          // Do not update status if contract creation fails
          throw new Error(
            'Error creating lease contract: ' +
              (contractError instanceof Error
                ? contractError.message
                : String(contractError)),
          );
        }
        // Also update the land lease status to 'booked'
        const { error: leaseUpdateError } = await supabase
          .from('leases')
          .update({ status: 'booked' })
          .eq('id', app.lease_id);
        if (leaseUpdateError) throw leaseUpdateError;
        // Cancel all other applications for this lease
        const { error: cancelOthersError } = await supabase
          .from('lease_applications')
          .update({ status: 'rejected' })
          .eq('lease_id', app.lease_id)
          .neq('id', applicationId);
        if (cancelOthersError) throw cancelOthersError;
      }

      // Update the application status (for both approve and reject)
      const { error } = await supabase
        .from('lease_applications')
        .update({ status })
        .eq('id', applicationId);
      if (error) throw error;
    } catch (error) {
      console.error('Error updating lease application status:', error);
      throw error;
    }
  }

  // Lease Contract Methods
  async createLeaseContract(contractData: {
    lease_id: number;
    tenant_id: string;
    owner_id: string;
    contract_amount: number;
    start_date: string;
    end_date: string;
    terms_conditions?: string;
    status?: string;
  }): Promise<number> {
    try {
      let finalContractData = { ...contractData };

      // Prefer to use the application snapshot (if available) so contracts
      // preserve the exact data that was present when the application was made.
      // Fallback to live lease data if no snapshot exists.
      try {
        const { data: appSnapshot, error: appSnapErr } = await supabase
          .from('lease_applications')
          .select('*')
          .eq('lease_id', contractData.lease_id)
          .eq('applicant_id', contractData.tenant_id)
          .order('created_at', { ascending: false })
          .limit(1)
          .single();

        if (!appSnapErr && appSnapshot) {
          // Copy snapshot fields into contract snapshot fields
          (finalContractData as any).lease_title = appSnapshot.lease_title;
          (finalContractData as any).lease_description =
            appSnapshot.lease_description || appSnapshot.description;
          (finalContractData as any).lease_location =
            appSnapshot.lease_location || appSnapshot.location;
          (finalContractData as any).lease_area = appSnapshot.lease_area;
          (finalContractData as any).lease_soil_type =
            appSnapshot.lease_soil_type || appSnapshot.soil_type;
          (finalContractData as any).lease_water_source =
            appSnapshot.lease_water_source || appSnapshot.water_source;
          (finalContractData as any).lease_crop_suitability =
            appSnapshot.lease_crop_suitability || appSnapshot.crop_suitability;
          (finalContractData as any).lease_distance =
            appSnapshot.lease_distance || appSnapshot.distance;
          (finalContractData as any).lease_rating =
            appSnapshot.lease_rating || appSnapshot.rating;
          (finalContractData as any).lease_image_url =
            appSnapshot.lease_image_url ||
            appSnapshot.lease_image ||
            appSnapshot.image_url;
          // Preserve duration from snapshot (months)
          (finalContractData as any).lease_duration =
            appSnapshot.lease_duration || appSnapshot.duration || null;
          // multiple_image_url may be stored as an array in the snapshot
          (finalContractData as any).multiple_image_url =
            appSnapshot.multiple_image_url ||
            appSnapshot.multiple_image_urls ||
            [];
          // Use the application message as terms_conditions if not provided
          if (!finalContractData.terms_conditions) {
            (finalContractData as any).terms_conditions =
              appSnapshot.message || '';
          }
        } else {
          // Fallback to live lease row
          try {
            const { data: leaseData, error: leaseError } = await supabase
              .from('leases')
              .select(
                'title, description, location, area, soil_type, water_source, crop_suitability, distance, rating, duration, image_url, multiple_image_url',
              )
              .eq('id', contractData.lease_id)
              .single();

            if (!leaseError && leaseData) {
              (finalContractData as any).lease_title = leaseData.title;
              (finalContractData as any).lease_description =
                leaseData.description;
              (finalContractData as any).lease_location = leaseData.location;
              (finalContractData as any).lease_area = leaseData.area;
              (finalContractData as any).lease_soil_type = leaseData.soil_type;
              (finalContractData as any).lease_water_source =
                leaseData.water_source;
              (finalContractData as any).lease_crop_suitability =
                leaseData.crop_suitability;
              (finalContractData as any).lease_distance = leaseData.distance;
              (finalContractData as any).lease_rating = leaseData.rating;
              (finalContractData as any).lease_image_url = leaseData.image_url;
              (finalContractData as any).lease_duration =
                leaseData.duration || null;
              (finalContractData as any).multiple_image_url =
                leaseData.multiple_image_url || [];
              (finalContractData as any).multiple_image_url =
                leaseData.multiple_image_url || [];
            }
          } catch (e) {
            console.warn(
              'Failed to capture live lease snapshot for contract:',
              e,
            );
          }
        }
      } catch (e) {
        console.warn('Failed to capture application snapshot for contract:', e);
      }

      const { data, error } = await supabase
        .from('lease_contracts')
        .insert(finalContractData)
        .select()
        .single();

      if (error) throw error;
      return data.id;
    } catch (error) {
      console.error('Error creating lease contract:', error);
      throw error;
    }
  }

  async getLeaseContracts(userId?: number, userRole?: string): Promise<any[]> {
    try {
      let query = supabase
        .from('lease_contracts')
        .select(
          `
          *,
          tenant:users!lease_contracts_tenant_id_fkey (name, email),
          owner:users!lease_contracts_owner_id_fkey (name, email)
        `,
        )
        .order('created_at', { ascending: false });

      if (userId && userRole) {
        if (userRole === 'farmer') {
          query = query.or(`tenant_id.eq.${userId},owner_id.eq.${userId}`);
        }
      }

      const { data, error } = await query;
      if (error) throw error;

      // Map to use snapshot data first, with fallbacks for deleted leases
      return data.map((row: any) => {
        const resolvedTitle = row.lease_title || 'Deleted land';
        const resolvedDescription =
          row.lease_description || 'This land has been removed';
        const resolvedLocation = row.lease_location || 'Deleted';

        return {
          ...row,
          // Use snapshot data first for lease info
          lease_title: resolvedTitle,
          lease_description: resolvedDescription,
          lease_location: resolvedLocation,
          lease_area: row.lease_area || 0,
          lease_soil_type: row.lease_soil_type || null,
          lease_water_source: row.lease_water_source || null,
          lease_crop_suitability: row.lease_crop_suitability || null,
          lease_distance: row.lease_distance || 0,
          lease_rating: row.lease_rating || 0,
          lease_image_url: row.lease_image_url || null,
          lease_duration: row.lease_duration || null,
          multiple_image_url: row.multiple_image_url || [],

          // Keep user information for display
          tenant_name: row.tenant?.name,
          tenant_email: row.tenant?.email,
          owner_name: row.owner?.name,
          owner_email: row.owner?.email,

          // Backward compatibility aliases
          location: resolvedLocation,
          description: resolvedDescription,

          // Flag to indicate if lease was deleted (no snapshot data means it was deleted before snapshots were implemented)
          leaseDeleted: !row.lease_title,
        };
      });
    } catch (error) {
      console.error('Error getting lease contracts:', error);
      throw error;
    }
  }

  async getLeaseContractById(contractId: number): Promise<any | null> {
    try {
      const { data, error } = await supabase
        .from('lease_contracts')
        .select(
          `
          *,
          tenant:users!lease_contracts_tenant_id_fkey (name, email),
          owner:users!lease_contracts_owner_id_fkey (name, email)
        `,
        )
        .eq('id', contractId)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw error;
      }

      // Return with snapshot data and backward compatibility aliases
      return {
        ...data,
        // Use snapshot data first for lease info
        lease_title: data.lease_title || 'Deleted land',
        lease_description:
          data.lease_description || 'This land has been removed',
        lease_location: data.lease_location || 'Deleted',
        lease_area: data.lease_area || 0,
        lease_soil_type: data.lease_soil_type || null,
        lease_water_source: data.lease_water_source || null,
        lease_crop_suitability: data.lease_crop_suitability || null,
        lease_distance: data.lease_distance || 0,
        lease_rating: data.lease_rating || 0,
        lease_image_url: data.lease_image_url || null,
        lease_duration: data.lease_duration || null,
        multiple_image_url: data.multiple_image_url || [],

        // Backward compatibility aliases
        location: data.lease_location || 'Deleted',
        description: data.lease_description || 'This land has been removed',

        // Flag to indicate if lease was deleted
        leaseDeleted: !data.lease_title,
      };
    } catch (error) {
      console.error('Error getting lease contract by ID:', error);
      throw error;
    }
  }

  async updateLeaseContract(
    contractId: number,
    updateData: any,
  ): Promise<void> {
    try {
      console.log('[DEBUG] updateLeaseContract called', {
        contractId,
        updateData,
      });
      const { data, error } = await supabase
        .from('lease_contracts')
        .update(updateData)
        .eq('id', contractId)
        .select();

      if (error) {
        console.error('[DEBUG] Supabase update error:', error);
        throw error;
      }
      console.log('[DEBUG] Supabase update data:', data);
    } catch (error) {
      console.error('[DEBUG] updateLeaseContract exception:', error);
      throw error;
    }
  }

  // Wallet Transaction Methods
  async createWalletTransaction(transactionData: {
    user_id: string;
    amount: number;
    transaction_type: string;
    description?: string;
    related_order_id?: number;
  }): Promise<number> {
    try {
      // Use RPC function to bypass RLS for system operations (refunds, payments, etc.)
      const { data, error } = await supabase.rpc('create_wallet_transaction', {
        p_user_id: transactionData.user_id,
        p_amount: transactionData.amount,
        p_transaction_type: transactionData.transaction_type,
        p_description: transactionData.description || null,
        p_related_order_id: transactionData.related_order_id || null,
      });

      if (error) throw error;
      return data; // RPC returns the transaction ID
    } catch (error) {
      console.error('Error creating wallet transaction:', error);
      throw error;
    }
  }

  async getUserWalletTransactions(
    userId: string,
  ): Promise<WalletTransaction[]> {
    try {
      const { data, error } = await supabase
        .from('wallet_transactions')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      return data.map(row => ({
        id: row.id,
        user_id: row.user_id,
        amount: row.amount,
        transaction_type: row.transaction_type,
        description: row.description,
        related_order_id: row.related_order_id,
        created_at: row.created_at,
      }));
    } catch (error) {
      console.error('Error getting wallet transactions:', error);
      throw error;
    }
  }

  async updateUserWalletBalance(
    userId: string,
    amount: number,
    operation: 'add' | 'subtract',
  ): Promise<void> {
    try {
      // Use RPC function to bypass RLS for system operations (refunds, payments, etc.)
      const { error } = await supabase.rpc('update_user_wallet_balance', {
        p_user_id: userId,
        p_amount: amount,
        p_operation: operation,
      });

      if (error) throw error;
    } catch (error) {
      console.error('Error updating wallet balance:', error);
      throw error;
    }
  }

  async getUserWalletBalance(userId: string): Promise<number> {
    try {
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('wallet_balance')
        .eq('id', userId)
        .single();
      if (userError || !userData) {
        console.error('Error fetching wallet balance:', userError);
        return 0;
      }
      return typeof userData.wallet_balance === 'number'
        ? userData.wallet_balance
        : parseFloat(userData.wallet_balance) || 0;
    } catch (error) {
      console.error('Error in getUserWalletBalance:', error);
      return 0;
    }
  }

  public async checkout(
    userId: string,
    paymentMethod: string,
  ): Promise<boolean> {
    try {
      // Fetch cart items for the user
      const cartItems = await this.getUserCart(userId);
      if (!cartItems || cartItems.length === 0) {
        return false;
      }

      // Calculate total
      let total = 0;
      for (const item of cartItems) {
        const itemPrice =
          typeof item.product_price === 'number' ? item.product_price : 0;
        const itemQuantity =
          typeof item.quantity === 'number' ? item.quantity : 0;
        total += itemPrice * itemQuantity;
      }

      // Create order
      const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert([
          {
            user_id: userId,
            total_price: total,
            payment_method: paymentMethod,
            status: 'pending',
          },
        ])
        .select()
        .single();

      if (orderError || !order) {
        return false;
      }

      // Insert order items
      const orderItems = cartItems.map((item: any) => ({
        order_id: order.id,
        product_id: item.product_id,
        quantity: item.quantity,
        price: item.product_price,
      }));

      const { error: orderItemsError } = await supabase
        .from('order_items')
        .insert(orderItems);

      if (orderItemsError) {
        return false;
      }

      // Clear user's cart
      await supabase.from('cart').delete().eq('user_id', userId);

      return true;
    } catch (error) {
      console.error('Checkout error:', error);
      return false;
    }
  }

  // Weather Cache Methods
  async getCachedWeather(location: string): Promise<any | null> {
    try {
      const { data, error } = await supabase
        .from('weather_cache')
        .select('*')
        .eq('location', location)
        .gt('expires_at', new Date().toISOString())
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null;
        throw error;
      }

      return data;
    } catch (error) {
      console.error('Error getting cached weather:', error);
      throw error;
    }
  }

  async cacheWeather(weatherData: {
    location: string;
    temperature: number;
    humidity: number;
    description: string;
    expires_at: string;
  }): Promise<void> {
    try {
      const { error } = await supabase
        .from('weather_cache')
        .upsert(weatherData, {
          onConflict: 'location',
        });

      if (error) throw error;
    } catch (error) {
      console.error('Error caching weather:', error);
      throw error;
    }
  }

  // Message Methods
  async sendMessage(messageData: {
    sender_id: string;
    receiver_id: string;
    content: string;
  }): Promise<number> {
    try {
      const { data, error } = await supabase
        .from('messages')
        .insert(messageData)
        .select()
        .single();

      if (error) throw error;
      return data.id;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  }

  async getUserMessages(userId: string, otherUserId?: string): Promise<any[]> {
    try {
      let query = supabase
        .from('messages')
        .select(
          `
          *,
          sender:users!messages_sender_id_fkey (name, email),
          receiver:users!messages_receiver_id_fkey (name, email)
        `,
        )
        .or(`sender_id.eq.${userId},receiver_id.eq.${userId}`)
        .order('created_at', { ascending: true });

      if (otherUserId) {
        query = query.or(
          `and(sender_id.eq.${userId},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${userId})`,
        );
      }

      const { data, error } = await query;
      if (error) throw error;

      return data;
    } catch (error) {
      console.error('Error getting messages:', error);
      throw error;
    }
  }

  public async getUserChatList(userId: string): Promise<any[]> {
    const safeUserId = String(userId);

    // Fetch all messages where the user is sender or receiver (latest first)
    const { data: messages, error: msgError } = await supabase
      .from('messages')
      .select('*')
      .or(`sender_id.eq.${safeUserId},receiver_id.eq.${safeUserId}`)
      .order('created_at', { ascending: false });
    if (msgError) throw msgError;
    if (!messages) return [];

    // Group by the conversation partner (store most recent message per partner)
    const chatMap = new Map<string, any>();
    for (const msg of messages) {
      const otherUserId =
        msg.sender_id === safeUserId ? msg.receiver_id : msg.sender_id;
      if (!otherUserId) continue;
      if (!chatMap.has(otherUserId)) {
        chatMap.set(otherUserId, msg);
      }
    }

    const otherUserIds = Array.from(chatMap.keys());

    // Fetch participant profiles
    let usersInfo: {
      id: string;
      name: string;
      role: string;
      profile_image_url?: string | null;
    }[] = [];
    if (otherUserIds.length > 0) {
      const { data: users, error: userError } = await supabase
        .from('users')
        .select('id, name, role, profile_image_url')
        .in('id', otherUserIds);
      if (userError) throw userError;
      usersInfo = users || [];
    }

    // Fetch unread counts from the new counters table
    const unreadStates = await this.getUnreadRoomStatuses(safeUserId);
    const unreadMap = new Map<string, number>();
    unreadStates.forEach(state => {
      unreadMap.set(state.room_id, state.unread_count ?? 0);
    });

    return otherUserIds.map(otherId => {
      const msg = chatMap.get(otherId);
      const user = usersInfo.find(u => u.id === otherId);
      const roomId = buildRoomId(safeUserId, otherId);
      const unreadCount = unreadMap.get(roomId) ?? 0;

      return {
        other_user_id: otherId,
        other_user_name: user?.name || 'Unknown',
        userRole: user?.role || 'user',
        profile_image_url: user?.profile_image_url || null,
        last_message: msg?.content ?? '',
        last_message_time: msg?.created_at ?? new Date().toISOString(),
        unreadCount,
        isRead: unreadCount === 0,
      };
    });
  }

  public async getConversation(
    userId: string,
    otherUserId: string,
  ): Promise<Message[]> {
    console.log('getConversation called with:', { userId, otherUserId });

    // Defensive validation: avoid passing invalid UUID strings like 'undefined'
    const isValidUUID = (id: any) => {
      if (!id || typeof id !== 'string') return false;
      // Reject literal 'undefined' or 'null' strings
      if (id === 'undefined' || id === 'null') return false;
      // Basic UUID v4-ish check (allows lowercase/uppercase hex with dashes)
      return /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(
        id,
      );
    };

    if (!isValidUUID(userId) || !isValidUUID(otherUserId)) {
      console.error('getConversation: invalid userId or otherUserId', {
        userId,
        otherUserId,
      });
      return [];
    }
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .or(
          `and(sender_id.eq.${userId},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${userId})`,
        )
        .order('created_at', { ascending: true });

      if (error) {
        throw error;
      }
      return data as Message[];
    } catch (err) {
      console.error('Error fetching conversation:', err);
      return [];
    }
  }

  public async getUnreadRoomStatuses(
    userId: string,
  ): Promise<Array<{ room_id: string; unread_count: number }>> {
    try {
      const { data, error } = await supabase
        .from('message_unread_counters')
        .select('room_id, unread_count')
        .eq('participant_id', userId);

      if (error) {
        console.error('Error fetching unread counters:', error);
        return [];
      }
      return data ?? [];
    } catch (err) {
      console.error('Unexpected error fetching unread counters:', err);
      return [];
    }
  }

  public async markRoomRead(roomId: string, userId: string): Promise<void> {
    if (!roomId || !userId) return;
    try {
      const { error } = await supabase.rpc('fn_mark_room_read', {
        p_room_id: roomId,
        p_user_id: userId,
      });
      if (error) {
        console.error('Error marking room read:', error);
      }
    } catch (err) {
      console.error('Unexpected error marking room read:', err);
    }
  }

  public async createMessage(
    senderId: string,
    receiverId: string,
    content: string,
  ): Promise<void> {
    const { error } = await supabase.from('messages').insert([
      {
        sender_id: senderId,
        receiver_id: receiverId,
        content,
      },
    ]);
    if (error) {
      throw error;
    }
  }

  // Follower Methods
  /**
   * Follows a farmer (user) by their farmerId. Uses the current authenticated user as the follower.
   */
  async followFarmer(farmerId: string): Promise<void> {
    const { data, error: authError } = await supabase.auth.getUser();
    if (authError || !data || !data.user || !data.user.id)
      throw authError || new Error('Not authenticated');
    const followerId = data.user.id;
    if (farmerId === followerId) throw new Error('Cannot follow yourself');
    const { error } = await supabase
      .from('followers')
      .insert({ user_id: farmerId, follower_id: followerId });
    if (error && error.code !== '23505') throw error; // Ignore duplicate
  }

  /**
   * Generic helper to follow any user role; aliases farmer-specific naming.
   */
  async followUser(userId: string): Promise<void> {
    await this.followFarmer(userId);
  }

  /**
   * Unfollows a farmer (user) by their farmerId. Uses the current authenticated user as the follower.
   */
  async unfollowFarmer(farmerId: string): Promise<void> {
    const { data, error: authError } = await supabase.auth.getUser();
    if (authError || !data || !data.user || !data.user.id)
      throw authError || new Error('Not authenticated');
    const followerId = data.user.id;
    if (farmerId === followerId) throw new Error('Cannot unfollow yourself');
    const { error } = await supabase
      .from('followers')
      .delete()
      .eq('user_id', farmerId)
      .eq('follower_id', followerId);
    if (error) throw error;
  }

  /**
   * Generic helper to unfollow any user role; aliases farmer-specific naming.
   */
  async unfollowUser(userId: string): Promise<void> {
    await this.unfollowFarmer(userId);
  }

  /**
   * Checks if the current authenticated user is following the given farmerId.
   * Returns true if following, false otherwise.
   */
  async isFollowing(farmerId: string): Promise<boolean> {
    const { data, error: authError } = await supabase.auth.getUser();
    if (authError || !data || !data.user || !data.user.id)
      throw authError || new Error('Not authenticated');
    const followerId = data.user.id;
    if (farmerId === followerId) return false;
    const { data: followData, error } = await supabase
      .from('followers')
      .select('id')
      .eq('user_id', farmerId)
      .eq('follower_id', followerId)
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return !!followData;
  }

  /**
   * Returns a list of user IDs the current user is following (i.e., following list).
   */
  async getFollowingList(): Promise<string[]> {
    const { data, error: authError } = await supabase.auth.getUser();
    if (authError || !data || !data.user || !data.user.id)
      throw authError || new Error('Not authenticated');
    const followerId = data.user.id;
    const { data: followingData, error } = await supabase
      .from('followers')
      .select('user_id')
      .eq('follower_id', followerId);
    if (error) throw error;
    return followingData?.map((row: any) => row.user_id) || [];
  }

  /**
   * Returns a list of user IDs who follow the current user (i.e., followers list).
   */
  async getFollowersList(): Promise<string[]> {
    const { data, error: authError } = await supabase.auth.getUser();
    if (authError || !data || !data.user || !data.user.id)
      throw authError || new Error('Not authenticated');
    const userId = data.user.id;
    const { data: followersData, error } = await supabase
      .from('followers')
      .select('follower_id')
      .eq('user_id', userId);
    if (error) throw error;
    return followersData?.map((row: any) => row.follower_id) || [];
  }

  /**
   * Returns the number of followers for a given user (farmerId).
   */
  async getFollowerCount(farmerId: string): Promise<number> {
    try {
      const { count, error } = await supabaseAdmin
        .from('followers')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', farmerId);
      if (error) throw error;
      if (typeof count === 'number') {
        return count;
      }
    } catch (adminError) {
      console.warn('getFollowerCount admin fallback', adminError);
    }

    try {
      const { data, error } = await supabase.rpc('get_follower_count', {
        target_user_id: farmerId,
      });
      if (error) throw error;
      if (typeof data === 'number') {
        return data;
      }
      if (data && typeof (data as any).count === 'number') {
        return (data as any).count;
      }
    } catch (rpcError) {
      console.warn('getFollowerCount RPC fallback', rpcError);
    }

    const { count, error: fallbackError } = await supabase
      .from('followers')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', farmerId);
    if (fallbackError) throw fallbackError;
    return count ?? 0;
  }

  /**
   * Returns the number of accounts the specified user is following.
   */
  async getFollowingCount(userId: string): Promise<number> {
    try {
      const { count, error } = await supabaseAdmin
        .from('followers')
        .select('id', { count: 'exact', head: true })
        .eq('follower_id', userId);
      if (error) throw error;
      if (typeof count === 'number') {
        return count;
      }
    } catch (adminError) {
      console.warn('getFollowingCount admin fallback', adminError);
    }

    const { count, error: fallbackError } = await supabase
      .from('followers')
      .select('id', { count: 'exact', head: true })
      .eq('follower_id', userId);
    if (fallbackError) throw fallbackError;
    return count ?? 0;
  }

  async getFarmerAggregateStats(
    farmerId: string,
  ): Promise<FarmerAggregateStats> {
    const cleanId = String(farmerId).trim();
    if (!cleanId) {
      return {
        productCount: 0,
        leaseCount: 0,
        followerCount: 0,
        followingCount: 0,
        totalSoldQuantity: 0,
        topProductName: null,
        topProductQuantity: 0,
      };
    }

    let productCount = 0;
    let leaseCount = 0;
    let followerCount = 0;
    let followingCount = 0;
    let totalSoldQuantity = 0;
    let topProductName: string | null = null;
    let topProductQuantity = 0;

    try {
      const { count, error } = await supabaseAdmin
        .from('products')
        .select('id', { count: 'exact', head: true })
        .eq('farmer_id', cleanId);
      if (error) throw error;
      productCount = count ?? 0;
    } catch (err) {
      console.warn('getFarmerAggregateStats product count error', err);
    }

    try {
      const { count, error } = await supabaseAdmin
        .from('leases')
        .select('id', { count: 'exact', head: true })
        .eq('owner_id', cleanId);
      if (error) throw error;
      leaseCount = count ?? 0;
    } catch (err) {
      console.warn('getFarmerAggregateStats lease count error', err);
    }

    try {
      followerCount = await this.getFollowerCount(cleanId);
    } catch (err) {
      console.warn('getFarmerAggregateStats follower count error', err);
      followerCount = 0;
    }

    try {
      followingCount = await this.getFollowingCount(cleanId);
    } catch (err) {
      console.warn('getFarmerAggregateStats following count error', err);
      followingCount = 0;
    }

    try {
      const { data, error } = await supabaseAdmin
        .from('orders')
        .select('product_id, product_name, quantity')
        .eq('farmer_id', cleanId);
      if (error) throw error;

      const salesMap = new Map<string, { name: string; quantity: number }>();
      for (const order of data || []) {
        const rawQuantity = Number(order.quantity);
        const quantity = Number.isFinite(rawQuantity) ? rawQuantity : 0;
        if (quantity <= 0) continue;
        totalSoldQuantity += quantity;

        const productKey = order.product_id
          ? String(order.product_id)
          : order.product_name || 'unknown';
        const productName =
          order.product_name ||
          (order.product_id
            ? `Product #${order.product_id}`
            : 'Unknown product');

        const existing = salesMap.get(productKey);
        if (existing) {
          existing.quantity += quantity;
        } else {
          salesMap.set(productKey, { name: productName, quantity });
        }
      }

      for (const entry of salesMap.values()) {
        if (entry.quantity > topProductQuantity) {
          topProductQuantity = entry.quantity;
          topProductName = entry.name;
        }
      }
    } catch (err) {
      console.warn('getFarmerAggregateStats orders aggregation error', err);
    }

    return {
      productCount,
      leaseCount,
      followerCount,
      followingCount,
      totalSoldQuantity,
      topProductName,
      topProductQuantity,
    };
  }

  async getConsumerAggregateStats(
    consumerId: string,
  ): Promise<ConsumerAggregateStats> {
    const cleanId = String(consumerId).trim();
    if (!cleanId) {
      return {
        orderCount: 0,
        totalSpent: 0,
        leaseApplicationCount: 0,
        leaseContractCount: 0,
        followingCount: 0,
        followerCount: 0,
        topProductName: null,
        topProductQuantity: 0,
      };
    }

    let orderCount = 0;
    let totalSpent = 0;
    let leaseApplicationCount = 0;
    let leaseContractCount = 0;
    let followingCount = 0;
    let followerCount = 0;
    let topProductName: string | null = null;
    let topProductQuantity = 0;

    try {
      const { data, count, error } = await supabaseAdmin
        .from('orders')
        .select('product_id, product_name, quantity, total_price', {
          count: 'exact',
        })
        .eq('user_id', cleanId);
      if (error) throw error;
      orderCount = count ?? data?.length ?? 0;

      const productSales = new Map<
        string,
        { name: string; quantity: number }
      >();
      for (const order of data || []) {
        const numericTotal = Number(order.total_price);
        if (Number.isFinite(numericTotal) && numericTotal > 0) {
          totalSpent += numericTotal;
        }

        const numericQuantity = Number(order.quantity);
        if (!Number.isFinite(numericQuantity) || numericQuantity <= 0) {
          continue;
        }

        const productKey = order.product_id
          ? String(order.product_id)
          : order.product_name || 'unknown';
        const displayName =
          order.product_name ||
          (order.product_id
            ? `Product #${order.product_id}`
            : 'Unknown product');

        const existing = productSales.get(productKey);
        if (existing) {
          existing.quantity += numericQuantity;
        } else {
          productSales.set(productKey, {
            name: displayName,
            quantity: numericQuantity,
          });
        }
      }

      for (const entry of productSales.values()) {
        if (entry.quantity > topProductQuantity) {
          topProductQuantity = entry.quantity;
          topProductName = entry.name;
        }
      }
    } catch (err) {
      console.warn('getConsumerAggregateStats orders aggregation error', err);
    }

    try {
      const { count, error } = await supabaseAdmin
        .from('lease_applications')
        .select('id', { count: 'exact', head: true })
        .eq('applicant_id', cleanId);
      if (error) throw error;
      leaseApplicationCount = count ?? 0;
    } catch (err) {
      console.warn(
        'getConsumerAggregateStats lease application count error',
        err,
      );
    }

    try {
      const { count, error } = await supabaseAdmin
        .from('lease_contracts')
        .select('id', { count: 'exact', head: true })
        .eq('tenant_id', cleanId);
      if (error) throw error;
      leaseContractCount = count ?? 0;
    } catch (err) {
      console.warn('getConsumerAggregateStats lease contract count error', err);
    }

    try {
      const { count, error } = await supabaseAdmin
        .from('followers')
        .select('id', { count: 'exact', head: true })
        .eq('follower_id', cleanId);
      if (error) throw error;
      followingCount = count ?? 0;
    } catch (err) {
      console.warn('getConsumerAggregateStats following count error', err);
    }

    try {
      followerCount = await this.getFollowerCount(cleanId);
    } catch (err) {
      console.warn('getConsumerAggregateStats follower count error', err);
      followerCount = 0;
    }

    return {
      orderCount,
      totalSpent,
      leaseApplicationCount,
      leaseContractCount,
      followingCount,
      followerCount,
      topProductName,
      topProductQuantity,
    };
  }
}

export default SupabaseDatabaseManager;
