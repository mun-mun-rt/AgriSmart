# Assets Folder

// Example: src/assets/\*
// Add images, fonts, etc. here
