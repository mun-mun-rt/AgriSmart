/**
 * Production Configuration for AgriSmart Bangladesh
 * Contains environment-specific settings for production deployment with Supabase
 */

export interface ProductionConfig {
  supabase: {
    url: string;
    anonKey: string;
    serviceRoleKey?: string;
  };
  api: {
    baseUrl: string;
    timeout: number;
    retryAttempts: number;
  };
  performance: {
    enableMonitoring: boolean;
    cacheExpiry: {
      weather: number; // minutes
      products: number; // minutes
      fertilizers: number; // hours
      lands: number; // hours
    };
    maxCacheSize: number; // MB
  };
  bangladesh: {
    currency: string;
    language: 'en' | 'bn';
    defaultDivision: string;
    supportedDivisions: string[];
  };
  features: {
    offlineMode: boolean;
    pushNotifications: boolean;
    socialFeatures: boolean;
    analytics: boolean;
    realtimeSync: boolean;
  };
  network: {
    lowBandwidthMode: boolean;
    compressionEnabled: boolean;
    imageQuality: number; // 0-100
  };
}

const productionConfig: ProductionConfig = {
  supabase: {
    url:
      process.env.EXPO_PUBLIC_SUPABASE_URL ||
      'https://fjuaaoeqbeqtauxrfxgd.supabase.co',
    anonKey:
      process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ||
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZqdWFhb2VxYmVxdGF1eHJmeGdkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTMyMDc4MDcsImV4cCI6MjA2ODc4MzgwN30.pP6XyD-VEu7ViSwrQW8OL4oRvquuTzSOSHAoQQiwciA',
    serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY, // For admin operations
  },
  api: {
    baseUrl: 'https://api.AgriSmart-bangladesh.com',
    timeout: 30000, // 30 seconds for rural connections
    retryAttempts: 3,
  },
  performance: {
    enableMonitoring: true,
    cacheExpiry: {
      weather: 60, // 1 hour
      products: 120, // 2 hours
      fertilizers: 24, // 24 hours
      lands: 6, // 6 hours
    },
    maxCacheSize: 50, // 50 MB cache limit
  },
  bangladesh: {
    currency: '৳',
    language: 'en', // Primary language (Bengali support for key content)
    defaultDivision: 'Dhaka',
    supportedDivisions: [
      'Dhaka',
      'Chittagong',
      'Rajshahi',
      'Khulna',
      'Barisal',
      'Sylhet',
      'Rangpur',
      'Mymensingh',
    ],
  },
  features: {
    offlineMode: true,
    pushNotifications: false,
    socialFeatures: true,
    analytics: true,
    realtimeSync: true, // Supabase real-time subscriptions
  },
  network: {
    lowBandwidthMode: true,
    compressionEnabled: true,
    imageQuality: 70, // Optimized for mobile and rural networks
  },
};

// Development configuration for testing
const developmentConfig: ProductionConfig = {
  ...productionConfig,
  supabase: {
    ...productionConfig.supabase,
    // Use same Supabase instance for development
  },
  api: {
    ...productionConfig.api,
    baseUrl: 'http://localhost:3000',
    timeout: 10000,
  },
  performance: {
    ...productionConfig.performance,
    enableMonitoring: false, // Disable in development for performance
  },
  features: {
    ...productionConfig.features,
    analytics: false, // Disable analytics in development
    realtimeSync: true, // Keep real-time sync for development testing
  },
};

// Determine which config to use based on environment
const isDevelopment = __DEV__;
export const config = isDevelopment ? developmentConfig : productionConfig;

// Helper functions for configuration
export const getSupabaseConfig = () => config.supabase;

export const getApiUrl = (endpoint: string): string => {
  return `${config.api.baseUrl}${endpoint}`;
};

export const getCacheExpiry = (
  type: keyof ProductionConfig['performance']['cacheExpiry'],
): number => {
  return config.performance.cacheExpiry[type];
};

export const isFeatureEnabled = (
  feature: keyof ProductionConfig['features'],
): boolean => {
  return config.features[feature];
};

export const getBangladeshConfig = () => config.bangladesh;

export const getNetworkConfig = () => config.network;

export default config;
