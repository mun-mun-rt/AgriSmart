import React, {
  useState,
  useEffect,
  useMemo,
  useCallback,
  useRef,
} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  Alert,
  Modal,
  FlatList,
  TextInput,
  useWindowDimensions,
  I18nManager,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../types';
import WeatherAPI, { BangladeshCity } from '../../api/WeatherAPI';
import { WeatherData } from '../../types';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type WeatherForecastScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'WeatherForecast'
>;

const weatherEmojiToIconName: Record<string, string> = {
  '☀': 'weather-sunny',
  '🌤': 'weather-partly-cloudy',
  '⛅': 'weather-partly-cloudy',
  '☁': 'weather-cloudy',
  '🌫': 'weather-fog',
  '🌦': 'weather-partly-rainy',
  '🌧': 'weather-rainy',
  '🌨': 'weather-snowy',
  '❄': 'weather-snowy-heavy',
  '⛈': 'weather-lightning-rainy',
  '🌩': 'weather-lightning',
  '🌪': 'weather-tornado',
  '❓': 'help-circle-outline',
};

const weatherConditionFallbacks: Array<{ keywords: string[]; icon: string }> = [
  { keywords: ['clear', 'sun'], icon: 'weather-sunny' },
  { keywords: ['cloud'], icon: 'weather-cloudy' },
  { keywords: ['rain', 'shower'], icon: 'weather-rainy' },
  { keywords: ['drizzle'], icon: 'weather-partly-rainy' },
  { keywords: ['snow'], icon: 'weather-snowy' },
  { keywords: ['thunder', 'storm'], icon: 'weather-lightning-rainy' },
  { keywords: ['fog', 'mist'], icon: 'weather-fog' },
  { keywords: ['wind'], icon: 'weather-windy' },
];

const resolveWeatherIconName = (
  iconSymbol?: string,
  condition?: string,
): string => {
  const normalizedSymbol = iconSymbol?.replace(/\uFE0F/g, '');

  if (normalizedSymbol && weatherEmojiToIconName[normalizedSymbol]) {
    return weatherEmojiToIconName[normalizedSymbol];
  }

  if (iconSymbol && weatherEmojiToIconName[iconSymbol]) {
    return weatherEmojiToIconName[iconSymbol];
  }

  if (condition) {
    const normalizedCondition = condition.toLowerCase();
    const matchedFallback = weatherConditionFallbacks.find(entry =>
      entry.keywords.some(keyword => normalizedCondition.includes(keyword)),
    );

    if (matchedFallback) {
      return matchedFallback.icon;
    }
  }

  return 'weather-cloudy';
};

type ForecastAccent = {
  cardBackground: string;
  borderColor: string;
  badgeBackground: string;
  badgeBorder: string;
  badgeText: string;
  accentColor: string;
  iconBackground: string;
  trackBackground: string;
};

const getForecastAccent = (condition: string): ForecastAccent => {
  const normalized = (condition ?? '').toLowerCase();

  if (normalized.includes('storm') || normalized.includes('thunder')) {
    return {
      cardBackground: '#FDECEA',
      borderColor: '#F9C9C3',
      badgeBackground: 'rgba(211, 47, 47, 0.12)',
      badgeBorder: '#D32F2F',
      badgeText: '#D32F2F',
      accentColor: '#D32F2F',
      iconBackground: 'rgba(211, 47, 47, 0.12)',
      trackBackground: '#F8D7DA',
    };
  }

  if (
    normalized.includes('rain') ||
    normalized.includes('shower') ||
    normalized.includes('drizzle')
  ) {
    return {
      cardBackground: '#E8F1FF',
      borderColor: '#C5DFFF',
      badgeBackground: 'rgba(25, 118, 210, 0.12)',
      badgeBorder: '#1976D2',
      badgeText: '#1976D2',
      accentColor: '#1976D2',
      iconBackground: 'rgba(25, 118, 210, 0.12)',
      trackBackground: '#D6E4FF',
    };
  }

  if (normalized.includes('snow')) {
    return {
      cardBackground: '#E3F2FD',
      borderColor: '#BBDEFB',
      badgeBackground: 'rgba(2, 136, 209, 0.16)',
      badgeBorder: '#0288D1',
      badgeText: '#0288D1',
      accentColor: '#0288D1',
      iconBackground: 'rgba(2, 136, 209, 0.16)',
      trackBackground: '#D0E8FF',
    };
  }

  if (normalized.includes('clear') || normalized.includes('sun')) {
    return {
      cardBackground: '#FFF8E1',
      borderColor: '#FFE082',
      badgeBackground: 'rgba(255, 167, 38, 0.18)',
      badgeBorder: '#FB8C00',
      badgeText: '#FB8C00',
      accentColor: '#FB8C00',
      iconBackground: 'rgba(255, 183, 77, 0.2)',
      trackBackground: '#FFE0B2',
    };
  }

  if (normalized.includes('cloud')) {
    return {
      cardBackground: '#ECEFF1',
      borderColor: '#CFD8DC',
      badgeBackground: 'rgba(96, 125, 139, 0.16)',
      badgeBorder: '#607D8B',
      badgeText: '#607D8B',
      accentColor: '#607D8B',
      iconBackground: 'rgba(96, 125, 139, 0.18)',
      trackBackground: '#E0E0E0',
    };
  }

  return {
    cardBackground: '#FFFFFF',
    borderColor: '#E3F2FD',
    badgeBackground: 'rgba(25, 118, 210, 0.12)',
    badgeBorder: '#1976D2',
    badgeText: '#1976D2',
    accentColor: '#1976D2',
    iconBackground: 'rgba(25, 118, 210, 0.1)',
    trackBackground: '#D6E4FF',
  };
};

const WeatherForecastScreen: React.FC = () => {
  const navigation = useNavigation<WeatherForecastScreenNavigationProp>();
  const weatherApi = useMemo(() => WeatherAPI.getInstance(), []);
  const [cities] = useState<BangladeshCity[]>(() =>
    weatherApi.getBangladeshCities(),
  );
  const defaultCity = useMemo(() => {
    return cities.find(city => city.key === 'dhaka') || cities[0];
  }, [cities]);
  const initialCityKey = defaultCity?.key || 'dhaka';
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [location, setLocation] = useState(
    defaultCity ? `${defaultCity.name}, Bangladesh` : 'Bangladesh',
  );
  const [selectedCityKey, setSelectedCityKey] = useState(initialCityKey);
  const selectedCityKeyRef = useRef(initialCityKey);
  const [isCityPickerVisible, setCityPickerVisible] = useState(false);
  const [citySearchTerm, setCitySearchTerm] = useState('');
  const [filteredCities, setFilteredCities] = useState<BangladeshCity[]>(() => [
    ...cities,
  ]);
  const { width } = useWindowDimensions();
  const isRTL = I18nManager.isRTL;
  const forecastCardWidth = useMemo(() => {
    if (width <= 340) {
      return 132;
    }

    if (width <= 414) {
      return 140;
    }

    if (width <= 640) {
      return 156;
    }

    if (width <= 900) {
      return 168;
    }

    return 176;
  }, [width]);
  const forecastCardSpacing = 12;
  const currentWeatherIconName = useMemo(() => {
    if (!weatherData) {
      return 'weather-cloudy';
    }

    return resolveWeatherIconName(
      weatherData.current.icon,
      weatherData.current.condition,
    );
  }, [weatherData]);
  const temperatureRange = useMemo(() => {
    if (!weatherData || weatherData.forecast.length === 0) {
      return { minLow: 0, maxHigh: 0 };
    }

    let minLow = Number.POSITIVE_INFINITY;
    let maxHigh = Number.NEGATIVE_INFINITY;

    weatherData.forecast.forEach(day => {
      if (typeof day.low === 'number') {
        minLow = Math.min(minLow, day.low);
      }

      if (typeof day.high === 'number') {
        maxHigh = Math.max(maxHigh, day.high);
      }
    });

    if (minLow === Number.POSITIVE_INFINITY) {
      minLow = 0;
    }

    if (maxHigh === Number.NEGATIVE_INFINITY) {
      maxHigh = 0;
    }

    return { minLow, maxHigh };
  }, [weatherData]);

  useEffect(() => {
    const normalizedSearch = citySearchTerm.trim().toLowerCase();
    if (!normalizedSearch) {
      setFilteredCities([...cities]);
      return;
    }

    const matchingCities = cities.filter(city =>
      city.name.toLowerCase().includes(normalizedSearch),
    );
    setFilteredCities(matchingCities);
  }, [citySearchTerm, cities]);

  const loadWeatherData = useCallback(
    async (cityKeyParam?: string) => {
      const fallbackCity =
        cities.find(city => city.key === 'dhaka') || cities[0];
      const keyToLoad =
        cityKeyParam || selectedCityKeyRef.current || fallbackCity?.key;
      const targetCity =
        cities.find(city => city.key === keyToLoad) || fallbackCity;

      if (!targetCity) {
        return;
      }

      try {
        setLoading(true);
        const data = await weatherApi.getWeatherData(
          targetCity.latitude,
          targetCity.longitude,
        );
        setWeatherData(data);
        selectedCityKeyRef.current = targetCity.key;
        setSelectedCityKey(targetCity.key);
        setLocation(`${targetCity.name}, Bangladesh`);
        setCityPickerVisible(false);
      } catch (error) {
        console.error('Failed to load weather data:', error);
        Alert.alert('Error', 'Failed to load weather data. Please try again.');
      } finally {
        setLoading(false);
        setCitySearchTerm('');
        setFilteredCities([...cities]);
      }
    },
    [cities, weatherApi],
  );

  useEffect(() => {
    loadWeatherData(initialCityKey);
  }, [loadWeatherData, initialCityKey]);

  const farmingInsights = [
    {
      title: 'Irrigation Recommendation',
      description: 'Light rain expected Wednesday. Reduce watering for 2 days.',
      iconName: 'water',
      iconColor: '#1976D2',
      priority: 'medium',
    },
    {
      title: 'Pest Alert',
      description: 'High humidity may increase pest activity. Monitor crops.',
      iconName: 'bug-outline',
      iconColor: '#D32F2F',
      priority: 'high',
    },
    {
      title: 'Harvest Window',
      description: 'Thursday-Friday ideal for harvesting with sunny weather.',
      iconName: 'sprout-outline',
      iconColor: '#4CAF50',
      priority: 'low',
    },
  ];

  const handleLocationChange = () => {
    setCityPickerVisible(true);
  };

  const handleCloseCityPicker = useCallback(() => {
    setCityPickerVisible(false);
    setCitySearchTerm('');
    setFilteredCities([...cities]);
  }, [cities]);

  const handleSelectCity = useCallback(
    (cityKey: string) => {
      loadWeatherData(cityKey);
    },
    [loadWeatherData],
  );

  const renderCityItem = useCallback(
    ({ item }: { item: BangladeshCity }) => {
      const isActive = item.key === selectedCityKey;
      return (
        <TouchableOpacity
          style={[
            styles.cityOption,
            isActive && styles.cityOptionActive,
            isRTL && styles.rowReverse,
          ]}
          onPress={() => handleSelectCity(item.key)}
          activeOpacity={0.85}
        >
          <View style={styles.cityInfo}>
            <Text style={[styles.cityName, isRTL && styles.textRightAligned]}>
              {item.name}
            </Text>
            <Text style={[styles.cityCoords, isRTL && styles.textRightAligned]}>
              {item.latitude.toFixed(2)}°, {item.longitude.toFixed(2)}°
            </Text>
          </View>
          {isActive ? (
            <MaterialCommunityIcons
              name="check-circle"
              size={20}
              color="#1976D2"
            />
          ) : null}
        </TouchableOpacity>
      );
    },
    [handleSelectCity, selectedCityKey],
  );

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return '#FF5722';
      case 'medium':
        return '#FF9800';
      case 'low':
        return '#4CAF50';
      default:
        return '#666';
    }
  };

  return (
    <SafeAreaView style={[styles.container, isRTL && styles.containerRtl]}>
      <StatusBar barStyle="light-content" backgroundColor="#1976D2" />

      {/* Header */}
      <View style={[styles.header, isRTL && styles.rowReverse]}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
          activeOpacity={0.7}
        >
          <MaterialCommunityIcons name="arrow-left" size={24} color="#FFFFFF" />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, isRTL && styles.textRightAligned]}>
          Weather Forecast
        </Text>
        <TouchableOpacity
          style={styles.refreshButton}
          onPress={() => loadWeatherData(selectedCityKey)}
          activeOpacity={0.7}
        >
          <MaterialCommunityIcons name="refresh" size={22} color="#FFFFFF" />
        </TouchableOpacity>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading weather data...</Text>
        </View>
      ) : !weatherData ? (
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load weather data</Text>
          <TouchableOpacity
            style={styles.retryButton}
            onPress={() => loadWeatherData(selectedCityKey)}
            activeOpacity={0.8}
          >
            <Text style={styles.retryButtonText}>Retry</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
          {/* Location Selector */}
          <TouchableOpacity
            style={[styles.locationCard, isRTL && styles.rowReverse]}
            onPress={handleLocationChange}
            activeOpacity={0.85}
          >
            <MaterialCommunityIcons
              name="map-marker"
              size={20}
              color="#1976D2"
              style={styles.locationIcon}
            />
            <Text
              style={[styles.locationText, isRTL && styles.textRightAligned]}
            >
              {location}
            </Text>
            <MaterialCommunityIcons
              name="chevron-down"
              size={20}
              color="#666666"
            />
          </TouchableOpacity>

          {/* Current Weather */}
          <View style={styles.currentWeatherCard}>
            <View
              style={[styles.currentWeatherMain, isRTL && styles.rowReverse]}
            >
              <MaterialCommunityIcons
                name={currentWeatherIconName}
                size={64}
                color="#1976D2"
                style={styles.currentIcon}
              />
              <View
                style={[
                  styles.currentTemperatureSection,
                  isRTL && styles.alignContentToEnd,
                ]}
              >
                <Text style={styles.currentTemperature}>
                  {weatherData.current.temperature}°C
                </Text>
                <Text
                  style={[
                    styles.currentCondition,
                    isRTL && styles.textRightAligned,
                  ]}
                >
                  {weatherData.current.condition}
                </Text>
              </View>
            </View>

            <View
              style={[styles.currentWeatherDetails, isRTL && styles.rowReverse]}
            >
              <View style={styles.weatherDetailItem}>
                <MaterialCommunityIcons
                  name="water-percent"
                  size={24}
                  color="#1976D2"
                  style={styles.weatherDetailIcon}
                />
                <Text style={styles.weatherDetailLabel}>Humidity</Text>
                <Text style={styles.weatherDetailValue}>
                  {weatherData.current.humidity}%
                </Text>
              </View>
              <View style={styles.weatherDetailItem}>
                <MaterialCommunityIcons
                  name="weather-windy"
                  size={24}
                  color="#1976D2"
                  style={styles.weatherDetailIcon}
                />
                <Text style={styles.weatherDetailLabel}>Wind</Text>
                <Text style={styles.weatherDetailValue}>
                  {weatherData.current.windSpeed} km/h
                </Text>
              </View>
            </View>
          </View>

          {/* 7-Day Forecast */}
          <View style={styles.section}>
            <Text
              style={[styles.sectionTitle, isRTL && styles.textRightAligned]}
            >
              7-Day Forecast
            </Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={[
                styles.forecastScrollContent,
                { paddingHorizontal: forecastCardSpacing },
                isRTL && styles.rowReverse,
              ]}
              snapToInterval={forecastCardWidth + forecastCardSpacing}
              decelerationRate="fast"
              snapToAlignment="start"
            >
              {weatherData.forecast.map((day, index) => {
                const accent = getForecastAccent(day.condition);
                const iconName = resolveWeatherIconName(
                  day.icon,
                  day.condition,
                );
                const { minLow, maxHigh } = temperatureRange;
                const tempSpan = Math.max(maxHigh - minLow, 0.0001);
                const startPercent =
                  maxHigh === minLow
                    ? 0
                    : ((day.low - minLow) / tempSpan) * 100;
                const endPercent =
                  maxHigh === minLow
                    ? 100
                    : ((day.high - minLow) / tempSpan) * 100;
                const clampedStart = Math.min(Math.max(startPercent, 0), 100);
                const clampedEnd = Math.min(Math.max(endPercent, 0), 100);
                const availableWidth = Math.max(100 - clampedStart, 0);
                const rawWidth = Math.max(clampedEnd - clampedStart, 0);
                const rangeWidth =
                  availableWidth === 0
                    ? 0
                    : Math.min(Math.max(rawWidth, 6), availableWidth);

                return (
                  <View
                    key={`${day.day}-${index}`}
                    style={[
                      styles.forecastCard,
                      {
                        width: forecastCardWidth,
                        marginHorizontal: forecastCardSpacing / 2,
                        backgroundColor: accent.cardBackground,
                        borderColor: accent.borderColor,
                      },
                    ]}
                  >
                    <View
                      style={[
                        styles.forecastHeader,
                        isRTL && styles.rowReverse,
                      ]}
                    >
                      <Text
                        style={[
                          styles.forecastDay,
                          { color: accent.accentColor },
                        ]}
                      >
                        {day.day}
                      </Text>
                      <View
                        style={[
                          styles.forecastBadge,
                          {
                            backgroundColor: accent.badgeBackground,
                            borderColor: accent.badgeBorder,
                          },
                        ]}
                      >
                        <MaterialCommunityIcons
                          name="weather-pouring"
                          size={14}
                          color={accent.badgeText}
                          style={styles.forecastBadgeIcon}
                        />
                        <Text
                          style={[
                            styles.forecastBadgeText,
                            { color: accent.badgeText },
                          ]}
                        >
                          {day.rainChance}%
                        </Text>
                      </View>
                    </View>

                    <View
                      style={[
                        styles.forecastIconRow,
                        isRTL && styles.rowReverse,
                      ]}
                    >
                      <View
                        style={[
                          styles.forecastIconWrapper,
                          { backgroundColor: accent.iconBackground },
                        ]}
                      >
                        <MaterialCommunityIcons
                          name={iconName}
                          size={30}
                          color={accent.accentColor}
                        />
                      </View>
                      <View
                        style={[
                          styles.forecastConditionBlock,
                          isRTL && styles.alignContentToEnd,
                        ]}
                      >
                        <Text
                          style={[
                            styles.forecastCondition,
                            isRTL && styles.textRightAligned,
                          ]}
                          numberOfLines={2}
                        >
                          {day.condition}
                        </Text>
                        <View
                          style={[
                            styles.forecastTemperatureRow,
                            isRTL && styles.rowReverse,
                          ]}
                        >
                          <Text
                            style={[
                              styles.forecastHigh,
                              { color: accent.accentColor },
                            ]}
                          >
                            {day.high}°
                          </Text>
                          <Text style={styles.forecastSlash}>/</Text>
                          <Text style={styles.forecastLow}>{day.low}°</Text>
                        </View>
                      </View>
                    </View>

                    <View
                      style={[
                        styles.temperatureRangeTrack,
                        { backgroundColor: accent.trackBackground },
                      ]}
                    >
                      <View
                        style={[
                          styles.temperatureRangeFill,
                          {
                            left: `${clampedStart}%`,
                            width: `${rangeWidth}%`,
                            backgroundColor: accent.accentColor,
                          },
                        ]}
                      />
                    </View>
                  </View>
                );
              })}
            </ScrollView>
          </View>

          {/* Farming Insights */}
          <View style={styles.section}>
            <Text
              style={[styles.sectionTitle, isRTL && styles.textRightAligned]}
            >
              Farming Insights
            </Text>
            <View style={styles.insightsContainer}>
              {farmingInsights.map((insight, index) => (
                <View key={index} style={styles.insightCard}>
                  <View
                    style={[styles.insightHeader, isRTL && styles.rowReverse]}
                  >
                    <MaterialCommunityIcons
                      name={insight.iconName}
                      size={20}
                      color={insight.iconColor}
                      style={styles.insightIcon}
                    />
                    <Text
                      style={[
                        styles.insightTitle,
                        isRTL && styles.textRightAligned,
                      ]}
                    >
                      {insight.title}
                    </Text>
                    <View
                      style={[
                        styles.priorityBadge,
                        { backgroundColor: getPriorityColor(insight.priority) },
                      ]}
                    >
                      <Text style={styles.priorityText}>
                        {insight.priority.toUpperCase()}
                      </Text>
                    </View>
                  </View>
                  <Text
                    style={[
                      styles.insightDescription,
                      isRTL && styles.textRightAligned,
                    ]}
                  >
                    {insight.description}
                  </Text>
                </View>
              ))}
            </View>
          </View>

          {/* Weather Alerts */}
          <View style={styles.section}>
            <Text
              style={[styles.sectionTitle, isRTL && styles.textRightAligned]}
            >
              Weather Alerts
            </Text>
            <View style={[styles.alertCard, isRTL && styles.rowReverse]}>
              <MaterialCommunityIcons
                name="alert-circle"
                size={24}
                color="#E65100"
                style={styles.alertIcon}
              />
              <View style={styles.alertContent}>
                <Text
                  style={[styles.alertTitle, isRTL && styles.textRightAligned]}
                >
                  Thunderstorm Warning
                </Text>
                <Text
                  style={[
                    styles.alertDescription,
                    isRTL && styles.textRightAligned,
                  ]}
                >
                  Severe thunderstorm expected on Saturday. Secure outdoor
                  equipment and avoid field work.
                </Text>
                <Text
                  style={[styles.alertTime, isRTL && styles.textRightAligned]}
                >
                  Valid until Sunday 6:00 AM
                </Text>
              </View>
            </View>
          </View>
        </ScrollView>
      )}

      <Modal
        visible={isCityPickerVisible}
        transparent
        animationType="slide"
        onRequestClose={handleCloseCityPicker}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={[styles.modalTitle, isRTL && styles.textRightAligned]}>
              Select City
            </Text>
            <TextInput
              style={[
                styles.modalSearchInput,
                isRTL && styles.textRightAligned,
              ]}
              placeholder="Search cities"
              placeholderTextColor="#999999"
              value={citySearchTerm}
              onChangeText={setCitySearchTerm}
              autoCorrect={false}
            />
            <FlatList
              data={filteredCities}
              keyExtractor={item => item.key}
              renderItem={renderCityItem}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={styles.cityListContent}
              showsVerticalScrollIndicator={false}
              ListEmptyComponent={
                <Text style={styles.emptyCityText}>No cities found</Text>
              }
            />
            <TouchableOpacity
              style={styles.modalCloseButton}
              onPress={handleCloseCityPicker}
              activeOpacity={0.85}
            >
              <Text style={styles.modalCloseButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F8FF',
    paddingBottom: 20,
  },
  containerRtl: {
    direction: 'rtl',
    writingDirection: 'rtl',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 18,
    color: '#666',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#1976D2',
    paddingHorizontal: 20,
    paddingTop: 40,
    paddingBottom: 15,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  refreshButton: {
    padding: 8,
  },
  retryButton: {
    marginTop: 12,
    paddingHorizontal: 20,
    paddingVertical: 12,
    backgroundColor: '#1976D2',
    borderRadius: 8,
  },
  retryButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  locationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  locationIcon: {
    marginEnd: 12,
  },
  locationText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  currentWeatherCard: {
    backgroundColor: '#FFFFFF',
    padding: 24,
    borderRadius: 16,
    marginBottom: 24,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  currentWeatherMain: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  currentIcon: {
    marginEnd: 20,
  },
  currentTemperatureSection: {
    flex: 1,
  },
  currentTemperature: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#1976D2',
  },
  currentCondition: {
    fontSize: 18,
    color: '#666',
    marginTop: 4,
  },
  currentWeatherDetails: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  weatherDetailItem: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F5F9FF',
    borderRadius: 12,
    paddingVertical: 16,
    width: '48%',
    marginBottom: 12,
  },
  weatherDetailIcon: {
    marginBottom: 8,
  },
  weatherDetailLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  weatherDetailValue: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  forecastContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  forecastCard: {
    backgroundColor: '#FFFFFF',
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 14,
    alignItems: 'stretch',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.18,
    shadowRadius: 2,
    borderWidth: 1,
    borderColor: '#E3F2FD',
    minHeight: 168,
  },
  forecastDay: {
    fontSize: 12,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  forecastCondition: {
    fontSize: 11,
    color: '#455A64',
    lineHeight: 14,
  },
  forecastHigh: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginEnd: 6,
  },
  forecastLow: {
    fontSize: 12,
    color: '#607D8B',
  },
  insightsContainer: {
    gap: 12,
  },
  insightCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  insightHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  insightIcon: {
    marginEnd: 12,
  },
  insightTitle: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  priorityText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  insightDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  alertCard: {
    backgroundColor: '#FFF3E0',
    padding: 16,
    borderRadius: 12,
    flexDirection: 'row',
    borderStartWidth: 4,
    borderStartColor: '#FF9800',
  },
  alertIcon: {
    marginEnd: 12,
  },
  alertContent: {
    flex: 1,
  },
  alertTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#E65100',
    marginBottom: 4,
  },
  alertDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
    marginBottom: 8,
  },
  alertTime: {
    fontSize: 12,
    color: '#FF9800',
    fontStyle: 'italic',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 16,
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
    maxHeight: '70%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#212121',
    marginBottom: 12,
  },
  modalSearchInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: '#333333',
    marginBottom: 12,
    backgroundColor: '#FAFAFA',
  },
  cityListContent: {
    paddingBottom: 12,
  },
  cityOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    marginBottom: 8,
    backgroundColor: '#F9F9F9',
  },
  cityOptionActive: {
    backgroundColor: '#E3F2FD',
  },
  cityInfo: {
    flex: 1,
    marginEnd: 12,
  },
  cityName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#212121',
  },
  cityCoords: {
    fontSize: 12,
    color: '#757575',
    marginTop: 2,
  },
  emptyCityText: {
    textAlign: 'center',
    color: '#777777',
    paddingVertical: 20,
    fontSize: 14,
  },
  modalCloseButton: {
    marginTop: 8,
    paddingVertical: 12,
    borderRadius: 10,
    backgroundColor: '#1976D2',
    alignItems: 'center',
  },
  modalCloseButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontSize: 16,
  },
  forecastHeader: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  forecastBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
  },
  forecastBadgeIcon: {
    marginEnd: 4,
  },
  forecastBadgeText: {
    fontSize: 11,
    fontWeight: '600',
  },
  forecastIconRow: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
  },
  forecastIconWrapper: {
    borderRadius: 16,
    padding: 12,
  },
  forecastConditionBlock: {
    flex: 1,
    marginStart: 12,
  },
  forecastTemperatureRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginTop: 6,
  },
  forecastSlash: {
    fontSize: 12,
    color: '#90A4AE',
    marginHorizontal: 4,
  },
  temperatureRangeTrack: {
    width: '100%',
    height: 6,
    borderRadius: 999,
    marginTop: 14,
    position: 'relative',
    overflow: 'hidden',
  },
  temperatureRangeFill: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    borderRadius: 999,
  },
  rowReverse: {
    flexDirection: 'row-reverse',
  },
  textRightAligned: {
    textAlign: 'right',
  },
  alignContentToEnd: {
    alignItems: 'flex-end',
  },
  forecastScrollContent: {
    paddingVertical: 4,
  },
});

export default WeatherForecastScreen;
