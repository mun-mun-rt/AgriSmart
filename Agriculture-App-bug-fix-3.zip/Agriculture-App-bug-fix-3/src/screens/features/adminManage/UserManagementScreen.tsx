import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Platform,
  ToastAndroid,
  Image,
  TextInput,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../../types';
import Layout from '../../../components/Layout';
import { User } from '../../../types';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import { getPublicUrlForPath } from '../../../utils/supabase';
import { getRoleDisplayName } from '../../../utils/authUtils';
import { buildRoomId } from '../../../utils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type UserManagementScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'UserManagement'
>;

const UserManagementScreen = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const navigation = useNavigation<UserManagementScreenNavigationProp>();
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [deletingUserId, setDeletingUserId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const fetchUsers = React.useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const allUsers = await authManager.getAllUsers();
      // Filter out admin users
      const nonAdminUsers = allUsers.filter(
        (user: User) => user.role !== 'admin',
      );

      // Resolve profile images to public URLs when possible
      const usersWithImages = await Promise.all(
        nonAdminUsers.map(async u => {
          try {
            const imagePath = (u as any).profile_image_url;
            if (imagePath) {
              const publicUrl = await getPublicUrlForPath(imagePath);
              return {
                ...(u as any),
                profile_image_public_url: publicUrl,
              } as User & { profile_image_public_url?: string };
            }
          } catch (e) {
            // ignore
          }
          return u as User & { profile_image_public_url?: string };
        }),
      );

      setUsers(usersWithImages as any);
    } catch (err) {
      setError('Failed to load users. Please try again.');
    } finally {
      setLoading(false);
    }
  }, [authManager]);

  useEffect(() => {
    fetchUsers();
    // get current user to determine admin privileges
    (async () => {
      try {
        const me = await authManager.getCurrentUser();
        setCurrentUser(me);
      } catch (e) {
        setCurrentUser(null);
      }
    })();
  }, [fetchUsers]);

  // Derived filtered list based on search query
  const filteredUsers = React.useMemo(() => {
    const q = (searchQuery || '').trim().toLowerCase();
    if (!q) return users;
    return users.filter(u => {
      const name = (u as any).name || '';
      const email = (u as any).email || '';
      const role = (u as any).role || '';
      const phone = (u as any).phone || (u as any).mobile || '';
      return (
        name.toLowerCase().includes(q) ||
        email.toLowerCase().includes(q) ||
        String(role).toLowerCase().includes(q) ||
        String(phone).toLowerCase().includes(q)
      );
    });
  }, [users, searchQuery]);

  const handleProfile = (user: User) => {
    navigation.navigate('UserProfile', { userId: String(user.id) });
  };

  const handleChat = (user: User) => {
    // Get current user id if available (for roomId)
    const currentUserId = currentUser?.id;
    const otherUserId = String(user.id);
    const otherUserName = user.name;
    const roomId = currentUserId
      ? buildRoomId(currentUserId, otherUserId)
      : otherUserId;
    navigation.navigate('ChatRoom', {
      roomId,
      otherUserId,
      otherUserName,
    });
  };

  const renderUserItem = ({ item }: { item: User }) => {
    const roleLabel = getRoleDisplayName(item.role);

    return (
      <TouchableOpacity
        style={styles.userCard}
        activeOpacity={0.85}
        onPress={() => handleProfile(item)}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          {(item as any).profile_image_public_url ||
          (item as any).profile_image_url ? (
            <Image
              source={{
                uri:
                  (item as any).profile_image_public_url ||
                  (item as any).profile_image_url,
              }}
              style={styles.avatar}
              resizeMode="cover"
            />
          ) : (
            <Image
              source={require('../../../assets/placeholder.png')}
              style={styles.avatar}
              resizeMode="cover"
            />
          )}
          <View style={styles.userInfo}>
            <Text style={styles.userName}>{item.name}</Text>
            <Text style={styles.userRole}>{roleLabel}</Text>
            <Text style={styles.userEmail}>{item.email || 'No email'}</Text>
          </View>
        </View>
        <View style={styles.actionsRow}>
          <TouchableOpacity
            style={[styles.actionButton, styles.viewButtonVariant]}
            onPress={() => handleProfile(item)}
          >
            <Text style={styles.actionButtonText}>View</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.actionButton, styles.chatButtonVariant]}
            onPress={() => handleChat(item)}
          >
            <Text style={styles.actionButtonText}>Chat</Text>
          </TouchableOpacity>
          {currentUser?.role === 'admin' && (
            <TouchableOpacity
              style={[styles.actionButton, styles.deleteButtonVariant]}
              onPress={async () => {
                // confirm deletion
                const confirmed = await new Promise<boolean>(resolve => {
                  Alert.alert(
                    'Confirm Delete',
                    `Delete user ${item.name}? This will remove all user data and the account.`,
                    [
                      {
                        text: 'Cancel',
                        style: 'cancel',
                        onPress: () => resolve(false),
                      },
                      {
                        text: 'Delete',
                        style: 'destructive',
                        onPress: () => resolve(true),
                      },
                    ],
                    { cancelable: true },
                  );
                });

                if (!confirmed) return;
                setDeletingUserId(String(item.id));
                try {
                  const res = await authManager.deleteUserAsAdmin(
                    String(item.id),
                  );
                  if (res.success) {
                    // refresh list
                    await fetchUsers();
                    const msg = 'User deleted successfully';
                    if (Platform.OS === 'android') {
                      ToastAndroid.show(msg, ToastAndroid.SHORT);
                    } else {
                      Alert.alert('Success', msg);
                    }
                  } else {
                    const msg = res.message || 'Failed to delete user';
                    Alert.alert('Delete failed', msg);
                    if (Platform.OS === 'android') {
                      ToastAndroid.show(msg, ToastAndroid.SHORT);
                    }
                  }
                } catch (err) {
                  const msg = (err as Error).message || 'Failed to delete user';
                  Alert.alert('Delete failed', msg);
                  if (Platform.OS === 'android')
                    ToastAndroid.show(msg, ToastAndroid.SHORT);
                } finally {
                  setDeletingUserId(null);
                }
              }}
            >
              <Text style={styles.actionButtonText}>
                {deletingUserId === String(item.id) ? 'Deleting...' : 'Delete'}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      </TouchableOpacity>
    );
  };

  const renderHeader = () => (
    <View style={styles.header}>
      <TouchableOpacity
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backButtonText}>Back</Text>
      </TouchableOpacity>
      <View style={{ flex: 1, alignItems: 'flex-end' }}>
        <Text style={styles.headerTitle}>Users</Text>
      </View>
    </View>
  );

  if (loading) {
    return (
      <Layout activeTab="dashboard">
        {renderHeader()}
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3498db" />
          <Text style={styles.loadingText}>Loading users...</Text>
        </View>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout activeTab="dashboard">
        {renderHeader()}
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      </Layout>
    );
  }

  return (
    <Layout activeTab="dashboard">
      {renderHeader()}
      <View style={{ paddingHorizontal: 18, paddingBottom: 12 }}>
        <View
          style={{
            marginTop: 8,
            marginBottom: 12,
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <View>
            <Text style={{ fontSize: 20, fontWeight: '700', color: '#111' }}>
              Manage Users
            </Text>
            <Text style={{ fontSize: 12, color: '#666', marginTop: 2 }}>
              View, message, or remove users from the app
            </Text>
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            backgroundColor: '#f2f6fb',
            borderRadius: 12,
            paddingHorizontal: 12,
            paddingVertical: 8,
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.05,
            shadowRadius: 4,
            elevation: 2,
          }}
        >
          <MaterialCommunityIcons
            name="magnify"
            size={20}
            color="#111111"
            style={{ marginRight: 8 }}
          />
          <TextInput
            placeholder="Search by name, email, role, or phone"
            value={searchQuery}
            onChangeText={setSearchQuery}
            style={{
              ...styles.searchInput,
              flex: 1,
              backgroundColor: 'transparent',
              borderWidth: 0,
              paddingVertical: Platform.OS === 'ios' ? 10 : 6,
            }}
            returnKeyType="search"
            clearButtonMode="while-editing"
          />
          {searchQuery ? (
            <TouchableOpacity
              onPress={() => setSearchQuery('')}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              style={{
                marginLeft: 8,
                padding: 6,
                borderRadius: 20,
                backgroundColor: 'rgba(0,0,0,0.04)',
              }}
            >
              <MaterialCommunityIcons name="close" size={18} color="#333333" />
            </TouchableOpacity>
          ) : null}
        </View>

        <View
          style={{
            marginTop: 10,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <Text style={{ color: '#666', fontSize: 13 }}>
            {filteredUsers.length} user{filteredUsers.length === 1 ? '' : 's'}
          </Text>
          <TouchableOpacity
            onPress={async () => {
              setSearchQuery('');
              await fetchUsers();
            }}
            style={{
              paddingHorizontal: 10,
              paddingVertical: 6,
              backgroundColor: '#fff',
              borderRadius: 8,
              borderWidth: 1,
              borderColor: '#e6e6e6',
            }}
          >
            <Text style={{ color: '#005BEA', fontWeight: '600' }}>Reset</Text>
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        data={filteredUsers}
        renderItem={renderUserItem}
        keyExtractor={item => String(item.id)}
        contentContainerStyle={styles.userList}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No users found</Text>
          </View>
        }
      />
    </Layout>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 18,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
    backgroundColor: '#fff',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 2,
  },
  backButton: {
    marginRight: 16,
    padding: 8,
    backgroundColor: '#f2f2f2',
    borderRadius: 16,
  },
  backButtonText: {
    fontSize: 16,
    color: '#111',
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#111',
    letterSpacing: 0.5,
  },
  userList: {
    padding: 18,
    backgroundColor: '#fff',
    minHeight: '100%',
  },
  userCard: {
    backgroundColor: '#f9f9f9',
    borderRadius: 18,
    padding: 22,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#eee',
  },
  userInfo: {
    marginBottom: 14,
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111',
    marginBottom: 2,
  },
  userRole: {
    fontSize: 13,
    color: '#2d9c5a',
    fontWeight: '600',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.6,
  },
  userEmail: {
    fontSize: 14,
    color: '#555',
    marginBottom: 2,
  },
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 12,
    gap: 10,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    elevation: 2,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.18,
    shadowRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 100,
  },
  viewButtonVariant: {
    backgroundColor: '#005BEA',
    shadowColor: '#00C6FB',
  },
  actionButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 15,
    letterSpacing: 0.5,
  },
  chatButtonVariant: {
    backgroundColor: '#FF512F',
    shadowColor: '#FF512F',
  },
  deleteButtonVariant: {
    backgroundColor: '#D62839',
    shadowColor: '#D62839',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#555',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#fff',
  },
  errorText: {
    fontSize: 16,
    color: '#FF512F',
    textAlign: 'center',
    marginBottom: 16,
  },
  emptyContainer: {
    padding: 32,
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  emptyText: {
    fontSize: 16,
    color: '#555',
    textAlign: 'center',
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 32,
    marginRight: 12,
    backgroundColor: '#e0e0e0',
  },
  searchInput: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#e6e6e6',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
});

export default UserManagementScreen;
