import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Modal,
  Platform,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import { RootStackParamList, SystemPaymentAccount } from '../../../types';
import { StackNavigationProp } from '@react-navigation/stack';

const METHOD_OPTIONS = [
  { value: 'bank', label: 'Bank' },
  { value: 'mobile_banking', label: 'Mobile Banking' },
] as const;

type MethodOption = (typeof METHOD_OPTIONS)[number]['value'];

type NavigationProp = StackNavigationProp<
  RootStackParamList,
  'SystemPaymentAccounts'
>;

type FormState = {
  method: MethodOption;
  provider: string;
  label: string;
  account_name: string;
  account_number: string;
  bank_name: string;
  branch_name: string;
  instructions: string;
  is_primary: boolean;
  is_active: boolean;
};

const INITIAL_FORM_STATE: FormState = {
  method: 'bank',
  provider: '',
  label: '',
  account_name: '',
  account_number: '',
  bank_name: '',
  branch_name: '',
  instructions: '',
  is_primary: false,
  is_active: true,
};

const METHOD_LABEL_MAP: Record<MethodOption, string> = {
  bank: 'Bank Accounts',
  mobile_banking: 'Mobile Banking',
};

const PROVIDER_HINT =
  'For mobile banking, specify provider name such as bKash, Nagad, or Rocket.';

const SystemPaymentAccountsScreen: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const [accounts, setAccounts] = useState<SystemPaymentAccount[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [filterMethod, setFilterMethod] = useState<MethodOption | 'all'>('all');
  const [isModalVisible, setIsModalVisible] = useState<boolean>(false);
  const [formState, setFormState] = useState<FormState>(INITIAL_FORM_STATE);
  const [editingAccount, setEditingAccount] =
    useState<SystemPaymentAccount | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [processingAccountId, setProcessingAccountId] = useState<string | null>(
    null,
  );

  const sortedAccounts = useMemo(() => {
    if (!accounts) return [];
    return [...accounts].sort((a, b) => {
      const primaryDiff =
        Number(Boolean(b.is_primary)) - Number(Boolean(a.is_primary));
      if (primaryDiff !== 0) {
        return primaryDiff;
      }
      const activeDiff =
        Number(Boolean(b.is_active ?? true)) -
        Number(Boolean(a.is_active ?? true));
      if (activeDiff !== 0) {
        return activeDiff;
      }
      const labelA = (a.label || '').toLowerCase();
      const labelB = (b.label || '').toLowerCase();
      return labelA.localeCompare(labelB);
    });
  }, [accounts]);

  const filteredAccounts = useMemo(() => {
    if (filterMethod === 'all') {
      return sortedAccounts;
    }
    return sortedAccounts.filter(account => {
      const normalizedMethod =
        (account.method as MethodOption) === 'mobile_banking'
          ? 'mobile_banking'
          : 'bank';
      return normalizedMethod === filterMethod;
    });
  }, [sortedAccounts, filterMethod]);

  const groupedAccounts = useMemo(() => {
    const groups: Record<MethodOption, SystemPaymentAccount[]> = {
      bank: [],
      mobile_banking: [],
    };

    filteredAccounts.forEach(account => {
      const method: MethodOption =
        (account.method as MethodOption) === 'mobile_banking'
          ? 'mobile_banking'
          : 'bank';
      groups[method].push(account);
    });

    return groups;
  }, [filteredAccounts]);

  const fetchAccounts = useCallback(
    async (showLoader = true) => {
      try {
        if (showLoader) {
          setIsLoading(true);
        }
        const results = await dbManager.getSystemPaymentAccounts(true);
        setAccounts(results || []);
      } catch (error) {
        console.error('Error fetching system payment accounts:', error);
        Alert.alert(
          'Error',
          'Unable to load payment accounts. Please try again later.',
        );
      } finally {
        if (showLoader) {
          setIsLoading(false);
        }
        setRefreshing(false);
      }
    },
    [dbManager],
  );

  useEffect(() => {
    fetchAccounts();
  }, [fetchAccounts]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchAccounts(false);
  };

  const openCreateModal = () => {
    setEditingAccount(null);
    setFormState(INITIAL_FORM_STATE);
    setIsModalVisible(true);
  };

  const openEditModal = (account: SystemPaymentAccount) => {
    setEditingAccount(account);
    setFormState({
      method: (account.method as MethodOption) || 'bank',
      provider: account.provider || '',
      label: account.label || '',
      account_name: account.account_name || '',
      account_number: account.account_number || '',
      bank_name: account.bank_name || '',
      branch_name: account.branch_name || '',
      instructions: account.instructions || '',
      is_primary: Boolean(account.is_primary),
      is_active: account.is_active ?? true,
    });
    setIsModalVisible(true);
  };

  const closeModal = () => {
    if (isSaving) return;
    setIsModalVisible(false);
    setEditingAccount(null);
    setFormState(INITIAL_FORM_STATE);
  };

  const handleFormChange = <K extends keyof FormState>(
    key: K,
    value: FormState[K],
  ) => {
    setFormState(prev => ({ ...prev, [key]: value }));
  };

  const buildPayload = () => {
    const trimmedLabel = formState.label.trim();
    const trimmedNumber = formState.account_number.trim();

    if (!trimmedLabel) {
      Alert.alert('Validation', 'Account label is required.');
      return null;
    }

    if (!trimmedNumber) {
      Alert.alert('Validation', 'Account number is required.');
      return null;
    }

    if (formState.method === 'mobile_banking') {
      const providerValue = formState.provider.trim();
      if (!providerValue) {
        Alert.alert(
          'Validation',
          'Please provide the mobile banking provider name.',
        );
        return null;
      }
    }

    return {
      method: formState.method,
      provider: formState.provider.trim() || null,
      label: trimmedLabel,
      account_name: formState.account_name.trim() || null,
      account_number: trimmedNumber,
      bank_name: formState.bank_name.trim() || null,
      branch_name: formState.branch_name.trim() || null,
      instructions: formState.instructions.trim() || null,
      is_primary: formState.is_primary,
      is_active: formState.is_active,
    };
  };

  const handleSaveAccount = async () => {
    const payload = buildPayload();
    if (!payload) {
      return;
    }

    setIsSaving(true);
    try {
      if (editingAccount) {
        await dbManager.updateSystemPaymentAccount(editingAccount.id, payload);
      } else {
        await dbManager.createSystemPaymentAccount(payload);
      }
      await fetchAccounts();
      closeModal();
    } catch (error) {
      console.error('Error saving system payment account:', error);
      Alert.alert('Error', 'Unable to save the account. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleActive = async (account: SystemPaymentAccount) => {
    if (processingAccountId) return;
    setProcessingAccountId(account.id);
    try {
      await dbManager.updateSystemPaymentAccount(account.id, {
        is_active: !(account.is_active ?? true),
      });
      await fetchAccounts(false);
    } catch (error) {
      console.error('Error toggling payment account status:', error);
      Alert.alert('Error', 'Failed to update account status.');
    } finally {
      setProcessingAccountId(null);
    }
  };

  const handleSetPrimary = async (account: SystemPaymentAccount) => {
    if (processingAccountId) return;
    setProcessingAccountId(account.id);
    try {
      await dbManager.setPrimarySystemPaymentAccount(
        account.id,
        account.method as MethodOption,
      );
      await fetchAccounts(false);
    } catch (error) {
      console.error('Error setting primary payment account:', error);
      Alert.alert('Error', 'Failed to mark this account as primary.');
    } finally {
      setProcessingAccountId(null);
    }
  };

  const handleDeleteAccount = (account: SystemPaymentAccount) => {
    Alert.alert(
      'Delete Account',
      'Are you sure you want to remove this payment account?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            setProcessingAccountId(account.id);
            try {
              await dbManager.deleteSystemPaymentAccount(account.id);
              await fetchAccounts(false);
            } catch (error) {
              console.error('Error deleting payment account:', error);
              Alert.alert('Error', 'Failed to delete the payment account.');
            } finally {
              setProcessingAccountId(null);
            }
          },
        },
      ],
    );
  };

  const renderAccountCard = (account: SystemPaymentAccount) => {
    const isPrimary = Boolean(account.is_primary);
    const isActive = account.is_active ?? true;
    const isProcessing = processingAccountId === account.id;

    return (
      <View key={account.id} style={styles.accountCard}>
        <View style={styles.accountHeader}>
          <View style={styles.accountHeaderText}>
            <Text style={styles.accountLabel}>{account.label}</Text>
            <Text style={styles.accountNumber}>{account.account_number}</Text>
            {account.account_name ? (
              <Text style={styles.subLabel}>{account.account_name}</Text>
            ) : null}
            {account.provider ? (
              <Text style={styles.subLabel}>Provider: {account.provider}</Text>
            ) : null}
            {account.bank_name ? (
              <Text style={styles.subLabel}>Bank: {account.bank_name}</Text>
            ) : null}
            {account.branch_name ? (
              <Text style={styles.subLabel}>Branch: {account.branch_name}</Text>
            ) : null}
            {account.instructions ? (
              <Text style={styles.instructions}>{account.instructions}</Text>
            ) : null}
          </View>
          <View style={styles.badgeColumn}>
            {isPrimary ? (
              <View style={[styles.badge, styles.primaryBadge]}>
                <Text style={styles.badgeText}>Primary</Text>
              </View>
            ) : null}
            {!isActive ? (
              <View style={[styles.badge, styles.inactiveBadge]}>
                <Text style={styles.badgeText}>Inactive</Text>
              </View>
            ) : null}
          </View>
        </View>

        <View style={styles.accountActionsRow}>
          <TouchableOpacity
            style={styles.accountActionButton}
            onPress={() => openEditModal(account)}
            disabled={isProcessing}
            activeOpacity={0.8}
          >
            <Text style={styles.actionButtonText}>Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.accountActionButton}
            onPress={() => handleToggleActive(account)}
            disabled={isProcessing}
            activeOpacity={0.8}
          >
            <Text style={styles.actionButtonText}>
              {account.is_active ?? true ? 'Disable' : 'Enable'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.accountActionButton}
            onPress={() => handleSetPrimary(account)}
            disabled={isProcessing || isPrimary}
            activeOpacity={0.8}
          >
            <Text style={styles.actionButtonText}>Set Primary</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.accountActionButton, styles.destructiveButton]}
            onPress={() => handleDeleteAccount(account)}
            disabled={isProcessing}
            activeOpacity={0.8}
          >
            <Text style={[styles.actionButtonText, styles.destructiveText]}>
              Delete
            </Text>
          </TouchableOpacity>
        </View>
        {isProcessing ? (
          <Text style={styles.processingHint}>Applying changes...</Text>
        ) : null}
      </View>
    );
  };

  const methodKeys = useMemo(() => {
    if (filterMethod === 'all') {
      return METHOD_OPTIONS.map(option => option.value);
    }
    return [filterMethod];
  }, [filterMethod]);

  const renderContent = () => {
    if (isLoading && !refreshing) {
      return (
        <View style={styles.emptyState}>
          <Text style={styles.emptyTitle}>Loading accounts...</Text>
          <Text style={styles.emptySubtitle}>
            Please wait while we fetch the configured payment methods.
          </Text>
        </View>
      );
    }

    if (sortedAccounts.length === 0) {
      return (
        <View style={styles.emptyState}>
          <Text style={styles.emptyTitle}>No payment accounts yet</Text>
          <Text style={styles.emptySubtitle}>
            Add your official bank or mobile banking accounts so customers can
            send payments securely.
          </Text>
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={openCreateModal}
            activeOpacity={0.85}
          >
            <Text style={styles.primaryButtonText}>Add Payment Account</Text>
          </TouchableOpacity>
        </View>
      );
    }

    return methodKeys.map(method => {
      const accountsForMethod = groupedAccounts[method];
      if (!accountsForMethod || accountsForMethod.length === 0) {
        return null;
      }
      return (
        <View key={method} style={styles.methodSection}>
          <Text style={styles.methodTitle}>{METHOD_LABEL_MAP[method]}</Text>
          {accountsForMethod.map(account => renderAccountCard(account))}
        </View>
      );
    });
  };

  return (
    <Layout activeTab="dashboard">
      <ModernHeader
        title="Payment Accounts"
        subtitle="Configure AgriSmart receiving details"
        leftIconName="arrow-left"
        onLeftPress={() => navigation.goBack()}
        rightIconName="plus"
        iconSize={24}
        onRightPress={openCreateModal}
      />
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.containerContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
        }
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.filterBar}>
          {(
            ['all', ...METHOD_OPTIONS.map(option => option.value)] as const
          ).map(option => {
            const isActive = filterMethod === option;
            return (
              <TouchableOpacity
                key={option}
                style={[styles.filterChip, isActive && styles.filterChipActive]}
                onPress={() => setFilterMethod(option as MethodOption | 'all')}
                activeOpacity={0.7}
              >
                <Text
                  style={[
                    styles.filterChipText,
                    isActive && styles.filterChipTextActive,
                  ]}
                >
                  {option === 'all'
                    ? 'All'
                    : METHOD_LABEL_MAP[option as MethodOption]}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <TouchableOpacity
          style={styles.primaryButton}
          onPress={openCreateModal}
          activeOpacity={0.85}
        >
          <Text style={styles.primaryButtonText}>Add Payment Account</Text>
        </TouchableOpacity>

        {renderContent()}

        <View style={styles.bottomSpacing} />
      </ScrollView>

      <Modal
        visible={isModalVisible}
        transparent
        animationType="slide"
        onRequestClose={closeModal}
      >
        <KeyboardAvoidingView
          style={styles.modalBackdrop}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>
              {editingAccount
                ? 'Update Payment Account'
                : 'Add Payment Account'}
            </Text>
            <ScrollView
              style={styles.modalForm}
              showsVerticalScrollIndicator={false}
            >
              <Text style={styles.inputLabel}>Payment Method</Text>
              <View style={styles.methodSelectorRow}>
                {METHOD_OPTIONS.map(option => {
                  const isSelected = formState.method === option.value;
                  return (
                    <TouchableOpacity
                      key={option.value}
                      style={[
                        styles.methodPill,
                        isSelected && styles.methodPillActive,
                      ]}
                      onPress={() =>
                        handleFormChange('method', option.value as MethodOption)
                      }
                      activeOpacity={0.8}
                    >
                      <Text
                        style={[
                          styles.methodPillText,
                          isSelected && styles.methodPillTextActive,
                        ]}
                      >
                        {option.label}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>

              {formState.method === 'mobile_banking' ? (
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Provider</Text>
                  <TextInput
                    style={styles.textInput}
                    placeholder="e.g. bKash"
                    value={formState.provider}
                    onChangeText={text => handleFormChange('provider', text)}
                  />
                  <Text style={styles.helperText}>{PROVIDER_HINT}</Text>
                </View>
              ) : (
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Reference Label</Text>
                  <Text style={styles.helperText}>
                    A short name customers will see. Example: AgriSmart Bank
                    Account.
                  </Text>
                </View>
              )}

              {formState.method !== 'mobile_banking' ? (
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Label</Text>
                  <TextInput
                    style={styles.textInput}
                    placeholder="Account label"
                    value={formState.label}
                    onChangeText={text => handleFormChange('label', text)}
                  />
                </View>
              ) : (
                <View style={styles.inputGroup}>
                  <Text style={styles.inputLabel}>Label</Text>
                  <TextInput
                    style={styles.textInput}
                    placeholder="Display label"
                    value={formState.label}
                    onChangeText={text => handleFormChange('label', text)}
                  />
                </View>
              )}

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Account Number</Text>
                <TextInput
                  style={styles.textInput}
                  placeholder="Account number"
                  value={formState.account_number}
                  onChangeText={text =>
                    handleFormChange('account_number', text)
                  }
                  keyboardType="default"
                  autoCapitalize="characters"
                />
              </View>

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Account Name</Text>
                <TextInput
                  style={styles.textInput}
                  placeholder="Account holder name"
                  value={formState.account_name}
                  onChangeText={text => handleFormChange('account_name', text)}
                />
              </View>

              {formState.method === 'bank' ? (
                <>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Bank Name</Text>
                    <TextInput
                      style={styles.textInput}
                      placeholder="Bank name"
                      value={formState.bank_name}
                      onChangeText={text => handleFormChange('bank_name', text)}
                    />
                  </View>
                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Branch Name</Text>
                    <TextInput
                      style={styles.textInput}
                      placeholder="Branch name"
                      value={formState.branch_name}
                      onChangeText={text =>
                        handleFormChange('branch_name', text)
                      }
                    />
                  </View>
                </>
              ) : null}

              <View style={styles.inputGroup}>
                <Text style={styles.inputLabel}>Instructions</Text>
                <TextInput
                  style={[styles.textInput, styles.multilineInput]}
                  placeholder="Optional payment instructions"
                  value={formState.instructions}
                  onChangeText={text => handleFormChange('instructions', text)}
                  multiline
                />
              </View>

              <View style={styles.toggleRow}>
                <Text style={styles.toggleLabel}>Mark as primary</Text>
                <Switch
                  value={formState.is_primary}
                  onValueChange={value => handleFormChange('is_primary', value)}
                  trackColor={{ true: '#4CAF50', false: '#D1D5DB' }}
                  thumbColor={formState.is_primary ? '#2E7D32' : '#F4F3F4'}
                />
              </View>

              <View style={styles.toggleRow}>
                <Text style={styles.toggleLabel}>Active</Text>
                <Switch
                  value={formState.is_active}
                  onValueChange={value => handleFormChange('is_active', value)}
                  trackColor={{ true: '#4CAF50', false: '#D1D5DB' }}
                  thumbColor={formState.is_active ? '#2E7D32' : '#F4F3F4'}
                />
              </View>
            </ScrollView>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalCancelButton]}
                onPress={closeModal}
                disabled={isSaving}
                activeOpacity={0.8}
              >
                <Text style={styles.modalCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.modalButton, styles.modalPrimaryButton]}
                onPress={handleSaveAccount}
                disabled={isSaving}
                activeOpacity={0.85}
              >
                <Text style={styles.modalPrimaryText}>
                  {isSaving ? 'Saving...' : 'Save Account'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  containerContent: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 32,
  },
  filterBar: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#E5E7EB',
  },
  filterChipActive: {
    backgroundColor: '#4CAF50',
  },
  filterChipText: {
    fontSize: 13,
    color: '#1F2937',
    fontWeight: '500',
  },
  filterChipTextActive: {
    color: '#FFFFFF',
  },
  primaryButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 18,
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 20,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  primaryButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  methodSection: {
    marginBottom: 28,
  },
  methodTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 12,
  },
  accountCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 18,
    marginBottom: 16,
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  accountHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  accountHeaderText: {
    flex: 1,
    paddingRight: 12,
  },
  accountLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 4,
  },
  accountNumber: {
    fontSize: 14,
    color: '#111827',
    fontWeight: '500',
    marginBottom: 6,
  },
  subLabel: {
    fontSize: 12,
    color: '#4B5563',
    marginBottom: 4,
  },
  instructions: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
  },
  badgeColumn: {
    alignItems: 'flex-end',
    gap: 6,
  },
  badge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  primaryBadge: {
    backgroundColor: '#DCFCE7',
  },
  inactiveBadge: {
    backgroundColor: '#FFE4E6',
  },
  badgeText: {
    fontSize: 11,
    fontWeight: '600',
    color: '#064E3B',
  },
  accountActionsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginTop: 16,
  },
  accountActionButton: {
    paddingHorizontal: 14,
    paddingVertical: 10,
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
  },
  destructiveButton: {
    backgroundColor: '#FEE2E2',
  },
  actionButtonText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1F2937',
  },
  destructiveText: {
    color: '#B91C1C',
  },
  processingHint: {
    marginTop: 10,
    fontSize: 12,
    color: '#6B7280',
  },
  emptyState: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 24,
    marginTop: 24,
    alignItems: 'center',
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 6,
    elevation: 2,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 16,
  },
  bottomSpacing: {
    height: 60,
  },
  modalBackdrop: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 16,
    backgroundColor: 'rgba(17, 24, 39, 0.4)',
  },
  modalCard: {
    width: '100%',
    maxHeight: '90%',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 10,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 16,
    textAlign: 'center',
  },
  modalForm: {
    flexGrow: 0,
    marginBottom: 12,
  },
  inputGroup: {
    marginBottom: 14,
  },
  inputLabel: {
    fontSize: 13,
    color: '#1F2937',
    fontWeight: '600',
    marginBottom: 6,
  },
  helperText: {
    fontSize: 12,
    color: '#6B7280',
  },
  textInput: {
    backgroundColor: '#F9FAFB',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    color: '#111827',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  multilineInput: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  methodSelectorRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  methodPill: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#F3F4F6',
  },
  methodPillActive: {
    backgroundColor: '#4CAF50',
  },
  methodPillText: {
    fontSize: 13,
    color: '#1F2937',
    fontWeight: '500',
  },
  methodPillTextActive: {
    color: '#FFFFFF',
  },
  toggleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  toggleLabel: {
    fontSize: 14,
    color: '#111827',
    fontWeight: '500',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    gap: 12,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  modalCancelButton: {
    backgroundColor: '#F3F4F6',
  },
  modalPrimaryButton: {
    backgroundColor: '#4CAF50',
  },
  modalCancelText: {
    color: '#1F2937',
    fontWeight: '600',
  },
  modalPrimaryText: {
    color: '#FFFFFF',
    fontWeight: '700',
    letterSpacing: 0.3,
  },
});

export default SystemPaymentAccountsScreen;
