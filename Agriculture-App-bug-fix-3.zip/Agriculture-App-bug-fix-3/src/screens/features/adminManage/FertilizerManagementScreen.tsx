import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
  TextInput,
  Alert,
  ScrollView,
  Dimensions,
  Platform,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Layout from '../../../components/Layout';
import { FertilizerGuide } from '../../../types';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';

const { width } = Dimensions.get('window');

const FertilizerManagementScreen = () => {
  const dbManager = SupabaseDatabaseManager.getInstance();
  const navigation = useNavigation();
  const [fertilizerGuides, setFertilizerGuides] = useState<FertilizerGuide[]>(
    [],
  );
  const [loading, setLoading] = useState(true);
  const [isModalVisible, setModalVisible] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [currentFertilizer, setCurrentFertilizer] =
    useState<FertilizerGuide | null>(null);
  const [availableProducts, setAvailableProducts] = useState<any[]>([]);
  const [selectedProductIds, setSelectedProductIds] = useState<number[]>([]);
  const [showProductSelector, setShowProductSelector] = useState(false);
  const [productSearchQuery, setProductSearchQuery] = useState('');
  const [cropName, setCropName] = useState('');
  const [fertilizerType, setFertilizerType] = useState('');
  const [amount, setAmount] = useState('');
  const [timing, setTiming] = useState('');
  const [instructions, setInstructions] = useState('');

  useEffect(() => {
    const initializeAndFetch = async () => {
      try {
        // Make sure the database is initialized before fetching data
        await dbManager.initializeDatabase();
        fetchFertilizerGuides();
      } catch (error) {
        console.error('Error initializing database:', error);
        Alert.alert('Error', 'Failed to initialize database');
      }
    };

    initializeAndFetch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fetchFertilizerGuides = async () => {
    try {
      setLoading(true);
      console.log('Fetching fertilizer guides...');
      const guides = await dbManager.getAllFertilizerGuidesWithProducts();
      console.log('Fetched fertilizer guides:', guides);
      setFertilizerGuides(guides || []);
    } catch (error) {
      console.error('Error fetching fertilizer guides:', error);
      Alert.alert('Error', 'Failed to fetch fertilizer guides');
    } finally {
      setLoading(false);
    }
  };

  const getFilteredProducts = () => {
    if (!productSearchQuery) return availableProducts;
    return availableProducts.filter(
      product =>
        product.name.toLowerCase().includes(productSearchQuery.toLowerCase()) ||
        product.category
          .toLowerCase()
          .includes(productSearchQuery.toLowerCase()),
    );
  };

  const fetchAvailableProducts = async () => {
    try {
      console.log('Fetching available products...');
      await dbManager.initializeDatabase(); // Ensure DB is initialized
      const products = await dbManager.getAvailableProductsForFertilizerGuide();
      console.log('Fetched products:', products?.length || 0, products);
      setAvailableProducts(products || []);

      // If no products found, show alert to user
      if (!products || products.length === 0) {
        Alert.alert(
          'No Products Found',
          'No products are available in the database. Please ensure products are seeded first.',
          [{ text: 'OK' }],
        );
      }
    } catch (error) {
      console.error('Error fetching available products:', error);
      Alert.alert(
        'Error',
        'Failed to fetch available products: ' + (error as Error).message,
      );
    }
  };

  const handleAddNew = () => {
    setEditMode(false);
    setCurrentFertilizer(null);
    setCropName('');
    setFertilizerType('');
    setAmount('');
    setTiming('');
    setInstructions('');
    setSelectedProductIds([]);
    fetchAvailableProducts();
    setModalVisible(true);
  };

  const handleEdit = (item: FertilizerGuide) => {
    setEditMode(true);
    setCurrentFertilizer(item);
    setCropName(item.crop_name);
    setFertilizerType(item.fertilizer_type);
    setAmount(item.amount);
    setTiming(item.timing);
    setInstructions(item.instructions || '');
    setSelectedProductIds(item.related_products?.map(p => p.id!) || []);
    fetchAvailableProducts();
    setModalVisible(true);
  };

  const handleDelete = async (id: number | undefined) => {
    if (!id) return;

    Alert.alert(
      'Confirm Delete',
      'Are you sure you want to delete this fertilizer guide?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              // Ensure database is initialized
              await dbManager.initializeDatabase();
              await dbManager.deleteFertilizerGuide(id);
              fetchFertilizerGuides();
              Alert.alert('Success', 'Fertilizer guide deleted successfully');
            } catch (error) {
              console.error('Error deleting fertilizer guide:', error);
              Alert.alert('Error', 'Failed to delete fertilizer guide');
            }
          },
        },
      ],
    );
  };

  const handleSave = async () => {
    if (!cropName || !fertilizerType || !amount || !timing) {
      Alert.alert('Error', 'Please fill all required fields');
      return;
    }

    const fertilizerGuide: FertilizerGuide = {
      id: currentFertilizer?.id,
      crop_name: cropName,
      fertilizer_type: fertilizerType,
      amount: amount,
      timing: timing,
      instructions: instructions,
    };

    try {
      // Ensure database is initialized
      await dbManager.initializeDatabase();
      console.log('Saving fertilizer guide:', fertilizerGuide);

      if (editMode && currentFertilizer?.id) {
        await dbManager.updateFertilizerGuide(
          fertilizerGuide.id!,
          fertilizerGuide,
        );
        await dbManager.updateFertilizerGuideProducts(
          currentFertilizer.id,
          selectedProductIds,
        );
        console.log('Updated fertilizer guide successfully');
        Alert.alert('Success', 'Fertilizer guide updated successfully');
      } else {
        // Check if a guide with the same crop and fertilizer type already exists
        try {
          const existingGuides = await dbManager.getAllFertilizerGuides();
          const duplicate = existingGuides.find(
            (guide: any) =>
              guide.crop_name.toLowerCase() === cropName.toLowerCase() &&
              guide.fertilizer_type.toLowerCase() ===
                fertilizerType.toLowerCase(),
          );

          if (duplicate) {
            Alert.alert(
              'Duplicate Entry',
              `A fertilizer guide for ${cropName} with ${fertilizerType} already exists. Please edit the existing entry instead.`,
              [{ text: 'OK' }],
            );
            return;
          }

          const newId = await dbManager.createFertilizerGuide(fertilizerGuide);
          await dbManager.updateFertilizerGuideProducts(
            newId,
            selectedProductIds,
          );
          console.log('Created new fertilizer guide with ID:', newId);
          Alert.alert('Success', 'Fertilizer guide added successfully');
        } catch (error) {
          throw error;
        }
      }
      setModalVisible(false);
      fetchFertilizerGuides();
    } catch (error) {
      console.error('Error saving fertilizer guide:', error);
      Alert.alert('Error', 'Failed to save fertilizer guide');
    }
  };

  const renderItem = ({ item }: { item: FertilizerGuide }) => (
    <View style={styles.modernCard}>
      <View style={styles.cardHeaderRow}>
        <Text style={styles.cardTitle}>{item.crop_name}</Text>
        <View style={styles.cardActionsRow}>
          <TouchableOpacity
            style={[styles.iconButton, styles.editButton]}
            onPress={() => handleEdit(item)}
          >
            <MaterialCommunityIcons name="pencil" size={18} color="#1A1A1A" />
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.iconButton, styles.deleteButton]}
            onPress={() => handleDelete(item.id)}
          >
            <MaterialCommunityIcons
              name="trash-can-outline"
              size={18}
              color="#B91C1C"
            />
          </TouchableOpacity>
        </View>
      </View>
      <Text style={styles.cardSubtitle}>
        Type: <Text style={styles.cardValue}>{item.fertilizer_type}</Text>
      </Text>
      <Text style={styles.cardSubtitle}>
        Amount: <Text style={styles.cardValue}>{item.amount}</Text>
      </Text>
      <Text style={styles.cardSubtitle}>
        Timing: <Text style={styles.cardValue}>{item.timing}</Text>
      </Text>
      {item.instructions && (
        <Text style={styles.cardInstructions}>
          Instructions: {item.instructions}
        </Text>
      )}
      {item.related_products && item.related_products.length > 0 && (
        <View style={styles.productsSection}>
          <Text style={styles.productsTitle}>Related Products:</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {item.related_products.map((product: any) => (
              <TouchableOpacity
                key={product.id}
                style={styles.productTag}
                onPress={() => {
                  (navigation as any).navigate('ProductDetails', {
                    productId: product.id,
                  });
                }}
              >
                <Text style={styles.productName}>{product.name}</Text>
                <Text style={styles.productPrice}>৳{product.price}</Text>
                <Text style={styles.productViewText}>Tap to view</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      )}
    </View>
  );

  return (
    <Layout activeTab="dashboard">
      <View style={styles.modernContainer}>
        {/* Modern Header */}
        <View style={styles.modernHeader}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={[
              styles.gobackButton,
              { paddingRight: 16, paddingVertical: 4 },
            ]}
            accessibilityLabel="Go back"
          >
            <MaterialCommunityIcons
              name="arrow-left"
              size={22}
              color="#1A1A1A"
            />
          </TouchableOpacity>
          <View style={{ flex: 1, alignItems: 'flex-end' }}>
            <Text style={styles.modernHeaderTitle}>Fertilizer Management</Text>
          </View>
        </View>
        <FlatList
          data={fertilizerGuides}
          renderItem={renderItem}
          keyExtractor={item => `${item.id}`}
          numColumns={width > 600 ? 2 : 1}
          columnWrapperStyle={width > 600 ? { gap: 16 } : undefined}
          contentContainerStyle={styles.modernListContainer}
          ListEmptyComponent={
            <Text style={styles.emptyText}>
              {loading ? 'Loading...' : 'No fertilizer guides found'}
            </Text>
          }
        />
        {/* Floating Action Button */}
        <TouchableOpacity
          style={styles.fab}
          onPress={handleAddNew}
          activeOpacity={0.85}
        >
          <MaterialCommunityIcons
            name="plus"
            size={30}
            color="#FFFFFF"
            style={styles.fabIcon}
          />
        </TouchableOpacity>
        {/* Modal for Add/Edit */}
        <Modal
          visible={isModalVisible}
          transparent
          animationType="slide"
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>
                {editMode
                  ? 'Edit Fertilizer Guide'
                  : 'Add New Fertilizer Guide'}
              </Text>
              <ScrollView
                style={styles.formContainer}
                nestedScrollEnabled
                keyboardShouldPersistTaps="handled"
              >
                <Text style={styles.inputLabel}>Crop Name *</Text>
                <TextInput
                  style={styles.input}
                  value={cropName}
                  onChangeText={setCropName}
                  placeholder="Enter crop name"
                />
                <Text style={styles.inputLabel}>Fertilizer Type *</Text>
                <TextInput
                  style={styles.input}
                  value={fertilizerType}
                  onChangeText={setFertilizerType}
                  placeholder="Enter fertilizer type"
                />
                <Text style={styles.inputLabel}>Amount *</Text>
                <TextInput
                  style={styles.input}
                  value={amount}
                  onChangeText={setAmount}
                  placeholder="Enter amount (e.g., 50kg/hectare)"
                />
                <Text style={styles.inputLabel}>Timing *</Text>
                <TextInput
                  style={styles.input}
                  value={timing}
                  onChangeText={setTiming}
                  placeholder="Enter application timing"
                />
                <Text style={styles.inputLabel}>Instructions</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={instructions}
                  onChangeText={setInstructions}
                  placeholder="Enter application instructions"
                  multiline
                  numberOfLines={4}
                />
                {/* Product Selection */}
                <View style={styles.productSelector}>
                  <Text style={styles.productSelectorTitle}>
                    Related Products (Optional)
                  </Text>
                  <TouchableOpacity
                    style={styles.productSelectorButton}
                    onPress={() => {
                      if (showProductSelector) setProductSearchQuery('');
                      setShowProductSelector(!showProductSelector);
                    }}
                  >
                    <Text style={styles.productSelectorButtonText}>
                      {showProductSelector
                        ? 'Hide Product Selection'
                        : 'Select Related Products'}
                      {selectedProductIds.length > 0 &&
                        ` (${selectedProductIds.length} selected)`}
                      {availableProducts.length === 0 &&
                        ' (No products available)'}
                    </Text>
                  </TouchableOpacity>
                  {showProductSelector && (
                    <View style={styles.productSelectorContainer}>
                      <TextInput
                        style={styles.productSearchInput}
                        placeholder="Search products by name or category..."
                        value={productSearchQuery}
                        onChangeText={setProductSearchQuery}
                      />
                      <ScrollView
                        style={styles.productList}
                        nestedScrollEnabled
                        keyboardShouldPersistTaps="handled"
                      >
                        {getFilteredProducts().length === 0 ? (
                          <View style={styles.emptyProductsContainer}>
                            <Text style={styles.emptyProductsText}>
                              {availableProducts.length === 0
                                ? 'No products available. Products might not be seeded in the database yet.'
                                : 'No products match your search criteria.'}
                            </Text>
                          </View>
                        ) : (
                          getFilteredProducts().map((product: any) => (
                            <TouchableOpacity
                              key={product.id}
                              style={styles.productItem}
                              onPress={() => {
                                const isSelected = selectedProductIds.includes(
                                  product.id,
                                );
                                if (isSelected) {
                                  setSelectedProductIds(prev =>
                                    prev.filter(id => id !== product.id),
                                  );
                                } else {
                                  setSelectedProductIds(prev => [
                                    ...prev,
                                    product.id,
                                  ]);
                                }
                              }}
                            >
                              <View
                                style={[
                                  styles.productCheckbox,
                                  selectedProductIds.includes(product.id) &&
                                    styles.productCheckboxSelected,
                                ]}
                              >
                                {selectedProductIds.includes(product.id) && (
                                  <MaterialCommunityIcons
                                    name="check"
                                    size={14}
                                    color="#FFFFFF"
                                  />
                                )}
                              </View>
                              <View style={styles.productInfo}>
                                <Text style={styles.productItemName}>
                                  {product.name}
                                </Text>
                                <Text style={styles.productItemPrice}>
                                  ৳{product.price} - {product.category}
                                </Text>
                              </View>
                            </TouchableOpacity>
                          ))
                        )}
                      </ScrollView>
                    </View>
                  )}
                </View>
              </ScrollView>
              <View style={styles.modalActions}>
                <TouchableOpacity
                  style={[styles.modalButton, styles.cancelButton]}
                  onPress={() => setModalVisible(false)}
                >
                  <Text style={styles.modalButtonText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.modalButton, styles.saveButton]}
                  onPress={handleSave}
                >
                  <Text style={styles.modalButtonText}>Save</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  modernContainer: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  modernHeader: {
    backgroundColor: '#FFFFFF',
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    paddingBottom: 20,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  modernHeaderTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1A1A1A',
  },
  modernListContainer: {
    paddingHorizontal: 24,
    paddingTop: 24,
    paddingBottom: 40,
  },
  gobackButton: {
    padding: 8,
    borderRadius: 999,
    backgroundColor: '#F5F5F5',
    marginRight: 16,
  },
  modernCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    flex: 1,
    minWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  cardHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1A1A1A',
  },
  cardActionsRow: {
    flexDirection: 'row',
    gap: 8,
  },
  iconButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  iconButtonText: {
    fontSize: 18,
  },
  editButton: {
    backgroundColor: '#F5F5F5',
  },
  deleteButton: {
    backgroundColor: '#FEE2E2',
  },
  cardSubtitle: {
    fontSize: 15,
    color: '#666',
    marginBottom: 2,
  },
  cardValue: {
    color: '#1A1A1A',
    fontWeight: '600',
  },
  cardInstructions: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
    marginBottom: 4,
  },
  productsSection: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  productsTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  productTag: {
    backgroundColor: '#E8F5E8',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginRight: 8,
    alignItems: 'center',
  },
  productName: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#2E7D32',
  },
  productPrice: {
    fontSize: 10,
    color: '#4CAF50',
  },
  productViewText: {
    fontSize: 9,
    color: '#2E7D32',
    fontStyle: 'italic',
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#666',
    marginTop: 32,
  },
  fab: {
    position: 'absolute',
    right: 28,
    bottom: 36,
    backgroundColor: '#10B981',
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.18,
    shadowRadius: 12,
    elevation: 6,
    zIndex: 10,
  },
  fabIcon: {
    marginTop: -2,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 16,
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
    color: '#1A1A1A',
  },
  formContainer: {
    maxHeight: 400,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
    marginTop: 12,
    color: '#1A1A1A',
  },
  input: {
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    marginBottom: 4,
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 24,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
    marginHorizontal: 8,
  },
  modalButtonText: {
    fontWeight: 'bold',
    color: '#FFFFFF',
    fontSize: 16,
  },
  cancelButton: {
    backgroundColor: '#95a5a6',
  },
  saveButton: {
    backgroundColor: '#10B981',
  },
  productSelector: {
    marginBottom: 16,
  },
  productSelectorTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#1A1A1A',
  },
  productSelectorButton: {
    backgroundColor: '#F0F0F0',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  productSelectorButtonText: {
    color: '#666',
  },
  productList: {
    maxHeight: 300,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 8,
  },
  productItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 4,
    marginBottom: 16,
  },
  productCheckbox: {
    width: 20,
    height: 20,
    borderWidth: 2,
    borderColor: '#10B981',
    borderRadius: 4,
    marginRight: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  productCheckboxSelected: {
    backgroundColor: '#10B981',
  },
  productInfo: {
    flex: 1,
  },
  productItemName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  productItemPrice: {
    fontSize: 12,
    color: '#666',
  },
  emptyProductsContainer: {
    padding: 16,
    alignItems: 'center',
  },
  emptyProductsText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
  productSelectorContainer: {
    marginTop: 8,
  },
  productSearchInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    fontSize: 14,
    backgroundColor: '#F9F9F9',
    marginBottom: 8,
  },
});

export default FertilizerManagementScreen;
