import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  SafeAreaView,
  Image,
  Platform,
  ToastAndroid,
} from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { RootStackParamList, ShoppingCartItem } from '../../../types';
import SupabaseDatabaseManager, {
  CartConstraintError,
} from '../../../api/SupabaseDatabaseManager';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';

type CartScreenNavigationProp = StackNavigationProp<RootStackParamList, 'Cart'>;

// toast helper
const showToast = (message: string) => {
  if (Platform.OS === 'android' && ToastAndroid && ToastAndroid.show) {
    ToastAndroid.show(message, ToastAndroid.SHORT);
    return;
  }
  // Fallback
  Alert.alert('', message);
};

const CartScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<CartScreenNavigationProp>();
  const [cartItems, setCartItems] = useState<ShoppingCartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [_processingCheckout, _setProcessingCheckout] = useState(false);
  const [_user, setUser] = useState<any>(null);

  const loadCartItems = useCallback(async () => {
    try {
      const currentUser = await authManager.getCurrentUser();

      if (!currentUser) {
        navigation.replace('SignIn');
        return;
      }

      setUser(currentUser);
      if (
        typeof currentUser.id === 'number' ||
        typeof currentUser.id === 'string'
      ) {
        const userIdStr = currentUser.id.toString();
        const items = await dbManager.getUserCart(userIdStr);
        setCartItems(items);
      } else {
        throw new Error('User ID is missing or invalid');
      }
    } catch (error) {
      console.error('Error loading cart items:', error);
      Alert.alert('Error', 'Failed to load cart items');
    } finally {
      setLoading(false);
    }
  }, [navigation, dbManager, authManager]);

  useEffect(() => {
    loadCartItems();
  }, [loadCartItems]);

  useFocusEffect(
    useCallback(() => {
      loadCartItems();
    }, [loadCartItems]),
  );

  const handleUpdateQuantity = async (
    item: ShoppingCartItem,
    newQuantity: number,
  ) => {
    try {
      if (item.id) {
        if (!_user || !_user.id || !item.product_id) {
          throw new Error('User or product information missing');
        }
        const minPurchase = Math.max(
          1,
          Math.floor(
            typeof item.product_min_purchase_quantity === 'number'
              ? item.product_min_purchase_quantity
              : 1,
          ),
        );
        const rawMax =
          typeof item.product_max_purchase_quantity === 'number'
            ? Math.floor(item.product_max_purchase_quantity)
            : null;
        const maxPurchase =
          rawMax !== null && !Number.isNaN(rawMax)
            ? Math.max(rawMax, minPurchase)
            : null;

        // Normalize and clamp requested quantity to allowed range [min, stock]
        if (typeof newQuantity !== 'number' || isNaN(newQuantity)) {
          newQuantity = minPurchase;
        }
        newQuantity = Math.floor(newQuantity);
        if (newQuantity < minPurchase) {
          showToast(`Minimum order is ${minPurchase}`);
          newQuantity = minPurchase;
        }
        if (maxPurchase !== null && newQuantity > maxPurchase) {
          showToast(`Maximum per order is ${maxPurchase}`);
          newQuantity = maxPurchase;
        }

        let currentStock: number | undefined = undefined;
        try {
          const prod = await dbManager.getProductById(item.product_id);
          if (
            prod &&
            (typeof prod.stock === 'number' || typeof prod.stock === 'string')
          ) {
            const parsed = Number(prod.stock);
            if (!isNaN(parsed)) currentStock = parsed;
          }
        } catch (e) {
          console.error('Error fetching product for stock check:', e);
        }

        // fallback to snapshot stock if DB didn't provide one
        if (
          typeof currentStock !== 'number' &&
          typeof item.product_stock === 'number'
        ) {
          currentStock = item.product_stock;
        } else if (
          typeof currentStock !== 'number' &&
          typeof item.product_stock === 'string'
        ) {
          const parsed = Number(item.product_stock);
          if (!isNaN(parsed)) currentStock = parsed;
        }

        if (typeof currentStock === 'number' && newQuantity > currentStock) {
          Alert.alert(
            'Insufficient stock',
            `Only ${currentStock} items available for ${item.product_name}`,
          );
          return;
        }

        // No-op if quantity didn't change
        if (newQuantity === item.quantity) return;
        try {
          await dbManager.updateCartQuantity(
            _user.id.toString(),
            item.product_id,
            newQuantity,
          );
          // Refresh cart items
          loadCartItems();
        } catch (dbErr: any) {
          if (dbErr instanceof CartConstraintError) {
            const {
              reason,
              minPurchase: min,
              maxPurchase: max,
              availableStock,
            } = dbErr.details;
            if (reason === 'min') {
              showToast(`Minimum order is ${min}`);
            } else if (reason === 'max' && max !== null) {
              showToast(`Maximum per order is ${max}`);
            } else if (reason === 'stock') {
              const stockMessage =
                typeof availableStock === 'number'
                  ? `Only ${availableStock} item(s) available right now`
                  : 'Not enough stock available';
              Alert.alert('Insufficient stock', stockMessage);
            }
            return;
          }
          const msg = dbErr?.message || String(dbErr);
          if (
            typeof msg === 'string' &&
            msg.toLowerCase().includes('insufficient stock')
          ) {
            Alert.alert('Insufficient stock', msg);
            return;
          }
          console.error('Error updating cart quantity (db):', dbErr);
          Alert.alert('Error', 'Failed to update quantity');
          return;
        }
      }
    } catch (error) {
      console.error('Error updating quantity:', error);
      Alert.alert('Error', 'Failed to update quantity');
    }
  };

  const handleRemoveItem = async (item: ShoppingCartItem) => {
    try {
      if (item.id) {
        if (!_user || !_user.id || !item.product_id) {
          throw new Error('User or product information missing');
        }
        await dbManager.removeFromCart(_user.id.toString(), item.product_id);
        // Refresh cart items
        loadCartItems();
      }
    } catch (error) {
      console.error('Error removing item:', error);
      Alert.alert('Error', 'Failed to remove item from cart');
    }
  };

  const handleCheckout = async () => {
    if (cartItems.length === 0) {
      Alert.alert('Empty Cart', 'Your cart is empty');
      return;
    }

    // Navigate to the payment screen
    navigation.navigate('Payment');
  };

  const calculateTotal = () => {
    // subtotal (price * qty) + per-item delivery fees (once per cart row)
    const subtotal = cartItems.reduce((s, item) => {
      const price = item.product_price || 0;
      const qty = item.quantity || 0;
      return s + price * qty;
    }, 0);
    const deliveryTotal = cartItems.reduce((d, item) => {
      const delivery =
        typeof item.product_delivery_fee === 'number'
          ? item.product_delivery_fee
          : 0;
      return d + delivery;
    }, 0);
    return subtotal + deliveryTotal;
  };

  const calculateDeliveryTotal = () => {
    // Sum delivery per cart item (not multiplied by quantity)
    return cartItems.reduce((total, item) => {
      const delivery =
        typeof item.product_delivery_fee === 'number'
          ? item.product_delivery_fee
          : 0;
      return total + delivery;
    }, 0);
  };

  const renderItem = ({ item }: { item: ShoppingCartItem }) => {
    const rawStock = (item as any).product_stock;
    const parsedStock =
      typeof rawStock === 'number'
        ? rawStock
        : typeof rawStock === 'string'
        ? Number(rawStock)
        : NaN;
    const hasStock = !isNaN(parsedStock);
    const currentStock: number | undefined = hasStock ? parsedStock : undefined;

    const minPurchase = Math.max(
      1,
      Math.floor(
        typeof item.product_min_purchase_quantity === 'number'
          ? item.product_min_purchase_quantity
          : 1,
      ),
    );
    const rawMax =
      typeof item.product_max_purchase_quantity === 'number'
        ? Math.floor(item.product_max_purchase_quantity)
        : null;
    const maxPurchase =
      rawMax !== null && !Number.isNaN(rawMax)
        ? Math.max(rawMax, minPurchase)
        : null;

    const isAtMaxStock =
      typeof currentStock === 'number' && item.quantity >= currentStock;
    const isAtMaxLimit = maxPurchase !== null && item.quantity >= maxPurchase;
    const isAtMax = isAtMaxStock || isAtMaxLimit;
    const isAtMin = item.quantity <= minPurchase;

    return (
      <View style={styles.cartItem}>
        <View style={styles.productImageContainer}>
          {item.product_image_url ? (
            <Image
              source={{ uri: item.product_image_url }}
              style={styles.productImage}
              resizeMode="cover"
            />
          ) : (
            <View style={styles.productImagePlaceholder}>
              <MaterialCommunityIcons
                name="package-variant"
                size={32}
                color="#999"
              />
            </View>
          )}
        </View>

        <View style={styles.productDetails}>
          <Text style={styles.productName}>{item.product_name}</Text>
          <Text style={styles.productPrice}>
            ৳{(item.product_price || 0).toFixed(2)}/{item.product_unit}
          </Text>
          <Text style={styles.purchaseRange}>
            Minimum order: {minPurchase}
            {maxPurchase !== null ? ` • Max per order: ${maxPurchase}` : ''}
          </Text>
          <Text style={styles.farmerName}>by {item.farmer_name}</Text>

          <View style={styles.quantityContainer}>
            <TouchableOpacity
              style={[
                styles.quantityButton,
                isAtMin ? styles.quantityButtonDisabled : undefined,
              ]}
              onPress={() =>
                handleUpdateQuantity(
                  item,
                  Math.max(minPurchase, item.quantity - 1),
                )
              }
              disabled={isAtMin}
              accessibilityState={{ disabled: isAtMin }}
              activeOpacity={isAtMin ? 1 : 0.7}
            >
              <Text style={styles.quantityButtonText}>-</Text>
            </TouchableOpacity>

            <Text style={styles.quantityText}>{item.quantity}</Text>

            <TouchableOpacity
              style={[
                styles.quantityButton,
                isAtMax ? styles.quantityButtonDisabled : undefined,
              ]}
              onPress={() => handleUpdateQuantity(item, item.quantity + 1)}
              disabled={isAtMax}
              accessibilityState={{ disabled: isAtMax }}
              activeOpacity={isAtMax ? 1 : 0.7}
            >
              <Text
                style={[
                  styles.quantityButtonText,
                  isAtMax ? styles.quantityButtonTextDisabled : undefined,
                ]}
              >
                +
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.removeButton}
              onPress={() => handleRemoveItem(item)}
            >
              <Text style={styles.removeButtonText}>Remove</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.itemTotal}>
            Item Total: ৳
            {((item.product_price || 0) * item.quantity).toFixed(2)}
          </Text>
          <Text style={[styles.itemTotal, { fontSize: 13, marginTop: 2 }]}>
            Delivery Fee: ৳
            {(typeof item.product_delivery_fee === 'number'
              ? item.product_delivery_fee
              : 0
            ).toFixed(2)}
          </Text>

          {typeof currentStock === 'number' && (
            <Text style={styles.stockInfo}>
              {item.quantity >= currentStock
                ? 'No more stock available'
                : `Only ${currentStock - item.quantity} left`}
            </Text>
          )}
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <MaterialCommunityIcons name="arrow-left" size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Shopping Cart</Text>
          <View style={styles.emptyHeaderRight} />
        </View>

        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4CAF50" />
          <Text style={styles.loadingText}>Loading your cart...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialCommunityIcons name="arrow-left" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Shopping Cart</Text>
        <View style={styles.emptyHeaderRight} />
      </View>

      {cartItems.length === 0 ? (
        <View style={styles.emptyCartContainer}>
          <MaterialCommunityIcons name="cart" size={64} color="#BDBDBD" />
          <Text style={styles.emptyCartTitle}>Your cart is empty</Text>
          <Text style={styles.emptyCartMessage}>
            Add some products to your cart to see them here
          </Text>
          <TouchableOpacity
            style={styles.continueShoppingButton}
            onPress={() => navigation.navigate('ECommerce')}
          >
            <Text style={styles.continueShoppingButtonText}>
              Continue Shopping
            </Text>
          </TouchableOpacity>
        </View>
      ) : (
        <>
          <FlatList
            data={cartItems}
            renderItem={renderItem}
            keyExtractor={item => item.id?.toString() || ''}
            contentContainerStyle={styles.cartList}
          />

          <View style={styles.cartSummary}>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>Subtotal</Text>
              <Text style={styles.summaryValue}>
                ৳{calculateTotal().toFixed(2)}
              </Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryLabel}>Delivery Fee</Text>
              <Text style={styles.summaryValue}>
                ৳{calculateDeliveryTotal().toFixed(2)}
              </Text>
            </View>
            <View style={styles.summaryDivider} />
            <View style={styles.summaryItem}>
              <Text style={[styles.summaryLabel, styles.totalLabel]}>
                Total
              </Text>
              <Text style={[styles.summaryValue, styles.totalValue]}>
                ৳{calculateTotal().toFixed(2)}
              </Text>
            </View>

            <TouchableOpacity
              style={styles.checkoutButton}
              onPress={handleCheckout}
            >
              <Text style={styles.checkoutButtonText}>Proceed to Checkout</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
    marginTop: 14,
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 22,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    elevation: 2,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#4CAF50',
    fontSize: 22,
    fontWeight: '700',
  },
  headerTitle: {
    color: '#1A1A1A',
    fontSize: 22,
    fontWeight: '700',
    textAlign: 'center',
    flex: 1,
  },
  emptyHeaderRight: {
    width: 44,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#666',
    marginTop: 10,
  },
  emptyCartContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  emptyCartIcon: {
    fontSize: 64,
    marginBottom: 18,
    color: '#BDBDBD',
  },
  emptyCartTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#1A1A1A',
    textAlign: 'center',
  },
  emptyCartMessage: {
    fontSize: 15,
    textAlign: 'center',
    color: '#757575',
    marginBottom: 24,
  },
  continueShoppingButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 12,
    paddingHorizontal: 32,
    borderRadius: 22,
    marginTop: 8,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
  },
  continueShoppingButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  cartList: {
    paddingHorizontal: 8,
    paddingTop: 16,
    paddingBottom: 220, // Space for the summary card
  },
  cartItem: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginBottom: 16,
    overflow: 'hidden',
    flexDirection: 'row',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  productImageContainer: {
    width: 100,
    height: 100,
    backgroundColor: '#F5F5F5',
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    overflow: 'hidden',
  },
  productImage: {
    width: '100%',
    height: '100%',
  },
  productImagePlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: '#E0E0E0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  placeholderText: {
    fontSize: 36,
  },
  productDetails: {
    flex: 1,
    padding: 14,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  productPrice: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: '600',
  },
  farmerName: {
    fontSize: 12,
    color: '#757575',
    marginBottom: 8,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 6,
    gap: 4,
  },
  quantityButton: {
    backgroundColor: '#EEEEEE',
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  quantityButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  quantityButtonDisabled: {
    backgroundColor: '#F0F0F0',
    borderColor: '#E0E0E0',
    opacity: 0.6,
  },
  quantityButtonTextDisabled: {
    color: '#A0A0A0',
  },
  quantityText: {
    fontSize: 16,
    marginHorizontal: 10,
    color: '#333',
    minWidth: 24,
    textAlign: 'center',
  },
  removeButton: {
    marginLeft: 'auto',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: '#FFEBEE',
    borderWidth: 1,
    borderColor: '#F44336',
  },
  removeButtonText: {
    color: '#F44336',
    fontSize: 12,
    fontWeight: '600',
  },
  itemTotal: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  purchaseRange: {
    fontSize: 12,
    color: '#616161',
    marginTop: 6,
  },
  stockInfo: {
    fontSize: 12,
    color: '#BF360C',
    marginTop: 6,
    textAlign: 'right',
  },
  cartSummary: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    borderTopWidth: 1,
    borderColor: '#F0F0F0',
  },
  summaryItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  summaryLabel: {
    fontSize: 15,
    color: '#757575',
  },
  summaryValue: {
    fontSize: 15,
    color: '#333',
    fontWeight: '600',
  },
  summaryDivider: {
    height: 1,
    backgroundColor: '#EEEEEE',
    marginVertical: 10,
  },
  totalLabel: {
    fontSize: 17,
    color: '#1A1A1A',
    fontWeight: 'bold',
  },
  totalValue: {
    fontSize: 20,
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  checkoutButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 22,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 18,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
  },
  checkoutButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  hintBanner: {
    position: 'absolute',
    bottom: 140,
    left: 20,
    right: 20,
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  hintText: {
    color: '#FFFFFF',
    fontSize: 13,
  },
});

export default CartScreen;
