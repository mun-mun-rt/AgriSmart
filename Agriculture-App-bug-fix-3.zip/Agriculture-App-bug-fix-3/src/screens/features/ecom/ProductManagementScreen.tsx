import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Modal,
  FlatList,
  Image,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, ProductCategory } from '../../../types';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import ModernButton from '../../../components/ModernButton';
import ModernInput from '../../../components/ModernInput';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';

type ProductManagementScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'ProductManagement'
>;

interface ProductInterface {
  id: number;
  farmer_id: number;
  name: string;
  description: string;
  price: number;
  quantity?: number;
  stock?: number;
  unit: string;
  category: string;
  category_id?: number;
  image_url?: string;
  image?: string;
  created_at: string;
  updated_at: string;
  delivery_fee?: number;
  min_purchase_quantity?: number;
  max_purchase_quantity?: number | null;
}

const CATEGORY_ICON_MAP: Record<string, string> = {
  vegetables: 'carrot',
  vegetable: 'carrot',
  fruits: 'fruit-cherries',
  fruit: 'fruit-cherries',
  grains: 'barley',
  grain: 'barley',
  cereals: 'barley',
  dairy: 'cow',
  livestock: 'cow',
  poultry: 'food-drumstick',
  fish: 'fish',
  seafood: 'fish',
  seeds: 'sprout',
  fertilizer: 'sprout',
  fertilizers: 'sprout',
  equipment: 'tractor',
  machinery: 'tractor',
  herbs: 'leaf',
  spices: 'chili-mild',
  flowers: 'flower',
  honey: 'bee',
};

const sanitizeIconName = (value?: string): string | undefined =>
  value && /^[a-z0-9-]+$/i.test(value) ? value.toLowerCase() : undefined;

const getCategoryIconName = (category?: string, icon?: string): string => {
  const sanitizedIcon = sanitizeIconName(icon);
  if (sanitizedIcon) {
    return sanitizedIcon;
  }

  if (!category) {
    return 'basket-outline';
  }

  const normalized = category.trim().toLowerCase();
  if (CATEGORY_ICON_MAP[normalized]) {
    return CATEGORY_ICON_MAP[normalized];
  }

  if (normalized.includes('veget')) {
    return 'carrot';
  }
  if (normalized.includes('fruit')) {
    return 'fruit-cherries';
  }
  if (normalized.includes('grain') || normalized.includes('rice')) {
    return 'barley';
  }
  if (normalized.includes('dairy') || normalized.includes('milk')) {
    return 'cow';
  }
  if (
    normalized.includes('livestock') ||
    normalized.includes('animal') ||
    normalized.includes('goat') ||
    normalized.includes('cattle')
  ) {
    return 'cow';
  }
  if (normalized.includes('poultry') || normalized.includes('chicken')) {
    return 'food-drumstick';
  }
  if (normalized.includes('fish')) {
    return 'fish';
  }
  if (normalized.includes('seed')) {
    return 'sprout';
  }
  if (normalized.includes('fertil')) {
    return 'sprout';
  }
  if (normalized.includes('equip') || normalized.includes('tool')) {
    return 'tractor';
  }
  if (normalized.includes('herb')) {
    return 'leaf';
  }
  if (normalized.includes('spice')) {
    return 'chili-mild';
  }
  if (normalized.includes('flower')) {
    return 'flower';
  }
  if (normalized.includes('honey') || normalized.includes('bee')) {
    return 'bee';
  }

  return 'basket-outline';
};

const ProductManagementScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<ProductManagementScreenNavigationProp>();
  const [isLoading, setIsLoading] = useState(true);
  const [products, setProducts] = useState<ProductInterface[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<ProductInterface | null>(
    null,
  );

  // Form states
  const [productName, setProductName] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [productPrice, setProductPrice] = useState('');
  const [productQuantity, setProductQuantity] = useState('');
  const [productDeliveryFee, setProductDeliveryFee] = useState('0.00');
  const [productUnit, setProductUnit] = useState('kg');
  const [productCategory, setProductCategory] = useState('');
  const [productCategoryId, setProductCategoryId] = useState<
    number | undefined
  >(undefined);
  const [productImage, setProductImage] = useState('');
  const [productMinPurchase, setProductMinPurchase] = useState('1');
  const [productMaxPurchase, setProductMaxPurchase] = useState('');

  // Category states
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [showCategoryModal, setShowCategoryModal] = useState(false);

  const db = dbManager;

  const loadCategories = useCallback(async () => {
    try {
      // Make sure database is properly initialized
      if (!db) {
        Alert.alert('Error', 'Database not initialized');
        return;
      }

      const dbCategories = await db.getAllProductCategories();
      console.log('Loaded categories:', JSON.stringify(dbCategories, null, 2));
      setCategories(dbCategories || []);
    } catch (error: any) {
      console.error('Error loading categories:', error);
      Alert.alert(
        'Error',
        `Failed to load categories: ${error?.message || 'Unknown error'}`,
      );
    }
  }, [db]);

  // Use useCallback to prevent dependency cycle
  const loadProducts = useCallback(async () => {
    setIsLoading(true);
    try {
      const currentUser = await authManager.getCurrentUser();
      if (!currentUser || currentUser.role !== 'farmer') {
        Alert.alert('Error', 'Only farmers can manage products');
        navigation.goBack();
        return;
      }

      // Make sure database is properly initialized
      if (!db) {
        Alert.alert('Error', 'Database not initialized');
        return;
      }

      // Load categories first
      await loadCategories();

      // Load products from database
      if (currentUser.id) {
        try {
          const dbProducts = await db.getAllFarmerProducts(
            currentUser.id.toString(),
          );
          console.log('Loaded products:', JSON.stringify(dbProducts, null, 2));
          setProducts(dbProducts || []);
        } catch (dbError: any) {
          console.error('Database error when loading products:', dbError);
          Alert.alert(
            'Error',
            `Failed to load products: ${dbError?.message || 'Unknown error'}`,
          );
        }
      }
    } catch (error: any) {
      console.error('Error loading products:', error);
      Alert.alert(
        'Error',
        `Failed to load products: ${error?.message || 'Unknown error'}`,
      );
    } finally {
      setIsLoading(false);
    }
  }, [navigation, db, loadCategories, authManager]);

  useEffect(() => {
    loadProducts();
  }, [loadProducts]);

  const resetForm = () => {
    setProductName('');
    setProductDescription('');
    setProductPrice('');
    setProductQuantity('');
    setProductDeliveryFee('0.00');
    setProductUnit('kg');
    setProductCategory('');
    setProductCategoryId(undefined);
    setProductImage('');
    setProductMinPurchase('1');
    setProductMaxPurchase('');
    setCurrentProduct(null);
  };

  const handleAddProduct = () => {
    setIsAdding(true);
    setIsEditing(false);
    resetForm();
  };

  const handleEditProduct = (product: ProductInterface) => {
    console.log('Editing product:', product);
    setIsEditing(true);
    setIsAdding(false);
    setCurrentProduct(product);

    // Populate form with product data
    setProductName(product.name);
    setProductDescription(product.description || '');
    setProductPrice(product.price.toString());

    // Handle either quantity or stock field
    if (product.quantity !== undefined) {
      console.log('Using quantity field:', product.quantity);
      setProductQuantity(product.quantity.toString());
    } else if (product.stock !== undefined) {
      console.log('Using stock field:', product.stock);
      setProductQuantity(product.stock.toString());
    } else {
      console.log('No quantity or stock field found, defaulting to 0');
      setProductQuantity('0');
    }

    // Handle optional fields - these might not exist in some schemas
    setProductUnit(product.unit || '');
    setProductCategory(product.category || '');
    setProductCategoryId(product.category_id);
    setProductImage(product.image_url || product.image || '');
    // Delivery fee may be missing in some schemas; normalize to string
    try {
      const fee = (product as any).delivery_fee;
      if (typeof fee === 'number') setProductDeliveryFee(fee.toFixed(2));
      else if (typeof fee === 'string') setProductDeliveryFee(fee);
      else setProductDeliveryFee('0.00');
    } catch (e) {
      setProductDeliveryFee('0.00');
    }

    const minPurchase = product.min_purchase_quantity;
    setProductMinPurchase(
      typeof minPurchase === 'number' && !Number.isNaN(minPurchase)
        ? String(minPurchase)
        : '1',
    );

    const maxPurchase = product.max_purchase_quantity;
    setProductMaxPurchase(
      typeof maxPurchase === 'number' && !Number.isNaN(maxPurchase)
        ? String(maxPurchase)
        : '',
    );
  };

  const handleCategorySelect = (category: ProductCategory) => {
    setProductCategory(category.name);
    setProductCategoryId(category.id);
    setShowCategoryModal(false);
  };

  const handleDeleteProduct = async (productId: number) => {
    Alert.alert(
      'Confirm Delete',
      'Are you sure you want to delete this product?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            setIsLoading(true);
            try {
              await db.deleteProduct(productId);
              await loadProducts(); // Reload products after deletion
              Alert.alert('Success', 'Product deleted successfully');
            } catch (error) {
              console.error('Error deleting product:', error);
              Alert.alert('Error', 'Failed to delete product');
            } finally {
              setIsLoading(false);
            }
          },
        },
      ],
    );
  };

  const validateForm = () => {
    if (!productName.trim()) {
      Alert.alert('Error', 'Product name is required');
      return false;
    }
    if (!productDescription.trim()) {
      Alert.alert('Error', 'Product description is required');
      return false;
    }
    if (
      !productPrice ||
      isNaN(Number(productPrice)) ||
      Number(productPrice) <= 0
    ) {
      Alert.alert('Error', 'Please enter a valid price');
      return false;
    }
    if (
      !productQuantity ||
      isNaN(Number(productQuantity)) ||
      Number(productQuantity) <= 0
    ) {
      Alert.alert('Error', 'Please enter a valid quantity');
      return false;
    }

    const minValue = parseInt(productMinPurchase, 10);
    if (Number.isNaN(minValue) || minValue < 1) {
      Alert.alert('Error', 'Minimum purchase must be at least 1');
      return false;
    }

    if (productMaxPurchase.trim().length > 0) {
      const maxValue = parseInt(productMaxPurchase, 10);
      if (Number.isNaN(maxValue) || maxValue < minValue) {
        Alert.alert(
          'Error',
          'Maximum purchase must be a number greater than or equal to the minimum purchase value',
        );
        return false;
      }
    }

    // Category is still required
    if (!productCategoryId && !productCategory.trim()) {
      Alert.alert('Error', 'Please select a product category');
      return false;
    }

    // Unit is optional
    return true;
  };

  const handleSaveProduct = async () => {
    if (!validateForm()) return;

    setIsLoading(true);
    try {
      const currentUser = await authManager.getCurrentUser();
      if (!currentUser || !currentUser.id) {
        Alert.alert('Error', 'User not found');
        return;
      }

      // Make sure database is properly initialized
      if (!db) {
        Alert.alert('Error', 'Database not initialized');
        return;
      }

      const minPurchaseValue = Math.max(
        1,
        parseInt(productMinPurchase, 10) || 1,
      );
      const maxPurchaseValueRaw = productMaxPurchase.trim();
      const parsedMaxPurchase =
        maxPurchaseValueRaw.length > 0
          ? parseInt(maxPurchaseValueRaw, 10)
          : undefined;
      const maxPurchaseValue =
        typeof parsedMaxPurchase === 'number' &&
        !Number.isNaN(parsedMaxPurchase)
          ? parsedMaxPurchase
          : null;

      const productData = {
        farmer_id: String(currentUser.id),
        name: productName,
        description: productDescription,
        price: parseFloat(productPrice),
        quantity: parseInt(productQuantity, 10),
        delivery_fee: parseFloat(productDeliveryFee) || 0,
        unit: productUnit,
        category: productCategory,
        category_id: productCategoryId,
        image_url: productImage || undefined,
        min_purchase_quantity: minPurchaseValue,
        max_purchase_quantity: maxPurchaseValue,
      };

      try {
        if (isEditing && currentProduct) {
          // Update existing product
          const updateData: any = {
            name: productData.name,
            description: productData.description,
            price: productData.price,
          };

          // add quantity based on what field name exists in the product
          if ('quantity' in currentProduct) {
            console.log('Using quantity field for update');
            updateData.quantity = productData.quantity;
          } else if ('stock' in currentProduct) {
            console.log('Using stock field for update');
            updateData.stock = productData.quantity; // Use stock field but with our quantity value
          }

          // Include unit when the current product supports it
          if ('unit' in currentProduct) {
            updateData.unit = productData.unit;
          }

          // Only add category fields if appropriate
          if ('category' in currentProduct) {
            updateData.category = productData.category;
          }

          if ('category_id' in currentProduct && productData.category_id) {
            updateData.category_id = productData.category_id;
          }

          // Only add image field if the appropriate field exists in the current product
          if (productData.image_url) {
            if ('image_url' in currentProduct) {
              updateData.image_url = productData.image_url;
            } else if ('image' in currentProduct) {
              updateData.image = productData.image_url;
            }
          }

          // Include delivery_fee if the product schema supports it or attempt to set it
          try {
            if ('delivery_fee' in currentProduct) {
              updateData.delivery_fee = parseFloat(productDeliveryFee) || 0;
            } else {
              // Some schemas may not include delivery_fee; try to set it anyway
              updateData.delivery_fee = parseFloat(productDeliveryFee) || 0;
            }
          } catch (e) {
            // Ignore if we cannot determine field support
          }

          updateData.min_purchase_quantity = minPurchaseValue;
          updateData.max_purchase_quantity = maxPurchaseValue;

          console.log(
            'Updating product with ID:',
            currentProduct.id,
            'Data:',
            updateData,
          );

          await db.updateProduct(currentProduct.id, updateData);

          console.log('Product updated successfully');
          Alert.alert('Success', 'Product updated successfully');
          // Immediately reload products to show the updated list
          await loadProducts();
          setIsEditing(false);
          resetForm();
        } else {
          // Create new product
          await db.createProduct(productData);
          Alert.alert('Success', 'Product added successfully');
        }
      } catch (dbError: any) {
        console.error('Database operation error:', dbError);
        Alert.alert(
          'Error',
          `Database operation failed: ${dbError?.message || 'Unknown error'}`,
        );
        return;
      }

      // Reload products and reset form
      await loadProducts();
      setIsAdding(false);
      setIsEditing(false);
      resetForm();
    } catch (error: any) {
      console.error('Error saving product:', error);
      Alert.alert(
        'Error',
        `Failed to save product: ${error?.message || 'Unknown error'}`,
      );
    } finally {
      setIsLoading(false);
    }
  };

  const renderProductForm = () => {
    return (
      <View style={styles.formContainer}>
        <Text style={[styles.formTitle, isEditing && styles.editingFormTitle]}>
          {isEditing
            ? `Edit Product: ${currentProduct?.name}`
            : 'Add New Product'}
        </Text>

        {isEditing && (
          <View style={styles.editingBanner}>
            <Text style={styles.editingBannerText}>
              Editing Product ID: {currentProduct?.id}
            </Text>
          </View>
        )}

        <ModernInput
          label="Product Name"
          value={productName}
          onChangeText={setProductName}
          placeholder="Enter product name"
        />

        <ModernInput
          label="Description"
          value={productDescription}
          onChangeText={setProductDescription}
          placeholder="Enter product description"
          multiline
          numberOfLines={3}
        />

        <View style={styles.rowContainer}>
          <View style={styles.halfWidth}>
            <ModernInput
              label="Price (BDT)"
              value={productPrice}
              onChangeText={setProductPrice}
              placeholder="0.00"
              keyboardType="numeric"
            />
          </View>

          <View style={styles.halfWidth}>
            <ModernInput
              label="Quantity"
              value={productQuantity}
              onChangeText={setProductQuantity}
              placeholder="0"
              keyboardType="numeric"
            />
          </View>
        </View>

        <View style={styles.rowContainer}>
          <View style={styles.halfWidth}>
            <Text style={styles.inputLabel}>Unit</Text>
            <View style={styles.pickerContainer}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {['kg', 'g', 'liter', 'piece', 'dozen', 'bag', 'box'].map(
                  unit => (
                    <TouchableOpacity
                      key={unit}
                      style={[
                        styles.unitOption,
                        productUnit === unit && styles.selectedUnit,
                      ]}
                      onPress={() => setProductUnit(unit)}
                    >
                      <Text
                        style={[
                          styles.unitText,
                          productUnit === unit && styles.selectedUnitText,
                        ]}
                      >
                        {unit}
                      </Text>
                    </TouchableOpacity>
                  ),
                )}
              </ScrollView>
            </View>
          </View>

          <View style={styles.halfWidth}>
            <Text style={styles.inputLabel}>Category</Text>
            <TouchableOpacity
              style={styles.categorySelector}
              onPress={() => setShowCategoryModal(true)}
            >
              <Text
                style={
                  productCategory
                    ? styles.categoryValue
                    : styles.placeholderText
                }
              >
                {productCategory || 'Select a category'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.rowContainer}>
          <View style={styles.halfWidth}>
            <ModernInput
              label="Min Purchase Quantity"
              value={productMinPurchase}
              onChangeText={setProductMinPurchase}
              placeholder="1"
              keyboardType="numeric"
            />
          </View>

          <View style={styles.halfWidth}>
            <ModernInput
              label="Max Purchase Quantity"
              value={productMaxPurchase}
              onChangeText={setProductMaxPurchase}
              placeholder="Optional"
              keyboardType="numeric"
            />
          </View>
        </View>

        <ModernInput
          label="Image URL (Optional)"
          value={productImage}
          onChangeText={setProductImage}
          placeholder="Enter image URL"
        />

        <ModernInput
          label="Delivery Fee (BDT)"
          value={productDeliveryFee}
          onChangeText={setProductDeliveryFee}
          placeholder="0.00"
          keyboardType="numeric"
        />

        <View style={styles.buttonContainer}>
          <View style={styles.halfWidth}>
            <ModernButton
              title={isEditing ? 'Cancel Edit' : 'Cancel'}
              variant="outline"
              onPress={() => {
                setIsAdding(false);
                setIsEditing(false);
                resetForm();
              }}
            />
          </View>

          <View style={styles.halfWidth}>
            <ModernButton
              title={isEditing ? 'Update Product' : 'Save Product'}
              onPress={handleSaveProduct}
              variant={isEditing ? 'secondary' : 'primary'}
            />
          </View>
        </View>
      </View>
    );
  };

  const renderProductCard = ({ item: product }: { item: ProductInterface }) => (
    <View style={styles.productCard}>
      <View style={styles.productImageWrapper}>
        {product.image_url || product.image ? (
          <Image
            source={{ uri: product.image_url || product.image }}
            style={styles.productImage}
            resizeMode="cover"
          />
        ) : (
          <View style={styles.productImagePlaceholder}>
            <Image
              source={require('../../../assets/placeholder.png')}
              style={styles.productImage}
              resizeMode="cover"
            />
          </View>
        )}
      </View>
      <View style={styles.productInfoSection}>
        <View style={styles.productHeader}>
          <Text style={styles.productName} numberOfLines={1}>
            {product.name}
          </Text>
          <Text style={styles.productPrice}>
            ৳{product.price.toFixed(2)}{' '}
            <Text style={styles.productUnit}>/ {product.unit}</Text>
          </Text>
        </View>
        <Text style={styles.productDescription} numberOfLines={2}>
          {product.description}
        </Text>
        <View style={styles.productDetailsRow}>
          <View style={styles.productDetailItem}>
            <Text>Quantity:</Text>
            <Text style={styles.productDetailText}>
              {product.quantity !== undefined
                ? product.quantity
                : product.stock !== undefined
                ? product.stock
                : '0'}{' '}
              {product.unit}
            </Text>
          </View>
          <View style={styles.productDetailItem}>
            <Text>Category:</Text>
            <Text style={styles.productDetailText}>
              {product.category || 'Uncategorized'}
            </Text>
          </View>
        </View>
        <View style={styles.productDetailsRow}>
          <View style={styles.productDetailItem}>
            <Text>Min Order:</Text>
            <Text style={styles.productDetailText}>
              {product.min_purchase_quantity ?? 1}
            </Text>
          </View>
          <View style={styles.productDetailItem}>
            <Text>Max / Order:</Text>
            <Text style={styles.productDetailText}>
              {product.max_purchase_quantity ?? 'No limit'}
            </Text>
          </View>
        </View>
        <View style={styles.actionButtonsRow}>
          <TouchableOpacity
            style={[styles.iconButton, styles.editButton]}
            onPress={() => handleEditProduct(product)}
            accessibilityLabel="Edit Product"
          >
            <Text style={{ color: '#2196F3', fontWeight: 'bold' }}>Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.iconButton, styles.deleteButton]}
            onPress={() => handleDeleteProduct(product.id)}
            accessibilityLabel="Delete Product"
          >
            <Text style={{ color: '#F44336', fontWeight: 'bold' }}>Delete</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  const renderProductList = () => {
    if (products.length === 0) {
      return (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>
            You don't have any products yet. Add your first product!
          </Text>
          <ModernButton title="Add Product" onPress={handleAddProduct} />
        </View>
      );
    }
    return (
      <FlatList
        data={products}
        renderItem={renderProductCard}
        keyExtractor={item => item.id.toString()}
        contentContainerStyle={styles.flatListContent}
        showsVerticalScrollIndicator={false}
        numColumns={1}
      />
    );
  };

  const renderListHeader = () => (
    <>
      <View style={styles.statsSection}>
        <Text style={styles.overviewTitle}>Overview</Text>
        <View style={styles.statsContainer}>
          <View style={styles.statCardRow}>
            <View style={[styles.statCard, { backgroundColor: '#E3F2FD' }]}>
              <Text style={styles.statValue}>{totalProducts}</Text>
              <Text style={styles.statLabel}>Total Products</Text>
            </View>
            <View style={[styles.statCard, { backgroundColor: '#FFF9C4' }]}>
              <Text style={styles.statValue}>{totalStock}</Text>
              <Text style={styles.statLabel}>Total Stock</Text>
            </View>
            <View style={[styles.statCard, { backgroundColor: '#C8E6C9' }]}>
              <Text style={styles.statValue}>{categoriesSet.size}</Text>
              <Text style={styles.statLabel}>Categories</Text>
            </View>
          </View>
        </View>
      </View>
      <View style={styles.addButtonRow}>
        <ModernButton title="Add Product" onPress={handleAddProduct} />
      </View>
      <Text style={styles.sectionTitle}>Your Products</Text>
    </>
  );

  const renderEmptyList = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyText}>
        You don't have any products yet. Add your first product!
      </Text>
      <ModernButton title="Add Product" onPress={handleAddProduct} />
    </View>
  );

  // Overview stats
  const totalProducts = products.length;
  const totalStock = products.reduce(
    (sum, p) =>
      sum +
      (typeof p.quantity === 'number'
        ? p.quantity
        : typeof p.stock === 'number'
        ? p.stock
        : 0),
    0,
  );
  const categoriesSet = new Set(
    products.map(p => p.category || 'Uncategorized'),
  );

  return (
    <Layout activeTab="dashboard">
      <View style={styles.container}>
        <ModernHeader
          title="Product Management"
          subtitle="Manage Your Farm Products"
          leftIconName="arrow-left"
          iconSize={24}
          onLeftPress={() => navigation.goBack()}
        />

        {isLoading ? (
          <ModernLoading visible={true} message="Loading products..." />
        ) : isAdding || isEditing ? (
          <ScrollView style={{ flex: 1 }}>{renderProductForm()}</ScrollView>
        ) : (
          <FlatList
            data={products}
            renderItem={renderProductCard}
            keyExtractor={item => item.id.toString()}
            ListHeaderComponent={renderListHeader}
            ListEmptyComponent={renderEmptyList}
            contentContainerStyle={styles.contentContainer}
            showsVerticalScrollIndicator={false}
          />
        )}

        {/* Category Selection Modal */}
        <Modal
          visible={showCategoryModal}
          transparent={true}
          animationType="slide"
          onRequestClose={() => setShowCategoryModal(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Select Category</Text>
              <FlatList
                data={categories}
                keyExtractor={(item, index) =>
                  (typeof item === 'string'
                    ? item
                    : item.id?.toString?.() || item.name) || index.toString()
                }
                renderItem={({ item }) => {
                  const cat = typeof item === 'string' ? { name: item } : item;
                  return (
                    <TouchableOpacity
                      style={styles.categoryItem}
                      onPress={() =>
                        handleCategorySelect(cat as ProductCategory)
                      }
                    >
                      <View
                        style={{ flexDirection: 'row', alignItems: 'center' }}
                      >
                        <MaterialCommunityIcons
                          name={getCategoryIconName(cat.name, cat.icon)}
                          size={20}
                          color="#4CAF50"
                          style={{ marginRight: 8 }}
                        />
                        <Text style={styles.categoryItemText}>{cat.name}</Text>
                      </View>
                    </TouchableOpacity>
                  );
                }}
              />
              <ModernButton
                title="Cancel"
                onPress={() => setShowCategoryModal(false)}
                variant="outline"
              />
            </View>
          </View>
        </Modal>
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  statsSection: {
    marginTop: 32,
    marginBottom: 40,
  },
  overviewTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    flexWrap: 'wrap',
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 1,
    marginBottom: 8,
    minWidth: 80,
  },
  statValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 13,
    color: '#666666',
    fontWeight: '500',
    textAlign: 'center',
  },
  inventoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    justifyContent: 'space-between',
  },
  bottomPadding: {
    height: 40,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  addButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
  productCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 14,
    marginBottom: 18,
    padding: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
    minHeight: 120,
    overflow: 'hidden',
  },
  productImageWrapper: {
    width: 100,
    height: 100,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    borderTopLeftRadius: 14,
    borderBottomLeftRadius: 14,
    marginRight: 12,
    alignSelf: 'center',
  },
  productImage: {
    width: 100,
    height: 100,
    borderTopLeftRadius: 14,
    borderBottomLeftRadius: 14,
  },
  productImagePlaceholder: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#E0E0E0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  productInfoSection: {
    flex: 1,
    paddingVertical: 14,
    paddingRight: 14,
    justifyContent: 'space-between',
  },
  productHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  productName: {
    fontSize: 17,
    fontWeight: '700',
    color: '#222',
    flex: 1,
    marginRight: 8,
  },
  productPrice: {
    fontSize: 16,
    fontWeight: '700',
    color: '#4CAF50',
  },
  productUnit: {
    fontSize: 13,
    color: '#888',
    fontWeight: '400',
  },
  productDescription: {
    fontSize: 13,
    color: '#666',
    marginBottom: 6,
  },
  productDetailsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 16,
  },
  productDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 16,
    gap: 4,
  },
  productDetailText: {
    fontSize: 13,
    color: '#757575',
    marginLeft: 4,
  },
  actionButtonsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 2,
  },
  iconButton: {
    backgroundColor: '#F5F5F5',
    borderRadius: 20,
    padding: 8,
    marginRight: 6,
  },
  editButton: {
    backgroundColor: '#E3F2FD',
  },
  deleteButton: {
    backgroundColor: '#FFEBEE',
  },
  flatListContent: {
    paddingBottom: 32,
  },
  statCardRow: {
    flexDirection: 'row',
    width: '100%',
    gap: 12,
  },
  addButtonRow: {
    marginBottom: 18,
    marginTop: 2,
    alignItems: 'flex-end',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 16,
    color: '#666666',
    textAlign: 'center',
    marginBottom: 20,
  },
  formContainer: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 10,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  formTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 16,
    textAlign: 'center',
  },
  rowContainer: {
    flexDirection: 'row',
    marginBottom: 15,
    justifyContent: 'space-between',
  },
  halfWidth: {
    width: '48%',
  },
  inputLabel: {
    fontSize: 14,
    color: '#555555',
    marginBottom: 6,
  },
  pickerContainer: {
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 10,
    backgroundColor: '#F9F9F9',
  },
  unitOption: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
    marginRight: 8,
    backgroundColor: '#EEEEEE',
  },
  selectedUnit: {
    backgroundColor: '#4CAF50',
  },
  unitText: {
    fontSize: 14,
    color: '#555555',
  },
  selectedUnitText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  buttonContainer: {
    flexDirection: 'row',
    marginTop: 20,
    justifyContent: 'space-between',
  },
  editingFormTitle: {
    color: '#2196F3', // Blue color to indicate editing
  },
  editingBanner: {
    backgroundColor: '#E3F2FD', // Light blue background
    padding: 8,
    borderRadius: 4,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#2196F3',
  },
  editingBannerText: {
    color: '#0D47A1',
    fontSize: 14,
    fontWeight: 'bold',
  },
  categorySelector: {
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 14,
    backgroundColor: '#F9F9F9',
  },
  categoryValue: {
    fontSize: 14,
    color: '#333333',
  },
  placeholderText: {
    fontSize: 14,
    color: '#999999',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    width: '80%',
    maxHeight: '70%',
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  categoryItem: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  categoryItemText: {
    fontSize: 16,
  },
});

export default ProductManagementScreen;
