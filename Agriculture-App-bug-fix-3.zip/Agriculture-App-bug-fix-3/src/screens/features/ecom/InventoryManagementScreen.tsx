import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Image,
  Modal,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { RootStackParamList } from '../../../types';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import ModernInput from '../../../components/ModernInput';
import ModernButton from '../../../components/ModernButton';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';

type InventoryManagementScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'InventoryManagement'
>;

type SortKey = 'name' | 'stock' | 'category' | 'price';

interface InventoryItem {
  id: number;
  product_id: number;
  product_name: string;
  current_stock: number;
  minimum_stock: number;
  last_restock_date: string;
  product_price: number;
  product_delivery_fee?: number;
  product_category: string;
  product_unit: string;
  pending_orders: number;
  image_url?: string | null;
}

const InventoryManagementScreen: React.FC = () => {
  const navigation = useNavigation<InventoryManagementScreenNavigationProp>();
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [currentItem, setCurrentItem] = useState<InventoryItem | null>(null);
  const [newStockAmount, setNewStockAmount] = useState<string>('');
  const [newDeliveryFee, setNewDeliveryFee] = useState<string>('');
  const [categories, setCategories] = useState<string[]>(['all']);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<SortKey>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [lowStockThreshold, setLowStockThreshold] = useState<number>(5);

  useEffect(() => {
    const fetchInventory = async () => {
      setIsLoading(true);
      try {
        const products =
          await SupabaseDatabaseManager.getInstance().getCurrentUserProducts();

        let pendingMap: Record<number, number> = {};
        try {
          const auth = await SupabaseAuthManager.getInstance().getCurrentUser();
          if (auth?.id) {
            const orders =
              await SupabaseDatabaseManager.getInstance().getFarmerOrders(
                String(auth.id),
              );
            (orders || []).forEach((o: any) => {
              const status = (o.status || 'pending').toLowerCase();
              const pid = Number(o.product_id || o.product?.id || 0);
              const qty = Number(o.quantity || 0);
              if (!pid) {
                return;
              }
              if (status === 'pending') {
                pendingMap[pid] = (pendingMap[pid] || 0) + qty;
              }
            });
          }
        } catch (err) {
          console.warn('Could not compute pending orders map', err);
          pendingMap = {};
        }

        const mapped: InventoryItem[] = (products || []).map((p: any) => ({
          id: p.id,
          product_id: p.id,
          product_name: p.name,
          image_url: p.image_url || p.image || null,
          current_stock:
            typeof p.quantity === 'number'
              ? p.quantity
              : typeof p.stock === 'number'
              ? p.stock
              : 0,
          minimum_stock:
            typeof p.minimum_stock === 'number' ? p.minimum_stock : 0,
          last_restock_date:
            p.updated_at || p.created_at || new Date().toISOString(),
          product_price: typeof p.price === 'number' ? p.price : 0,
          product_delivery_fee:
            typeof p.delivery_fee === 'number' ? p.delivery_fee : undefined,
          product_category: p.category || p.product_category || 'Other',
          product_unit: p.unit || 'unit',
          pending_orders: pendingMap[p.id] || 0,
        }));

        setInventoryItems(mapped);
        const cats = Array.from(
          new Set(
            mapped.map(
              (item: InventoryItem) => item.product_category || 'Other',
            ),
          ),
        );
        setCategories(['all', ...cats.filter(c => c && c !== 'all')]);
      } catch (error) {
        console.error('Error fetching inventory:', error);
        setInventoryItems([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchInventory();
  }, []);

  const getFilteredAndSortedItems = () => {
    let filtered = [...inventoryItems];
    if (searchQuery) {
      filtered = filtered.filter(
        item =>
          item.product_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.product_category
            .toLowerCase()
            .includes(searchQuery.toLowerCase()),
      );
    }
    if (filterCategory !== 'all') {
      filtered = filtered.filter(
        item => item.product_category === filterCategory,
      );
    }
    filtered.sort((a, b) => {
      let comparison = 0;
      switch (sortBy) {
        case 'name':
          comparison = a.product_name.localeCompare(b.product_name);
          break;
        case 'stock':
          comparison = a.current_stock - b.current_stock;
          break;
        case 'category':
          comparison = a.product_category.localeCompare(b.product_category);
          break;
        case 'price':
          comparison = a.product_price - b.product_price;
          break;
        default:
          comparison = 0;
      }
      return sortOrder === 'asc' ? comparison : -comparison;
    });
    return filtered;
  };

  const cancelStockUpdate = () => {
    setIsUpdating(false);
    setCurrentItem(null);
    setNewStockAmount('');
    setNewDeliveryFee('');
  };

  const saveStockUpdate = async () => {
    if (!currentItem) {
      return;
    }
    const newStock = parseInt(newStockAmount, 10);
    if (Number.isNaN(newStock) || newStock < 0) {
      Alert.alert('Error', 'Please enter a valid stock amount');
      return;
    }
    setIsLoading(true);
    try {
      await SupabaseDatabaseManager.getInstance().updateProductStock(
        currentItem.product_id,
        newStock,
      );

      let fee: number | null = null;
      if (newDeliveryFee !== '') {
        const parsed = parseFloat(newDeliveryFee);
        if (!Number.isNaN(parsed)) {
          fee = parsed;
          await SupabaseDatabaseManager.getInstance().updateProduct(
            currentItem.product_id,
            { delivery_fee: parsed },
          );
        }
      }

      const updatedItems = inventoryItems.map(item =>
        item.id === currentItem.id
          ? {
              ...item,
              current_stock: newStock,
              last_restock_date: new Date().toISOString(),
              product_delivery_fee:
                fee !== null ? fee : item.product_delivery_fee,
            }
          : item,
      );

      setInventoryItems(updatedItems);
      setIsUpdating(false);
      Alert.alert('Success', 'Stock updated successfully');
    } catch (error: any) {
      console.error('Error updating stock:', error);
      Alert.alert(
        'Error',
        `Failed to update stock: ${error?.message || 'Unknown error'}`,
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateStock = (item: InventoryItem) => {
    setCurrentItem(item);
    setNewStockAmount(item.current_stock.toString());
    setNewDeliveryFee(
      item.product_delivery_fee !== undefined
        ? String(item.product_delivery_fee)
        : '0',
    );
    setIsUpdating(true);
  };

  const handleSortPress = (key: SortKey) => {
    if (sortBy === key) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(key);
      setSortOrder('asc');
    }
  };

  const renderSortOption = (key: SortKey, label: string) => (
    <TouchableOpacity
      key={key}
      style={[styles.sortOption, sortBy === key && styles.activeSortOption]}
      onPress={() => handleSortPress(key)}
      accessibilityRole="button"
      accessibilityLabel={`Sort by ${label}`}
    >
      <View style={styles.sortOptionContent}>
        <Text
          style={[
            styles.sortOptionText,
            sortBy === key && styles.activeSortOptionText,
          ]}
        >
          {label}
        </Text>
        {sortBy === key && (
          <MaterialCommunityIcons
            name={sortOrder === 'asc' ? 'chevron-down' : 'chevron-up'}
            size={16}
            color="#1976D2"
            style={styles.sortOptionIcon}
          />
        )}
      </View>
    </TouchableOpacity>
  );

  const renderInventoryItem = ({ item }: { item: InventoryItem }) => {
    const isLowStock = item.current_stock <= lowStockThreshold;
    const isOutOfStock = item.current_stock === 0;
    const willBeOutOfStock = item.current_stock - item.pending_orders <= 0;

    return (
      <View style={styles.inventoryCardModern}>
        <View style={styles.inventoryCardHeader}>
          {item.image_url ? (
            <Image
              source={{ uri: item.image_url }}
              style={styles.productImage}
            />
          ) : (
            <View style={styles.inventoryAvatar}>
              <Text style={styles.inventoryAvatarText}>
                {item.product_name.charAt(0).toUpperCase()}
              </Text>
            </View>
          )}
          <View style={styles.inventoryCardInfo}>
            <Text style={styles.itemName}>{item.product_name}</Text>
            <Text style={styles.itemCategory}>{item.product_category}</Text>
          </View>
        </View>
        <View style={styles.inventoryDetailsRow}>
          <View style={styles.itemDetailModern}>
            <Text style={styles.detailLabel}>Stock</Text>
            <Text
              style={[
                styles.detailValue,
                isOutOfStock && styles.outOfStock,
                isLowStock && !isOutOfStock && styles.lowStock,
              ]}
            >
              {item.current_stock} {item.product_unit}
            </Text>
          </View>
          <View style={styles.itemDetailModern}>
            <Text style={styles.detailLabel}>Pending</Text>
            <Text style={styles.detailValue}>
              {item.pending_orders} {item.product_unit}
            </Text>
          </View>
          <View style={styles.itemDetailModern}>
            <Text style={styles.detailLabel}>After Orders</Text>
            <Text
              style={[
                styles.detailValue,
                willBeOutOfStock && styles.outOfStock,
                item.current_stock - item.pending_orders <= lowStockThreshold &&
                  !willBeOutOfStock &&
                  styles.lowStock,
              ]}
            >
              {Math.max(0, item.current_stock - item.pending_orders)}{' '}
              {item.product_unit}
            </Text>
          </View>
          <View style={styles.itemDetailModern}>
            <Text style={styles.detailLabel}>Price</Text>
            <Text style={styles.detailValue}>
              Tk {item.product_price.toFixed(2)} / {item.product_unit}
            </Text>
          </View>
          <View style={styles.itemDetailModern}>
            <Text style={styles.detailLabel}>Restocked</Text>
            <Text style={styles.detailValue}>
              {new Date(item.last_restock_date).toLocaleDateString()}
            </Text>
          </View>
        </View>
        <View style={styles.inventoryActionsModern}>
          <ModernButton
            title="Update Stock"
            onPress={() => handleUpdateStock(item)}
            variant="secondary"
            style={styles.inventoryActionButton}
          />
        </View>
        {isLowStock && (
          <View style={styles.warningBannerModern}>
            <View style={styles.warningContent}>
              <MaterialCommunityIcons
                name={isOutOfStock ? 'alert-octagon' : 'alert-outline'}
                size={18}
                color="#E65100"
              />
              <Text style={styles.warningTextModern}>
                {isOutOfStock
                  ? 'Out of stock!'
                  : 'Low stock! Consider restocking soon.'}
              </Text>
            </View>
          </View>
        )}
        {!isLowStock && willBeOutOfStock && (
          <View style={styles.warningBannerModern}>
            <View style={styles.warningContent}>
              <MaterialCommunityIcons
                name="alert-outline"
                size={18}
                color="#E65100"
              />
              <Text style={styles.warningTextModern}>
                Will be out of stock after fulfilling pending orders!
              </Text>
            </View>
          </View>
        )}
      </View>
    );
  };

  const renderStockUpdateModal = () => {
    if (!currentItem) {
      return null;
    }

    return (
      <Modal
        visible={isUpdating}
        transparent={true}
        animationType="slide"
        onRequestClose={cancelStockUpdate}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modal}>
            <Text style={styles.modalTitle}>Update Stock</Text>
            <Text style={styles.modalSubtitle}>{currentItem.product_name}</Text>
            <View style={styles.modalContent}>
              <Text style={styles.modalLabel}>
                Current Stock: {currentItem.current_stock}{' '}
                {currentItem.product_unit}
              </Text>
              <ModernInput
                label="New Stock Amount"
                value={newStockAmount}
                onChangeText={setNewStockAmount}
                keyboardType="numeric"
                placeholder="Enter new stock amount"
              />
              <ModernInput
                label="Delivery Fee"
                value={newDeliveryFee}
                onChangeText={setNewDeliveryFee}
                keyboardType="numeric"
                placeholder="Delivery fee (e.g. 2.50)"
              />
              <Text style={styles.modalNote}>
                Note: Pending orders: {currentItem.pending_orders}{' '}
                {currentItem.product_unit}
              </Text>
            </View>
            <View style={styles.modalActions}>
              <ModernButton
                title="Cancel"
                onPress={cancelStockUpdate}
                variant="outline"
                style={styles.modalButtonCancel}
              />
              <ModernButton
                title="Save"
                onPress={saveStockUpdate}
                variant="primary"
                style={styles.modalButtonSave}
              />
            </View>
          </View>
        </View>
      </Modal>
    );
  };

  const totalProducts = inventoryItems.length;
  const lowStockCount = inventoryItems.filter(
    item => item.current_stock <= lowStockThreshold && item.current_stock > 0,
  ).length;
  const outOfStockCount = inventoryItems.filter(
    item => item.current_stock === 0,
  ).length;
  const totalStock = inventoryItems.reduce(
    (sum, item) => sum + (item.current_stock || 0),
    0,
  );
  const totalPending = inventoryItems.reduce(
    (sum, item) => sum + (item.pending_orders || 0),
    0,
  );

  return (
    <Layout activeTab="dashboard">
      <View style={styles.container}>
        <ModernHeader
          title="Inventory Management"
          subtitle="Manage Your Product Stock"
          leftIconName="arrow-left"
          iconSize={24}
          onLeftPress={() => navigation.goBack()}
        />

        {isLoading ? (
          <ModernLoading visible={true} message="Loading inventory data..." />
        ) : (
          <ScrollView
            style={styles.content}
            contentContainerStyle={styles.contentContainer}
            showsVerticalScrollIndicator={false}
          >
            <View style={styles.statsSection}>
              <Text style={styles.overviewTitle}>Overview</Text>
              <View style={styles.statsContainer}>
                <View style={{ flexDirection: 'row', width: '100%', gap: 12 }}>
                  <View
                    style={[styles.statCard, { backgroundColor: '#E3F2FD' }]}
                  >
                    <Text style={styles.statValue}>{totalProducts}</Text>
                    <Text style={styles.statLabel}>Total Products</Text>
                  </View>
                  <View
                    style={[styles.statCard, { backgroundColor: '#FFF9C4' }]}
                  >
                    <Text style={styles.statValue}>{totalStock}</Text>
                    <Text style={styles.statLabel}>Total Stock</Text>
                  </View>
                  <View
                    style={[styles.statCard, { backgroundColor: '#C8E6C9' }]}
                  >
                    <Text style={styles.statValue}>{totalPending}</Text>
                    <Text style={styles.statLabel}>Pending Orders</Text>
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    width: '100%',
                    gap: 12,
                    marginTop: 12,
                  }}
                >
                  <View
                    style={[styles.statCard, { backgroundColor: '#BBDEFB' }]}
                  >
                    <Text style={styles.statValue}>{lowStockCount}</Text>
                    <Text style={styles.statLabel}>Low Stock</Text>
                  </View>
                  <View
                    style={[styles.statCard, { backgroundColor: '#FFCDD2' }]}
                  >
                    <Text style={styles.statValue}>{outOfStockCount}</Text>
                    <Text style={styles.statLabel}>Out of Stock</Text>
                  </View>
                </View>
              </View>
            </View>

            <View style={styles.filterContainer}>
              <ModernInput
                placeholder="Search products..."
                value={searchQuery}
                onChangeText={setSearchQuery}
                style={styles.searchInput}
              />
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={styles.categoryFilters}
                contentContainerStyle={styles.categoryFiltersContent}
              >
                {categories.map(category => (
                  <TouchableOpacity
                    key={category}
                    style={[
                      styles.categoryFilter,
                      filterCategory === category &&
                        styles.activeCategoryFilter,
                    ]}
                    onPress={() => setFilterCategory(category)}
                  >
                    <Text
                      style={[
                        styles.categoryFilterText,
                        filterCategory === category &&
                          styles.activeCategoryFilterText,
                      ]}
                    >
                      {category === 'all' ? 'All Categories' : category}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
            <View style={styles.sortContainer}>
              <Text style={styles.sortLabel}>Sort by:</Text>
              <View style={styles.sortOptions}>
                {renderSortOption('name', 'Name')}
                {renderSortOption('stock', 'Stock')}
                {renderSortOption('category', 'Category')}
                {renderSortOption('price', 'Price')}
              </View>
            </View>
            <View style={styles.thresholdContainer}>
              <Text style={styles.thresholdLabel}>
                Low Stock Alert Threshold:
              </Text>
              <View style={styles.thresholdControls}>
                <TouchableOpacity
                  style={styles.thresholdButton}
                  onPress={() =>
                    setLowStockThreshold(Math.max(1, lowStockThreshold - 1))
                  }
                  accessibilityRole="button"
                  accessibilityLabel="Decrease low stock threshold"
                >
                  <MaterialCommunityIcons name="minus" size={18} color="#FFF" />
                </TouchableOpacity>
                <Text style={styles.thresholdValue}>{lowStockThreshold}</Text>
                <TouchableOpacity
                  style={styles.thresholdButton}
                  onPress={() => setLowStockThreshold(lowStockThreshold + 1)}
                  accessibilityRole="button"
                  accessibilityLabel="Increase low stock threshold"
                >
                  <MaterialCommunityIcons name="plus" size={18} color="#FFF" />
                </TouchableOpacity>
              </View>
            </View>

            <Text style={styles.sectionTitle}>Your Products</Text>
            <View style={styles.inventoryGrid}>
              {getFilteredAndSortedItems().length > 0 ? (
                getFilteredAndSortedItems().map(item => (
                  <View key={item.id}>{renderInventoryItem({ item })}</View>
                ))
              ) : (
                <View style={styles.emptyContainer}>
                  <Text style={styles.emptyText}>
                    {searchQuery || filterCategory !== 'all'
                      ? 'No products match your search or filter criteria'
                      : 'No products in your inventory yet'}
                  </Text>
                  <ModernButton
                    title="Add Products"
                    onPress={() => navigation.navigate('ProductManagement')}
                    style={styles.addProductButton}
                  />
                </View>
              )}
            </View>

            {isUpdating && renderStockUpdateModal()}
            <View style={styles.bottomPadding} />
          </ScrollView>
        )}
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  statsSection: {
    marginTop: 32,
    marginBottom: 40,
  },
  overviewTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    flexWrap: 'wrap',
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 1,
    marginBottom: 8,
    minWidth: 80,
  },
  statValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 13,
    color: '#666666',
    fontWeight: '500',
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  inventoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    justifyContent: 'space-between',
  },
  bottomPadding: {
    height: 40,
  },
  filterContainer: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  searchInput: {
    marginBottom: 8,
  },
  categoryFilters: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  categoryFiltersContent: {
    paddingRight: 16,
  },
  categoryFilter: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#EEEEEE',
    marginRight: 8,
  },
  activeCategoryFilter: {
    backgroundColor: '#4CAF50',
  },
  categoryFilterText: {
    fontSize: 14,
    color: '#333333',
  },
  activeCategoryFilterText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  sortContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  sortLabel: {
    fontSize: 14,
    color: '#666666',
    marginRight: 8,
  },
  sortOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  sortOption: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginRight: 8,
    borderRadius: 4,
    backgroundColor: '#F5F5F5',
  },
  activeSortOption: {
    backgroundColor: '#E3F2FD',
  },
  sortOptionContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  sortOptionText: {
    fontSize: 13,
    color: '#333333',
  },
  activeSortOptionText: {
    color: '#1976D2',
    fontWeight: '600',
  },
  sortOptionIcon: {
    marginLeft: 2,
  },
  thresholdContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#EEEEEE',
  },
  thresholdLabel: {
    fontSize: 14,
    color: '#666666',
  },
  thresholdControls: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  thresholdButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  thresholdValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginHorizontal: 12,
  },
  inventoryCardModern: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 18,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  inventoryCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  productImage: {
    width: 54,
    height: 54,
    borderRadius: 8,
    marginRight: 12,
    backgroundColor: '#F5F5F5',
  },
  inventoryAvatar: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  inventoryAvatarText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 26,
  },
  inventoryCardInfo: {
    flex: 1,
  },
  itemName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
  },
  itemCategory: {
    fontSize: 14,
    color: '#777777',
    marginTop: 2,
  },
  inventoryDetailsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 10,
  },
  itemDetailModern: {
    flexDirection: 'column',
    alignItems: 'flex-start',
    minWidth: 90,
    marginBottom: 2,
  },
  detailLabel: {
    fontSize: 14,
    color: '#666666',
  },
  detailValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333333',
  },
  inventoryActionsModern: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 4,
  },
  inventoryActionButton: {
    minWidth: 120,
  },
  warningBannerModern: {
    backgroundColor: '#FFF3E0',
    borderLeftWidth: 3,
    borderLeftColor: '#FFA000',
    padding: 10,
    marginTop: 12,
    borderRadius: 8,
  },
  warningContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  warningTextModern: {
    color: '#E65100',
    fontSize: 14,
    fontWeight: 'bold',
  },
  outOfStock: {
    color: '#F44336',
    fontWeight: 'bold',
  },
  lowStock: {
    color: '#FFA000',
    fontWeight: 'bold',
  },
  emptyContainer: {
    padding: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#666666',
    textAlign: 'center',
  },
  addProductButton: {
    marginTop: 16,
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  modal: {
    backgroundColor: '#FFFFFF',
    width: '85%',
    borderRadius: 8,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 4,
    textAlign: 'center',
  },
  modalSubtitle: {
    fontSize: 16,
    color: '#666666',
    marginBottom: 16,
    textAlign: 'center',
  },
  modalContent: {
    marginBottom: 20,
  },
  modalLabel: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 8,
  },
  modalNote: {
    fontSize: 14,
    color: '#666666',
    marginTop: 12,
    fontStyle: 'italic',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  modalButtonCancel: {
    flex: 1,
    marginRight: 8,
  },
  modalButtonSave: {
    flex: 1,
    marginLeft: 8,
  },
});

export default InventoryManagementScreen;
