import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import Clipboard from '@react-native-clipboard/clipboard';

import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import SupabaseDatabaseManager, {
  CartConstraintError,
} from '../../../api/SupabaseDatabaseManager';
import {
  PaymentMethodKey,
  RootStackParamList,
  ShoppingCartItem,
  SystemPaymentAccount,
} from '../../../types';

type NavigationProp = StackNavigationProp<RootStackParamList, 'Payment'>;

type MobileAccountsMap = Record<string, SystemPaymentAccount[]>;

type PaymentMethodOption = {
  id: PaymentMethodKey;
  name: string;
  description: string;
  iconName: string;
  iconColor?: string;
  disabled?: boolean;
  disabledReason?: string;
};

const normalizeProviderKey = (value?: string | null): string => {
  if (!value) {
    return 'other';
  }
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_');
};

const humanizeLabel = (value?: string | null): string => {
  if (!value) {
    return 'Unnamed';
  }
  return value
    .toString()
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase()
    .replace(/\b\w/g, char => char.toUpperCase());
};

const getProviderDisplayName = (
  providerKey: string,
  map: MobileAccountsMap,
): string => {
  const providerValue = map[providerKey]?.[0]?.provider;
  if (providerValue) {
    return humanizeLabel(providerValue);
  }
  return humanizeLabel(providerKey);
};

const PaymentScreen: React.FC = () => {
  const navigation = useNavigation<NavigationProp>();
  const authManager = useMemo(() => SupabaseAuthManager.getInstance(), []);
  const dbManager = useMemo(() => SupabaseDatabaseManager.getInstance(), []);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [cartItems, setCartItems] = useState<ShoppingCartItem[]>([]);
  const [walletBalance, setWalletBalance] = useState<number>(0);
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethodKey>('cod');
  const [paymentReference, setPaymentReference] = useState<string>('');
  const [systemBankAccounts, setSystemBankAccounts] = useState<
    SystemPaymentAccount[]
  >([]);
  const [systemMobileAccounts, setSystemMobileAccounts] =
    useState<MobileAccountsMap>({});
  const [mobileProviders, setMobileProviders] = useState<string[]>([]);
  const [selectedBankAccountId, setSelectedBankAccountId] = useState<
    string | null
  >(null);
  const [selectedMobileProvider, setSelectedMobileProvider] = useState<
    string | null
  >(null);
  const [selectedMobileAccountId, setSelectedMobileAccountId] = useState<
    string | null
  >(null);
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  const copyFeedbackTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );

  const clearCopyFeedbackTimer = () => {
    if (copyFeedbackTimeoutRef.current) {
      clearTimeout(copyFeedbackTimeoutRef.current);
      copyFeedbackTimeoutRef.current = null;
    }
  };

  useEffect(() => {
    let isMounted = true;

    const load = async () => {
      try {
        setIsLoading(true);
        const user = await authManager.getCurrentUser();
        if (!user || !user.id) {
          if (isMounted) {
            setIsLoading(false);
            Alert.alert('Authentication Required', 'Please sign in again.', [
              {
                text: 'OK',
                onPress: () => navigation.replace('SignIn'),
              },
            ]);
          }
          return;
        }

        const userId = user.id.toString();

        const [cartData, systemAccounts, balance] = await Promise.all([
          dbManager.getUserCart(userId),
          dbManager.getSystemPaymentAccounts(),
          dbManager.getUserWalletBalance(userId),
        ]);

        if (!isMounted) {
          return;
        }

        setCartItems(cartData || []);

        const bankAccounts = (systemAccounts || [])
          .filter(
            account =>
              account.method === 'bank' && (account.is_active ?? true) === true,
          )
          .sort((a, b) => {
            const primaryScore =
              Number(Boolean(b.is_primary)) - Number(Boolean(a.is_primary));
            if (primaryScore !== 0) {
              return primaryScore;
            }
            return (a.label || '').localeCompare(b.label || '');
          });

        const mobileAccountMap: MobileAccountsMap = {};
        (systemAccounts || []).forEach(account => {
          if (account.method !== 'mobile_banking') {
            return;
          }
          if ((account.is_active ?? true) !== true) {
            return;
          }
          const providerKey = normalizeProviderKey(account.provider);
          if (!mobileAccountMap[providerKey]) {
            mobileAccountMap[providerKey] = [];
          }
          mobileAccountMap[providerKey].push(account);
        });

        Object.values(mobileAccountMap).forEach(providerAccounts => {
          providerAccounts.sort((a, b) => {
            const primaryScore =
              Number(Boolean(b.is_primary)) - Number(Boolean(a.is_primary));
            if (primaryScore !== 0) {
              return primaryScore;
            }
            return (a.label || '').localeCompare(b.label || '');
          });
        });

        const providerKeys = Object.keys(mobileAccountMap).sort((a, b) => {
          const accountsA = mobileAccountMap[a] ?? [];
          const accountsB = mobileAccountMap[b] ?? [];
          const primaryScore =
            Number(Boolean(accountsB[0]?.is_primary)) -
            Number(Boolean(accountsA[0]?.is_primary));
          if (primaryScore !== 0) {
            return primaryScore;
          }
          return humanizeLabel(a).localeCompare(humanizeLabel(b));
        });

        setSystemBankAccounts(bankAccounts);
        setSystemMobileAccounts(mobileAccountMap);
        setMobileProviders(providerKeys);
        setWalletBalance(
          typeof balance === 'number' && !Number.isNaN(balance) ? balance : 0,
        );
      } catch (error) {
        console.error('Error fetching payment screen data:', error);
        if (isMounted) {
          Alert.alert(
            'Error',
            'Unable to load payment information. Please try again.',
          );
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };

    load();

    return () => {
      isMounted = false;
      clearCopyFeedbackTimer();
    };
  }, [authManager, dbManager, navigation]);

  useEffect(() => {
    if (systemBankAccounts.length === 0) {
      setSelectedBankAccountId(null);
      return;
    }
    setSelectedBankAccountId(prev => {
      if (prev && systemBankAccounts.some(account => account.id === prev)) {
        return prev;
      }
      const primaryAccount =
        systemBankAccounts.find(account => account.is_primary) ||
        systemBankAccounts[0];
      return primaryAccount?.id ?? null;
    });
  }, [systemBankAccounts]);

  useEffect(() => {
    if (mobileProviders.length === 0) {
      setSelectedMobileProvider(null);
      setSelectedMobileAccountId(null);
      return;
    }
    setSelectedMobileProvider(prev => {
      if (prev && mobileProviders.includes(prev)) {
        return prev;
      }
      return mobileProviders[0];
    });
  }, [mobileProviders]);

  useEffect(() => {
    if (!selectedMobileProvider) {
      setSelectedMobileAccountId(null);
      return;
    }
    const accounts = systemMobileAccounts[selectedMobileProvider] || [];
    if (accounts.length === 0) {
      setSelectedMobileAccountId(null);
      return;
    }
    setSelectedMobileAccountId(prev => {
      if (prev && accounts.some(account => account.id === prev)) {
        return prev;
      }
      return accounts[0].id;
    });
  }, [selectedMobileProvider, systemMobileAccounts]);

  const paymentMethods = useMemo<PaymentMethodOption[]>(() => {
    return [
      {
        id: 'cod',
        name: 'Cash on Delivery',
        description: 'Pay when your order arrives.',
        iconName: 'cash',
        iconColor: '#2E7D32',
      },
      {
        id: 'wallet',
        name: 'AgriWallet',
        description: 'Use your AgriSmart wallet balance.',
        iconName: 'wallet',
        iconColor: '#1E88E5',
      },
      {
        id: 'bank',
        name: 'Bank Transfer',
        description: 'Transfer funds to a AgriSmart bank account.',
        iconName: 'bank',
        iconColor: '#6D4C41',
        disabled: systemBankAccounts.length === 0,
        disabledReason: 'No bank accounts are currently configured.',
      },
      {
        id: 'mobile-banking',
        name: 'Mobile Banking',
        description: 'Send payment via bKash, Nagad, Rocket, etc.',
        iconName: 'cellphone',
        iconColor: '#8E24AA',
        disabled: mobileProviders.length === 0,
        disabledReason: 'No mobile banking numbers are currently configured.',
      },
    ];
  }, [systemBankAccounts.length, mobileProviders.length]);

  useEffect(() => {
    const activeMethod = paymentMethods.find(
      method => method.id === selectedMethod,
    );
    if (!activeMethod || activeMethod.disabled) {
      const fallback = paymentMethods.find(method => !method.disabled);
      if (fallback && fallback.id !== selectedMethod) {
        setSelectedMethod(fallback.id);
      }
    }
  }, [paymentMethods, selectedMethod]);

  useEffect(() => {
    clearCopyFeedbackTimer();
    setCopyFeedback(null);
    setPaymentReference('');
  }, [selectedMethod]);

  useEffect(() => {
    if (selectedMethod === 'bank') {
      setPaymentReference('');
      clearCopyFeedbackTimer();
      setCopyFeedback(null);
    }
  }, [selectedMethod, selectedBankAccountId]);

  useEffect(() => {
    if (selectedMethod === 'mobile-banking') {
      setPaymentReference('');
      clearCopyFeedbackTimer();
      setCopyFeedback(null);
    }
  }, [selectedMethod, selectedMobileAccountId, selectedMobileProvider]);

  const cartSubtotal = useMemo(() => {
    return cartItems.reduce((total, item) => {
      const price =
        typeof item.product_price === 'number' ? item.product_price : 0;
      const quantity = typeof item.quantity === 'number' ? item.quantity : 0;
      return total + price * quantity;
    }, 0);
  }, [cartItems]);

  const calculatedDeliveryTotal = useMemo(() => {
    return cartItems.reduce((total, item) => {
      const delivery =
        typeof item.product_delivery_fee === 'number'
          ? item.product_delivery_fee
          : 0;
      return total + delivery;
    }, 0);
  }, [cartItems]);

  const cartTotal = useMemo(
    () => cartSubtotal + calculatedDeliveryTotal,
    [cartSubtotal, calculatedDeliveryTotal],
  );

  const hasCartItems = cartItems.length > 0;

  const selectedBankAccount = useMemo(() => {
    if (!selectedBankAccountId) {
      return null;
    }
    return (
      systemBankAccounts.find(
        account => account.id === selectedBankAccountId,
      ) || null
    );
  }, [selectedBankAccountId, systemBankAccounts]);

  const selectedProviderAccounts = useMemo(() => {
    if (!selectedMobileProvider) {
      return [] as SystemPaymentAccount[];
    }
    return systemMobileAccounts[selectedMobileProvider] || [];
  }, [selectedMobileProvider, systemMobileAccounts]);

  const selectedMobileAccount = useMemo(() => {
    if (!selectedMobileAccountId) {
      return null;
    }
    return (
      selectedProviderAccounts.find(
        account => account.id === selectedMobileAccountId,
      ) || null
    );
  }, [selectedMobileAccountId, selectedProviderAccounts]);

  const isPaymentFormValid = useMemo(() => {
    if (!hasCartItems || cartTotal <= 0) {
      return false;
    }
    if (selectedMethod === 'bank') {
      return Boolean(selectedBankAccount) && paymentReference.trim().length > 0;
    }
    if (selectedMethod === 'mobile-banking') {
      return (
        Boolean(selectedMobileProvider) &&
        Boolean(selectedMobileAccount) &&
        paymentReference.trim().length > 0
      );
    }
    if (selectedMethod === 'wallet') {
      return walletBalance >= cartTotal;
    }
    return true;
  }, [
    hasCartItems,
    cartTotal,
    selectedMethod,
    selectedBankAccount,
    selectedMobileProvider,
    selectedMobileAccount,
    paymentReference,
    walletBalance,
  ]);

  const handleSelectBankAccount = (accountId: string) => {
    setSelectedBankAccountId(accountId);
    setPaymentReference('');
    clearCopyFeedbackTimer();
    setCopyFeedback(null);
  };

  const handleSelectMobileProvider = (providerKey: string) => {
    setSelectedMobileProvider(providerKey);
    setPaymentReference('');
    clearCopyFeedbackTimer();
    setCopyFeedback(null);
  };

  const handleSelectMobileAccount = (accountId: string) => {
    setSelectedMobileAccountId(accountId);
    setPaymentReference('');
    clearCopyFeedbackTimer();
    setCopyFeedback(null);
  };

  const handleCopyPaymentNumber = (accountNumber: string) => {
    if (!accountNumber) {
      return;
    }
    Clipboard.setString(accountNumber);
    clearCopyFeedbackTimer();
    setCopyFeedback('Account number copied to clipboard');
    copyFeedbackTimeoutRef.current = setTimeout(() => {
      setCopyFeedback(null);
      copyFeedbackTimeoutRef.current = null;
    }, 2000);
  };

  const handlePayment = async () => {
    if (!hasCartItems) {
      Alert.alert('Cart Empty', 'Your cart is empty.');
      return;
    }

    if (selectedMethod === 'mobile-banking') {
      if (!selectedMobileProvider || !selectedMobileAccount) {
        Alert.alert(
          'Payment Error',
          'Select an official mobile banking account before placing your order.',
        );
        return;
      }
      if (!paymentReference.trim()) {
        Alert.alert(
          'Payment Error',
          'Enter the transaction ID from your payment receipt.',
        );
        return;
      }
    }

    if (selectedMethod === 'bank') {
      if (!selectedBankAccount) {
        Alert.alert(
          'Payment Error',
          'Select an official bank account before placing your order.',
        );
        return;
      }
      if (!paymentReference.trim()) {
        Alert.alert(
          'Payment Error',
          'Enter the bank transfer reference before placing the order.',
        );
        return;
      }
    }

    if (selectedMethod === 'wallet' && walletBalance < cartTotal) {
      Alert.alert(
        'Insufficient Balance',
        'Your wallet balance is too low for this purchase.',
      );
      return;
    }

    setIsLoading(true);

    try {
      const user = await authManager.getCurrentUser();
      if (!user || !user.id) {
        setIsLoading(false);
        Alert.alert('Authentication Required', 'Please sign in again.', [
          {
            text: 'OK',
            onPress: () => navigation.replace('SignIn'),
          },
        ]);
        return;
      }

      const userId = user.id.toString();
      const freshCart = await dbManager.getUserCart(userId);
      if (!freshCart || freshCart.length === 0) {
        setIsLoading(false);
        Alert.alert('Cart Empty', 'Your cart is empty.');
        return;
      }

      const paymentMethodLabel =
        selectedMethod === 'cod'
          ? 'Cash on Delivery'
          : selectedMethod === 'wallet'
          ? 'AgriWallet'
          : selectedMethod === 'bank'
          ? 'Bank Transfer'
          : 'Mobile Banking';

      const trimmedReference = paymentReference.trim().toUpperCase();

      for (const item of freshCart) {
        const itemDelivery =
          typeof item.product_delivery_fee === 'number'
            ? item.product_delivery_fee
            : 0;
        const itemPrice =
          typeof item.product_price === 'number' ? item.product_price : 0;
        const itemQuantity =
          typeof item.quantity === 'number' ? item.quantity : 0;

        let orderId: number | null = null;
        try {
          orderId = await dbManager.createOrder({
            user_id: userId,
            product_id: item.product_id,
            quantity: item.quantity,
            product_delivery_fee: itemDelivery,
            total_price: itemPrice * itemQuantity + itemDelivery,
            payment_method: paymentMethodLabel,
            payment_method_key: selectedMethod,
            mobile_banking_provider:
              selectedMethod === 'mobile-banking'
                ? selectedMobileProvider
                : null,
            mobile_banking_transaction_id:
              selectedMethod === 'mobile-banking' || selectedMethod === 'bank'
                ? trimmedReference
                : null,
            status: 'pending',
          });
        } catch (orderError) {
          if (orderError instanceof CartConstraintError) {
            const { reason, minPurchase, maxPurchase, availableStock } =
              orderError.details;
            let message =
              'Unable to place the order due to a purchase constraint.';
            if (reason === 'min') {
              message = `You must order at least ${minPurchase} unit(s) of ${item.product_name}.`;
            } else if (reason === 'max' && maxPurchase !== null) {
              message = `You can order up to ${maxPurchase} unit(s) of ${item.product_name} per purchase.`;
            } else if (reason === 'stock') {
              message =
                typeof availableStock === 'number'
                  ? `Only ${availableStock} unit(s) of ${item.product_name} are currently available.`
                  : `Not enough stock available right now for ${item.product_name}.`;
            }
            setIsLoading(false);
            Alert.alert('Order Requirement', message);
            return;
          }
          throw orderError;
        }

        if (!orderId) {
          throw new Error('Failed to create order');
        }
      }

      await dbManager.clearUserCart(userId);
      setCartItems([]);
      setPaymentReference('');
      clearCopyFeedbackTimer();
      setCopyFeedback(null);

      Alert.alert(
        'Payment Successful',
        'Your order has been placed successfully!',
        [
          {
            text: 'OK',
            onPress: () =>
              navigation.navigate('Dashboard', { role: 'consumer' }),
          },
        ],
      );
    } catch (error) {
      console.error('Payment error:', error);
      Alert.alert('Payment Error', 'An error occurred during payment.');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Processing Payment..." />
      </Layout>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.bgFill} />
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <MaterialCommunityIcons name="arrow-left" size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Make Payment</Text>
          <View style={styles.emptyHeaderRight} />
        </View>
        <ScrollView
          style={styles.scrollContainer}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.card}>
            <Text style={styles.sectionTitle}>Select Payment Method</Text>
            <View style={styles.paymentMethodsContainer}>
              {paymentMethods.map(method => {
                const isSelected = selectedMethod === method.id;
                const isDisabled = Boolean(method.disabled);
                return (
                  <TouchableOpacity
                    key={method.id}
                    style={[
                      styles.paymentMethodCard,
                      isSelected && styles.selectedPaymentMethod,
                      isDisabled && styles.disabledPaymentMethod,
                    ]}
                    onPress={() => {
                      if (!isDisabled) {
                        setSelectedMethod(method.id);
                      }
                    }}
                    disabled={isDisabled}
                    activeOpacity={isDisabled ? 1 : 0.85}
                  >
                    <MaterialCommunityIcons
                      name={method.iconName}
                      size={24}
                      color={
                        isDisabled ? '#9E9E9E' : method.iconColor || '#4CAF50'
                      }
                      style={styles.paymentMethodIcon}
                    />
                    <View style={styles.paymentMethodInfo}>
                      <Text style={styles.paymentMethodName}>
                        {method.name}
                      </Text>
                      <Text style={styles.paymentMethodDescription}>
                        {isDisabled && method.disabledReason
                          ? method.disabledReason
                          : method.description}
                      </Text>
                    </View>
                    {isSelected && !isDisabled ? (
                      <View style={styles.selectedCheckmark}>
                        <MaterialCommunityIcons
                          name="check-bold"
                          size={16}
                          color="#FFFFFF"
                        />
                      </View>
                    ) : null}
                  </TouchableOpacity>
                );
              })}
            </View>

            {selectedMethod === 'cod' ? (
              <View style={styles.paymentDetailsContainer}>
                <Text style={styles.paymentDetailsTitle}>Cash on Delivery</Text>
                <Text style={styles.instructionText}>
                  Pay the courier when your order arrives. Please keep BDT{' '}
                  {cartTotal.toFixed(2)} ready.
                </Text>
              </View>
            ) : null}

            {selectedMethod === 'wallet' ? (
              <View style={styles.paymentDetailsContainer}>
                <Text style={styles.paymentDetailsTitle}>Wallet Balance</Text>
                <View style={styles.walletBalanceContainer}>
                  <Text style={styles.walletBalanceLabel}>
                    Current Balance:
                  </Text>
                  <Text style={styles.walletBalance}>
                    BDT {walletBalance.toFixed(2)}
                  </Text>
                </View>
                {walletBalance < cartTotal ? (
                  <View style={styles.insufficientBalanceContainer}>
                    <Text style={styles.insufficientBalanceText}>
                      Insufficient balance. You need BDT{' '}
                      {(cartTotal - walletBalance).toFixed(2)} more.
                    </Text>
                    <TouchableOpacity
                      style={styles.topUpButton}
                      onPress={() => navigation.navigate('Wallet')}
                    >
                      <Text style={styles.topUpButtonText}>Top Up Wallet</Text>
                    </TouchableOpacity>
                  </View>
                ) : null}
              </View>
            ) : null}

            {selectedMethod === 'bank' ? (
              <View style={styles.paymentDetailsContainer}>
                <Text style={styles.paymentDetailsTitle}>Bank Transfer</Text>
                <Text style={styles.instructionText}>
                  Choose the official AgriSmart bank account that matches your
                  transfer. Copy the account number and include your transfer
                  reference before submitting.
                </Text>
                {systemBankAccounts.length === 0 ? (
                  <Text style={styles.warningText}>
                    No bank accounts are configured. Please choose another
                    payment method.
                  </Text>
                ) : (
                  <View style={styles.selectionList}>
                    {systemBankAccounts.map(account => {
                      const isSelected = account.id === selectedBankAccountId;
                      return (
                        <TouchableOpacity
                          key={account.id}
                          style={[
                            styles.selectionCard,
                            isSelected && styles.selectionCardActive,
                          ]}
                          onPress={() => handleSelectBankAccount(account.id)}
                          activeOpacity={0.85}
                        >
                          <View style={styles.selectionHeader}>
                            <Text style={styles.selectionTitle}>
                              {account.label ||
                                humanizeLabel(account.bank_name)}
                            </Text>
                            {account.is_primary ? (
                              <View style={[styles.badge, styles.primaryBadge]}>
                                <Text style={styles.badgeText}>Primary</Text>
                              </View>
                            ) : null}
                          </View>
                          {account.bank_name ? (
                            <Text style={styles.selectionSubtitle}>
                              {account.bank_name}
                              {account.branch_name
                                ? ` - ${account.branch_name}`
                                : ''}
                            </Text>
                          ) : null}
                          <View style={styles.selectionDetailRow}>
                            <Text style={styles.selectionDetailLabel}>
                              Account
                            </Text>
                            <Text style={styles.selectionDetailValue}>
                              {account.account_number}
                            </Text>
                          </View>
                          {account.account_name ? (
                            <View style={styles.selectionDetailRow}>
                              <Text style={styles.selectionDetailLabel}>
                                Name
                              </Text>
                              <Text style={styles.selectionDetailValue}>
                                {account.account_name}
                              </Text>
                            </View>
                          ) : null}
                          {isSelected ? (
                            <TouchableOpacity
                              style={styles.copyButton}
                              onPress={() =>
                                handleCopyPaymentNumber(account.account_number)
                              }
                              activeOpacity={0.85}
                            >
                              <Text style={styles.copyButtonText}>
                                Copy Number
                              </Text>
                            </TouchableOpacity>
                          ) : null}
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                )}
                {selectedBankAccount?.instructions ? (
                  <Text style={styles.instructionText}>
                    {selectedBankAccount.instructions}
                  </Text>
                ) : null}
                {selectedBankAccount ? (
                  <>
                    <Text
                      style={[
                        styles.instructionText,
                        styles.instructionSpacing,
                      ]}
                    >
                      Enter the bank transfer reference or transaction ID.
                    </Text>
                    <TextInput
                      style={styles.input}
                      placeholder="Bank Transfer Reference"
                      value={paymentReference}
                      onChangeText={setPaymentReference}
                      autoCapitalize="characters"
                      autoCorrect={false}
                      maxLength={40}
                    />
                  </>
                ) : null}
                {selectedMethod === 'bank' && copyFeedback ? (
                  <Text style={styles.copyFeedback}>{copyFeedback}</Text>
                ) : null}
              </View>
            ) : null}

            {selectedMethod === 'mobile-banking' ? (
              <View style={styles.paymentDetailsContainer}>
                <Text style={styles.paymentDetailsTitle}>Mobile Banking</Text>
                <Text style={styles.instructionText}>
                  Select a provider to view the official AgriSmart receiving
                  number. Copy the number and enter your transaction ID after
                  sending the payment.
                </Text>
                {mobileProviders.length === 0 ? (
                  <Text style={styles.warningText}>
                    No mobile banking numbers are configured. Please choose a
                    different payment method.
                  </Text>
                ) : (
                  <View style={styles.mobileProviderButtonRow}>
                    {mobileProviders.map(providerKey => {
                      const accounts = systemMobileAccounts[providerKey] || [];
                      const isActive = selectedMobileProvider === providerKey;
                      return (
                        <TouchableOpacity
                          key={providerKey}
                          style={[
                            styles.mobileProviderButton,
                            isActive && styles.mobileProviderButtonActive,
                          ]}
                          onPress={() =>
                            handleSelectMobileProvider(providerKey)
                          }
                          activeOpacity={0.85}
                        >
                          <Text
                            style={[
                              styles.mobileProviderButtonText,
                              isActive && styles.mobileProviderButtonTextActive,
                            ]}
                          >
                            {getProviderDisplayName(
                              providerKey,
                              systemMobileAccounts,
                            )}
                            {accounts.length > 1 ? ` (${accounts.length})` : ''}
                          </Text>
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                )}
                {selectedMobileProvider &&
                selectedProviderAccounts.length === 0 ? (
                  <Text style={styles.warningText}>
                    No active accounts are configured for this provider.
                  </Text>
                ) : null}
                {selectedProviderAccounts.length > 0 ? (
                  <View style={styles.selectionList}>
                    {selectedProviderAccounts.map(account => {
                      const isSelected = account.id === selectedMobileAccountId;
                      return (
                        <TouchableOpacity
                          key={account.id}
                          style={[
                            styles.selectionCard,
                            isSelected && styles.selectionCardActive,
                          ]}
                          onPress={() => handleSelectMobileAccount(account.id)}
                          activeOpacity={0.85}
                        >
                          <View style={styles.selectionHeader}>
                            <Text style={styles.selectionTitle}>
                              {account.label ||
                                humanizeLabel(
                                  account.provider || 'Mobile Wallet',
                                )}
                            </Text>
                            {account.is_primary ? (
                              <View style={[styles.badge, styles.primaryBadge]}>
                                <Text style={styles.badgeText}>Primary</Text>
                              </View>
                            ) : null}
                          </View>
                          <View style={styles.selectionDetailRow}>
                            <Text style={styles.selectionDetailLabel}>
                              Number
                            </Text>
                            <Text style={styles.selectionDetailValue}>
                              {account.account_number}
                            </Text>
                          </View>
                          {account.account_name ? (
                            <View style={styles.selectionDetailRow}>
                              <Text style={styles.selectionDetailLabel}>
                                Name
                              </Text>
                              <Text style={styles.selectionDetailValue}>
                                {account.account_name}
                              </Text>
                            </View>
                          ) : null}
                          {account.instructions ? (
                            <Text style={styles.instructionText}>
                              {account.instructions}
                            </Text>
                          ) : null}
                          {isSelected ? (
                            <TouchableOpacity
                              style={styles.copyButton}
                              onPress={() =>
                                handleCopyPaymentNumber(account.account_number)
                              }
                              activeOpacity={0.85}
                            >
                              <Text style={styles.copyButtonText}>
                                Copy Number
                              </Text>
                            </TouchableOpacity>
                          ) : null}
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                ) : null}
                {selectedMobileAccount ? (
                  <>
                    <Text
                      style={[
                        styles.instructionText,
                        styles.instructionSpacing,
                      ]}
                    >
                      Enter the transaction ID from your payment receipt.
                    </Text>
                    <TextInput
                      style={styles.input}
                      placeholder="Transaction / Reference ID"
                      value={paymentReference}
                      onChangeText={setPaymentReference}
                      autoCapitalize="characters"
                      autoCorrect={false}
                      maxLength={40}
                    />
                  </>
                ) : null}
                {selectedMethod === 'mobile-banking' && copyFeedback ? (
                  <Text style={styles.copyFeedback}>{copyFeedback}</Text>
                ) : null}
              </View>
            ) : null}
          </View>

          <View style={styles.card}>
            <Text style={styles.orderSummaryTitle}>Order Summary</Text>
            {hasCartItems ? (
              <>
                <View style={styles.orderSummaryRow}>
                  <Text style={styles.orderSummaryLabel}>Subtotal</Text>
                  <Text style={styles.orderSummaryValue}>
                    BDT {cartSubtotal.toFixed(2)}
                  </Text>
                </View>
                <View style={styles.orderSummaryRow}>
                  <Text style={styles.orderSummaryLabel}>Delivery Fee</Text>
                  <Text style={styles.orderSummaryValue}>
                    BDT {calculatedDeliveryTotal.toFixed(2)}
                  </Text>
                </View>
                <View style={styles.divider} />
                <View style={styles.orderSummaryRow}>
                  <Text style={[styles.orderSummaryLabel, styles.totalLabel]}>
                    Total
                  </Text>
                  <Text style={[styles.orderSummaryValue, styles.totalValue]}>
                    BDT {cartTotal.toFixed(2)}
                  </Text>
                </View>
              </>
            ) : (
              <Text style={styles.emptyStateText}>
                Your cart is empty. Add items to continue.
              </Text>
            )}
          </View>

          <View style={{ height: 120 }} />
        </ScrollView>

        <View style={styles.payButtonContainer}>
          <TouchableOpacity
            style={[
              styles.payButton,
              !isPaymentFormValid && styles.disabledPayButton,
            ]}
            onPress={handlePayment}
            disabled={!isPaymentFormValid}
            activeOpacity={isPaymentFormValid ? 0.85 : 1}
          >
            <Text style={styles.payButtonText}>
              {selectedMethod === 'cod' ? 'Place Order' : 'Pay Now'}
            </Text>
          </TouchableOpacity>
        </View>
      </Layout>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  bgFill: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#F5F5F5',
  },
  scrollContainer: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 140,
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    elevation: 2,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#4CAF50',
    fontSize: 22,
    fontWeight: '700',
  },
  headerTitle: {
    color: '#1A1A1A',
    fontSize: 22,
    fontWeight: '700',
    textAlign: 'center',
    flex: 1,
  },
  emptyHeaderRight: {
    width: 44,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginBottom: 18,
    padding: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 15,
  },
  paymentMethodsContainer: {
    marginBottom: 16,
  },
  paymentMethodCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 1,
  },
  selectedPaymentMethod: {
    borderColor: '#4CAF50',
    borderWidth: 2,
  },
  disabledPaymentMethod: {
    opacity: 0.5,
  },
  paymentMethodIcon: {
    marginRight: 15,
  },
  paymentMethodInfo: {
    flex: 1,
  },
  paymentMethodName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  paymentMethodDescription: {
    fontSize: 14,
    color: '#666666',
  },
  selectedCheckmark: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  paymentDetailsContainer: {
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 1,
  },
  paymentDetailsTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 12,
  },
  instructionText: {
    fontSize: 13,
    color: '#666666',
    lineHeight: 18,
    marginBottom: 8,
  },
  instructionSpacing: {
    marginTop: 6,
  },
  warningText: {
    fontSize: 13,
    color: '#D97706',
    lineHeight: 18,
    marginTop: 8,
  },
  selectionList: {
    marginTop: 12,
  },
  selectionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    padding: 14,
    marginBottom: 12,
  },
  selectionCardActive: {
    borderColor: '#4CAF50',
    backgroundColor: '#E8F5E9',
  },
  selectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  selectionTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#333333',
  },
  selectionSubtitle: {
    fontSize: 13,
    color: '#666666',
    marginBottom: 6,
  },
  selectionDetailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 6,
  },
  selectionDetailLabel: {
    fontSize: 12,
    color: '#777777',
  },
  selectionDetailValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333333',
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
  },
  primaryBadge: {
    backgroundColor: '#4CAF50',
  },
  badgeText: {
    fontSize: 11,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  copyButton: {
    marginTop: 12,
    alignSelf: 'flex-start',
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 8,
    backgroundColor: '#4CAF50',
  },
  copyButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  copyFeedback: {
    marginTop: 8,
    fontSize: 12,
    color: '#1B5E20',
  },
  mobileProviderButtonRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
  },
  mobileProviderButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    backgroundColor: '#FFFFFF',
    marginRight: 8,
    marginBottom: 8,
  },
  mobileProviderButtonActive: {
    borderColor: '#4CAF50',
    backgroundColor: '#E8F5E9',
  },
  mobileProviderButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333333',
  },
  mobileProviderButtonTextActive: {
    color: '#1B5E20',
  },
  input: {
    backgroundColor: '#F5F5F5',
    padding: 12,
    borderRadius: 8,
    marginTop: 12,
    fontSize: 16,
    color: '#333333',
  },
  walletBalanceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  walletBalanceLabel: {
    fontSize: 15,
    color: '#666666',
  },
  walletBalance: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  insufficientBalanceContainer: {
    backgroundColor: '#FFECB3',
    padding: 10,
    borderRadius: 8,
    marginTop: 10,
  },
  insufficientBalanceText: {
    color: '#F57F17',
    marginBottom: 10,
  },
  topUpButton: {
    backgroundColor: '#FF9800',
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  topUpButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  orderSummaryTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 12,
  },
  orderSummaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  orderSummaryLabel: {
    fontSize: 15,
    color: '#666666',
  },
  orderSummaryValue: {
    fontSize: 15,
    color: '#333333',
  },
  divider: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginVertical: 10,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  emptyStateText: {
    fontSize: 14,
    color: '#777777',
  },
  payButtonContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingBottom: Platform.OS === 'ios' ? 24 : 16,
    paddingTop: 8,
    backgroundColor: 'transparent',
  },
  payButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    borderRadius: 22,
    alignItems: 'center',
    width: '100%',
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
  },
  disabledPayButton: {
    backgroundColor: '#BDBDBD',
  },
  payButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
});

export default PaymentScreen;
