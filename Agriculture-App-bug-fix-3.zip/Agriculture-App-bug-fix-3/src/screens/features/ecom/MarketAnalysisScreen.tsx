import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  useWindowDimensions,
  Alert,
  TouchableOpacity,
  Image,
  Modal,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../../types';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import Layout from '../../../components/Layout';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';

type MarketAnalysisNavigationProp = StackNavigationProp<
  RootStackParamList,
  'MarketAnalysis'
>;

interface ProductAnalytics {
  id: number;
  name: string;
  category: string;
  totalListed: number;
  totalSold: number;
  totalRevenue: number;
  avgPrice: number;
  soldPercentage: number;
  lastSoldDate?: string;
  image_url?: string | null;
}

interface SalesOverview {
  totalProducts: number;
  totalSales: number;
  totalRevenue: number;
  totalListedValue: number;
  profitMargin: number;
  conversionRate: number;
  topCategory: string;
  recentOrders: number;
}

interface CategoryPerformance {
  category: string;
  productsCount: number;
  totalSales: number;
  revenue: number;
  avgPrice: number;
}

interface MonthlyProductSale {
  productId: number;
  productName: string;
  unitsSold: number;
  ordersCount: number;
  totalRevenue: number;
}

interface MonthlyIncome {
  month: number; // 1-12
  monthName: string;
  year: number;
  totalOrders: number;
  totalRevenue: number;
  products: MonthlyProductSale[];
  hasData: boolean;
}

// Color palette and spacing
const COLORS = {
  background: '#F9F9F9',
  card: '#FFFFFF',
  accent: '#4CAF50',
  accent2: '#2196F3',
  accent3: '#FF9800',
  accent4: '#9C27B0',
  border: '#F0F0F0',
  text: '#1A1A1A',
  subtext: '#888888',
  stat: '#2E7D32',
  shadow: '#000',
};
const SPACING = 16;

const MarketAnalysisScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<MarketAnalysisNavigationProp>();
  const [_user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<'analysis' | 'income'>('analysis');
  const [salesOverview, setSalesOverview] = useState<SalesOverview | null>(
    null,
  );
  const [productAnalytics, setProductAnalytics] = useState<ProductAnalytics[]>(
    [],
  );
  const [categoryPerformance, setCategoryPerformance] = useState<
    CategoryPerformance[]
  >([]);

  // Income tab states
  const [selectedYear, setSelectedYear] = useState<number>(
    new Date().getFullYear(),
  );
  const [availableYears, setAvailableYears] = useState<number[]>([]);
  const [monthlyIncomeData, setMonthlyIncomeData] = useState<MonthlyIncome[]>(
    [],
  );
  const [expandedMonth, setExpandedMonth] = useState<number | null>(null);
  const [showYearPicker, setShowYearPicker] = useState<boolean>(false);

  const { width } = useWindowDimensions();
  // responsive columns: small phones 1 column, tablets/large 2 columns
  const isSmall = width < 420;
  const columns = width >= 900 ? 3 : width >= 600 ? 2 : 1;
  const cardWidth = Math.floor((width - 32 - (columns - 1) * 12) / columns);

  const calculateMonthlyIncome = useCallback(
    async (farmerId: number, year: number) => {
      try {
        setLoading(true);

        const orders = await dbManager.getFarmerOrders(farmerId.toString());
        const products = await dbManager.getAllFarmerProducts(
          farmerId.toString(),
        );

        const isApproved = (s: string) => {
          const st = (s || '').toLowerCase();
          return (
            st === 'approved' ||
            st === 'delivered' ||
            st === 'completed' ||
            st === 'paid'
          );
        };

        // Filter orders for the selected year and approved status
        const yearOrders = orders.filter((order: any) => {
          const orderDate = new Date(order.created_at || '');
          return orderDate.getFullYear() === year && isApproved(order.status);
        });

        console.log(`[Income] Orders for year ${year}:`, yearOrders.length);

        // Initialize monthly data (December to January, reverse chronological)
        const monthNames = [
          'January',
          'February',
          'March',
          'April',
          'May',
          'June',
          'July',
          'August',
          'September',
          'October',
          'November',
          'December',
        ];

        const monthlyData: MonthlyIncome[] = [];

        // Current month to filter future months
        const currentDate = new Date();
        const currentYear = currentDate.getFullYear();
        const currentMonth = currentDate.getMonth(); // 0-11

        for (let month = 11; month >= 0; month--) {
          // December to January
          // Skip future months in current year
          if (year === currentYear && month > currentMonth) {
            continue;
          }

          const monthOrders = yearOrders.filter((order: any) => {
            const orderDate = new Date(order.created_at || '');
            return orderDate.getMonth() === month;
          });

          const productSalesMap = new Map<number, MonthlyProductSale>();
          let totalRevenue = 0;

          for (const order of monthOrders) {
            const productId = Number(order.product_id);
            const product = products.find(
              (p: any) => Number(p.id) === productId,
            );
            const productName = product?.name || `Product #${productId}`;
            const quantity = Number(order.quantity || 0);
            const orderRevenue = Number(order.total_price || 0);

            totalRevenue += orderRevenue;

            if (!productSalesMap.has(productId)) {
              productSalesMap.set(productId, {
                productId,
                productName,
                unitsSold: 0,
                ordersCount: 0,
                totalRevenue: 0,
              });
            }

            const productSale = productSalesMap.get(productId)!;
            productSale.unitsSold += quantity;
            productSale.ordersCount += 1;
            productSale.totalRevenue += orderRevenue;
          }

          monthlyData.push({
            month: month + 1,
            monthName: monthNames[month],
            year,
            totalOrders: monthOrders.length,
            totalRevenue,
            products: Array.from(productSalesMap.values()).sort(
              (a, b) => b.totalRevenue - a.totalRevenue,
            ),
            hasData: monthOrders.length > 0,
          });
        }

        setMonthlyIncomeData(monthlyData);
        setLoading(false);
      } catch (error) {
        console.error('Error calculating monthly income:', error);
        Alert.alert('Error', 'Failed to load monthly income data.');
        setLoading(false);
      }
    },
    [dbManager],
  );

  const calculateAnalytics = useCallback(
    async (farmerId: number) => {
      try {
        setLoading(true);

        // Get farmer's products
        const products = await dbManager.getAllFarmerProducts(
          farmerId.toString(),
        );

        // Get all orders for farmer's products
        const orders = await dbManager.getFarmerOrders(farmerId.toString());

        // Calculate product analytics
        const productAnalyticsData: ProductAnalytics[] = [];
        let totalListedValue = 0;
        let totalRevenue = 0;
        let categoryMap = new Map<string, CategoryPerformance>();

        // Only consider approved and delivered orders as completed sales
        const isApproved = (s: string) => {
          const st = (s || '').toLowerCase();
          return (
            st === 'approved' ||
            st === 'delivered' ||
            st === 'completed' ||
            st === 'paid'
          );
        };

        // Debug logging
        console.log('[Market Analysis] Total products:', products.length);
        console.log('[Market Analysis] Total orders:', orders.length);
        const approvedOrders = orders.filter((o: any) => isApproved(o.status));
        console.log(
          '[Market Analysis] Approved/Delivered orders:',
          approvedOrders.length,
        );
        console.log(
          '[Market Analysis] Order statuses:',
          orders
            .map((o: any) => o.status)
            .filter((s, i, arr) => arr.indexOf(s) === i),
        );

        for (const product of products) {
          const productOrders = orders.filter(
            (order: any) =>
              Number(order.product_id) === Number(product.id) &&
              isApproved(order.status),
          );

          const totalSold = productOrders.reduce(
            (sum: number, order: any) => sum + Number(order.quantity || 0),
            0,
          );

          const revenue = productOrders.reduce(
            (sum: number, order: any) => sum + Number(order.total_price || 0),
            0,
          );

          const qtyAvailable = Number(product.quantity || product.stock || 0);
          const listedValue = qtyAvailable * Number(product.price || 0);

          const soldPercentage =
            qtyAvailable + totalSold > 0
              ? (totalSold / (qtyAvailable + totalSold)) * 100
              : 0;

          // Find last sold date
          const lastOrder = productOrders
            .slice()
            .sort(
              (a: any, b: any) =>
                new Date(b.created_at || '').getTime() -
                new Date(a.created_at || '').getTime(),
            )[0];

          const avgPrice =
            totalSold > 0 ? revenue / totalSold : Number(product.price || 0);

          productAnalyticsData.push({
            id: product.id,
            name: product.name,
            category: product.category || product.product_category || 'Other',
            totalListed: qtyAvailable + totalSold,
            totalSold,
            totalRevenue: revenue,
            avgPrice,
            soldPercentage,
            lastSoldDate: lastOrder?.created_at,
            image_url: product.image_url || product.image || null,
          });

          totalListedValue += listedValue;
          totalRevenue += revenue;

          // Category performance
          const categoryKey =
            product.category || product.product_category || 'Other';
          if (!categoryMap.has(categoryKey)) {
            categoryMap.set(categoryKey, {
              category: categoryKey,
              productsCount: 0,
              totalSales: 0,
              revenue: 0,
              avgPrice: 0,
            });
          }

          const categoryData = categoryMap.get(categoryKey)!;
          categoryData.productsCount += 1;
          categoryData.totalSales += totalSold;
          categoryData.revenue += revenue;
          categoryData.avgPrice =
            (categoryData.avgPrice + Number(product.price || 0)) / 2;
        }

        // Sort products by revenue
        productAnalyticsData.sort((a, b) => b.totalRevenue - a.totalRevenue);

        // Calculate overall metrics (only approved orders)
        const totalSales = orders.filter((o: any) =>
          isApproved(o.status),
        ).length;
        const profitMargin =
          totalListedValue > 0 ? (totalRevenue / totalListedValue) * 100 : 0;
        const conversionRate =
          products.length > 0 ? (totalSales / products.length) * 100 : 0;

        // Find top category
        const topCategory =
          Array.from(categoryMap.values()).sort(
            (a, b) => b.revenue - a.revenue,
          )[0]?.category || 'N/A';

        // Recent approved orders (last 30 days)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        const recentOrders = orders.filter(
          (order: any) =>
            isApproved(order.status) &&
            new Date(order.created_at || '') > thirtyDaysAgo,
        ).length;

        const overview: SalesOverview = {
          totalProducts: products.length,
          totalSales,
          totalRevenue,
          totalListedValue,
          profitMargin,
          conversionRate,
          topCategory,
          recentOrders,
        };

        // Debug final calculations
        console.log('[Market Analysis] Final Overview:', {
          totalProducts: products.length,
          totalSales,
          totalRevenue: totalRevenue.toFixed(2),
          totalListedValue: totalListedValue.toFixed(2),
          profitMargin: profitMargin.toFixed(2) + '%',
          conversionRate: conversionRate.toFixed(2) + '%',
          topCategory,
          recentOrders,
        });

        setSalesOverview(overview);
        // sort and set
        productAnalyticsData.sort((a, b) => b.totalRevenue - a.totalRevenue);
        setProductAnalytics(productAnalyticsData);
        setCategoryPerformance(
          Array.from(categoryMap.values()).sort(
            (a, b) => b.revenue - a.revenue,
          ),
        );
      } catch (error) {
        console.error('Error calculating analytics:', error);
        Alert.alert('Error', 'Failed to load market analysis data.');
      } finally {
        setLoading(false);
      }
    },
    [dbManager],
  );

  useEffect(() => {
    const initializeData = async () => {
      try {
        const currentUser = await authManager.getCurrentUser();
        if (currentUser && currentUser.role === 'farmer') {
          setUser(currentUser);

          // Calculate available years (from account creation year to current year)
          const accountCreatedYear = new Date(
            currentUser.created_at || Date.now(),
          ).getFullYear();
          const currentYear = new Date().getFullYear();
          const years: number[] = [];
          for (let year = currentYear; year >= accountCreatedYear; year--) {
            years.push(year);
          }
          setAvailableYears(years);
          setSelectedYear(currentYear);

          // Load initial data based on active tab
          if (activeTab === 'analysis') {
            await calculateAnalytics(currentUser.id!);
          } else {
            await calculateMonthlyIncome(currentUser.id!, currentYear);
          }
        } else {
          Alert.alert(
            'Access Denied',
            'This feature is only available for farmers.',
          );
          navigation.goBack();
        }
      } catch (error) {
        console.error('Error initializing market analysis:', error);
        navigation.goBack();
      }
    };

    initializeData();
  }, [
    navigation,
    calculateAnalytics,
    calculateMonthlyIncome,
    authManager,
    activeTab,
  ]);

  // Handle tab switch
  useEffect(() => {
    const loadTabData = async () => {
      const currentUser = await authManager.getCurrentUser();
      if (!currentUser) return;

      if (activeTab === 'income' && monthlyIncomeData.length === 0) {
        await calculateMonthlyIncome(currentUser.id!, selectedYear);
      }
    };

    loadTabData();
  }, [
    activeTab,
    authManager,
    calculateMonthlyIncome,
    monthlyIncomeData.length,
    selectedYear,
  ]);

  // Handle year change
  const handleYearChange = useCallback(
    async (year: number) => {
      setSelectedYear(year);
      setShowYearPicker(false);
      const currentUser = await authManager.getCurrentUser();
      if (currentUser) {
        await calculateMonthlyIncome(currentUser.id!, year);
      }
    },
    [authManager, calculateMonthlyIncome],
  );

  const renderOverviewCard = (
    title: string,
    value: string,
    subtitle?: string,
    color = '#4CAF50',
  ) => (
    <View style={styles.overviewCard}>
      <Text style={styles.cardTitle}>{title}</Text>
      <Text style={[styles.cardValue, { color }]}>{value}</Text>
      {subtitle && <Text style={styles.cardSubtitle}>{subtitle}</Text>}
    </View>
  );

  const renderProductAnalyticsItem = (
    item: ProductAnalytics,
    index: number,
  ) => {
    const revenueBase = salesOverview?.totalRevenue || 1;
    const widthPct = Math.min((item.totalRevenue / revenueBase) * 100, 100);

    return (
      <View key={item.id} style={[styles.analyticsItem, { padding: 12 }]}>
        <View style={styles.analyticsHeader}>
          <TouchableOpacity
            onPress={() =>
              navigation.navigate('ProductDetails' as any, {
                productId: item.id,
              })
            }
            style={{ flex: 1 }}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <Image
                source={
                  item.image_url
                    ? { uri: item.image_url }
                    : require('../../../assets/placeholder.png')
                }
                style={styles.productThumb}
              />
              <Text style={styles.productName} numberOfLines={2}>
                {item.name}
              </Text>
            </View>
          </TouchableOpacity>

          <View style={styles.rankBadge}>
            <Text style={styles.rankText}>#{index + 1}</Text>
          </View>
        </View>

        <Text style={styles.categoryText}>{item.category}</Text>

        <View style={styles.metricsRow}>
          <View style={styles.metric}>
            <Text style={styles.metricLabel}>Sold</Text>
            <Text style={styles.metricValue}>
              {item.totalSold}/{item.totalListed}
            </Text>
          </View>
          <View style={styles.metric}>
            <Text style={styles.metricLabel}>Revenue</Text>
            <Text style={styles.metricValue}>
              ৳{Number(item.totalRevenue || 0).toFixed(2)}
            </Text>
          </View>
          <View style={styles.metric}>
            <Text style={styles.metricLabel}>Conversion</Text>
            <Text style={styles.metricValue}>
              {Number(item.soldPercentage || 0).toFixed(1)}%
            </Text>
          </View>
        </View>

        <View style={styles.revenueBarContainer}>
          <View
            style={[
              styles.revenueBar,
              {
                width: `${widthPct}%`,
              },
            ]}
          />
        </View>

        {item.lastSoldDate && (
          <Text style={styles.lastSoldText}>
            Last sold: {new Date(item.lastSoldDate).toLocaleDateString()}
          </Text>
        )}
      </View>
    );
  };

  const renderCategoryItem = (item: CategoryPerformance, _index: number) => (
    <View key={item.category} style={styles.categoryItem}>
      <View style={styles.categoryHeader}>
        <Text style={styles.categoryName}>{item.category}</Text>
        <Text style={styles.categoryRevenue}>৳{item.revenue.toFixed(2)}</Text>
      </View>
      <View style={styles.categoryMetrics}>
        <Text style={styles.categoryMetric}>{item.productsCount} products</Text>
        <Text style={styles.categoryMetric}>{item.totalSales} sold</Text>
        <Text style={styles.categoryMetric}>
          Avg: ৳{item.avgPrice.toFixed(2)}
        </Text>
      </View>
    </View>
  );

  if (loading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Analyzing market data..." />
      </Layout>
    );
  }

  return (
    <Layout activeTab="dashboard">
      {/* Custom header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialCommunityIcons name="arrow-left" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Market Analysis</Text>
        <View style={styles.headerRight} />
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'analysis' && styles.activeTab]}
          onPress={() => setActiveTab('analysis')}
        >
          <MaterialCommunityIcons
            name="chart-line"
            size={20}
            color={activeTab === 'analysis' ? COLORS.accent : COLORS.subtext}
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'analysis' && styles.activeTabText,
            ]}
          >
            Analysis
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === 'income' && styles.activeTab]}
          onPress={() => setActiveTab('income')}
        >
          <MaterialCommunityIcons
            name="cash-multiple"
            size={20}
            color={activeTab === 'income' ? COLORS.accent : COLORS.subtext}
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'income' && styles.activeTabText,
            ]}
          >
            Income
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        style={{ backgroundColor: COLORS.background }}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
      >
        {activeTab === 'analysis' ? (
          <>
            {/* Welcome Section */}
            <View style={styles.welcomeSection}>
              <Text style={styles.welcomeTitle}>Your Sales Performance</Text>
              <Text style={styles.welcomeSubtitle}>
                Insights and analytics for your farm business
              </Text>
            </View>

            {/* Sales Overview */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Sales Overview</Text>

              {/* Stack overview cards  */}
              <View style={{ paddingHorizontal: 8, paddingTop: 8 }}>
                {[
                  {
                    key: 'revenue',
                    title: 'Total Revenue',
                    value: `৳${(salesOverview?.totalRevenue ?? 0).toFixed(2)}`,
                    subtitle: 'From all sales',
                    color: COLORS.accent,
                  },
                  {
                    key: 'listed',
                    title: 'Listed Value',
                    value: `৳${(salesOverview?.totalListedValue ?? 0).toFixed(
                      2,
                    )}`,
                    subtitle: 'Current inventory',
                    color: COLORS.accent2,
                  },
                  {
                    key: 'profit',
                    title: 'Profit Margin',
                    value: `${(salesOverview?.profitMargin ?? 0).toFixed(1)}%`,
                    subtitle: 'Revenue vs Listed',
                    color: COLORS.accent3,
                  },
                  {
                    key: 'conversion',
                    title: 'Conversion Rate',
                    value: `${(salesOverview?.conversionRate ?? 0).toFixed(
                      1,
                    )}%`,
                    subtitle: 'Sales per product',
                    color: COLORS.accent4,
                  },
                ].map(card => {
                  // dynamic sizing based on screen width
                  const horizontalPadding = isSmall ? 12 : 16;
                  const verticalPadding = isSmall ? 12 : 18;
                  const titleSize = isSmall ? 14 : 16;
                  const valueSize = isSmall ? 18 : 20;
                  const subtitleSize = isSmall ? 12 : 13;

                  return (
                    <View
                      key={card.key}
                      style={{
                        width: '100%',
                        marginBottom: 12,
                        // cards don't stretch too wide on very large screens
                        alignSelf: 'center',
                        maxWidth: 880,
                        paddingHorizontal: 4,
                      }}
                    >
                      <View
                        style={[
                          styles.overviewCard,
                          {
                            // override grid-based styles to make each card full-width
                            flexBasis: '100%',
                            maxWidth: '100%',
                            minWidth: 0,
                            alignItems: 'flex-start',
                            paddingHorizontal: horizontalPadding,
                            paddingVertical: verticalPadding,
                            backgroundColor: '#fff',
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                          },
                        ]}
                      >
                        <View style={{ flex: 1, paddingRight: 8 }}>
                          <Text
                            style={[
                              styles.cardTitle,
                              { textAlign: 'left', fontSize: titleSize },
                            ]}
                            numberOfLines={1}
                            ellipsizeMode="tail"
                          >
                            {card.title}
                          </Text>

                          {card.subtitle ? (
                            <Text
                              style={[
                                styles.cardSubtitle,
                                {
                                  textAlign: 'left',
                                  width: '100%',
                                  fontSize: subtitleSize,
                                  marginTop: 4,
                                },
                              ]}
                              numberOfLines={1}
                              ellipsizeMode="tail"
                            >
                              {card.subtitle}
                            </Text>
                          ) : null}
                        </View>

                        <View
                          style={{
                            alignItems: 'flex-end',
                            justifyContent: 'center',
                            minWidth: 120,
                            marginLeft: 8,
                          }}
                        >
                          <Text
                            style={[
                              styles.cardValue,
                              {
                                color: card.color,
                                fontSize: valueSize,
                                textAlign: 'right',
                              },
                            ]}
                            numberOfLines={1}
                            ellipsizeMode="tail"
                          >
                            {card.value}
                          </Text>
                        </View>
                      </View>
                    </View>
                  );
                })}
              </View>
            </View>

            {/* Quick Stats */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Quick Stats</Text>

              {/*  widths adapt based on screen columns */}
              <View style={styles.statsContainer}>
                {[
                  {
                    key: 'products',
                    label: 'Products Listed',
                    value: salesOverview?.totalProducts ?? 0,
                  },
                  {
                    key: 'orders',
                    label: 'Total Orders',
                    value: salesOverview?.totalSales ?? 0,
                  },
                  {
                    key: 'recent',
                    label: 'Recent Orders',
                    value: salesOverview?.recentOrders ?? 0,
                  },
                  {
                    key: 'top',
                    label: 'Top Category',
                    value: salesOverview?.topCategory ?? 'N/A',
                  },
                ].map((stat, idx) => {
                  // determine dynamic width
                  const computedWidth =
                    isSmall || columns === 1
                      ? '100%'
                      : typeof cardWidth === 'number'
                      ? cardWidth
                      : '48%';

                  return (
                    <View
                      key={stat.key + idx}
                      style={[
                        styles.statItem,
                        {
                          width: computedWidth,
                          minWidth: 140,
                          //  items visually separate on very wide screens
                          maxWidth: columns >= 3 ? 320 : undefined,
                        },
                      ]}
                    >
                      <Text
                        style={[
                          styles.statNumber,
                          typeof stat.value === 'string'
                            ? { fontSize: 16 }
                            : {},
                        ]}
                        numberOfLines={1}
                        ellipsizeMode="tail"
                      >
                        {stat.value}
                      </Text>
                      <Text style={styles.statLabel}>{stat.label}</Text>
                    </View>
                  );
                })}
              </View>
            </View>

            {/* Product Performance */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Product Performance</Text>

              <View
                style={{
                  paddingHorizontal: 8,
                  paddingTop: 8,
                  alignItems: 'center',
                }}
              >
                {productAnalytics.length > 0 ? (
                  productAnalytics.map((item, index) => {
                    const itemWidth = Math.min(420, width - 48);
                    const revenueBase = salesOverview?.totalRevenue || 1;
                    const widthPct = Math.min(
                      (item.totalRevenue / revenueBase) * 100,
                      100,
                    );

                    return (
                      <TouchableOpacity
                        key={item.id}
                        activeOpacity={0.8}
                        onPress={() =>
                          navigation.navigate('ProductDetails' as any, {
                            productId: item.id,
                          })
                        }
                        style={{
                          width: itemWidth,
                          backgroundColor: '#fff',
                          borderRadius: 12,
                          padding: 12,
                          marginBottom: 12,
                          flexDirection: 'row',
                          alignItems: 'center',
                          borderWidth: 1,
                          borderColor: COLORS.border,
                          shadowColor: COLORS.shadow,
                          shadowOffset: { width: 0, height: 1 },
                          shadowOpacity: 0.06,
                          shadowRadius: 6,
                          elevation: 2,
                        }}
                      >
                        <Image
                          source={
                            item.image_url
                              ? { uri: item.image_url }
                              : require('../../../assets/placeholder.png')
                          }
                          style={{
                            width: 56,
                            height: 56,
                            borderRadius: 10,
                            marginRight: 12,
                            backgroundColor: '#fff',
                          }}
                        />

                        <View style={{ flex: 1 }}>
                          <Text
                            numberOfLines={2}
                            style={{
                              fontSize: 15,
                              fontWeight: '700',
                              color: COLORS.text,
                            }}
                          >
                            {item.name}
                          </Text>

                          <Text
                            numberOfLines={1}
                            style={{
                              fontSize: 12,
                              color: COLORS.subtext,
                              marginTop: 4,
                            }}
                          >
                            {item.category}
                          </Text>

                          <View
                            style={{
                              flexDirection: 'row',
                              justifyContent: 'space-between',
                              marginTop: 8,
                              alignItems: 'center',
                            }}
                          >
                            <View>
                              <Text
                                style={{
                                  fontSize: 12,
                                  color: '#666',
                                }}
                              >
                                Sold
                              </Text>
                              <Text
                                style={{
                                  fontSize: 13,
                                  fontWeight: '700',
                                  color: COLORS.text,
                                }}
                              >
                                {item.totalSold}/{item.totalListed}
                              </Text>
                            </View>

                            <View style={{ alignItems: 'flex-end' }}>
                              <Text
                                style={{
                                  fontSize: 12,
                                  color: '#666',
                                }}
                              >
                                Revenue
                              </Text>
                              <Text
                                style={{
                                  fontSize: 13,
                                  fontWeight: '700',
                                  color: COLORS.accent,
                                }}
                              >
                                ৳{Number(item.totalRevenue || 0).toFixed(2)}
                              </Text>
                            </View>
                          </View>

                          <View
                            style={{
                              height: 8,
                              backgroundColor: '#f0f0f0',
                              borderRadius: 6,
                              overflow: 'hidden',
                              marginTop: 10,
                            }}
                          >
                            <View
                              style={{
                                width: `${widthPct}%`,
                                height: '100%',
                                backgroundColor: COLORS.accent2,
                              }}
                            />
                          </View>
                        </View>

                        <View style={{ marginLeft: 12, alignItems: 'center' }}>
                          <Text
                            style={{
                              fontSize: 12,
                              color: COLORS.subtext,
                              marginBottom: 6,
                            }}
                          >
                            Conv
                          </Text>
                          <Text
                            style={{
                              fontSize: 14,
                              fontWeight: '700',
                              color: COLORS.stat,
                            }}
                          >
                            {Number(item.soldPercentage || 0).toFixed(0)}%
                          </Text>
                          {item.lastSoldDate && (
                            <Text
                              style={{
                                fontSize: 10,
                                color: '#999',
                                marginTop: 8,
                              }}
                            >
                              {new Date(item.lastSoldDate).toLocaleDateString()}
                            </Text>
                          )}
                        </View>
                      </TouchableOpacity>
                    );
                  })
                ) : (
                  <View style={styles.emptyState}>
                    <Text style={styles.emptyText}>
                      No product data available
                    </Text>
                  </View>
                )}
              </View>
            </View>

            {/* Category Performance */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Category Performance</Text>

              <View
                style={{
                  paddingHorizontal: 8,
                  paddingTop: 8,
                  paddingBottom: 4,
                  alignItems: 'center', // center narrower list cards
                }}
              >
                {categoryPerformance.length > 0 ? (
                  categoryPerformance.map((item, index) => {
                    const itemMaxWidth = Math.min(360, width - 48); // cap width for large screens
                    const itemWidth = Math.max(140, Math.floor(itemMaxWidth));

                    return (
                      <View
                        key={item.category}
                        style={{
                          width: itemWidth,
                          backgroundColor: '#ffffff',
                          borderRadius: 12,
                          paddingVertical: 10,
                          paddingHorizontal: 12,
                          marginBottom: 12,
                          flexDirection: 'row',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          borderWidth: 1,
                          borderColor: COLORS.border,
                          shadowColor: COLORS.shadow,
                          shadowOffset: { width: 0, height: 1 },
                          shadowOpacity: 0.06,
                          shadowRadius: 4,
                          elevation: 1,
                        }}
                      >
                        <View
                          style={{ flexDirection: 'row', alignItems: 'center' }}
                        >
                          <View
                            style={{
                              width: 44,
                              height: 44,
                              borderRadius: 22,
                              backgroundColor: '#E8F5E9',
                              alignItems: 'center',
                              justifyContent: 'center',
                              marginRight: 12,
                            }}
                          >
                            <Text
                              style={{
                                color: COLORS.accent,
                                fontWeight: '700',
                                fontSize: 16,
                              }}
                            >
                              {item.category.charAt(0).toUpperCase()}
                            </Text>
                          </View>

                          <View style={{ maxWidth: itemWidth - 160 }}>
                            <Text
                              numberOfLines={1}
                              style={{
                                fontSize: 15,
                                fontWeight: '700',
                                color: COLORS.text,
                              }}
                            >
                              {item.category}
                            </Text>
                            <Text
                              style={{
                                fontSize: 12,
                                color: COLORS.subtext,
                                marginTop: 4,
                              }}
                              numberOfLines={1}
                            >
                              {item.productsCount} products • {item.totalSales}{' '}
                              sold
                            </Text>
                          </View>
                        </View>

                        <View style={{ alignItems: 'flex-end' }}>
                          <Text
                            style={{
                              fontSize: 14,
                              fontWeight: '700',
                              color: COLORS.accent,
                            }}
                          >
                            ৳{item.revenue.toFixed(2)}
                          </Text>
                          <Text
                            style={{
                              fontSize: 12,
                              color: COLORS.subtext,
                              marginTop: 6,
                            }}
                          >
                            Avg ৳{item.avgPrice.toFixed(2)}
                          </Text>
                        </View>
                      </View>
                    );
                  })
                ) : (
                  <View style={styles.emptyState}>
                    <Text style={styles.emptyText}>
                      No category data available
                    </Text>
                  </View>
                )}
              </View>
            </View>

            {/* Recommendations */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Recommendations</Text>
              <View style={styles.recommendationCard}>
                <Text style={styles.recommendationTitle}>
                  💡 Market Insights
                </Text>
                {salesOverview && (
                  <>
                    {salesOverview.profitMargin < 20 && (
                      <Text style={styles.recommendationText}>
                        • Consider adjusting prices to improve profit margins
                      </Text>
                    )}
                    {salesOverview.conversionRate < 50 && (
                      <Text style={styles.recommendationText}>
                        • Focus on promoting your best-selling products
                      </Text>
                    )}
                    {productAnalytics.length > 0 &&
                      productAnalytics[0].soldPercentage > 80 && (
                        <Text style={styles.recommendationText}>
                          • "{productAnalytics[0].name}" is performing well -
                          consider increasing stock
                        </Text>
                      )}
                    {categoryPerformance.length > 0 && (
                      <Text style={styles.recommendationText}>
                        • "{categoryPerformance[0].category}" category is your
                        top performer
                      </Text>
                    )}
                  </>
                )}
              </View>
            </View>
          </>
        ) : (
          <>
            {/* Income Tab Content */}
            <View style={styles.incomeHeader}>
              <View style={styles.yearSelectorContainer}>
                <Text style={styles.yearLabel}>Year:</Text>
                <TouchableOpacity
                  style={styles.yearSelector}
                  onPress={() => setShowYearPicker(true)}
                >
                  <Text style={styles.yearText}>{selectedYear}</Text>
                  <MaterialCommunityIcons
                    name="chevron-down"
                    size={20}
                    color={COLORS.text}
                  />
                </TouchableOpacity>
              </View>

              <Text style={styles.incomeSubtitle}>
                Monthly sales breakdown for {selectedYear}
              </Text>
            </View>

            {/* Monthly Income Cards */}
            <View style={styles.monthlyCardsContainer}>
              {monthlyIncomeData.map(monthData => (
                <TouchableOpacity
                  key={`${monthData.year}-${monthData.month}`}
                  style={styles.monthCard}
                  onPress={() =>
                    setExpandedMonth(
                      expandedMonth === monthData.month
                        ? null
                        : monthData.month,
                    )
                  }
                  activeOpacity={0.7}
                >
                  <View style={styles.monthCardHeader}>
                    <View style={styles.monthNameContainer}>
                      <MaterialCommunityIcons
                        name="calendar-month"
                        size={24}
                        color={
                          monthData.hasData ? COLORS.accent : COLORS.subtext
                        }
                      />
                      <Text
                        style={[
                          styles.monthName,
                          !monthData.hasData && styles.noDataMonthName,
                        ]}
                      >
                        {monthData.monthName}
                      </Text>
                    </View>

                    <MaterialCommunityIcons
                      name={
                        expandedMonth === monthData.month
                          ? 'chevron-up'
                          : 'chevron-down'
                      }
                      size={24}
                      color={COLORS.subtext}
                    />
                  </View>

                  {!monthData.hasData ? (
                    <View style={styles.noDataContainer}>
                      <Text style={styles.noDataText}>No sales data</Text>
                    </View>
                  ) : (
                    <>
                      <View style={styles.monthStatsRow}>
                        <View style={styles.monthStat}>
                          <Text style={styles.monthStatLabel}>Orders</Text>
                          <Text style={styles.monthStatValue}>
                            {monthData.totalOrders}
                          </Text>
                        </View>
                        <View style={styles.monthStat}>
                          <Text style={styles.monthStatLabel}>Revenue</Text>
                          <Text
                            style={[
                              styles.monthStatValue,
                              { color: COLORS.accent },
                            ]}
                          >
                            ৳{monthData.totalRevenue.toFixed(2)}
                          </Text>
                        </View>
                      </View>

                      {expandedMonth === monthData.month && (
                        <View style={styles.productsList}>
                          <Text style={styles.productsListTitle}>
                            Product Breakdown ({monthData.products.length})
                          </Text>

                          {monthData.products.map(product => (
                            <View
                              key={product.productId}
                              style={styles.productItem}
                            >
                              <View style={styles.productInfo}>
                                <Text
                                  style={styles.productName}
                                  numberOfLines={2}
                                >
                                  {product.productName}
                                </Text>
                                <View style={styles.productMetrics}>
                                  <Text style={styles.productMetric}>
                                    {product.unitsSold} units
                                  </Text>
                                  <Text style={styles.productMetricDot}>•</Text>
                                  <Text style={styles.productMetric}>
                                    {product.ordersCount} orders
                                  </Text>
                                </View>
                              </View>
                              <View style={styles.productRevenue}>
                                <Text style={styles.productRevenueValue}>
                                  ৳{product.totalRevenue.toFixed(2)}
                                </Text>
                              </View>
                            </View>
                          ))}
                        </View>
                      )}
                    </>
                  )}
                </TouchableOpacity>
              ))}

              {monthlyIncomeData.length === 0 && (
                <View style={styles.emptyState}>
                  <MaterialCommunityIcons
                    name="calendar-blank"
                    size={64}
                    color={COLORS.subtext}
                  />
                  <Text style={styles.emptyText}>
                    No data available for {selectedYear}
                  </Text>
                </View>
              )}
            </View>
          </>
        )}
      </ScrollView>

      {/* Year Picker Modal */}
      <Modal
        visible={showYearPicker}
        transparent
        animationType="fade"
        onRequestClose={() => setShowYearPicker(false)}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setShowYearPicker(false)}
        >
          <View style={styles.yearPickerModal}>
            <Text style={styles.yearPickerTitle}>Select Year</Text>
            <ScrollView style={styles.yearPickerList}>
              {availableYears.map(year => (
                <TouchableOpacity
                  key={year}
                  style={[
                    styles.yearOption,
                    year === selectedYear && styles.selectedYearOption,
                  ]}
                  onPress={() => handleYearChange(year)}
                >
                  <Text
                    style={[
                      styles.yearOptionText,
                      year === selectedYear && styles.selectedYearOptionText,
                    ]}
                  >
                    {year}
                  </Text>
                  {year === selectedYear && (
                    <MaterialCommunityIcons
                      name="check"
                      size={20}
                      color={COLORS.accent}
                    />
                  )}
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </TouchableOpacity>
      </Modal>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    backgroundColor: COLORS.card,
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    elevation: 2,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: COLORS.stat,
    fontSize: 22,
    fontWeight: '700',
  },
  headerTitle: {
    color: COLORS.text,
    fontSize: 22,
    fontWeight: '700',
    textAlign: 'center',
    flex: 1,
  },
  headerRight: {
    width: 44,
    height: 44,
  },
  welcomeSection: {
    backgroundColor: '#E8F5E9',
    borderRadius: 16,
    padding: 24,
    marginBottom: 18,
    marginHorizontal: 16,
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  welcomeTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: COLORS.stat,
    marginBottom: 8,
    textAlign: 'center',
  },
  welcomeSubtitle: {
    fontSize: 15,
    color: '#388E3C',
    textAlign: 'center',
  },
  section: {
    backgroundColor: COLORS.card,
    marginBottom: 22,
    paddingHorizontal: 8,
    borderRadius: 16,
    paddingTop: 18,
    paddingBottom: 12,
    marginHorizontal: 16,
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 1,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: 10,
    paddingHorizontal: 8,
  },
  overviewGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
    paddingHorizontal: 4,
  },
  overviewCard: {
    flexBasis: '48%',
    backgroundColor: '#f8f9fa',
    paddingVertical: 18,
    paddingHorizontal: 12,
    borderRadius: 14,
    marginBottom: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
    minWidth: 150,
    maxWidth: '48%',
    elevation: 1,
  },
  metric: {
    alignItems: 'center',
    flex: 1,
  },
  metricLabel: {
    fontSize: 10,
    color: '#666',
    marginBottom: 2,
  },
  metricValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  cardTitle: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
    textAlign: 'center',
  },
  cardValue: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  cardSubtitle: {
    fontSize: 10,
    color: '#999',
    textAlign: 'center',
  },
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
    paddingHorizontal: 4,
  },
  statItem: {
    flexBasis: '48%',
    alignItems: 'center',
    marginBottom: 16,
    backgroundColor: '#f8f9fa',
    borderRadius: 14,
    paddingVertical: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    minWidth: 150,
    maxWidth: '48%',
    elevation: 1,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.accent,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
    gap: 14,
    paddingHorizontal: 4,
  },
  productCard: {
    backgroundColor: '#f8f9fa',
    borderRadius: 16,
    overflow: 'hidden',
    // width will be set dynamically per screen size
    marginBottom: 18,
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
    borderWidth: 1,
    borderColor: COLORS.border,
    minWidth: 140,
    maxWidth: 600,
  },
  analyticsItem: {
    backgroundColor: 'transparent',
    padding: 0,
    borderRadius: 0,
    marginBottom: 0,
  },
  analyticsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.text,
    flex: 1,
  },
  rankBadge: {
    backgroundColor: COLORS.accent,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  rankText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  categoryText: {
    fontSize: 12,
    color: COLORS.subtext,
    marginBottom: 12,
  },
  metricsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  // Removed duplicate 'section' style to fix object literal property conflict
  progressBarContainer: {
    backgroundColor: '#e0e0e0',
    borderRadius: 2,
    marginBottom: 8,
    height: 4,
    width: '100%',
    overflow: 'hidden',
  },
  progressBar: {
    height: 4,
    backgroundColor: COLORS.accent,
    borderRadius: 2,
  },
  lastSoldText: {
    fontSize: 10,
    color: '#999',
    textAlign: 'right',
  },
  productThumb: {
    width: 44,
    height: 44,
    borderRadius: 8,
    marginRight: 8,
    backgroundColor: '#fff',
  },
  revenueBarContainer: {
    height: 8,
    backgroundColor: '#eee',
    borderRadius: 6,
    overflow: 'hidden',
    marginVertical: 8,
    marginHorizontal: 8,
  },
  revenueBar: {
    height: '100%',
    backgroundColor: COLORS.accent2,
  },
  categoryItem: {
    backgroundColor: 'transparent',
    padding: 0,
    borderRadius: 0,
    marginBottom: 0,
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  categoryRevenue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.accent,
  },
  categoryMetrics: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  categoryMetric: {
    fontSize: 12,
    color: COLORS.subtext,
  },
  recommendationCard: {
    backgroundColor: '#f0f8ff',
    padding: 16,
    borderRadius: 8,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.accent2,
    marginHorizontal: 8,
  },
  recommendationTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: 12,
  },
  recommendationText: {
    fontSize: 14,
    color: '#555',
    marginBottom: 8,
    lineHeight: 20,
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
    paddingHorizontal: 8,
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
  },
  // Tab styles
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: COLORS.card,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    gap: 8,
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: '#E8F5E9',
  },
  tabText: {
    fontSize: 15,
    fontWeight: '600',
    color: COLORS.subtext,
  },
  activeTabText: {
    color: COLORS.accent,
    fontWeight: '700',
  },
  // Income tab styles
  incomeHeader: {
    backgroundColor: COLORS.card,
    padding: 20,
    marginHorizontal: 16,
    marginTop: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  yearSelectorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  yearLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginRight: 12,
  },
  yearSelector: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    gap: 8,
  },
  yearText: {
    fontSize: 16,
    fontWeight: '700',
    color: COLORS.text,
  },
  incomeSubtitle: {
    fontSize: 13,
    color: COLORS.subtext,
  },
  monthlyCardsContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 16,
  },
  monthCard: {
    backgroundColor: COLORS.card,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  monthCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  monthNameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  monthName: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.text,
  },
  noDataMonthName: {
    color: COLORS.subtext,
  },
  noDataContainer: {
    paddingVertical: 8,
  },
  noDataText: {
    fontSize: 14,
    color: COLORS.subtext,
    fontStyle: 'italic',
  },
  monthStatsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 12,
    backgroundColor: '#F9F9F9',
    borderRadius: 8,
    marginBottom: 12,
  },
  monthStat: {
    alignItems: 'center',
  },
  monthStatLabel: {
    fontSize: 12,
    color: COLORS.subtext,
    marginBottom: 4,
  },
  monthStatValue: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.text,
  },
  productsList: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  productsListTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 12,
  },
  productItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    backgroundColor: '#F9F9F9',
    borderRadius: 8,
    marginBottom: 8,
  },
  productInfo: {
    flex: 1,
    marginRight: 12,
  },
  productMetrics: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  productMetric: {
    fontSize: 12,
    color: COLORS.subtext,
  },
  productMetricDot: {
    fontSize: 12,
    color: COLORS.subtext,
  },
  productRevenue: {
    alignItems: 'flex-end',
  },
  productRevenueValue: {
    fontSize: 15,
    fontWeight: '700',
    color: COLORS.accent,
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  yearPickerModal: {
    backgroundColor: COLORS.card,
    borderRadius: 16,
    padding: 20,
    width: '80%',
    maxWidth: 300,
    maxHeight: '60%',
  },
  yearPickerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.text,
    marginBottom: 16,
    textAlign: 'center',
  },
  yearPickerList: {
    maxHeight: 300,
  },
  yearOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: '#F5F5F5',
  },
  selectedYearOption: {
    backgroundColor: '#E8F5E9',
  },
  yearOptionText: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
  },
  selectedYearOptionText: {
    color: COLORS.accent,
    fontWeight: '700',
  },
});

export default MarketAnalysisScreen;
