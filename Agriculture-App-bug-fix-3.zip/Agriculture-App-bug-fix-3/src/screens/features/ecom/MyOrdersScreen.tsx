import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
  Platform,
  Image,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, User } from '../../../types';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import { buildRoomId } from '../../../utils';

type MyOrdersScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'MyOrders'
>;

const placeholderImage = require('../../../assets/placeholder.png');

const MyOrdersScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();

  const navigation = useNavigation<MyOrdersScreenNavigationProp>();
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [myOrders, setMyOrders] = useState<any[]>([]);

  const loadData = useCallback(async () => {
    try {
      setIsLoading(true);
      const currentUser = await authManager.getCurrentUser();
      if (!currentUser) {
        navigation.replace('SignIn');
        return;
      }

      setUser(currentUser);

      if (currentUser.id) {
        await fetchMyOrders(currentUser.id);
      }
    } catch (error) {
      console.error('Error loading orders data:', error);
    } finally {
      setIsLoading(false);
    }
  }, [navigation, authManager]);

  const fetchMyOrders = async (userId: number) => {
    try {
      const dbManager = SupabaseDatabaseManager.getInstance();
      // Get orders placed by the user
      const orders = await dbManager.getUserOrders(String(userId));

      const processedOrders = orders.map(order => {
        const price =
          typeof order.unit_price === 'number' ? order.unit_price : 0;
        const quantity =
          typeof order.quantity === 'number' ? order.quantity : 1;
        const delivery =
          typeof order.product_delivery_fee === 'number'
            ? order.product_delivery_fee
            : typeof order.product_delivery_fee === 'string'
            ? parseFloat(order.product_delivery_fee) || 0
            : 0;
        return {
          ...order,
          price,
          quantity,
          product_delivery_fee: delivery,
          status: (order.status || 'Processing').toLowerCase(),
          product_name: order.product_name || 'Product',
          payment_method: order.payment_method || 'Cash on Delivery',
          total_price: (price + delivery) * quantity,
        };
      });

      setMyOrders(processedOrders);
    } catch (error) {
      console.error('Error fetching my orders:', error);
    }
  };

  const confirmOrderDelivery = async (orderId: number) => {
    try {
      const dbManager = SupabaseDatabaseManager.getInstance();
      // Update order status to 'Delivered'
      await dbManager.updateOrderStatus(orderId, 'Delivered');

      // If it was a cash on delivery order, process the payment
      Alert.alert(
        'Delivery Confirmed',
        'Order confirmed as delivered. Thank you for your purchase!',
      );

      // Refresh orders list
      if (user?.id) {
        await fetchMyOrders(user.id);
      }
    } catch (error) {
      console.error('Error confirming order delivery:', error);
      Alert.alert('Error', 'Failed to confirm delivery. Please try again.');
    }
  };

  useEffect(() => {
    loadData();
  }, [loadData]);

  if (isLoading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Loading Your Orders..." />
      </Layout>
    );
  }

  // Responsive layout calculations
  const { width } = Dimensions.get('window');
  const isLargeScreen = width > 600;
  const cardWidth = isLargeScreen ? (width - 60) / 2 : '100%';

  // Stats
  const totalOrders = myOrders.length;
  const processingOrders = myOrders.filter(
    o => o.status === 'processing',
  ).length;
  const approvedOrders = myOrders.filter(o => o.status === 'approved').length;
  const deliveredOrders = myOrders.filter(o => o.status === 'delivered').length;
  const cancelledOrders = myOrders.filter(o => o.status === 'cancelled').length;
  // Refund handler for cancelled wallet orders
  const handleReceiveRefund = async (order: any) => {
    try {
      const dbManager = SupabaseDatabaseManager.getInstance();
      // Only allow if order is cancelled, not already refunded, and paid by AgriWallet
      if (
        order.status !== 'cancelled' ||
        order.payment_method !== 'AgriWallet' ||
        order.refunded === true
      ) {
        Alert.alert(
          'Refund Not Available',
          'Refund is only available for cancelled AgriWallet orders that have not already been refunded.',
        );
        return;
      }
      // Update user's wallet balance
      await dbManager.updateUserWalletBalance(
        order.user_id,
        order.total_price,
        'add',
      );
      // Create wallet transaction record
      await dbManager.createWalletTransaction({
        user_id: order.user_id,
        amount: order.total_price,
        transaction_type: 'refund',
        description: `Order #${order.id} cancelled refund`,
        related_order_id: order.id,
      });
      // Mark order as refunded
      await dbManager.updateOrderRefunded(order.id, true);
      Alert.alert(
        'Refund Received',
        'The refund has been added to your wallet.',
      );
      if (user?.id) {
        await fetchMyOrders(user.id);
      }
    } catch (error) {
      console.error('Error receiving refund:', error);
      Alert.alert('Error', 'Failed to process refund. Please try again.');
    }
  };

  return (
    <Layout activeTab="dashboard">
      <View style={styles.container}>
        {/* Header Section */}
        <ModernHeader
          title="My Orders"
          leftIconName="arrow-left"
          rightIconName="shopping-outline"
          iconSize={24}
          onLeftPress={() => navigation.goBack()}
          onRightPress={() => navigation.navigate('ECommerce')}
        />

        <ScrollView
          style={styles.content}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}
        >
          {/* Order Summary Stats */}
          <View style={styles.statsSection}>
            <Text style={styles.sectionTitle}>Order Summary</Text>
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <Text style={styles.statValue}>{totalOrders}</Text>
                <Text style={styles.statLabel}>Total Orders</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statValue}>{approvedOrders}</Text>
                <Text style={styles.statLabel}>Approved</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statValue}>{processingOrders}</Text>
                <Text style={styles.statLabel}>Processing</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statValue}>{deliveredOrders}</Text>
                <Text style={styles.statLabel}>Delivered</Text>
              </View>
            </View>
          </View>

          {/* Orders Grid Section */}
          <Text style={styles.sectionTitle}>My Purchase History</Text>
          <View style={styles.ordersGrid}>
            {myOrders.length > 0 ? (
              myOrders.map((order, index) => {
                const productName = order.product_name || 'Product';
                const imageUri =
                  (order.product && order.product.image_url) ||
                  order.product_image_url ||
                  null;
                const productExists = Boolean(
                  (order.product && order.product.id) || order.product_id,
                );
                const handleOpenProduct = async () => {
                  // Use live product id if present, otherwise fallback to stored product_id
                  const productId = order?.product?.id || order?.product_id;
                  if (!productId) {
                    Alert.alert(
                      'Product Unavailable',
                      'This product has been deleted or is no longer available.',
                    );
                    return;
                  }
                  try {
                    const dbManager = SupabaseDatabaseManager.getInstance();
                    const product = await dbManager.getProductById(
                      Number(productId),
                    );
                    if (product) {
                      navigation.navigate('ProductDetails', {
                        productId: Number(productId),
                      } as any);
                    } else {
                      Alert.alert(
                        'Product Unavailable',
                        'This product has been deleted or is no longer available.',
                      );
                    }
                  } catch (err) {
                    console.error('Error checking product availability:', err);
                    Alert.alert(
                      'Error',
                      'Could not verify product availability. Please try again.',
                    );
                  }
                };
                const quantity =
                  typeof order.quantity === 'number' ? order.quantity : 1;
                const price = typeof order.price === 'number' ? order.price : 0;
                const deliveryFeePerUnit =
                  typeof order.product_delivery_fee === 'number'
                    ? order.product_delivery_fee
                    : 0;
                const status = (order.status || '').toLowerCase();
                const paymentMethod = order.payment_method || '';
                const totalPrice = (price + deliveryFeePerUnit) * quantity;
                return (
                  <View
                    key={order.id || index}
                    style={[styles.orderCard, { width: cardWidth }]}
                  >
                    <View style={styles.orderHeaderRow}>
                      <View style={styles.leftHeader}>
                        <TouchableOpacity
                          onPress={handleOpenProduct}
                          activeOpacity={0.8}
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                            flex: 1,
                          }}
                        >
                          <Image
                            source={
                              imageUri ? { uri: imageUri } : placeholderImage
                            }
                            style={styles.productImage}
                            resizeMode="cover"
                          />
                          <Text
                            style={styles.orderTitle}
                            numberOfLines={2}
                            ellipsizeMode="tail"
                          >
                            {productName}
                          </Text>
                        </TouchableOpacity>
                      </View>
                      <View style={styles.rightHeader}>
                        <View
                          style={[
                            styles.orderStatusBadge,
                            status === 'processing'
                              ? styles.processingBadge
                              : status === 'approved'
                              ? styles.approvedBadge
                              : status === 'delivered'
                              ? styles.deliveredBadge
                              : status === 'cancelled'
                              ? styles.cancelledBadge
                              : null,
                          ]}
                        >
                          <Text style={styles.orderStatusText}>
                            {status.charAt(0).toUpperCase() + status.slice(1)}
                          </Text>
                        </View>
                        {/* Chat button */}
                        {user &&
                          order.farmer_id &&
                          (status === 'pending' || status === 'approved') &&
                          String(order.farmer_id) !== String(user.id) && (
                            <TouchableOpacity
                              style={styles.chatButton}
                              onPress={() => {
                                // Guards and navigation to ChatRoom
                                if (!user || !user.id) {
                                  Alert.alert('Error', 'Please log in to chat');
                                  return;
                                }
                                const otherUserId = String(
                                  order.farmer_id ?? '',
                                );
                                if (
                                  !otherUserId ||
                                  otherUserId === 'undefined'
                                ) {
                                  Alert.alert(
                                    'Error',
                                    'Invalid chat recipient',
                                  );
                                  return;
                                }
                                if (String(user.id) === otherUserId) {
                                  Alert.alert(
                                    'Error',
                                    'You cannot chat with yourself',
                                  );
                                  return;
                                }
                                const roomId = buildRoomId(
                                  String(user.id),
                                  otherUserId,
                                );
                                navigation.navigate('ChatRoom', {
                                  roomId,
                                  otherUserId,
                                  otherUserName:
                                    order.farmer_name ||
                                    order.farmer ||
                                    'Owner',
                                } as any);
                              }}
                            >
                              <MaterialCommunityIcons
                                name="message-text"
                                size={22}
                                color="#4CAF50"
                              />
                            </TouchableOpacity>
                          )}
                      </View>
                    </View>

                    <Text style={styles.orderDetails}>
                      Quantity: {quantity}
                    </Text>
                    <Text style={styles.orderDetails}>
                      Delivery Fee: ৳{deliveryFeePerUnit.toFixed(2)}
                    </Text>
                    <Text style={styles.orderDetails}>
                      Payment: {paymentMethod}
                    </Text>
                    <Text style={styles.orderPrice}>
                      ৳ {totalPrice.toFixed(2)}
                    </Text>
                    {/* Show refund info for cancelled orders (refunds are automatic) */}
                    {status === 'cancelled' &&
                      paymentMethod !== 'Cash on Delivery' &&
                      paymentMethod !== 'COD' && (
                        <View style={styles.refundInfoContainer}>
                          <MaterialCommunityIcons
                            name="check-circle"
                            size={20}
                            color="#4CAF50"
                          />
                          <Text style={styles.refundInfoText}>
                            Refund has been processed to your wallet
                          </Text>
                        </View>
                      )}
                    {/* Confirm delivery button for delivered orders */}
                    {status === 'approved' && (
                      <TouchableOpacity
                        style={[styles.actionButton, styles.approveButton]}
                        onPress={() => confirmOrderDelivery(order.id)}
                      >
                        <Text style={styles.actionButtonText}>
                          Confirm Delivery
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                );
              })
            ) : (
              <Text style={styles.emptyStateText}>
                You haven't placed any orders yet.
              </Text>
            )}
          </View>
          <View style={styles.bottomPadding} />
        </ScrollView>
      </View>
    </Layout>
  );
};

const { width: screenWidth } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    paddingBottom: 20,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#666666',
    fontWeight: '400',
  },
  headerBackButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerBackIcon: {
    fontSize: 20,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  statsSection: {
    marginTop: 32,
    marginBottom: 40,
  },
  overviewTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    flexWrap: 'wrap',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
  },
  statCard: {
    width: (screenWidth - 60) / 2 - 6,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 1,
    marginBottom: 8,
  },
  statValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 13,
    color: '#666666',
    fontWeight: '500',
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  ordersGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    justifyContent: 'space-between',
  },
  orderCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
    minWidth: 260,
    maxWidth: '100%',
    alignSelf: 'flex-start',
  },
  orderHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  leftHeader: {
    flex: 1,
    marginRight: 8,
    minWidth: 0,
  },
  rightHeader: {
    alignItems: 'flex-end',
    justifyContent: 'center',
    marginLeft: 8,
  },
  orderTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    flex: 1,
  },
  productImage: {
    width: 56,
    height: 56,
    borderRadius: 8,
    marginRight: 12,
    backgroundColor: '#F0F0F0',
  },
  orderStatusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: '#E0E0E0',
  },
  processingBadge: {
    backgroundColor: '#FFF9C4', // Light yellow
  },
  approvedBadge: {
    backgroundColor: '#C8E6C9', // Light green
  },
  deliveredBadge: {
    backgroundColor: '#BBDEFB', // Light blue
  },
  cancelledBadge: {
    backgroundColor: '#FFCDD2', // Light red
  },
  orderStatusText: {
    fontSize: 13,
    fontWeight: 'bold',
  },
  orderDetails: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 2,
  },
  orderPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginTop: 8,
    textAlign: 'right',
  },
  actionButton: {
    borderRadius: 6,
    padding: 10,
    alignItems: 'center',
    marginTop: 12,
  },
  approveButton: {
    backgroundColor: '#4CAF50',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
  noteText: {
    marginTop: 10,
    fontStyle: 'italic',
    color: '#666666',
    fontSize: 13,
  },
  refundInfoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    padding: 10,
    backgroundColor: '#E8F5E9',
    borderRadius: 8,
    gap: 8,
  },
  refundInfoText: {
    fontSize: 13,
    color: '#2E7D32',
    fontWeight: '500',
    flex: 1,
  },
  chatButton: {
    marginTop: 10,
    marginLeft: 10,
    paddingHorizontal: 10,
    paddingVertical: 6,
    backgroundColor: '#EFEFEF',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatButtonText: {
    fontSize: 16,
  },
  emptyStateText: {
    textAlign: 'center',
    color: '#999999',
    fontStyle: 'italic',
    padding: 20,
  },
  bottomPadding: {
    height: 40,
  },
});

export default MyOrdersScreen;
