import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Dimensions,
  Image,
} from 'react-native';
import { useNavigation, useIsFocused } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, User } from '../../../types';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import { buildRoomId } from '../../../utils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type OrdersManagementScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'OrdersManagement'
>;

const OrdersManagementScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<OrdersManagementScreenNavigationProp>();
  const isFocused = useIsFocused();
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [customerOrders, setCustomerOrders] = useState<any[]>([]);

  const fetchCustomerOrders = useCallback(
    async (farmerId: number) => {
      try {
        // Log the farmerId being used for fetching orders
        console.log(
          '[OrdersManagementScreen] Fetching orders for farmerId:',
          farmerId,
        );
        // Get all orders for products owned by this farmer
        const orders = await dbManager.getFarmerOrders(String(farmerId));
        // Log raw orders for debugging
        console.log('[OrdersManagementScreen] Orders from DB:', orders);

        // Collect all unique buyer user_ids
        const buyerIds = Array.from(
          new Set(orders.map(o => o.user_id).filter(Boolean)),
        );
        console.log('[OrdersManagementScreen] Buyer IDs:', buyerIds);

        // Batch fetch all buyers
        const buyersMap = await dbManager.getUsersByIds(buyerIds);
        console.log('[OrdersManagementScreen] Buyers from DB:', buyersMap);

        // Exclude orders where the current user is the buyer (the farmer themselves)
        const filteredOrders = orders.filter(
          order => String(order.user_id) !== String(farmerId),
        );

        const ordersWithAddress = filteredOrders.map(order => {
          let address = '';
          let buyerName = '';
          if (order.buyer) {
            address = [
              order.buyer.address_line1,
              order.buyer.address_line2,
              order.buyer.city,
              order.buyer.state,
              order.buyer.postal_code,
              order.buyer.country,
            ]
              .filter(Boolean)
              .join(', ');
            buyerName = order.buyer.name || '';
          } else if (order.user_id && buyersMap[order.user_id]) {
            const buyer = buyersMap[order.user_id];
            buyerName = buyer.name || order.user_id || 'Customer';
            address = [
              buyer.address_line1,
              buyer.address_line2,
              buyer.city,
              buyer.state,
              buyer.postal_code,
              buyer.country,
            ]
              .filter(Boolean)
              .join(', ');
          } else {
            buyerName = 'Customer';
          }
          // If order.products is missing, fallback to product_id
          let productName = order.products?.name || '';
          if (!productName && order.product_id) {
            productName = `${order.product_name}`;
          }
          return {
            ...order,
            total_price:
              typeof order.total_price === 'number'
                ? order.total_price
                : Number(order.total_price) || 0,
            quantity:
              typeof order.quantity === 'number'
                ? order.quantity
                : Number(order.quantity) || 1,
            status: (order.status || 'pending').toLowerCase(),
            product_name: productName || 'Product',
            user_id: order.user_id || 'Unknown',
            payment_method: order.payment_method || 'Cash on Delivery',
            buyer_address: address,
            buyer_name: buyerName,
            product_unit: order.product_unit || order.products?.unit || 'kg',
          };
        });
        setCustomerOrders(ordersWithAddress);
      } catch (error) {
        console.error('Error fetching customer orders:', error);
      }
    },
    [dbManager],
  );

  const [accessDenied, setAccessDenied] = useState(false);
  const loadData = useCallback(async () => {
    try {
      setIsLoading(true);
      setAccessDenied(false);
      const currentUser = await authManager.getCurrentUser();
      if (!currentUser) {
        navigation.replace('SignIn');
        return;
      }

      if (currentUser.role !== 'farmer') {
        setAccessDenied(true);
        setIsLoading(false);
        return;
      }

      setUser(currentUser);

      if (currentUser.id) {
        // Log the currentUser id for debugging
        console.log('[OrdersManagementScreen] currentUser.id:', currentUser.id);
        await fetchCustomerOrders(currentUser.id);
      }
    } catch (error) {
      console.error('Error loading orders management data:', error);
    } finally {
      setIsLoading(false);
    }
  }, [navigation, authManager, fetchCustomerOrders]);

  const handleApproveOrder = async (orderId: number) => {
    try {
      const orderDetails = await dbManager.getOrderDetails(orderId);
      if (!orderDetails) {
        throw new Error('Order details not found');
      }
      // Only update if not already approved/cancelled
      const status = (orderDetails.status || 'pending').toLowerCase();
      if (status === 'approved' || status === 'cancelled') {
        if (isFocused) {
          Alert.alert(
            'Order already processed',
            'This order has already been processed.',
          );
        }
        return;
      }
      // Update the order status
      await dbManager.updateOrderStatus(orderId, 'approved');
      // Handle wallet update for approved order (payment to owner)
      await dbManager.handleOrderWalletUpdate(orderId, 'approved');
      // Deduct product stock by the approved quantity
      try {
        const productId = Number(
          orderDetails.product_id || orderDetails.product?.id || 0,
        );
        const qty = Number(orderDetails.quantity || 0);
        if (productId && qty > 0) {
          // Fetch current product to determine current stock
          const product = await dbManager.getProductById(productId);

          // Check if product still exists
          if (product) {
            const currentStock = Number(
              product?.quantity ?? product?.stock ?? 0,
            );
            const newStock = Math.max(0, currentStock - qty);
            await dbManager.updateProductStock(productId, newStock);
            console.log(
              `[OrdersManagement] Deducted ${qty} from product ${productId}, new stock: ${newStock}`,
            );
          } else {
            console.log(
              `[OrdersManagement] Product ${productId} no longer exists, skipping stock deduction. Order uses snapshot data.`,
            );
          }
        }
      } catch (stockErr) {
        console.warn(
          'Failed to deduct product stock after approving order:',
          stockErr,
        );
        // Don't fail the order approval if stock update fails
      }
      // Refresh orders list after update
      if (user?.id) {
        await fetchCustomerOrders(user.id);
      }
      // Show appropriate message based on payment method
      let message = 'The order has been approved and is ready for delivery.';
      if (orderDetails.payment_method === 'Wallet') {
        message += ' Payment has been transferred to your wallet.';
      }
      if (isFocused) {
        Alert.alert('Order Approved', message, [{ text: 'OK' }]);
      }
    } catch (error) {
      console.error('Error approving order:', error);
      if (isFocused) {
        Alert.alert('Error', 'Failed to approve order. Please try again.');
      }
    }
  };

  const handleCancelOrder = async (orderId: number) => {
    try {
      const orderDetails = await dbManager.getOrderDetails(orderId);
      if (!orderDetails) {
        throw new Error('Order details not found');
      }
      const status = (orderDetails.status || 'pending').toLowerCase();
      if (status === 'approved' || status === 'cancelled') {
        if (isFocused) {
          Alert.alert(
            'Order already processed',
            'This order has already been processed.',
          );
        }
        return;
      }
      // Prepare confirmation message based on payment method
      let confirmMessage = 'Are you sure you want to cancel this order?';
      const paymentMethod = (orderDetails.payment_method || '').toLowerCase();
      if (paymentMethod !== 'cash on delivery' && paymentMethod !== 'cod') {
        confirmMessage +=
          ' The customer will automatically receive a refund to their wallet.';
      }
      if (isFocused) {
        Alert.alert('Cancel Order', confirmMessage, [
          { text: 'No', style: 'cancel' },
          {
            text: 'Yes',
            style: 'destructive',
            onPress: async () => {
              try {
                await dbManager.updateOrderStatus(orderId, 'cancelled');
                // Process refund automatically for all payment methods except COD
                await dbManager.handleOrderWalletUpdate(orderId, 'cancelled');
                if (user?.id) {
                  await fetchCustomerOrders(user.id);
                }
                // Show appropriate message based on payment method
                let message = 'The order has been cancelled.';
                const paymentMethod = (
                  orderDetails.payment_method || ''
                ).toLowerCase();
                // Check if refund was processed
                if (
                  paymentMethod !== 'cash on delivery' &&
                  paymentMethod !== 'cod'
                ) {
                  message += " Refund has been processed to customer's wallet.";
                }
                if (isFocused) {
                  Alert.alert('Order Cancelled', message, [{ text: 'OK' }]);
                }
              } catch (error) {
                console.error('Error cancelling order:', error);
                if (isFocused) {
                  Alert.alert(
                    'Error',
                    'Failed to cancel order. Please try again.',
                  );
                }
              }
            },
          },
        ]);
      }
    } catch (error) {
      console.error('Error getting order details:', error);
      if (isFocused) {
        Alert.alert(
          'Error',
          'Failed to process the order cancellation. Please try again.',
        );
      }
    }
  };

  useEffect(() => {
    loadData();
  }, [loadData]);

  if (isLoading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Loading Orders Management..." />
      </Layout>
    );
  }

  if (accessDenied) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            padding: 32,
          }}
        >
          <Text
            style={{
              fontSize: 18,
              color: '#D32F2F',
              textAlign: 'center',
              marginBottom: 16,
            }}
          >
            Access Denied
          </Text>
          <Text style={{ fontSize: 16, color: '#666', textAlign: 'center' }}>
            Only product owners (farmers) can manage orders. If you are a buyer,
            please use the My Orders screen to view your purchases.
          </Text>
        </View>
      </Layout>
    );
  }

  const { width } = Dimensions.get('window');
  const isLargeScreen = width > 600;
  const cardWidth = isLargeScreen ? (width - 60) / 2 : '100%';
  const totalOrders = customerOrders.length;
  const pendingOrders = customerOrders.filter(
    o => o.status === 'pending',
  ).length;
  const approvedOrders = customerOrders.filter(
    o => o.status === 'approved',
  ).length;
  const deliveredOrders = customerOrders.filter(
    o => o.status === 'delivered',
  ).length;
  const cancelledOrders = customerOrders.filter(
    o => o.status === 'cancelled',
  ).length;

  const statusSummary = [
    {
      key: 'total',
      label: 'Total Orders',
      count: totalOrders,
      icon: 'clipboard-list-outline',
      iconColor: '#1976D2',
      backgroundColor: '#E3F2FD',
      textColor: '#1A1A1A',
    },
    {
      key: 'pending',
      label: 'Pending',
      count: pendingOrders,
      icon: 'progress-clock',
      iconColor: '#FBC02D',
      backgroundColor: '#FFF9C4',
      textColor: '#8D6E63',
    },
    {
      key: 'approved',
      label: 'Approved',
      count: approvedOrders,
      icon: 'check-circle',
      iconColor: '#388E3C',
      backgroundColor: '#C8E6C9',
      textColor: '#2E7D32',
    },
    {
      key: 'delivered',
      label: 'Delivered',
      count: deliveredOrders,
      icon: 'truck-check',
      iconColor: '#1976D2',
      backgroundColor: '#BBDEFB',
      textColor: '#1A237E',
    },
    {
      key: 'cancelled',
      label: 'Cancelled',
      count: cancelledOrders,
      icon: 'close-circle',
      iconColor: '#D32F2F',
      backgroundColor: '#FFCDD2',
      textColor: '#C62828',
    },
  ] as const;

  const ORDER_STATUS_CONFIG: Record<
    string,
    { label: string; icon: string; color: string; backgroundColor: string }
  > = {
    pending: {
      label: 'Pending',
      icon: 'progress-clock',
      color: '#8D6E63',
      backgroundColor: '#FFF9C4',
    },
    approved: {
      label: 'Approved',
      icon: 'check-circle',
      color: '#2E7D32',
      backgroundColor: '#C8E6C9',
    },
    delivered: {
      label: 'Delivered',
      icon: 'truck-check',
      color: '#1A237E',
      backgroundColor: '#BBDEFB',
    },
    cancelled: {
      label: 'Cancelled',
      icon: 'close-circle',
      color: '#C62828',
      backgroundColor: '#FFCDD2',
    },
  };

  return (
    <Layout activeTab="dashboard">
      <View style={styles.container}>
        <ModernHeader
          title="Orders Management"
          subtitle="Manage Customer Orders"
          leftIconName="arrow-left"
          iconSize={24}
          onLeftPress={() => navigation.goBack()}
        />

        <ScrollView
          style={styles.content}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}
        >
          {/* Overview Section */}
          <View style={styles.statsSection}>
            <Text style={styles.overviewTitle}>Orders Overview</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.summaryScrollContainer}
            >
              {statusSummary.map(status => (
                <View
                  key={status.key}
                  style={[
                    styles.statCard,
                    { backgroundColor: status.backgroundColor },
                  ]}
                >
                  <View style={styles.statIconWrapper}>
                    <MaterialCommunityIcons
                      name={status.icon}
                      size={24}
                      color={status.iconColor}
                    />
                  </View>
                  <Text style={[styles.statLabel, { color: status.textColor }]}>
                    {status.label}
                  </Text>
                  <Text style={[styles.statValue, { color: status.iconColor }]}>
                    {status.count}
                  </Text>
                </View>
              ))}
            </ScrollView>
          </View>

          {/* Orders Grid Section */}
          <Text style={styles.sectionTitle}>Customer Orders</Text>
          <View style={styles.ordersGrid}>
            {customerOrders.length > 0 ? (
              customerOrders.map((order, index) => {
                // Prefer order snapshot product_name, then live product, then fallback to product id
                const productName =
                  (order.product_name &&
                  String(order.product_name).trim() !== ''
                    ? order.product_name
                    : order.products?.name) ||
                  (order.product_id ? `${order.product_name}` : 'Product');
                // Debug: Log order product fields
                console.log('[OrdersManagement] Order product fields:', {
                  orderId: order.id,
                  product_id: order.product_id,
                  snapshot_name: order.product_name,
                  snapshot_image: order.product_image_url,
                  live_product_name: order.products?.name,
                  live_product_image: order.products?.image_url,
                });
                const quantity =
                  typeof order.quantity === 'number' ? order.quantity : 1;
                const deliveryFeePerUnit =
                  typeof order.product_delivery_fee === 'number'
                    ? order.product_delivery_fee
                    : typeof order.product_delivery_fee === 'string'
                    ? parseFloat(order.product_delivery_fee) || 0
                    : 0;
                const unitPrice =
                  typeof order.product_price === 'number'
                    ? order.product_price
                    : typeof order.unit_price === 'number'
                    ? order.unit_price
                    : 0;
                const totalPrice =
                  typeof order.total_price === 'number' && order.total_price > 0
                    ? order.total_price
                    : (unitPrice + deliveryFeePerUnit) * quantity;
                const status = (order.status || 'pending').toLowerCase();
                const statusConfig =
                  ORDER_STATUS_CONFIG[status] || ORDER_STATUS_CONFIG.pending;
                const buyerName =
                  order.buyer_name && order.buyer_name.trim() !== ''
                    ? order.buyer_name
                    : 'Customer';
                const paymentMethod =
                  order.payment_method || 'Cash on Delivery';
                return (
                  <View
                    key={index}
                    style={[styles.orderCard, { width: cardWidth }]}
                  >
                    <View style={styles.orderHeaderRow}>
                      <View
                        style={{
                          flexDirection: 'row',
                          alignItems: 'center',
                          flex: 1,
                        }}
                      >
                        {/* Product thumbnail */}
                        {(() => {
                          const imageUrl =
                            order.products?.image_url ||
                            order.product_image_url ||
                            null;
                          return (
                            <Image
                              source={
                                imageUrl
                                  ? { uri: String(imageUrl) }
                                  : require('../../../assets/placeholder.png')
                              }
                              style={styles.productImage}
                              resizeMode="cover"
                            />
                          );
                        })()}

                        <TouchableOpacity
                          onPress={() =>
                            navigation.navigate('ProductDetails', {
                              productId: Number(
                                order.product_id || order.products?.id || 0,
                              ),
                            } as any)
                          }
                          activeOpacity={0.8}
                          style={{ flex: 1 }}
                        >
                          <Text style={styles.orderTitle}>{productName}</Text>
                        </TouchableOpacity>
                      </View>

                      <View
                        style={[
                          styles.orderStatusBadge,
                          { backgroundColor: statusConfig.backgroundColor },
                        ]}
                      >
                        <MaterialCommunityIcons
                          name={statusConfig.icon}
                          size={16}
                          color={statusConfig.color}
                          style={styles.orderStatusIcon}
                        />
                        <Text
                          style={[
                            styles.orderStatusText,
                            { color: statusConfig.color },
                          ]}
                        >
                          {statusConfig.label}
                        </Text>
                      </View>
                    </View>
                    <Text style={styles.orderDetails}>
                      Quantity: {quantity} {order.product_unit || 'kg'}
                    </Text>

                    <Text style={styles.orderDetails}>
                      Customer Name: {buyerName}
                    </Text>
                    {order.buyer_address && (
                      <Text style={styles.orderDetails}>
                        Delivery Address: {order.buyer_address}
                      </Text>
                    )}
                    <Text style={styles.orderDetails}>
                      Delivery Fee: ৳{deliveryFeePerUnit.toFixed(2)}
                    </Text>
                    <Text style={styles.orderDetails}>
                      Payment Method: {paymentMethod}
                    </Text>
                    <Text style={styles.orderPrice}>
                      ৳{isNaN(totalPrice) ? '0.00' : totalPrice.toFixed(2)}
                    </Text>
                    {status === 'pending' && (
                      <View style={styles.actionButtonsContainer}>
                        <TouchableOpacity
                          style={[
                            styles.actionButton,
                            styles.approveButton,
                            { flex: 1, marginRight: 6, minWidth: 0 },
                          ]}
                          onPress={() => handleApproveOrder(order.id)}
                          activeOpacity={0.85}
                          accessibilityLabel="Approve Order"
                        >
                          <Text style={styles.actionButtonText}>Approve</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={[
                            styles.actionButton,
                            styles.cancelButton,
                            {
                              flex: 1,
                              marginLeft: 6,
                              marginRight: 6,
                              minWidth: 0,
                            },
                          ]}
                          onPress={() => handleCancelOrder(order.id)}
                          activeOpacity={0.85}
                          accessibilityLabel="Cancel Order"
                        >
                          <Text style={styles.actionButtonText}>Cancel</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={[
                            styles.actionButton,
                            {
                              backgroundColor: '#2196F3',
                              flex: 1,
                              marginLeft: 6,
                              minWidth: 0,
                              flexDirection: 'row',
                              alignItems: 'center',
                              justifyContent: 'center',
                            },
                          ]}
                          onPress={() => {
                            const otherId = String(order.user_id || '');
                            if (
                              !otherId ||
                              otherId === 'Unknown' ||
                              otherId === 'null' ||
                              otherId === 'undefined'
                            ) {
                              Alert.alert('Error', 'Invalid user to chat with');
                              return;
                            }
                            const currentId = user?.id ? String(user.id) : '';
                            const roomId = currentId
                              ? buildRoomId(currentId, otherId)
                              : otherId;
                            navigation.navigate('ChatRoom', {
                              roomId,
                              otherUserId: otherId,
                              otherUserName: order.buyer_name || 'Customer',
                              orderId: order.id,
                            } as any);
                          }}
                          activeOpacity={0.85}
                          accessibilityLabel="Chat with Customer"
                        >
                          <Text style={styles.actionButtonText}>Chat</Text>
                        </TouchableOpacity>
                      </View>
                    )}
                    {status === 'approved' && (
                      <>
                        <Text style={styles.noteText}>
                          Order approved and ready for delivery. Customer will
                          confirm when received.
                        </Text>
                        <View style={styles.actionButtonsContainer}>
                          <TouchableOpacity
                            style={[
                              styles.actionButton,
                              {
                                backgroundColor: '#2196F3',
                                flex: 1,
                                minWidth: 0,
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'center',
                              },
                            ]}
                            onPress={() => {
                              const otherId = String(order.user_id || '');
                              if (
                                !otherId ||
                                otherId === 'Unknown' ||
                                otherId === 'null' ||
                                otherId === 'undefined'
                              ) {
                                Alert.alert(
                                  'Error',
                                  'Invalid user to chat with',
                                );
                                return;
                              }
                              const currentId = user?.id ? String(user.id) : '';
                              const roomId = currentId
                                ? buildRoomId(currentId, otherId)
                                : otherId;
                              navigation.navigate('ChatRoom', {
                                roomId,
                                otherUserId: otherId,
                                otherUserName: order.buyer_name || 'Customer',
                                orderId: order.id,
                              } as any);
                            }}
                            activeOpacity={0.85}
                            accessibilityLabel="Chat with Customer"
                          >
                            <Text style={styles.actionButtonText}>Chat</Text>
                          </TouchableOpacity>
                        </View>
                      </>
                    )}
                    {status === 'delivered' && (
                      <Text style={styles.noteText}>
                        Order delivered and payment received.
                      </Text>
                    )}
                    {status === 'cancelled' && (
                      <Text style={styles.noteText}>Order was cancelled.</Text>
                    )}
                  </View>
                );
              })
            ) : (
              <Text style={styles.emptyStateText}>
                No orders have been placed for your products yet.
              </Text>
            )}
          </View>
          <View style={styles.bottomPadding} />
        </ScrollView>
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 24,
    paddingBottom: 24,
  },
  statsSection: {
    marginTop: 32,
    marginBottom: 40,
  },
  overviewTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  summaryScrollContainer: {
    paddingLeft: 4,
    paddingRight: 16,
    paddingVertical: 4,
  },
  statCard: {
    width: 160,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    paddingVertical: 18,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
    marginRight: 12,
    marginBottom: 8,
  },
  statIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1A',
    marginTop: 8,
  },
  statLabel: {
    fontSize: 13,
    color: '#666666',
    fontWeight: '500',
    textAlign: 'center',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  ordersGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    justifyContent: 'space-between',
  },
  orderCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
    minWidth: 260,
    maxWidth: '100%',
    alignSelf: 'flex-start',
  },
  orderHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  orderTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333333',
    flex: 1,
  },
  productImage: {
    width: 56,
    height: 56,
    borderRadius: 8,
    marginRight: 12,
    backgroundColor: '#F0F0F0',
  },
  orderStatusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#E0E0E0',
  },
  orderStatusIcon: {
    marginRight: 6,
  },
  orderStatusText: {
    fontSize: 13,
    fontWeight: 'bold',
  },
  orderDetails: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 2,
  },
  orderPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginTop: 8,
    textAlign: 'right',
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  actionButton: {
    flex: 1,
    borderRadius: 6,
    padding: 10,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  approveButton: {
    backgroundColor: '#4CAF50',
  },
  cancelButton: {
    backgroundColor: '#F44336',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
  noteText: {
    marginTop: 10,
    fontStyle: 'italic',
    color: '#666666',
    fontSize: 13,
  },
  emptyStateText: {
    textAlign: 'center',
    color: '#999999',
    fontStyle: 'italic',
    padding: 20,
  },
  bottomPadding: {
    height: 40,
  },
});

export default OrdersManagementScreen;
