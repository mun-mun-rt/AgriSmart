import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
  Image,
  ImageBackground,
  ActivityIndicator,
  Alert,
  RefreshControl,
  Modal,
  TextInput,
} from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { RootStackParamList, Product, ProductCategory } from '../../../types';
import SupabaseDatabaseManager, {
  CartConstraintError,
} from '../../../api/SupabaseDatabaseManager';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import Layout from '../../../components/Layout';

type ECommerceScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'ECommerce'
>;

const emojiToIconMap: Record<string, string> = {
  '🌾': 'sprout',
  '🌱': 'sprout',
  '🌿': 'leaf',
  '🌻': 'flower',
  '🌼': 'flower-outline',
  '🌸': 'flower-tulip',
  '🍀': 'clover',
  '🍃': 'leaf-maple',
  '🍅': 'food-apple',
  '🥕': 'food-carrot',
  '🌽': 'corn',
  '🥦': 'food-apple-outline',
  '🍇': 'grape',
  '🍉': 'fruit-watermelon',
  '🍌': 'food-banana',
  '🍚': 'rice',
  '🍗': 'food-drumstick',
  '🐄': 'cow',
  '🐓': 'chicken',
  '🐟': 'fish',
  '🐝': 'bee',
  '🧪': 'flask',
  '🧫': 'bacteria',
  '🔧': 'wrench',
  '⚙️': 'cog',
  '💧': 'water',
  '🔥': 'fire',
  '🪴': 'sprout',
  '🌋': 'terrain',
  '🚜': 'tractor',
  '🧺': 'basket',
  '📦': 'package-variant',
};

const DEFAULT_CATEGORY_ICON = 'package-variant';

type SortKey = 'recommended' | 'priceHigh' | 'priceLow' | 'newest' | 'oldest';

const SORT_OPTIONS: Array<{ key: SortKey; label: string; icon: string }> = [
  { key: 'recommended', label: 'Recommended', icon: 'star-outline' },
  { key: 'priceHigh', label: 'Price: High-Low', icon: 'arrow-up-bold-circle' },
  { key: 'priceLow', label: 'Price: Low-High', icon: 'arrow-down-bold-circle' },
  { key: 'newest', label: 'Newest First', icon: 'clock-outline' },
  { key: 'oldest', label: 'Oldest First', icon: 'history' },
];

const ECommerceScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<ECommerceScreenNavigationProp>();
  const [products, setProducts] = useState<Product[]>([]);
  const [cartItemCount, setCartItemCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  // support multi-select categories in filters
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(
    null,
  );
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<number[]>([]);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [selectedSortKey, setSelectedSortKey] =
    useState<SortKey>('recommended');
  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const [filterPriceMin, setFilterPriceMin] = useState<string>('');
  const [filterPriceMax, setFilterPriceMax] = useState<string>('');
  const [tempSelectedCategoryIds, setTempSelectedCategoryIds] = useState<
    number[]
  >([]);
  const [heroProducts, setHeroProducts] = useState<Product[]>([]);
  const [heroIndex, setHeroIndex] = useState(0);

  const resolveCategoryIconName = useCallback((iconValue?: string | null) => {
    if (!iconValue) {
      return DEFAULT_CATEGORY_ICON;
    }

    const trimmed = iconValue.trim();
    if (trimmed.length === 0) {
      return DEFAULT_CATEGORY_ICON;
    }

    if (emojiToIconMap[trimmed]) {
      return emojiToIconMap[trimmed];
    }

    if (/^[a-z0-9-]+$/i.test(trimmed)) {
      return trimmed.toLowerCase();
    }

    const withoutPrefix = trimmed.split(':').pop();
    if (withoutPrefix && /^[a-z0-9-]+$/i.test(withoutPrefix)) {
      return withoutPrefix.toLowerCase();
    }

    return DEFAULT_CATEGORY_ICON;
  }, []);

  const loadCategories = useCallback(async () => {
    try {
      const dbCategories = await dbManager.getAllProductCategories();
      setCategories(dbCategories);
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  }, [dbManager]);

  const loadProducts = useCallback(async () => {
    try {
      const allProducts = await dbManager.getAllProducts();
      setProducts(allProducts);
    } catch (error) {
      console.error('Error loading products:', error);
      Alert.alert('Error', 'Failed to load products');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [dbManager]);

  const loadUserData = useCallback(async () => {
    try {
      const user = await authManager.getCurrentUser();
      setCurrentUser(user);

      if (user && user.id) {
        const count = await dbManager.getCartItemCount(String(user.id));
        setCartItemCount(count);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  }, [authManager, dbManager]);

  const loadData = useCallback(async () => {
    setLoading(true);
    await Promise.all([loadProducts(), loadUserData(), loadCategories()]);
  }, [loadProducts, loadUserData, loadCategories]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // debounce searchQuery -> debouncedQuery
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(searchQuery.trim()), 300);
    return () => clearTimeout(t);
  }, [searchQuery]);

  const shuffleProducts = useCallback((items: Product[]) => {
    const arr = [...items];
    for (let i = arr.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadUserData();
    }, [loadUserData]),
  );

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadData();
  }, [loadData]);

  const handleAddToCart = async (product: Product) => {
    if (!currentUser) {
      Alert.alert(
        'Login Required',
        'You need to log in to add items to your cart',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Login', onPress: () => navigation.navigate('SignIn') },
        ],
      );
      return;
    }

    // Only allow farmers and consumers to add to cart
    if (currentUser.role !== 'farmer' && currentUser.role !== 'consumer') {
      Alert.alert(
        'Access Restricted',
        'Only farmers and consumers can add items to cart',
        [{ text: 'OK' }],
      );
      return;
    }

    try {
      const result = await dbManager.addToCart({
        user_id: currentUser.id,
        product_id: product.id!,
        quantity: 1,
      });
      setCartItemCount(prev => prev + 1);
      if (result.adjustedToMin) {
        Alert.alert(
          'Minimum Quantity Applied',
          `${product.name} added with the minimum order quantity of ${result.minPurchase}.`,
        );
        return;
      }
      if (result.adjustedToStock) {
        Alert.alert(
          'Limited Stock',
          `${product.name} added, but only ${result.quantity} unit(s) are currently available.`,
        );
        return;
      }
      if (result.adjustedToMax) {
        const maxLabel =
          result.maxPurchase !== null ? result.maxPurchase : result.quantity;
        Alert.alert(
          'Order Limit Applied',
          `${product.name} added up to the maximum per order of ${maxLabel}.`,
        );
        return;
      }
      Alert.alert('Success', `${product.name} added to cart`);
    } catch (error) {
      if (error instanceof CartConstraintError) {
        const { reason, minPurchase, maxPurchase, availableStock } =
          error.details;
        if (reason === 'min') {
          Alert.alert(
            'Minimum Order Required',
            `You must order at least ${minPurchase} unit(s) of ${product.name}.`,
          );
        } else if (reason === 'max' && maxPurchase !== null) {
          Alert.alert(
            'Order Limit Reached',
            `You can order up to ${maxPurchase} unit(s) of ${product.name} per purchase.`,
          );
        } else if (reason === 'stock') {
          const stockMessage =
            typeof availableStock === 'number'
              ? `Only ${availableStock} unit(s) of ${product.name} are currently available.`
              : 'Not enough stock available right now.';
          Alert.alert('Insufficient Stock', stockMessage);
        }
        return;
      }
      console.error('Error adding to cart:', error);
      Alert.alert('Error', 'Failed to add item to cart');
    }
  };

  const handleCategorySelect = (category: ProductCategory) => {
    if (selectedCategoryId === category.id) {
      setSelectedCategory(null);
      setSelectedCategoryId(null);
    } else {
      setSelectedCategory(category.name);
      setSelectedCategoryId(category.id || null);
    }
  };

  const displayedProducts = useMemo(() => {
    let categoryFiltered = products;
    if (selectedCategoryIds && selectedCategoryIds.length > 0) {
      const idSet = new Set(selectedCategoryIds.filter(Boolean));
      categoryFiltered = products.filter(p =>
        idSet.has(p.category_id as number),
      );
    } else if (selectedCategory) {
      categoryFiltered = products.filter(
        p =>
          p.category === selectedCategory ||
          p.category_id === selectedCategoryId,
      );
    }

    const normalizedQuery = debouncedQuery.trim().toLowerCase();
    const searchFiltered = normalizedQuery
      ? categoryFiltered.filter(product => {
          const haystack = [
            product.name,
            product.description,
            product.category,
            product.farmer_name,
          ]
            .filter(Boolean)
            .join(' ')
            .toLowerCase();
          return haystack.includes(normalizedQuery);
        })
      : categoryFiltered;

    // apply price range filters if provided
    const min = filterPriceMin ? Number(filterPriceMin) : null;
    const max = filterPriceMax ? Number(filterPriceMax) : null;
    const priceFiltered = searchFiltered.filter(p => {
      const price = p.price ?? 0;
      if (min !== null && price < min) return false;
      if (max !== null && price > max) return false;
      return true;
    });

    const sorted = [...priceFiltered];
    const parseDate = (value?: string) =>
      value ? new Date(value).getTime() : 0;

    switch (selectedSortKey) {
      case 'priceHigh':
        sorted.sort((a, b) => (b.price ?? 0) - (a.price ?? 0));
        break;
      case 'priceLow':
        sorted.sort((a, b) => (a.price ?? 0) - (b.price ?? 0));
        break;
      case 'newest':
        sorted.sort(
          (a, b) => parseDate(b.created_at) - parseDate(a.created_at),
        );
        break;
      case 'oldest':
        sorted.sort(
          (a, b) => parseDate(a.created_at) - parseDate(b.created_at),
        );
        break;
      default:
        break;
    }

    return sorted;
  }, [
    products,
    selectedCategory,
    selectedCategoryId,
    selectedCategoryIds,
    debouncedQuery,
    filterPriceMin,
    filterPriceMax,
    selectedSortKey,
  ]);

  useEffect(() => {
    if (displayedProducts.length > 0) {
      setHeroProducts(shuffleProducts(displayedProducts));
      setHeroIndex(0);
    } else {
      setHeroProducts([]);
      setHeroIndex(0);
    }
  }, [displayedProducts, shuffleProducts]);

  useEffect(() => {
    if (heroProducts.length > 1) {
      const intervalId = setInterval(() => {
        setHeroIndex(prev => (prev + 1) % heroProducts.length);
      }, 5000);
      return () => clearInterval(intervalId);
    }
    return undefined;
  }, [heroProducts]);

  const currentHeroProduct = heroProducts[heroIndex];

  // Handler for Details button: if not logged in, go to SignIn, else ProductDetails
  const handleDetailsPress = (productId: number | string) => {
    if (!currentUser) {
      navigation.navigate('SignIn');
    } else {
      navigation.navigate('ProductDetails', { productId: Number(productId) });
    }
  };

  return (
    <Layout activeTab="dashboard">
      <StatusBar barStyle="light-content" backgroundColor="#2E7D32" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialCommunityIcons name="arrow-left" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>AgriSmart Store</Text>
        {currentUser &&
          (currentUser.role === 'farmer' ||
            currentUser.role === 'consumer') && (
            <TouchableOpacity
              style={styles.cartButton}
              onPress={() => navigation.navigate('Cart')}
            >
              <MaterialCommunityIcons name="cart" size={24} color="#4CAF50" />
              {cartItemCount > 0 && (
                <View style={styles.cartBadge}>
                  <Text style={styles.cartBadgeText}>
                    {cartItemCount > 99 ? '99+' : cartItemCount}
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          )}
        {(!currentUser ||
          (currentUser.role !== 'farmer' &&
            currentUser.role !== 'consumer')) && (
          <View style={styles.cartButton}>
            <MaterialCommunityIcons name="account" size={24} color="#757575" />
          </View>
        )}
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#4CAF50']}
            tintColor="#4CAF50"
          />
        }
      >
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#2E7D32" />
            <Text style={styles.loadingText}>Loading products...</Text>
          </View>
        ) : (
          <>
            {/* Welcome Section */}
            {currentHeroProduct && (
              <TouchableOpacity
                activeOpacity={0.9}
                style={styles.heroCard}
                onPress={() => {
                  if (currentHeroProduct?.id) {
                    handleDetailsPress(currentHeroProduct.id);
                  }
                }}
              >
                <ImageBackground
                  source={
                    currentHeroProduct.image_url
                      ? { uri: currentHeroProduct.image_url }
                      : require('../../../assets/placeholder.png')
                  }
                  style={styles.heroImage}
                  imageStyle={styles.heroImageStyle}
                  resizeMode="cover"
                >
                  <View style={styles.heroOverlay}>
                    <Text style={styles.heroBadge}>Featured</Text>
                    <Text style={styles.heroTitle} numberOfLines={2}>
                      {currentHeroProduct.name}
                    </Text>
                    <Text style={styles.heroPrice}>
                      ৳{(currentHeroProduct.price ?? 0).toFixed(2)}
                    </Text>
                    {heroProducts.length > 1 && (
                      <View style={styles.heroIndicators}>
                        {heroProducts.slice(0, 6).map((_, index) => {
                          const isActive = index === heroIndex;
                          return (
                            <View
                              key={String(index)}
                              style={[
                                styles.heroIndicatorDot,
                                isActive && styles.heroIndicatorDotActive,
                              ]}
                            />
                          );
                        })}
                      </View>
                    )}
                  </View>
                </ImageBackground>
              </TouchableOpacity>
            )}

            <View style={styles.welcomeSection}>
              <Text style={styles.welcomeTitle}>Agricultural Marketplace</Text>
              <Text style={styles.welcomeSubtitle}>
                Everything you need for successful farming
              </Text>
            </View>

            {/* Search and Filter Row */}
            <View style={styles.searchSection}>
              <View style={styles.searchInputRow}>
                <View style={styles.searchInputWrapper}>
                  <MaterialCommunityIcons
                    name="magnify"
                    size={20}
                    color="#4CAF50"
                    style={styles.searchIcon}
                  />
                  <TextInput
                    value={searchQuery}
                    onChangeText={text => setSearchQuery(text)}
                    placeholder="Search products, categories, farmers"
                    placeholderTextColor="#9E9E9E"
                    style={styles.searchInput}
                    returnKeyType="search"
                  />
                  {searchQuery.length > 0 && (
                    <TouchableOpacity
                      onPress={() => setSearchQuery('')}
                      style={styles.clearSearchButton}
                      accessibilityLabel="Clear search"
                    >
                      <MaterialCommunityIcons
                        name="close-circle"
                        size={18}
                        color="#9E9E9E"
                      />
                    </TouchableOpacity>
                  )}
                </View>

                <TouchableOpacity
                  style={styles.filterButton}
                  onPress={() => {
                    // open modal and prepare temp selections
                    setTempSelectedCategoryIds(
                      selectedCategoryIds.length
                        ? selectedCategoryIds
                        : selectedCategoryId
                        ? [selectedCategoryId]
                        : [],
                    );
                    setFilterPriceMin(filterPriceMin);
                    setFilterPriceMax(filterPriceMax);
                    setFilterModalVisible(true);
                  }}
                >
                  <MaterialCommunityIcons
                    name="filter-variant"
                    size={20}
                    color="#4CAF50"
                  />
                </TouchableOpacity>
              </View>
            </View>

            {/* Filter Modal */}
            <Modal
              visible={filterModalVisible}
              animationType="slide"
              transparent
              onRequestClose={() => setFilterModalVisible(false)}
            >
              <View style={styles.modalOverlay}>
                <View style={styles.modalContent}>
                  <Text style={styles.modalTitle}>Filters</Text>

                  <Text style={styles.modalSectionTitle}>Categories</Text>
                  <ScrollView style={styles.modalCategories}>
                    {categories.map(cat => {
                      const isSelected = tempSelectedCategoryIds.includes(
                        cat.id || -1,
                      );
                      return (
                        <TouchableOpacity
                          key={cat.id?.toString() || cat.name}
                          style={styles.modalCategoryRow}
                          onPress={() => {
                            if (isSelected) {
                              setTempSelectedCategoryIds(prev =>
                                prev.filter(id => id !== cat.id),
                              );
                            } else {
                              setTempSelectedCategoryIds(prev => [
                                ...prev,
                                cat.id!,
                              ]);
                            }
                          }}
                        >
                          <MaterialCommunityIcons
                            name={
                              isSelected
                                ? 'checkbox-marked'
                                : 'checkbox-blank-outline'
                            }
                            size={18}
                            color="#4CAF50"
                            style={{ marginRight: 8 }}
                          />
                          <Text style={styles.modalCategoryName}>
                            {cat.name}
                          </Text>
                        </TouchableOpacity>
                      );
                    })}
                  </ScrollView>

                  <Text style={styles.modalSectionTitle}>Price Range (৳)</Text>
                  <View style={styles.priceRow}>
                    <TextInput
                      value={filterPriceMin}
                      onChangeText={text =>
                        setFilterPriceMin(text.replace(/[^0-9.]/g, ''))
                      }
                      placeholder="Min"
                      keyboardType="numeric"
                      style={styles.priceInput}
                    />
                    <Text style={{ marginHorizontal: 8 }}>—</Text>
                    <TextInput
                      value={filterPriceMax}
                      onChangeText={text =>
                        setFilterPriceMax(text.replace(/[^0-9.]/g, ''))
                      }
                      placeholder="Max"
                      keyboardType="numeric"
                      style={styles.priceInput}
                    />
                  </View>

                  <Text style={styles.modalSectionTitle}>Sort By</Text>
                  <View style={styles.sortOptionsColumn}>
                    {SORT_OPTIONS.map(option => (
                      <TouchableOpacity
                        key={option.key}
                        style={styles.sortOptionRow}
                        onPress={() => setSelectedSortKey(option.key)}
                      >
                        <MaterialCommunityIcons
                          name={
                            selectedSortKey === option.key
                              ? 'radiobox-marked'
                              : 'radiobox-blank'
                          }
                          size={18}
                          color="#4CAF50"
                          style={{ marginRight: 8 }}
                        />
                        <Text>{option.label}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>

                  <View style={styles.modalActions}>
                    <TouchableOpacity
                      style={styles.modalButtonClear}
                      onPress={() => {
                        setTempSelectedCategoryIds([]);
                        setFilterPriceMin('');
                        setFilterPriceMax('');
                        setSelectedCategory(null);
                        setSelectedCategoryId(null);
                        setSelectedCategoryIds([]);
                        setFilterModalVisible(false);
                      }}
                    >
                      <Text style={styles.modalButtonClearText}>Clear</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={styles.modalButtonApply}
                      onPress={() => {
                        // apply temp selections
                        setSelectedCategoryIds(tempSelectedCategoryIds);
                        if (tempSelectedCategoryIds.length === 1) {
                          setSelectedCategoryId(tempSelectedCategoryIds[0]);
                          const c = categories.find(
                            cc => cc.id === tempSelectedCategoryIds[0],
                          );
                          setSelectedCategory(c ? c.name : null);
                        } else {
                          setSelectedCategory(null);
                          setSelectedCategoryId(null);
                        }
                        setFilterModalVisible(false);
                      }}
                    >
                      <Text style={styles.modalButtonApplyText}>Apply</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </Modal>

            {/* Categories Grid */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Categories</Text>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={styles.categoriesScroll}
              >
                {categories.map((category, index) => (
                  <TouchableOpacity
                    key={category.id?.toString() || index.toString()}
                    style={[
                      styles.categoryCard,
                      selectedCategoryId === category.id &&
                        styles.selectedCategory,
                    ]}
                    onPress={() => handleCategorySelect(category)}
                  >
                    <MaterialCommunityIcons
                      name={resolveCategoryIconName(category.icon)}
                      size={28}
                      color="#4CAF50"
                      style={styles.categoryIcon}
                    />
                    <Text style={styles.categoryName}>{category.name}</Text>
                    <Text style={styles.categoryCount}>
                      {
                        products.filter(
                          p =>
                            p.category === category.name ||
                            p.category_id === category.id,
                        ).length
                      }{' '}
                      items
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>

            {/* Products Grid */}
            <View style={styles.section}>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>
                  {selectedCategory ? selectedCategory : 'All Products'}
                </Text>
                {selectedCategory && (
                  <TouchableOpacity
                    onPress={() => {
                      setSelectedCategory(null);
                      setSelectedCategoryId(null);
                    }}
                  >
                    <Text style={styles.clearFilterText}>Clear Filter</Text>
                  </TouchableOpacity>
                )}
              </View>

              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.sortOptionsContainer}
                style={styles.sortOptionsScroll}
              >
                {SORT_OPTIONS.map(option => {
                  const isActive = option.key === selectedSortKey;
                  return (
                    <TouchableOpacity
                      key={option.key}
                      style={[
                        styles.sortChip,
                        isActive && styles.sortChipActive,
                      ]}
                      onPress={() => setSelectedSortKey(option.key)}
                    >
                      <MaterialCommunityIcons
                        name={option.icon}
                        size={16}
                        color={isActive ? '#FFFFFF' : '#4CAF50'}
                        style={styles.sortChipIcon}
                      />
                      <Text
                        style={[
                          styles.sortChipText,
                          isActive && styles.sortChipTextActive,
                        ]}
                      >
                        {option.label}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </ScrollView>

              {displayedProducts.length === 0 ? (
                <View style={styles.emptyState}>
                  <Text style={styles.emptyStateText}>
                    No products found in this category
                  </Text>
                </View>
              ) : (
                <View style={styles.productsGrid}>
                  {displayedProducts.map(product => (
                    <View key={product.id} style={styles.productCard}>
                      <Image
                        source={
                          product.image_url
                            ? { uri: product.image_url }
                            : require('../../../assets/placeholder.png')
                        }
                        style={styles.productImage}
                        resizeMode="cover"
                      />
                      <View style={styles.productInfo}>
                        <Text style={styles.productName}>{product.name}</Text>
                        <Text style={styles.productCategory}>
                          {product.category}
                        </Text>
                        <Text style={styles.productPrice}>
                          ৳{product.price.toFixed(2)}
                        </Text>

                        <View style={styles.productActions}>
                          <TouchableOpacity
                            style={styles.detailsButton}
                            onPress={() => handleDetailsPress(product.id!)}
                          >
                            <Text style={styles.detailsButtonText}>
                              Details
                            </Text>
                          </TouchableOpacity>

                          {currentUser &&
                            (currentUser.role === 'farmer' ||
                              currentUser.role === 'consumer') &&
                            currentUser.id !== product.farmer_id && (
                              <TouchableOpacity
                                style={styles.addToCartButton}
                                onPress={() => handleAddToCart(product)}
                              >
                                <Text style={styles.addToCartButtonText}>
                                  Buy
                                </Text>
                              </TouchableOpacity>
                            )}

                          {(!currentUser ||
                            (currentUser.role !== 'farmer' &&
                              currentUser.role !== 'consumer')) && (
                            <TouchableOpacity
                              style={styles.restrictedCartButton}
                              onPress={() => navigation.navigate('SignIn')}
                            >
                              <MaterialCommunityIcons
                                name="lock"
                                size={12}
                                color="#666666"
                                style={styles.restrictedCartIcon}
                              />
                            </TouchableOpacity>
                          )}
                        </View>
                      </View>
                    </View>
                  ))}
                </View>
              )}
            </View>
          </>
        )}
      </ScrollView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F9F9',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 22,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    elevation: 2,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    color: '#2E7D32',
    fontSize: 22,
    fontWeight: '700',
  },
  headerTitle: {
    color: '#1A1A1A',
    fontSize: 22,
    fontWeight: '700',
    textAlign: 'center',
    flex: 1,
  },
  cartButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  cartButtonText: {
    color: '#2E7D32',
    fontSize: 22,
  },
  cartBadge: {
    position: 'absolute',
    top: 2,
    right: 2,
    backgroundColor: '#FF5722',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 2,
  },
  cartBadgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
    paddingHorizontal: 4,
  },
  content: {
    flex: 1,
    paddingTop: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 50,
  },
  loadingText: {
    marginTop: 10,
    color: '#2E7D32',
    fontSize: 16,
  },
  welcomeSection: {
    backgroundColor: '#E8F5E9',
    borderRadius: 16,
    padding: 24,
    marginBottom: 18,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  welcomeTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#2E7D32',
    marginBottom: 8,
    textAlign: 'center',
  },
  welcomeSubtitle: {
    fontSize: 15,
    color: '#388E3C',
    textAlign: 'center',
  },
  section: {
    marginBottom: 22,
    paddingHorizontal: 8,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    paddingHorizontal: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 10,
  },
  clearFilterText: {
    color: '#2196F3',
    fontSize: 14,
    fontWeight: '500',
  },
  searchSection: {
    paddingHorizontal: 16,
    marginBottom: 18,
  },
  heroCard: {
    marginHorizontal: 16,
    marginBottom: 18,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 3,
    shadowColor: '#000000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
  },
  heroImage: {
    width: '100%',
    height: 200,
    justifyContent: 'flex-end',
  },
  heroImageStyle: {
    borderRadius: 20,
  },
  heroOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.35)',
    padding: 20,
  },
  heroBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(255,255,255,0.85)',
    color: '#2E7D32',
    fontWeight: '600',
    fontSize: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 10,
  },
  heroTitle: {
    color: '#FFFFFF',
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 6,
  },
  heroPrice: {
    color: '#FFEB3B',
    fontSize: 18,
    fontWeight: '700',
  },
  heroIndicators: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 12,
    gap: 6,
  },
  heroIndicatorDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#C8E6C9',
  },
  heroIndicatorDotActive: {
    backgroundColor: '#4CAF50',
  },
  searchInputWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 24,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: '#1A1A1A',
  },
  clearSearchButton: {
    marginLeft: 8,
  },
  searchInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    gap: 12,
  },
  filterButton: {
    marginLeft: 10,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  sortOptionsScroll: {
    marginBottom: 12,
    paddingLeft: 8,
  },
  sortOptionsContainer: {
    paddingRight: 16,
  },
  sortChip: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#C8E6C9',
    marginRight: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 2,
    elevation: 1,
  },
  sortChipActive: {
    backgroundColor: '#4CAF50',
    borderColor: '#4CAF50',
  },
  sortChipIcon: {
    marginRight: 6,
  },
  sortChipText: {
    fontSize: 12,
    color: '#4CAF50',
    fontWeight: '600',
  },
  sortChipTextActive: {
    color: '#FFFFFF',
  },
  categoriesScroll: {
    flexDirection: 'row',
    marginBottom: 8,
    paddingLeft: 8,
  },
  categoryCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    paddingVertical: 16,
    paddingHorizontal: 10,
    marginRight: 12,
    marginBottom: 8,
    alignItems: 'center',
    width: 100,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 1,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  selectedCategory: {
    backgroundColor: '#E8F5E9',
    borderWidth: 2,
    borderColor: '#4CAF50',
  },
  categoryIcon: {
    marginBottom: 8,
  },
  categoryName: {
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#1A1A1A',
  },
  categoryCount: {
    fontSize: 12,
    color: '#888888',
    marginTop: 4,
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
  },
  productCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    overflow: 'hidden',
    width: '48%',
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  productImage: {
    width: '100%',
    height: 140,
    backgroundColor: '#EEEEEE',
  },
  productInfo: {
    padding: 14,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  productCategory: {
    fontSize: 12,
    color: '#888888',
    marginBottom: 6,
  },
  productPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginBottom: 8,
  },
  productActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 4,
  },
  detailsButton: {
    backgroundColor: '#2196F3',
    borderRadius: 20,
    paddingVertical: 7,
    paddingHorizontal: 14,
    flex: 1,
    alignItems: 'center',
    marginRight: 4,
  },
  detailsButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  addToCartButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 20,
    paddingVertical: 7,
    paddingHorizontal: 14,
    flex: 1,
    alignItems: 'center',
    marginLeft: 4,
  },
  addToCartButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  emptyState: {
    padding: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyStateText: {
    fontSize: 16,
    color: '#888888',
    textAlign: 'center',
    marginTop: 8,
  },
  restrictedCartButton: {
    backgroundColor: '#CCCCCC',
    borderRadius: 20,
    paddingVertical: 7,
    paddingHorizontal: 14,
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 4,
    gap: 4,
  },
  restrictedCartIcon: {
    marginRight: 2,
  },
  restrictedCartButtonText: {
    color: '#666666',
    fontSize: 12,
    fontWeight: 'bold',
  },
  // Responsive bottom padding for scroll
  bottomPadding: {
    height: 32,
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    padding: 16,
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 12,
  },
  modalSectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginTop: 8,
    marginBottom: 6,
  },
  modalCategories: {
    maxHeight: 120,
    marginBottom: 8,
  },
  modalCategoryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  modalCategoryName: {
    fontSize: 14,
    color: '#1A1A1A',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  priceInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 10,
    backgroundColor: '#FAFAFA',
  },
  sortOptionsColumn: {
    marginBottom: 12,
  },
  sortOptionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
  },
  modalButtonClear: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
    backgroundColor: '#F5F5F5',
  },
  modalButtonClearText: {
    color: '#333333',
    fontWeight: '600',
  },
  modalButtonApply: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
    backgroundColor: '#4CAF50',
  },
  modalButtonApplyText: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
});

export default ECommerceScreen;
