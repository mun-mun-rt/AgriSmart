import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  ActivityIndicator,
  Modal,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { RootStackParamList, Product, User } from '../../../types';
import SupabaseDatabaseManager, {
  CartConstraintError,
} from '../../../api/SupabaseDatabaseManager';
import ModernLoading from '../../../components/ModernLoading';
import Layout from '../../../components/Layout';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import { getRoleDisplayName } from '../../../utils/authUtils';
import { buildRoomId } from '../../../utils';

type ProductDetailsNavigationProp = StackNavigationProp<
  RootStackParamList,
  'ProductDetails'
>;

type ProductDetailsRouteProp = RouteProp<RootStackParamList, 'ProductDetails'>;

const ProductDetailsScreen: React.FC = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [modalMessage, setModalMessage] = useState('');
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<ProductDetailsNavigationProp>();
  const route = useRoute<ProductDetailsRouteProp>();
  const { productId } = route.params;

  const [product, setProduct] = useState<Product | null>(null);
  const [farmer, setFarmer] = useState<User | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isFollowing, setIsFollowing] = useState<boolean>(false);
  const [followerCount, setFollowerCount] = useState<number>(0);
  const [addingToCart, setAddingToCart] = useState<boolean>(false);
  const [cartItemCount, setCartItemCount] = useState<number>(0);

  // Function to show modal with message
  const showModal = (message: string) => {
    setModalMessage(message);
    setModalVisible(true);
  };

  // Function to hide modal
  const hideModal = () => {
    setModalVisible(false);
    setModalMessage('');
  };

  const loadProductDetails = useCallback(async () => {
    let isMounted = true;
    try {
      setLoading(true);

      // Get product details
      const productData = await dbManager.getProductById(productId);
      if (!productData) {
        if (isMounted) {
          navigation.goBack();
        }
        return;
      }

      if (isMounted) setProduct(productData);

      // Get farmer details
      const farmerData = await dbManager.getUserById(productData.farmer_id);
      if (isMounted) {
        setFarmer(farmerData || null);
      }
      if (farmerData && isMounted) {
        // Get follower count for this farmer
        const count = await dbManager.getFollowerCount(
          farmerData.id!.toString(),
        );
        setFollowerCount(count);
      }

      // Get current user and check if following
      const user = await authManager.getCurrentUser();
      if (user && isMounted) {
        setCurrentUser(user);
        try {
          const cartItems = await dbManager.getUserCart(String(user.id));
          if (isMounted) {
            setCartItemCount(Array.isArray(cartItems) ? cartItems.length : 0);
          }
        } catch (cartError) {
          console.error(
            'Error loading cart items for details screen:',
            cartError,
          );
          if (isMounted) {
            setCartItemCount(0);
          }
        }
        if (farmerData && user.id !== farmerData.id) {
          const following = await dbManager.isFollowing(String(farmerData.id));
          setIsFollowing(following);
        }
      }
    } catch (error) {
      console.error('Error loading product details:', error);
      if (isMounted) {
        showModal('Failed to load product details. Please try again.');
      }
    } finally {
      if (isMounted) setLoading(false);
    }
    return () => {
      isMounted = false;
    };
  }, [productId, dbManager, navigation, authManager]);

  useEffect(() => {
    loadProductDetails();
  }, [loadProductDetails]);

  const handleFollow = async () => {
    if (!currentUser || !product) return;

    if (String(currentUser.id) === String(product.farmer_id)) {
      Alert.alert('Error', 'You cannot follow yourself');
      return;
    }

    // Only allow farmers and consumers to follow
    if (currentUser.role !== 'farmer' && currentUser.role !== 'consumer') {
      Alert.alert(
        'Access Restricted',
        'Only farmers and consumers can follow other users',
        [{ text: 'OK' }],
      );
      return;
    }

    try {
      const farmerName = farmer ? farmer.name : 'this farmer';
      if (isFollowing) {
        await dbManager.unfollowFarmer(product.farmer_id.toString());
        setIsFollowing(false);
        setFollowerCount(prev => prev - 1);
        const message = `You unfollowed ${farmerName}${
          currentUser.role === 'farmer'
            ? ' - Stay connected with fellow farmers!'
            : ''
        }`;
        showModal(message);
      } else {
        await dbManager.followFarmer(product.farmer_id.toString());
        setIsFollowing(true);
        setFollowerCount(prev => prev + 1);
        const message =
          currentUser.role === 'farmer'
            ? `You are now following ${farmerName} - Great for farmer-to-farmer collaboration!`
            : `You are now following ${farmerName}`;
        showModal(message);
      }
      // Always re-fetch follow status and follower count from backend after action
      if (farmer) {
        const [following, count] = await Promise.all([
          dbManager.isFollowing(String(farmer.id)),
          dbManager.getFollowerCount(String(farmer.id)),
        ]);
        setIsFollowing(following);
        setFollowerCount(count);
      }
    } catch (error) {
      console.error('Error updating follow status:', error);
      showModal('Failed to update follow status. Please try again.');
    }
  };

  const handleChat = () => {
    if (!currentUser || !product) {
      Alert.alert('Error', 'Please log in to chat');
      return;
    }

    if (String(currentUser.id) === String(product.farmer_id)) {
      Alert.alert('Error', 'You cannot chat with yourself');
      return;
    }

    // Only allow farmers and consumers to chat
    if (currentUser.role !== 'farmer' && currentUser.role !== 'consumer') {
      Alert.alert(
        'Access Restricted',
        'Only farmers and consumers can chat with other users',
        [{ text: 'OK' }],
      );
      return;
    }

    const currentUserId = currentUser.id?.toString();
    const farmerId = product?.farmer_id?.toString();
    if (!currentUserId || !farmerId) {
      Alert.alert('Error', 'Farmer information is missing for this product');
      return;
    }

    // Navigate to chat with this farmer
    navigation.navigate('ChatRoom', {
      roomId: buildRoomId(currentUserId, farmerId),
      otherUserId: farmerId,
      otherUserName: farmer ? farmer.name : 'Farmer',
    });
  };

  const handleAddToCart = async () => {
    if (!currentUser) {
      Alert.alert(
        'Login Required',
        'You need to log in to add items to your cart',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Login', onPress: () => navigation.navigate('SignIn') },
        ],
      );
      return;
    }

    // Only allow farmers and consumers to add to cart
    if (currentUser.role !== 'farmer' && currentUser.role !== 'consumer') {
      Alert.alert(
        'Access Restricted',
        'Only farmers and consumers can add items to cart',
        [{ text: 'OK' }],
      );
      return;
    }

    if (!product) return;

    try {
      setAddingToCart(true);
      // Check if product already in cart
      const cartItems = await dbManager.getUserCart(currentUser.id!.toString());
      setCartItemCount(Array.isArray(cartItems) ? cartItems.length : 0);
      const alreadyInCart = cartItems.some(
        (item: any) => item.product_id === product.id,
      );
      if (alreadyInCart) {
        showModal('This product is already in your cart.');
        return;
      }
      const result = await dbManager.addToCart({
        user_id: currentUser.id!.toString(),
        product_id: product.id!,
        quantity: 1,
      });
      setCartItemCount(prev => prev + 1);
      if (result.adjustedToMin) {
        showModal(
          `${product.name} added with the minimum order quantity of ${result.minPurchase}.`,
        );
      } else if (result.adjustedToStock) {
        showModal(
          `${product.name} added, but limited to available stock (${result.quantity}).`,
        );
      } else if (result.adjustedToMax) {
        showModal(
          `${product.name} added up to the maximum per order of ${result.maxPurchase}.`,
        );
      } else {
        showModal(`${product.name} has been added to your cart!`);
      }
    } catch (error) {
      if (error instanceof CartConstraintError) {
        const { reason, minPurchase, maxPurchase, availableStock } =
          error.details;
        if (reason === 'min') {
          showModal(
            `You must order at least ${minPurchase} unit(s) of ${product.name}.`,
          );
        } else if (reason === 'max' && maxPurchase !== null) {
          showModal(
            `You can order up to ${maxPurchase} unit(s) of ${product.name} per purchase.`,
          );
        } else if (reason === 'stock') {
          const stockMessage =
            typeof availableStock === 'number'
              ? `Only ${availableStock} unit(s) of ${product.name} are currently available.`
              : 'Not enough stock available right now.';
          showModal(stockMessage);
        }
        return;
      }
      console.error('Error adding to cart:', error);
      showModal('Failed to add item to cart. Please try again.');
    } finally {
      setAddingToCart(false);
    }
  };

  const handleViewFarmerProducts = () => {
    if (farmer) {
      navigation.navigate('UserProfile', {
        userId: farmer.id!.toString(),
      });
    }
  };

  if (loading) {
    return (
      <Layout activeTab="home" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Loading product details..." />
      </Layout>
    );
  }

  if (!product) {
    return (
      <Layout activeTab="home" showBottomNavigation={false}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Product not found</Text>
        </View>
      </Layout>
    );
  }

  const minPurchase = Math.max(
    1,
    Math.floor(product.min_purchase_quantity ?? 1),
  );
  const maxPurchaseValue =
    typeof product.max_purchase_quantity === 'number'
      ? Math.max(minPurchase, Math.floor(product.max_purchase_quantity))
      : null;
  const availableQuantityRaw =
    typeof product.quantity === 'number'
      ? product.quantity
      : typeof product.stock === 'number'
      ? product.stock
      : null;
  const hasSufficientStock =
    availableQuantityRaw === null || availableQuantityRaw >= minPurchase;
  const addToCartDisabled =
    addingToCart ||
    !hasSufficientStock ||
    (typeof availableQuantityRaw === 'number' && availableQuantityRaw <= 0);
  const addToCartLabel = hasSufficientStock
    ? 'Add to Cart'
    : typeof availableQuantityRaw === 'number' && availableQuantityRaw <= 0
    ? 'Out of Stock'
    : 'Stock Below Minimum';

  return (
    <Layout activeTab="dashboard">
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialCommunityIcons name="arrow-left" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.topHeaderTitle}>Product Details</Text>
        {currentUser &&
          (currentUser.role === 'farmer' ||
            currentUser.role === 'consumer') && (
            <TouchableOpacity
              style={styles.cartButton}
              onPress={() => navigation.navigate('Cart')}
            >
              <MaterialCommunityIcons name="cart" size={22} color="#4CAF50" />
              {cartItemCount > 0 && (
                <View style={styles.cartBadge}>
                  <Text style={styles.cartBadgeText}>
                    {cartItemCount > 99 ? '99+' : cartItemCount}
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          )}
        {(!currentUser ||
          (currentUser.role !== 'farmer' &&
            currentUser.role !== 'consumer')) && (
          <View style={styles.cartButton}>
            <MaterialCommunityIcons name="account" size={22} color="#757575" />
          </View>
        )}
      </View>

      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        {/* Product Image */}
        <View style={styles.imageCard}>
          <Image
            source={
              product.image_url
                ? { uri: product.image_url }
                : require('../../../assets/placeholder.png')
            }
            style={styles.productImage}
            resizeMode="cover"
          />
        </View>

        {/* Product Info */}
        <View style={styles.productInfoCard}>
          <Text style={styles.productName}>{product.name}</Text>
          <Text style={styles.productCategory}>{product.category}</Text>
          <Text style={styles.productPrice}>৳{product.price.toFixed(2)}</Text>
          <Text style={styles.productUnit}>per {product.unit}</Text>
          {typeof product.delivery_fee === 'number' && (
            <Text style={styles.productDelivery}>
              Delivery Fee: ৳{product.delivery_fee.toFixed(2)}
            </Text>
          )}
          <Text style={styles.purchaseConstraints}>
            Minimum order: {minPurchase}
            {maxPurchaseValue !== null
              ? ` • Max per order: ${maxPurchaseValue}`
              : ''}
          </Text>

          {product.description && (
            <View style={styles.descriptionContainer}>
              <Text style={styles.descriptionTitle}>Description</Text>
              <Text style={styles.productDescription}>
                {product.description}
              </Text>
            </View>
          )}

          <View style={styles.stockContainer}>
            <Text style={styles.stockLabel}>Available Stock:</Text>
            <Text style={styles.stockValue}>
              {availableQuantityRaw !== null ? availableQuantityRaw : 'N/A'}{' '}
              {product.unit}
            </Text>
          </View>
        </View>

        {/* Farmer Info */}
        {farmer ? (
          <View style={styles.farmerCardSection}>
            <Text style={styles.sectionTitle}>Farmer Information</Text>
            <View style={styles.farmerCard}>
              <View style={styles.farmerInfo}>
                <Text style={styles.farmerName}>{farmer.name}</Text>
                <Text style={styles.farmerRole}>
                  {getRoleDisplayName(farmer.role)}
                </Text>
                <Text style={styles.followerCount}>
                  {followerCount} follower{followerCount !== 1 ? 's' : ''}
                </Text>
              </View>

              <View style={styles.farmerActions}>
                {/* Only show follow/chat if not owner and both users loaded */}
                {currentUser &&
                  product &&
                  String(currentUser.id ?? '') !==
                    String(product.farmer_id ?? '') &&
                  (currentUser.role === 'farmer' ||
                    currentUser.role === 'consumer') && (
                    <>
                      <TouchableOpacity
                        style={[
                          styles.actionButton,
                          isFollowing
                            ? styles.unfollowButton
                            : styles.followButton,
                        ]}
                        onPress={handleFollow}
                        activeOpacity={0.8}
                      >
                        <Text style={styles.actionButtonText}>
                          {isFollowing ? 'Unfollow' : 'Follow'}
                        </Text>
                      </TouchableOpacity>

                      <TouchableOpacity
                        style={styles.chatButton}
                        onPress={handleChat}
                        activeOpacity={0.8}
                      >
                        <MaterialCommunityIcons
                          name="message-text"
                          size={16}
                          color="#fff"
                          style={{ marginRight: 6 }}
                        />
                        <Text style={styles.chatButtonText}>Chat</Text>
                      </TouchableOpacity>
                    </>
                  )}

                {/* Always show view all products */}
                <TouchableOpacity
                  style={styles.viewProductsButton}
                  onPress={handleViewFarmerProducts}
                  activeOpacity={0.8}
                >
                  <Text style={styles.viewProductsButtonText}>
                    View All Products
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ) : (
          <View style={styles.farmerCardSection}>
            <Text style={styles.sectionTitle}>Farmer Information</Text>
            <View style={styles.farmerCard}>
              <Text style={styles.errorText}>
                Farmer information is not available for this product.
              </Text>
            </View>
          </View>
        )}

        {/* Add to Cart Button (only for non-owner farmers/consumers) */}
        {currentUser &&
          product &&
          (currentUser.role === 'farmer' || currentUser.role === 'consumer') &&
          String(currentUser.id ?? '') !== String(product.farmer_id ?? '') && (
            <View style={styles.addToCartContainer}>
              <TouchableOpacity
                style={[
                  styles.addToCartButton,
                  addToCartDisabled && styles.addToCartButtonDisabled,
                ]}
                onPress={handleAddToCart}
                disabled={addToCartDisabled}
                activeOpacity={addToCartDisabled ? 1 : 0.8}
              >
                {addingToCart ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text style={styles.addToCartButtonText}>
                    {addToCartLabel}
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          )}

        {/* Access Restriction Message for Non-Farmers/Consumers */}
        {currentUser &&
          currentUser.role !== 'farmer' &&
          currentUser.role !== 'consumer' && (
            <View style={styles.addToCartContainer}>
              <View style={styles.restrictedAccess}>
                <View style={styles.restrictedAccessContent}>
                  <MaterialCommunityIcons
                    name="lock"
                    size={18}
                    color="#666"
                    style={styles.restrictedAccessIcon}
                  />
                  <Text style={styles.restrictedAccessText}>
                    Cart access is restricted to farmers and consumers
                  </Text>
                </View>
              </View>
            </View>
          )}
        <View style={styles.bottomPadding} />
      </ScrollView>

      {/* Modal - Moved outside ScrollView for better positioning */}
      <Modal
        visible={modalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={hideModal}
        statusBarTranslucent={true}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={hideModal}
        >
          <TouchableOpacity
            style={styles.modalContent}
            activeOpacity={1}
            onPress={() => {}} // Prevent modal from closing when touching content
          >
            <Text style={styles.modalMessage}>{modalMessage}</Text>
            <TouchableOpacity
              style={styles.modalButton}
              onPress={hideModal}
              activeOpacity={0.8}
            >
              <Text style={styles.modalButtonText}>OK</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>
    </Layout>
  );
};

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  cartButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
    position: 'relative',
  },
  cartButtonText: {
    fontSize: 22,
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  cartBadge: {
    position: 'absolute',
    top: 2,
    right: 2,
    backgroundColor: '#FF5252',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  cartBadgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 18,
    color: '#999',
    textAlign: 'center',
  },
  topHeader: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  topHeaderContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 20,
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  backIcon: {
    fontSize: 20,
    color: '#4CAF50',
  },
  topHeaderTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1A',
    textAlign: 'center',
    flex: 1,
  },
  imageCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    margin: 16,
    marginBottom: 8,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  productImage: {
    width: '100%',
    height: 300,
    backgroundColor: '#EEEEEE',
  },
  productInfoCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    marginHorizontal: 16,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  productName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  productCategory: {
    fontSize: 16,
    color: '#666',
    marginBottom: 8,
  },
  productPrice: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginBottom: 4,
  },
  productUnit: {
    fontSize: 14,
    color: '#999',
    marginBottom: 16,
  },
  productDelivery: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
    fontStyle: 'italic',
  },
  purchaseConstraints: {
    fontSize: 14,
    color: '#616161',
    marginBottom: 16,
  },
  descriptionContainer: {
    marginBottom: 16,
  },
  descriptionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  productDescription: {
    fontSize: 16,
    color: '#666',
    lineHeight: 24,
  },
  stockContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f0f8ff',
    padding: 12,
    borderRadius: 8,
  },
  stockLabel: {
    fontSize: 16,
    color: '#333',
    marginRight: 8,
  },
  stockValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  farmerCardSection: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  farmerCard: {
    backgroundColor: '#f8f9fa',
    borderRadius: 16,
    padding: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  bottomPadding: {
    height: 32,
  },
  farmerInfo: {
    marginBottom: 16,
  },
  farmerName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  farmerRole: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  followerCount: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: '500',
  },
  farmerActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  actionButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    minWidth: 80,
    alignItems: 'center',
  },
  followButton: {
    backgroundColor: '#4CAF50',
  },
  unfollowButton: {
    backgroundColor: '#FF5722',
  },
  actionButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  chatButton: {
    flexDirection: 'row',
    backgroundColor: '#2196F3',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chatButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  viewProductsButton: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignItems: 'center',
  },
  viewProductsButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  addToCartContainer: {
    backgroundColor: '#fff',
    padding: 16,
    marginTop: 8,
  },
  addToCartButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addToCartButtonDisabled: {
    backgroundColor: '#ccc',
  },
  addToCartButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  restrictedAccess: {
    backgroundColor: '#f5f5f5',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  restrictedAccessContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  restrictedAccessIcon: {
    marginRight: 8,
  },
  restrictedAccessText: {
    color: '#666',
    fontSize: 16,
    textAlign: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 28,
    alignItems: 'center',
    minWidth: 280,
    maxWidth: '90%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 8,
  },
  modalMessage: {
    fontSize: 16,
    color: '#333',
    marginBottom: 20,
    textAlign: 'center',
    lineHeight: 22,
  },
  modalButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 32,
    alignItems: 'center',
    minWidth: 80,
  },
  modalButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ProductDetailsScreen;
