import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Alert,
  Modal,
  ScrollView,
  ToastAndroid,
  Platform,
  Dimensions,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { RootStackParamList } from '../../../types';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import ModernHeader from '../../../components/ModernHeader';
import ModernInput from '../../../components/ModernInput';
import ModernLoading from '../../../components/ModernLoading';
import Layout from '../../../components/Layout';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';

const { width: screenWidth } = Dimensions.get('window');

// Toast notification helper
const showToast = (message: string) => {
  if (Platform.OS === 'android') {
    ToastAndroid.show(message, ToastAndroid.LONG);
  } else {
    Alert.alert('Success', message);
  }
};

// Define deposit modal component with payment methods
const DepositModal = ({
  visible,
  onClose,
  onConfirm,
  amount,
  onChangeAmount,
  transactionId,
  onChangeTransactionId,
  paymentAccounts,
  selectedAccount,
  onSelectAccount,
}: {
  visible: boolean;
  onClose: () => void;
  onConfirm: () => void;
  amount: string;
  onChangeAmount: (text: string) => void;
  transactionId: string;
  onChangeTransactionId: (text: string) => void;
  paymentAccounts: any[];
  selectedAccount: any;
  onSelectAccount: (account: any) => void;
}) => (
  <Modal
    visible={visible}
    transparent
    animationType="slide"
    onRequestClose={onClose}
  >
    <View style={styles.modalContainer}>
      <ScrollView
        style={styles.modalScrollView}
        contentContainerStyle={styles.modalScrollContent}
      >
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Deposit Funds</Text>

          <Text style={styles.modalSectionTitle}>
            <MaterialCommunityIcons
              name="credit-card-outline"
              size={18}
              color={COLORS.text}
            />{' '}
            Select Payment Method
          </Text>
          <ScrollView
            style={styles.paymentMethodsScroll}
            showsVerticalScrollIndicator={false}
          >
            {paymentAccounts.length === 0 ? (
              <View style={styles.emptyPaymentAccounts}>
                <MaterialCommunityIcons
                  name="credit-card-off-outline"
                  size={48}
                  color={COLORS.subtext}
                />
                <Text style={styles.emptyPaymentText}>
                  No payment methods available
                </Text>
              </View>
            ) : (
              paymentAccounts.map(account => {
                const accountIcon =
                  account.account_type === 'mobile_banking'
                    ? 'cellphone'
                    : account.account_type === 'bank'
                    ? 'bank'
                    : 'account-cash';

                return (
                  <TouchableOpacity
                    key={account.id}
                    style={[
                      styles.paymentMethodCard,
                      selectedAccount?.id === account.id &&
                        styles.paymentMethodCardSelected,
                    ]}
                    onPress={() => onSelectAccount(account)}
                  >
                    <View style={styles.paymentMethodRow}>
                      <View style={styles.paymentMethodIconContainer}>
                        <MaterialCommunityIcons
                          name={accountIcon}
                          size={28}
                          color={
                            selectedAccount?.id === account.id
                              ? COLORS.accent
                              : COLORS.subtext
                          }
                        />
                      </View>
                      <View style={styles.paymentMethodDetails}>
                        <View style={styles.paymentMethodHeader}>
                          <Text style={styles.paymentMethodType}>
                            {account.account_type === 'mobile_banking'
                              ? 'Mobile Banking'
                              : account.account_type === 'bank'
                              ? 'Bank Account'
                              : 'Agent'}
                          </Text>
                          {account.provider && (
                            <Text style={styles.paymentMethodProvider}>
                              {account.provider}
                            </Text>
                          )}
                        </View>
                        <Text style={styles.paymentMethodAccount}>
                          {account.account_number}
                        </Text>
                        {account.account_name && (
                          <Text style={styles.paymentMethodName}>
                            {account.account_name}
                          </Text>
                        )}
                      </View>
                      {selectedAccount?.id === account.id && (
                        <MaterialCommunityIcons
                          name="check-circle"
                          size={24}
                          color={COLORS.accent}
                        />
                      )}
                    </View>
                  </TouchableOpacity>
                );
              })
            )}
          </ScrollView>

          {selectedAccount && (
            <>
              <ModernInput
                placeholder="Enter amount"
                value={amount}
                onChangeText={onChangeAmount}
                keyboardType="numeric"
                style={styles.modalInput}
              />
              <ModernInput
                placeholder="Enter transaction ID"
                value={transactionId}
                onChangeText={onChangeTransactionId}
                style={styles.modalInput}
              />
            </>
          )}

          <View style={styles.modalButtons}>
            <TouchableOpacity
              style={[styles.modalButton, styles.cancelButton]}
              onPress={onClose}
            >
              <Text style={styles.buttonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.modalButton,
                styles.confirmButton,
                !selectedAccount && styles.buttonDisabled,
              ]}
              onPress={onConfirm}
              disabled={!selectedAccount}
            >
              <Text style={styles.buttonText}>Deposit</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  </Modal>
);

// Modern, light-themed color palette
const COLORS = {
  background: '#F6F8FB', // very light blue-gray
  card: '#FFFFFF',
  accent: '#5C9EFF', // modern blue
  accent2: '#7ED957', // soft green
  accent3: '#FFD36E', // pastel yellow
  accent4: '#FFB6B6', // soft red
  border: '#E3EAF2', // lighter border
  text: '#23272F', // dark blue-gray
  subtext: '#8A94A6', // soft gray
  stat: '#5C9EFF', // use accent blue for stat
  shadow: '#B0C4DE', // soft blue shadow
  error: '#FF6B6B',
  success: '#7ED957',
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollViewContent: {
    paddingBottom: 100,
  },
  balanceContainer: {
    backgroundColor: COLORS.card,
    borderRadius: 20,
    marginHorizontal: 20,
    marginTop: 20,
    marginBottom: 20,
    paddingVertical: 32,
    paddingHorizontal: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  balanceIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#E8F4FD',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  balanceLabel: {
    fontSize: 16,
    color: COLORS.subtext,
    marginBottom: 8,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  balanceAmount: {
    fontSize: 42,
    fontWeight: 'bold',
    color: COLORS.stat,
    marginBottom: 24,
    letterSpacing: 0.5,
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    gap: 16,
    marginTop: 8,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    elevation: 2,
    maxWidth: (screenWidth - 88) / 2,
    minWidth: (screenWidth - 88) / 2,
    backgroundColor: COLORS.accent,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
  },
  depositButton: {
    backgroundColor: '#19b105ff',
  },
  withdrawButton: {
    backgroundColor: '#F44336',
  },
  actionButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 17,
    letterSpacing: 0.5,
  },
  transactionsContainer: {
    backgroundColor: COLORS.card,
    borderRadius: 20,
    marginHorizontal: 20,
    marginTop: 0,
    marginBottom: 24,
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  transactionsListContainer: {
    paddingBottom: 8,
  },
  transactionsTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
  },
  transactionsTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.text,
    letterSpacing: 0.2,
  },
  transactionsList: {
    paddingBottom: 16,
    paddingHorizontal: 0,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    paddingVertical: 16,
    alignItems: 'center',
    gap: 12,
  },
  transactionIconCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: COLORS.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  transactionInfo: {
    flex: 1,
    minWidth: 0,
  },
  transactionDescription: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    flexShrink: 1,
    letterSpacing: 0.1,
  },
  transactionDate: {
    fontSize: 12,
    color: COLORS.subtext,
    marginTop: 4,
    letterSpacing: 0.1,
  },
  transactionAmountContainer: {
    alignItems: 'flex-end',
    minWidth: 90,
  },
  transactionAmount: {
    fontSize: 17,
    fontWeight: 'bold',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  transactionTypeBadge: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 8,
    marginTop: 2,
    minWidth: 70,
    alignItems: 'center',
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 2,
    elevation: 1,
  },
  transactionTypeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
    letterSpacing: 0.3,
  },
  emptyTransactions: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 48,
    paddingHorizontal: 20,
  },
  emptyTransactionsText: {
    color: COLORS.text,
    fontSize: 16,
    fontWeight: '600',
    marginTop: 16,
    letterSpacing: 0.2,
  },
  emptyTransactionsSubtext: {
    color: COLORS.subtext,
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
    letterSpacing: 0.1,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(246, 248, 251, 0.92)',
  },
  modalContent: {
    backgroundColor: COLORS.card,
    borderRadius: 22,
    padding: 32,
    width: '92%',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 16,
    elevation: 3,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 22,
    color: COLORS.text,
    letterSpacing: 0.2,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginTop: 22,
    gap: 16,
  },
  modalButton: {
    paddingVertical: 15,
    paddingHorizontal: 22,
    borderRadius: 16,
    flex: 1,
    marginHorizontal: 4,
    alignItems: 'center',
    elevation: 2,
    backgroundColor: COLORS.accent,
    shadowColor: COLORS.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
  },
  cancelButton: {
    backgroundColor: COLORS.subtext,
  },
  confirmButton: {
    backgroundColor: COLORS.accent2,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 17,
  },
  modalInput: {
    width: '100%',
    marginBottom: 14,
  },
  inputText: {
    fontSize: 18,
    minHeight: 45,
  },
  modalScrollView: {
    maxHeight: '90%',
    width: '100%',
  },
  modalScrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
  },
  modalSectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginTop: 16,
    marginBottom: 12,
    alignSelf: 'flex-start',
    width: '100%',
  },
  paymentMethodsScroll: {
    maxHeight: 250,
    width: '100%',
    marginBottom: 12,
  },
  paymentMethodCard: {
    backgroundColor: COLORS.background,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: COLORS.border,
  },
  paymentMethodCardSelected: {
    borderColor: COLORS.accent,
    backgroundColor: '#E8F4FD',
  },
  paymentMethodHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  paymentMethodType: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  paymentMethodProvider: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.accent,
  },
  paymentMethodAccount: {
    fontSize: 14,
    color: COLORS.subtext,
    marginTop: 4,
  },
  paymentMethodName: {
    fontSize: 13,
    color: COLORS.subtext,
    marginTop: 2,
  },
  withdrawMethodCard: {
    backgroundColor: COLORS.background,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: COLORS.border,
  },
  withdrawMethodCardSelected: {
    borderColor: COLORS.accent,
    backgroundColor: '#E8F4FD',
  },
  withdrawMethodTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.text,
    marginBottom: 4,
  },
  withdrawMethodDesc: {
    fontSize: 13,
    color: COLORS.subtext,
  },
  providerButtonsRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
    width: '100%',
  },
  providerButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 10,
    backgroundColor: COLORS.background,
    borderWidth: 2,
    borderColor: COLORS.border,
    alignItems: 'center',
  },
  providerButtonSelected: {
    backgroundColor: COLORS.accent,
    borderColor: COLORS.accent,
  },
  providerButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
  },
  providerButtonTextSelected: {
    color: '#FFFFFF',
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  emptyPaymentAccounts: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  emptyPaymentText: {
    color: COLORS.subtext,
    fontSize: 15,
    marginTop: 12,
    textAlign: 'center',
  },
  paymentMethodRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  paymentMethodIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.card,
    justifyContent: 'center',
    alignItems: 'center',
  },
  paymentMethodDetails: {
    flex: 1,
  },
  withdrawMethodRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  withdrawMethodIconContainer: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: COLORS.card,
    justifyContent: 'center',
    alignItems: 'center',
  },
  withdrawMethodContent: {
    flex: 1,
  },
});

// Define WithdrawModal component with withdrawal methods
const WithdrawModal = ({
  visible,
  onClose,
  onConfirm,
  amount,
  onChangeAmount,
  withdrawMethod,
  onSelectMethod,
  mobileProvider,
  onSelectMobileProvider,
  accountNumber,
  onChangeAccountNumber,
  agentNumber,
  onChangeAgentNumber,
}: {
  visible: boolean;
  onClose: () => void;
  onConfirm: () => void;
  amount: string;
  onChangeAmount: (text: string) => void;
  withdrawMethod: 'mobile_banking' | 'bank' | 'agent' | null;
  onSelectMethod: (method: 'mobile_banking' | 'bank' | 'agent') => void;
  mobileProvider: string;
  onSelectMobileProvider: (provider: string) => void;
  accountNumber: string;
  onChangeAccountNumber: (text: string) => void;
  agentNumber: string;
  onChangeAgentNumber: (text: string) => void;
}) => (
  <Modal
    visible={visible}
    transparent
    animationType="slide"
    onRequestClose={onClose}
  >
    <View style={styles.modalContainer}>
      <ScrollView
        style={styles.modalScrollView}
        contentContainerStyle={styles.modalScrollContent}
      >
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>Withdraw Funds</Text>

          <Text style={styles.modalSectionTitle}>
            <MaterialCommunityIcons
              name="cash-multiple"
              size={18}
              color={COLORS.text}
            />{' '}
            Select Withdrawal Method
          </Text>

          <TouchableOpacity
            style={[
              styles.withdrawMethodCard,
              withdrawMethod === 'mobile_banking' &&
                styles.withdrawMethodCardSelected,
            ]}
            onPress={() => onSelectMethod('mobile_banking')}
          >
            <View style={styles.withdrawMethodRow}>
              <View style={styles.withdrawMethodIconContainer}>
                <MaterialCommunityIcons
                  name="cellphone"
                  size={32}
                  color={
                    withdrawMethod === 'mobile_banking'
                      ? COLORS.accent
                      : COLORS.subtext
                  }
                />
              </View>
              <View style={styles.withdrawMethodContent}>
                <Text style={styles.withdrawMethodTitle}>Mobile Banking</Text>
                <Text style={styles.withdrawMethodDesc}>
                  Withdraw to bKash, Rocket, or Nagad
                </Text>
              </View>
              {withdrawMethod === 'mobile_banking' && (
                <MaterialCommunityIcons
                  name="check-circle"
                  size={24}
                  color={COLORS.accent}
                />
              )}
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.withdrawMethodCard,
              withdrawMethod === 'bank' && styles.withdrawMethodCardSelected,
            ]}
            onPress={() => onSelectMethod('bank')}
          >
            <View style={styles.withdrawMethodRow}>
              <View style={styles.withdrawMethodIconContainer}>
                <MaterialCommunityIcons
                  name="bank"
                  size={32}
                  color={
                    withdrawMethod === 'bank' ? COLORS.accent : COLORS.subtext
                  }
                />
              </View>
              <View style={styles.withdrawMethodContent}>
                <Text style={styles.withdrawMethodTitle}>Bank Transfer</Text>
                <Text style={styles.withdrawMethodDesc}>
                  Withdraw to your bank account
                </Text>
              </View>
              {withdrawMethod === 'bank' && (
                <MaterialCommunityIcons
                  name="check-circle"
                  size={24}
                  color={COLORS.accent}
                />
              )}
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.withdrawMethodCard,
              withdrawMethod === 'agent' && styles.withdrawMethodCardSelected,
            ]}
            onPress={() => onSelectMethod('agent')}
          >
            <View style={styles.withdrawMethodRow}>
              <View style={styles.withdrawMethodIconContainer}>
                <MaterialCommunityIcons
                  name="account-cash"
                  size={32}
                  color={
                    withdrawMethod === 'agent' ? COLORS.accent : COLORS.subtext
                  }
                />
              </View>
              <View style={styles.withdrawMethodContent}>
                <Text style={styles.withdrawMethodTitle}>
                  Collect from Agent
                </Text>
                <Text style={styles.withdrawMethodDesc}>
                  Withdraw cash from an agent
                </Text>
              </View>
              {withdrawMethod === 'agent' && (
                <MaterialCommunityIcons
                  name="check-circle"
                  size={24}
                  color={COLORS.accent}
                />
              )}
            </View>
          </TouchableOpacity>

          {withdrawMethod === 'mobile_banking' && (
            <>
              <Text style={styles.modalSectionTitle}>Select Provider</Text>
              <View style={styles.providerButtonsRow}>
                {['bKash', 'Rocket', 'Nagad'].map(provider => (
                  <TouchableOpacity
                    key={provider}
                    style={[
                      styles.providerButton,
                      mobileProvider === provider &&
                        styles.providerButtonSelected,
                    ]}
                    onPress={() => onSelectMobileProvider(provider)}
                  >
                    <Text
                      style={[
                        styles.providerButtonText,
                        mobileProvider === provider &&
                          styles.providerButtonTextSelected,
                      ]}
                    >
                      {provider}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
              <ModernInput
                placeholder="Enter mobile number"
                value={accountNumber}
                onChangeText={onChangeAccountNumber}
                keyboardType="phone-pad"
                style={styles.modalInput}
              />
            </>
          )}

          {withdrawMethod === 'bank' && (
            <>
              <ModernInput
                placeholder="Enter bank account number"
                value={accountNumber}
                onChangeText={onChangeAccountNumber}
                keyboardType="numeric"
                style={styles.modalInput}
              />
            </>
          )}

          {withdrawMethod === 'agent' && (
            <>
              <ModernInput
                placeholder="Enter agent number"
                value={agentNumber}
                onChangeText={onChangeAgentNumber}
                keyboardType="phone-pad"
                style={styles.modalInput}
              />
            </>
          )}

          {withdrawMethod && (
            <ModernInput
              placeholder="Enter amount to withdraw"
              value={amount}
              onChangeText={onChangeAmount}
              keyboardType="numeric"
              style={styles.modalInput}
            />
          )}

          <View style={styles.modalButtons}>
            <TouchableOpacity
              style={[styles.modalButton, styles.cancelButton]}
              onPress={onClose}
            >
              <Text style={styles.buttonText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.modalButton,
                styles.withdrawButton,
                !withdrawMethod && styles.buttonDisabled,
              ]}
              onPress={onConfirm}
              disabled={!withdrawMethod}
            >
              <Text style={styles.buttonText}>Withdraw</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  </Modal>
);

// Main WalletScreen component

const WalletScreen: React.FC = () => {
  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
  const dbManager = SupabaseDatabaseManager.getInstance();
  const authManager = SupabaseAuthManager.getInstance();

  // State variables
  const [user, setUser] = useState<any>(null);
  const [balance, setBalance] = useState<number>(0);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Deposit modal state
  const [isDepositModalVisible, setIsDepositModalVisible] = useState(false);
  const [depositAmount, setDepositAmount] = useState('');
  const [depositTransactionId, setDepositTransactionId] = useState('');
  const [paymentAccounts, setPaymentAccounts] = useState<any[]>([]);
  const [selectedPaymentAccount, setSelectedPaymentAccount] =
    useState<any>(null);

  // Withdraw modal state
  const [isWithdrawModalVisible, setIsWithdrawModalVisible] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawMethod, setWithdrawMethod] = useState<
    'mobile_banking' | 'bank' | 'agent' | null
  >(null);
  const [mobileProvider, setMobileProvider] = useState<string>('');
  const [withdrawAccountNumber, setWithdrawAccountNumber] = useState('');
  const [agentNumber, setAgentNumber] = useState('');

  // Fetch user on mount
  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await authManager.getCurrentUser();
      setUser(currentUser);
      if (currentUser?.id) {
        fetchWalletData(String(currentUser.id));
        fetchPaymentAccounts();
      } else {
        setLoading(false);
      }
    };
    fetchUser();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Fetch payment accounts for deposit
  const fetchPaymentAccounts = async () => {
    try {
      const accounts = await dbManager.getSystemPaymentAccounts(false);
      setPaymentAccounts(accounts || []);
    } catch (error) {
      console.error('Error fetching payment accounts:', error);
    }
  };

  // Fetch wallet data
  const fetchWalletData = useCallback(
    async (userId: string) => {
      setLoading(true);
      try {
        // userId is a UUID string, use as-is for both balance and transactions
        const userBalance = await dbManager.getUserWalletBalance(userId);
        setBalance(userBalance ?? 0);

        const txns = await dbManager.getUserWalletTransactions(userId);
        setTransactions(txns ?? []);
      } catch (error) {
        console.error('Error fetching wallet data:', error);
        Alert.alert('Error', 'Failed to fetch wallet data.');
      } finally {
        setLoading(false);
      }
    },
    [dbManager],
  );

  // Deposit handler
  const handleDeposit = async () => {
    if (!user?.id) return;

    if (!selectedPaymentAccount) {
      Alert.alert('Error', 'Please select a payment method.');
      return;
    }

    const amount = parseFloat(depositAmount);
    if (isNaN(amount) || amount <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid deposit amount.');
      return;
    }

    if (!depositTransactionId.trim()) {
      Alert.alert('Error', 'Please enter transaction ID.');
      return;
    }

    setLoading(true);
    try {
      await dbManager.updateUserWalletBalance(user.id, amount, 'add');
      const accountInfo = `${selectedPaymentAccount.method} - ${selectedPaymentAccount.account_number}`;
      await dbManager.createWalletTransaction({
        user_id: String(user.id),
        amount,
        transaction_type: 'deposit',
        description: `Deposit via ${accountInfo} (TxID: ${depositTransactionId})`,
      });

      showToast(`Successfully deposited ৳${amount.toFixed(2)}`);
      setDepositAmount('');
      setDepositTransactionId('');
      setSelectedPaymentAccount(null);
      setIsDepositModalVisible(false);
      fetchWalletData(user.id);
    } catch (error) {
      console.error('Error making deposit:', error);
      Alert.alert('Error', 'An error occurred while processing your deposit.');
    } finally {
      setLoading(false);
    }
  };

  // Withdraw handler
  const handleWithdraw = async () => {
    if (!user?.id) return;

    if (!withdrawMethod) {
      Alert.alert('Error', 'Please select a withdrawal method.');
      return;
    }

    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      Alert.alert('Invalid Amount', 'Please enter a valid withdrawal amount.');
      return;
    }

    if (amount > balance) {
      Alert.alert(
        'Insufficient Funds',
        'You do not have enough balance to withdraw this amount.',
      );
      return;
    }

    // Validate required fields based on method
    if (withdrawMethod === 'mobile_banking') {
      if (!mobileProvider) {
        Alert.alert('Error', 'Please select a mobile banking provider.');
        return;
      }
      if (!withdrawAccountNumber.trim()) {
        Alert.alert('Error', 'Please enter your mobile number.');
        return;
      }
    } else if (withdrawMethod === 'bank') {
      if (!withdrawAccountNumber.trim()) {
        Alert.alert('Error', 'Please enter your bank account number.');
        return;
      }
    } else if (withdrawMethod === 'agent') {
      if (!agentNumber.trim()) {
        Alert.alert('Error', 'Please enter the agent number.');
        return;
      }
    }

    setLoading(true);
    try {
      await dbManager.updateUserWalletBalance(user.id, amount, 'subtract');

      let description = '';
      if (withdrawMethod === 'mobile_banking') {
        description = `Withdrawal to ${mobileProvider} (${withdrawAccountNumber})`;
      } else if (withdrawMethod === 'bank') {
        description = `Withdrawal to Bank Account (${withdrawAccountNumber})`;
      } else if (withdrawMethod === 'agent') {
        description = `Withdrawal via Agent (${agentNumber})`;
      }

      await dbManager.createWalletTransaction({
        user_id: String(user.id),
        amount,
        transaction_type: 'withdrawal',
        description,
      });

      showToast(`Successfully withdrew ৳${amount.toFixed(2)}`);
      setWithdrawAmount('');
      setWithdrawMethod(null);
      setMobileProvider('');
      setWithdrawAccountNumber('');
      setAgentNumber('');
      setIsWithdrawModalVisible(false);
      fetchWalletData(user.id);
    } catch (error) {
      console.error('Error making withdrawal:', error);
      Alert.alert(
        'Error',
        'An error occurred while processing your withdrawal.',
      );
    } finally {
      setLoading(false);
    }
  };

  // Transaction color
  const getTransactionStatusColor = (type: string) => {
    switch (type) {
      case 'deposit':
        return '#4CAF50'; // Green
      case 'withdrawal':
        return '#F44336'; // Red
      case 'payment':
        return '#FF9800'; // Orange
      case 'payment_received':
        return '#8BC34A'; // Light Green
      case 'refund':
        return '#2196F3'; // Blue
      default:
        return '#757575'; // Grey
    }
  };

  // Get transaction icon
  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'deposit':
        return 'plus-circle';
      case 'withdrawal':
        return 'minus-circle';
      case 'payment':
        return 'arrow-up-circle';
      case 'payment_received':
        return 'arrow-down-circle';
      case 'refund':
        return 'cash-refund';
      default:
        return 'cash';
    }
  };

  // Render transaction item
  const renderTransactionItem = ({ item }: { item: any }) => {
    const isPositive = ['deposit', 'refund', 'payment_received'].includes(
      item.transaction_type,
    );
    const iconColor = getTransactionStatusColor(item.transaction_type);
    const icon = getTransactionIcon(item.transaction_type);

    return (
      <View style={styles.transactionItem}>
        <View style={styles.transactionIconCircle}>
          <MaterialCommunityIcons name={icon} size={24} color={iconColor} />
        </View>
        <View style={styles.transactionInfo}>
          <Text style={styles.transactionDescription}>{item.description}</Text>
          <Text style={styles.transactionDate}>
            {new Date(item.created_at).toLocaleDateString()}{' '}
            {new Date(item.created_at).toLocaleTimeString()}
          </Text>
        </View>
        <View style={styles.transactionAmountContainer}>
          <Text style={[styles.transactionAmount, { color: iconColor }]}>
            {isPositive ? '+' : '-'}৳{Math.abs(item.amount).toFixed(2)}
          </Text>
          <View
            style={[
              styles.transactionTypeBadge,
              {
                backgroundColor: iconColor,
              },
            ]}
          >
            <Text style={styles.transactionTypeText}>
              {item.transaction_type === 'payment_received'
                ? 'Received'
                : item.transaction_type.charAt(0).toUpperCase() +
                  item.transaction_type.slice(1)}
            </Text>
          </View>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} />
      </Layout>
    );
  }

  return (
    <Layout activeTab="dashboard">
      <ModernHeader
        title="My Wallet"
        leftIconName="arrow-left"
        iconSize={24}
        onLeftPress={() => navigation.goBack()}
        rightAvatarUrl={user?.profile_image_url}
        rightAvatarName={user?.name}
        onRightPress={() =>
          user
            ? navigation.navigate('UserProfile', { userId: String(user.id) })
            : navigation.navigate('SignIn')
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollViewContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.balanceContainer}>
          <View style={styles.balanceIconContainer}>
            <MaterialCommunityIcons
              name="wallet"
              size={48}
              color={COLORS.stat}
            />
          </View>
          <Text style={styles.balanceLabel}>Current Balance</Text>
          <Text style={styles.balanceAmount}>৳{balance.toFixed(2)}</Text>

          <View style={styles.actionButtonsContainer}>
            <TouchableOpacity
              style={[styles.actionButton, styles.depositButton]}
              onPress={() => setIsDepositModalVisible(true)}
              activeOpacity={0.8}
            >
              <MaterialCommunityIcons
                name="plus-circle"
                size={20}
                color="#FFFFFF"
              />
              <Text style={styles.actionButtonText}>Deposit</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.actionButton, styles.withdrawButton]}
              onPress={() => setIsWithdrawModalVisible(true)}
              activeOpacity={0.8}
            >
              <MaterialCommunityIcons
                name="minus-circle"
                size={20}
                color="#FFFFFF"
              />
              <Text style={styles.actionButtonText}>Withdraw</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.transactionsContainer}>
          <View style={styles.transactionsTitleRow}>
            <MaterialCommunityIcons
              name="history"
              size={22}
              color={COLORS.text}
            />
            <Text style={styles.transactionsTitle}>Transaction History</Text>
          </View>

          {transactions.length === 0 ? (
            <View style={styles.emptyTransactions}>
              <MaterialCommunityIcons
                name="receipt-text-outline"
                size={64}
                color={COLORS.border}
              />
              <Text style={styles.emptyTransactionsText}>
                No transactions yet
              </Text>
              <Text style={styles.emptyTransactionsSubtext}>
                Your transaction history will appear here
              </Text>
            </View>
          ) : (
            <View style={styles.transactionsListContainer}>
              {transactions.map(item => (
                <View key={item.id}>{renderTransactionItem({ item })}</View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      <DepositModal
        visible={isDepositModalVisible}
        onClose={() => {
          setIsDepositModalVisible(false);
          setDepositAmount('');
          setDepositTransactionId('');
          setSelectedPaymentAccount(null);
        }}
        onConfirm={handleDeposit}
        amount={depositAmount}
        onChangeAmount={setDepositAmount}
        transactionId={depositTransactionId}
        onChangeTransactionId={setDepositTransactionId}
        paymentAccounts={paymentAccounts}
        selectedAccount={selectedPaymentAccount}
        onSelectAccount={setSelectedPaymentAccount}
      />

      <WithdrawModal
        visible={isWithdrawModalVisible}
        onClose={() => {
          setIsWithdrawModalVisible(false);
          setWithdrawAmount('');
          setWithdrawMethod(null);
          setMobileProvider('');
          setWithdrawAccountNumber('');
          setAgentNumber('');
        }}
        onConfirm={handleWithdraw}
        amount={withdrawAmount}
        onChangeAmount={setWithdrawAmount}
        withdrawMethod={withdrawMethod}
        onSelectMethod={setWithdrawMethod}
        mobileProvider={mobileProvider}
        onSelectMobileProvider={setMobileProvider}
        accountNumber={withdrawAccountNumber}
        onChangeAccountNumber={setWithdrawAccountNumber}
        agentNumber={agentNumber}
        onChangeAgentNumber={setAgentNumber}
      />
    </Layout>
  );
};

export default WalletScreen;
