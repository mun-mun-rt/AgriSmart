import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
  Dimensions,
} from 'react-native';
import { Image } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../../types';
import ModernLoading from '../../../components/ModernLoading';
import ModernButton from '../../../components/ModernButton';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import { buildRoomId } from '../../../utils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type LandLeaseDetailsScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'LandLeaseDetails'
>;

interface RouteParams {
  leaseId: string;
  fromMyLeases?: boolean;
  applicationId?: string;
}

const LandLeaseDetailsScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<LandLeaseDetailsScreenNavigationProp>();
  const route = useRoute();
  const { leaseId, fromMyLeases } = route.params as RouteParams;
  const { applicationId } = route.params as RouteParams;

  const [lease, setLease] = useState<any>(null);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [ownerUser, setOwnerUser] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showApplyModal, setShowApplyModal] = useState(false);
  const [offeredPrice, setOfferedPrice] = useState('');
  const [message, setMessage] = useState('');
  const [userApplication, setUserApplication] = useState<any>(null);
  const [snapshotLease, setSnapshotLease] = useState<any>(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const db = dbManager;

  const windowWidth = Dimensions.get('window').width;

  const getImageList = (data: any) => {
    if (!data) return [] as string[];
    // Primary image (single image) should come first
    const primary: string | undefined =
      (typeof data.image_url === 'string' && data.image_url) ||
      (typeof data.lease_image_url === 'string' && data.lease_image_url) ||
      undefined;

    // Collect additional images from multiple_image_url(s)
    let extras: string[] = [];
    if (
      Array.isArray(data.multiple_image_url) &&
      data.multiple_image_url.length > 0
    ) {
      extras = data.multiple_image_url.filter(
        (u: any) => !!u && typeof u === 'string',
      );
    } else if (
      Array.isArray(data.multiple_image_urls) &&
      data.multiple_image_urls.length > 0
    ) {
      extras = data.multiple_image_urls.filter(
        (u: any) => !!u && typeof u === 'string',
      );
    }

    // Build final list: primary first (if present), then extras without duplicating the primary
    const list: string[] = [];
    if (primary) list.push(primary);
    extras.forEach(u => {
      if (!u) return;
      if (primary && u === primary) return;
      if (!list.includes(u)) list.push(u);
    });
    return list;
  };

  useEffect(() => {
    loadLeaseDetails();
  }, [leaseId]); // eslint-disable-line react-hooks/exhaustive-deps

  const loadLeaseDetails = async () => {
    try {
      setIsLoading(true);

      // Get current user
      const user = await authManager.getCurrentUser();
      setCurrentUser(user);

      // Priority 1: If applicationId is provided, ALWAYS show application snapshot view
      if (applicationId) {
        try {
          const app = await db.getLeaseApplicationById(Number(applicationId));
          if (app) {
            console.log('[DEBUG] loaded application snapshot by id:', app);
            setSnapshotLease(app);
            // Also set user application if current user has one
            if (user && user.id) {
              setUserApplication(app);
            }
            return; // Exit early to show snapshot view
          }
        } catch (e) {
          console.error('Error fetching specific application snapshot:', e);
        }
      }

      // Get lease details
      const leaseDetails = await db.getLandLeaseById(Number(leaseId));
      setLease(leaseDetails);

      if (leaseDetails) {
        // CASE 1: Lease exists - normal flow
        // Fetch owner user for display
        if (leaseDetails.owner_id) {
          try {
            const owner = await db.getUserById(String(leaseDetails.owner_id));
            setOwnerUser(owner || null);
          } catch (e) {
            // ignore owner fetch errors
          }
        }

        // Set default offered price to the lease price (defensive)
        try {
          setOfferedPrice(
            leaseDetails.price != null && leaseDetails.price !== undefined
              ? String(leaseDetails.price)
              : '',
          );
        } catch (e) {
          setOfferedPrice('');
        }

        // Fetch user applications for existing lease
        if (user && user.id) {
          try {
            let applications = [] as any[];
            if (String(user.id) === String(leaseDetails.owner_id)) {
              // Owner: fetch all applications for this lease by owner id
              applications = await db.getLeaseApplications(
                Number(leaseId),
                undefined,
                String(user.id),
              );
            } else {
              // Applicant: fetch only their application for this lease
              applications = await db.getLeaseApplications(
                Number(leaseId),
                String(user.id),
              );
            }
            if (applications.length > 0) setUserApplication(applications[0]);
            else setUserApplication(null);
          } catch (e) {
            // ignore application fetch errors
          }
        }
      } else {
        // CASE 2: Lease NOT found - check for snapshot in applications
        try {
          // Prepare to fetch either a specific application (by applicationId) or all applications for this lease
          let appSnapshot: any = null;
          let appsList: any[] = [];
          if (applicationId) {
            const app = await db.getLeaseApplicationById(Number(applicationId));
            if (app) {
              console.log('[DEBUG] loaded application snapshot by id:', app);
              appSnapshot = app;
              appsList = [app];
            }
          } else {
            const allApplications = await db.getLeaseApplications(
              Number(leaseId),
            );
            if (allApplications && allApplications.length > 0) {
              console.log(
                '[DEBUG] lease applications for deleted lease:',
                allApplications[0],
              );
              appSnapshot = allApplications[0];
              appsList = allApplications;
            }
          }

          setSnapshotLease(appSnapshot || null);

          // Also set user application if current user has one
          if (user && user.id) {
            const userApp = appsList.find(
              (a: any) => String(a.applicant_id) === String(user.id),
            );
            setUserApplication(userApp || null);
          }
        } catch (e) {
          console.error('Error fetching application snapshots:', e);
          setSnapshotLease(null);
          setUserApplication(null);
        }
      }
    } catch (error) {
      console.error('Error loading lease details:', error);
      Alert.alert('Error', 'Failed to load lease details');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = async () => {
    if (!currentUser) {
      Alert.alert('Login Required', 'Please login to apply for leases', [
        { text: 'Cancel' },
        { text: 'Login', onPress: () => navigation.navigate('SignIn') },
      ]);
      return;
    }

    // Check user role restrictions
    if (currentUser.role === 'admin' || currentUser.role === 'guest') {
      Alert.alert(
        'Access Restricted',
        'Only farmers and consumers can apply for land leases.',
        [{ text: 'OK' }],
      );
      return;
    }

    // Only allow if not the owner
    if (
      lease &&
      currentUser.id &&
      lease.owner_id &&
      String(currentUser.id) === String(lease.owner_id)
    ) {
      Alert.alert('Not Allowed', 'You cannot apply for your own land lease.', [
        { text: 'OK' },
      ]);
      return;
    }

    if (
      !offeredPrice ||
      isNaN(Number(offeredPrice)) ||
      Number(offeredPrice) <= 0
    ) {
      Alert.alert('Invalid Price', 'Please enter a valid offered price');
      return;
    }

    try {
      setIsLoading(true);
      // Ensure database is initialized
      await db.initializeDatabase();

      // Fetch lease to get owner_id
      const leaseDetails =
        lease || (await db.getLandLeaseById(Number(leaseId)));
      if (!leaseDetails) throw new Error('Lease not found');

      // Double check status is available
      if (leaseDetails.status !== 'available') {
        Alert.alert(
          'Not Allowed',
          'This land lease is not available for application.',
          [{ text: 'OK' }],
        );
        return;
      }

      await db.createLeaseApplication(
        Number(leaseId),
        currentUser.id,
        Number(offeredPrice),
        message,
      );

      Alert.alert(
        'Application Submitted',
        `Your lease application has been submitted with an offer of ৳${Number(
          offeredPrice,
        ).toLocaleString()}/month. The owner will review your application.`,
        [
          {
            text: 'OK',
            onPress: () => {
              setShowApplyModal(false);
              loadLeaseDetails();
            },
          },
        ],
      );
    } catch (error: any) {
      console.error('Error applying for lease:', error);
      let errorMessage = 'Failed to submit application';
      if (error && error.message) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      } else if (error) {
        errorMessage = JSON.stringify(error);
      }
      setTimeout(() => {
        Alert.alert('Error', errorMessage);
      }, 100);
    } finally {
      setIsLoading(false);
    }
  };

  const canApply = () => {
    if (!currentUser) return false;
    if (currentUser.role === 'admin' || currentUser.role === 'guest')
      return false;
    if (!lease || lease.status !== 'available') return false;
    if (userApplication && userApplication.status === 'pending') return false;
    // Only allow if current user is not the owner
    if (
      lease &&
      currentUser.id &&
      lease.owner_id &&
      String(currentUser.id) === String(lease.owner_id)
    )
      return false;
    return true;
  };

  const getApplicationStatusMessage = () => {
    if (!userApplication) return null;

    switch (userApplication.status) {
      case 'pending':
        return `Your application is pending review. Offered: ৳${userApplication.offered_price?.toLocaleString()}/month`;
      case 'approved':
        return `Your application has been approved! Contract price: ৳${userApplication.offered_price?.toLocaleString()}/month`;
      case 'rejected':
        return 'Your previous application was rejected. You can apply again with a different offer.';
      default:
        return null;
    }
  };

  // Defensive status label to avoid calling charAt on undefined
  const getStatusLabel = (status?: string) => {
    if (!status) return 'Unknown';
    if (status === 'available') return 'Available';
    if (status === 'booked') return 'Booked';
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  if (isLoading) {
    return (
      <Layout
        activeTab="dashboard"
        backgroundColor="#FFF8E1"
        barStyle="dark-content"
      >
        <ModernLoading visible={true} message="Loading lease details..." />
      </Layout>
    );
  }

  if (!lease) {
    // If there's an application snapshot available for this lease, render that instead
    if (snapshotLease) {
      // Use the same approach as My Applications tab - prefer actual snapshot data
      const s = snapshotLease;

      // Use the actual snapshot fields directly (they should contain real data, not fallbacks)
      const title = s.lease_title || 'Land Lease';
      const location =
        s.lease_location || s.location || 'Location not available';
      const ownerPrice = s.lease_price;
      const offeredPrice = s.offered_price;
      const duration = s.lease_duration;
      const area = s.lease_area;
      const soilType = s.lease_soil_type;
      const waterSource = s.lease_water_source;
      const cropSuitability = s.lease_crop_suitability;
      const distance = s.lease_distance;
      const rating = s.lease_rating;
      const description = s.lease_description;
      const imageUrl = s.lease_image_url;
      const applicantName = s.applicant?.name || s.applicant_name || 'Unknown';
      const message = s.message;
      const appliedDate = s.created_at;

      // Safe formatting helper (same as My Applications tab)
      const fmt = (v: any) => {
        if (v == null || v === '' || v === 0) return '—';
        const n = Number(v);
        return !isNaN(n) ? n.toLocaleString() : String(v);
      };

      return (
        <Layout
          activeTab="dashboard"
          backgroundColor="#FFF8E1"
          barStyle="dark-content"
        >
          <ModernHeader
            title="Lease Application Details"
            leftIconName="arrow-left"
            onLeftPress={() => navigation.goBack()}
            rightIconName="file-document-edit-outline"
            rightIconColor="#795548"
            onRightPress={() => navigation.navigate('LeaseApplicationList')}
          />

          <ScrollView style={styles.content}>
            {/* Lease images carousel from snapshot */}
            {(() => {
              const imgs = getImageList(s);
              if (imgs.length === 0) return null;
              return (
                <View style={styles.carouselContainer}>
                  <ScrollView
                    horizontal
                    pagingEnabled
                    showsHorizontalScrollIndicator={false}
                    onScroll={e => {
                      const x = e.nativeEvent.contentOffset.x || 0;
                      const idx = Math.round(x / (windowWidth - 40));
                      setCurrentImageIndex(idx);
                    }}
                    scrollEventThrottle={16}
                  >
                    {imgs.map((uri: string, i: number) => (
                      <Image
                        key={String(i)}
                        source={{ uri }}
                        style={[styles.leaseImage, { width: windowWidth - 40 }]}
                        resizeMode="cover"
                      />
                    ))}
                  </ScrollView>

                  <View style={styles.paginationContainer}>
                    {imgs.map((_: string, i: number) => (
                      <View
                        key={String(i)}
                        style={
                          i === currentImageIndex
                            ? [styles.dot, styles.activeDot]
                            : styles.dot
                        }
                      />
                    ))}
                  </View>
                </View>
              );
            })()}

            {/* Title and Status */}
            <View style={styles.titleSection}>
              <Text style={styles.leaseTitle}>{title}</Text>
              <View style={styles.statusContainer}>
                <View style={[styles.statusBadge, styles.leasedBadge]}>
                  <Text style={styles.statusText}>Lease Applied</Text>
                </View>
              </View>
            </View>

            {/* Application Status Banner */}
            <View style={[styles.applicationStatus, styles.rejectedStatus]}>
              <View style={styles.statusRow}>
                <MaterialCommunityIcons
                  name="clipboard-text-outline"
                  size={20}
                  color="#333"
                  style={styles.statusIcon}
                />
                <Text style={styles.applicationStatusText}>
                  You have applied for this lease, the application details are
                  preserved below.
                </Text>
              </View>
            </View>

            {/* Main Details from Snapshot */}
            <View style={styles.detailsCard}>
              <View style={styles.detailRow}>
                <MaterialCommunityIcons
                  name="map-marker"
                  size={20}
                  color="#795548"
                  style={styles.detailIcon}
                />
                <Text style={styles.detailLabel}>Location:</Text>
                <Text style={styles.detailValue}>{location}</Text>
              </View>

              <View style={styles.detailRow}>
                <MaterialCommunityIcons
                  name="cash-multiple"
                  size={20}
                  color="#4CAF50"
                  style={styles.detailIcon}
                />
                <Text style={styles.detailLabel}>Owner Price:</Text>
                <Text style={styles.priceValue}>
                  {ownerPrice != null ? `৳${fmt(ownerPrice)}/month` : '—'}
                </Text>
              </View>

              <View style={styles.detailRow}>
                <MaterialCommunityIcons
                  name="hand-coin"
                  size={20}
                  color="#4CAF50"
                  style={styles.detailIcon}
                />
                <Text style={styles.detailLabel}>Offered Price:</Text>
                <Text style={styles.priceValue}>
                  {offeredPrice != null ? `৳${fmt(offeredPrice)}/month` : '—'}
                </Text>
              </View>

              <View style={styles.detailRow}>
                <MaterialCommunityIcons
                  name="timer-sand"
                  size={20}
                  color="#795548"
                  style={styles.detailIcon}
                />
                <Text style={styles.detailLabel}>Duration:</Text>
                <Text style={styles.detailValue}>
                  {duration != null && duration !== 0
                    ? `${duration} months`
                    : '—'}
                </Text>
              </View>

              <View style={styles.detailRow}>
                <MaterialCommunityIcons
                  name="account"
                  size={20}
                  color="#795548"
                  style={styles.detailIcon}
                />
                <Text style={styles.detailLabel}>Applicant:</Text>
                <Text style={styles.detailValue}>{applicantName}</Text>
              </View>

              <View style={styles.detailRow}>
                <MaterialCommunityIcons
                  name="calendar"
                  size={20}
                  color="#795548"
                  style={styles.detailIcon}
                />
                <Text style={styles.detailLabel}>Applied:</Text>
                <Text style={styles.detailValue}>
                  {appliedDate
                    ? new Date(appliedDate).toLocaleDateString()
                    : '—'}
                </Text>
              </View>

              {area != null && area !== 0 && (
                <View style={styles.detailRow}>
                  <MaterialCommunityIcons
                    name="ruler-square"
                    size={20}
                    color="#795548"
                    style={styles.detailIcon}
                  />
                  <Text style={styles.detailLabel}>Area:</Text>
                  <Text style={styles.detailValue}>{fmt(area)} acres</Text>
                </View>
              )}

              {soilType && (
                <View style={styles.detailRow}>
                  <MaterialCommunityIcons
                    name="sprout"
                    size={20}
                    color="#795548"
                    style={styles.detailIcon}
                  />
                  <Text style={styles.detailLabel}>Soil:</Text>
                  <Text style={styles.detailValue}>{soilType}</Text>
                </View>
              )}

              {waterSource && (
                <View style={styles.detailRow}>
                  <MaterialCommunityIcons
                    name="water"
                    size={20}
                    color="#795548"
                    style={styles.detailIcon}
                  />
                  <Text style={styles.detailLabel}>Water:</Text>
                  <Text style={styles.detailValue}>{waterSource}</Text>
                </View>
              )}

              {distance != null && distance !== 0 && (
                <View style={styles.detailRow}>
                  <MaterialCommunityIcons
                    name="map-marker-distance"
                    size={20}
                    color="#795548"
                    style={styles.detailIcon}
                  />
                  <Text style={styles.detailLabel}>Distance:</Text>
                  <Text style={styles.detailValue}>{fmt(distance)} km</Text>
                </View>
              )}

              {rating != null && rating !== 0 && (
                <View style={styles.detailRow}>
                  <MaterialCommunityIcons
                    name="star"
                    size={20}
                    color="#FFB300"
                    style={styles.detailIcon}
                  />
                  <Text style={styles.detailLabel}>Rating:</Text>
                  <Text style={styles.detailValue}>{fmt(rating)}</Text>
                </View>
              )}

              {cropSuitability && (
                <View style={styles.detailRow}>
                  <MaterialCommunityIcons
                    name="leaf"
                    size={20}
                    color="#795548"
                    style={styles.detailIcon}
                  />
                  <Text style={styles.detailLabel}>Crops:</Text>
                  <Text style={styles.detailValue}>{cropSuitability}</Text>
                </View>
              )}
            </View>

            {/* Description from snapshot */}
            {description && description !== 'This land has been removed' && (
              <View style={styles.descriptionCard}>
                <Text style={styles.descriptionTitle}>Description</Text>
                <Text style={styles.descriptionText}>{description}</Text>
              </View>
            )}

            {/* Application Message */}
            {message && (
              <View style={styles.descriptionCard}>
                <Text style={styles.descriptionTitle}>Application Message</Text>
                <Text style={styles.descriptionText}>{message}</Text>
              </View>
            )}
          </ScrollView>
        </Layout>
      );
    }

    return (
      <Layout
        activeTab="dashboard"
        backgroundColor="#FFF8E1"
        barStyle="dark-content"
      >
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Lease not found</Text>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.backButtonText}>Go Back</Text>
          </TouchableOpacity>
        </View>
      </Layout>
    );
  }

  return (
    <Layout
      activeTab="dashboard"
      backgroundColor="#FFF8E1"
      barStyle="dark-content"
    >
      <ModernLoading visible={isLoading} message="Processing..." />

      {/* Header */}
      <ModernHeader
        title="Lease Details"
        leftIconName="arrow-left"
        onLeftPress={() => navigation.goBack()}
        rightIconName="file-document-edit-outline"
        rightIconColor="#795548"
        onRightPress={() => navigation.navigate('LeaseApplicationList')}
      />

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Lease images carousel */}
        {(() => {
          const imgs = getImageList(lease);
          if (imgs.length === 0) return null;
          return (
            <View style={styles.carouselContainer}>
              <ScrollView
                horizontal
                pagingEnabled
                showsHorizontalScrollIndicator={false}
                onScroll={e => {
                  const x = e.nativeEvent.contentOffset.x || 0;
                  const idx = Math.round(x / (windowWidth - 40));
                  setCurrentImageIndex(idx);
                }}
                scrollEventThrottle={16}
              >
                {imgs.map((uri: string, i: number) => (
                  <Image
                    key={String(i)}
                    source={{ uri }}
                    style={[styles.leaseImage, { width: windowWidth - 40 }]}
                    resizeMode="cover"
                  />
                ))}
              </ScrollView>

              <View style={styles.paginationContainer}>
                {imgs.map((_: string, i: number) => (
                  <View
                    key={String(i)}
                    style={
                      i === currentImageIndex
                        ? [styles.dot, styles.activeDot]
                        : styles.dot
                    }
                  />
                ))}
              </View>
            </View>
          );
        })()}
        {/* Lease Title and Status */}
        <View style={styles.titleSection}>
          <Text style={styles.leaseTitle}>{lease.title}</Text>
          <View style={styles.statusContainer}>
            <View
              style={[
                styles.statusBadge,
                lease.status === 'available'
                  ? styles.availableBadge
                  : styles.leasedBadge,
              ]}
            >
              <Text style={styles.statusText}>
                {lease.status === 'available'
                  ? 'Available'
                  : lease.status === 'booked'
                  ? 'Booked'
                  : getStatusLabel(lease.status)}
              </Text>
            </View>
          </View>
        </View>

        {/* Application Status */}
        {userApplication && (
          <View
            style={[
              styles.applicationStatus,
              userApplication.status === 'pending'
                ? styles.pendingStatus
                : userApplication.status === 'approved'
                ? styles.approvedStatus
                : styles.rejectedStatus,
            ]}
          >
            <Text style={styles.applicationStatusText}>
              {getApplicationStatusMessage()}
            </Text>
          </View>
        )}

        {/* Main Details */}
        <View style={styles.detailsCard}>
          <View style={styles.detailRow}>
            <MaterialCommunityIcons
              name="map-marker"
              size={20}
              color="#795548"
              style={styles.detailIcon}
            />
            <Text style={styles.detailLabel}>Location:</Text>
            <Text style={styles.detailValue}>{lease.location}</Text>
          </View>

          <View style={styles.detailRow}>
            <MaterialCommunityIcons
              name="cash-multiple"
              size={20}
              color="#4CAF50"
              style={styles.detailIcon}
            />
            <Text style={styles.detailLabel}>Price:</Text>
            <Text style={styles.priceValue}>
              ৳
              {lease.price != null && lease.price !== undefined
                ? Number(lease.price).toLocaleString()
                : '—'}
              /month
            </Text>
          </View>

          <View style={styles.detailRow}>
            <MaterialCommunityIcons
              name="timer-sand"
              size={20}
              color="#795548"
              style={styles.detailIcon}
            />
            <Text style={styles.detailLabel}>Duration:</Text>
            <Text style={styles.detailValue}>{lease.duration} months</Text>
          </View>

          <View style={styles.detailRow}>
            {ownerUser?.profile_image_url ? (
              <Image
                source={{ uri: ownerUser.profile_image_url }}
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 16,
                  marginRight: 12,
                }}
              />
            ) : (
              <View
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 16,
                  backgroundColor: '#E0E0E0',
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginRight: 12,
                }}
              >
                <MaterialCommunityIcons name="account" size={20} color="#888" />
              </View>
            )}
            <Text style={styles.detailLabel}>Owner:</Text>
            <View
              style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}
            >
              <TouchableOpacity
                onPress={() =>
                  lease.owner_id
                    ? navigation.navigate('UserProfile', {
                        userId: String(lease.owner_id),
                      })
                    : null
                }
                style={{ flex: 1 }}
              >
                <Text style={styles.detailValue}>
                  {ownerUser?.name || lease.owner_name || 'Land Owner'}
                </Text>
              </TouchableOpacity>

              {/* Visit Owner button (replaces inline chat button) */}
              {lease.owner_id && (
                <TouchableOpacity
                  style={styles.visitButton}
                  onPress={() =>
                    navigation.navigate('UserProfile', {
                      userId: String(lease.owner_id),
                    })
                  }
                >
                  <View style={styles.buttonContent}>
                    <MaterialCommunityIcons
                      name="account-eye"
                      size={16}
                      color="#FFFFFF"
                      style={styles.buttonIcon}
                    />
                    <Text style={styles.visitButtonText}>Visit</Text>
                  </View>
                </TouchableOpacity>
              )}
            </View>
          </View>

          {ownerUser?.phone && (
            <View style={styles.detailRow}>
              <MaterialCommunityIcons
                name="phone"
                size={20}
                color="#795548"
                style={styles.detailIcon}
              />
              <Text style={styles.detailLabel}>Contact:</Text>
              <Text style={styles.detailValue}>{ownerUser.phone}</Text>
            </View>
          )}
          {ownerUser?.email && (
            <View style={styles.detailRow}>
              <MaterialCommunityIcons
                name="email"
                size={20}
                color="#795548"
                style={styles.detailIcon}
              />
              <Text style={styles.detailLabel}>Email:</Text>
              <Text style={styles.detailValue}>{ownerUser.email}</Text>
            </View>
          )}

          <View style={styles.detailRow}>
            <MaterialCommunityIcons
              name="calendar"
              size={20}
              color="#795548"
              style={styles.detailIcon}
            />
            <Text style={styles.detailLabel}>Listed:</Text>
            <Text style={styles.detailValue}>
              {new Date(lease.created_at).toLocaleDateString()}
            </Text>
          </View>

          <View style={styles.detailRow}>
            <MaterialCommunityIcons
              name="ruler-square"
              size={20}
              color="#795548"
              style={styles.detailIcon}
            />
            <Text style={styles.detailLabel}>Area:</Text>
            <Text style={styles.detailValue}>{lease.area ?? '—'} acres</Text>
          </View>

          <View style={styles.detailRow}>
            <MaterialCommunityIcons
              name="sprout"
              size={20}
              color="#795548"
              style={styles.detailIcon}
            />
            <Text style={styles.detailLabel}>Soil:</Text>
            <Text style={styles.detailValue}>{lease.soil_type || '—'}</Text>
          </View>

          <View style={styles.detailRow}>
            <MaterialCommunityIcons
              name="water"
              size={20}
              color="#795548"
              style={styles.detailIcon}
            />
            <Text style={styles.detailLabel}>Water:</Text>
            <Text style={styles.detailValue}>{lease.water_source || '—'}</Text>
          </View>

          <View style={styles.detailRow}>
            <MaterialCommunityIcons
              name="map-marker-distance"
              size={20}
              color="#795548"
              style={styles.detailIcon}
            />
            <Text style={styles.detailLabel}>Distance:</Text>
            <Text style={styles.detailValue}>{lease.distance ?? '—'} km</Text>
          </View>

          <View style={styles.detailRow}>
            <MaterialCommunityIcons
              name="star"
              size={20}
              color="#FFB300"
              style={styles.detailIcon}
            />
            <Text style={styles.detailLabel}>Rating:</Text>
            <Text style={styles.detailValue}>{lease.rating ?? '—'}</Text>
          </View>
        </View>

        {/* Description */}
        <View style={styles.descriptionCard}>
          <Text style={styles.descriptionTitle}>Description</Text>
          <Text style={styles.descriptionText}>{lease.description}</Text>
        </View>

        {/* Apply Section */}
        {!fromMyLeases && (
          <View style={styles.applySection}>
            {canApply() || userApplication?.status === 'rejected' ? (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <View style={{ flex: 1 }}>
                  <ModernButton
                    title={canApply() ? 'Apply for This Lease' : 'Apply Again'}
                    onPress={() => setShowApplyModal(true)}
                    variant="primary"
                    size="large"
                    style={styles.submitButton}
                  />
                </View>

                {/* Chat button placed next to Apply button */}
                {currentUser &&
                  lease.owner_id &&
                  String(currentUser.id) !== String(lease.owner_id) && (
                    <TouchableOpacity
                      style={styles.chatButton}
                      onPress={async () => {
                        if (!currentUser) {
                          Alert.alert('Error', 'Please log in to chat');
                          return;
                        }
                        if (!lease?.owner_id) {
                          Alert.alert(
                            'Error',
                            'Owner information not available',
                          );
                          return;
                        }
                        if (String(currentUser.id) === String(lease.owner_id)) {
                          Alert.alert('Error', 'You cannot chat with yourself');
                          return;
                        }
                        if (
                          currentUser.role !== 'farmer' &&
                          currentUser.role !== 'consumer'
                        ) {
                          Alert.alert(
                            'Access Restricted',
                            'Only farmers and consumers can chat with other users',
                            [{ text: 'OK' }],
                          );
                          return;
                        }

                        const roomId = buildRoomId(
                          String(currentUser.id),
                          String(lease.owner_id),
                        );
                        navigation.navigate('ChatRoom', {
                          roomId,
                          otherUserId: String(lease.owner_id),
                          otherUserName:
                            ownerUser?.name || lease.owner_name || 'Owner',
                        });
                      }}
                    >
                      <View style={styles.buttonContent}>
                        <MaterialCommunityIcons
                          name="chat-processing"
                          size={18}
                          color="#FFFFFF"
                          style={styles.buttonIcon}
                        />
                        <Text style={styles.chatButtonText}>Chat</Text>
                      </View>
                    </TouchableOpacity>
                  )}
              </View>
            ) : (
              <View style={styles.cannotApplyContainer}>
                <Text style={styles.cannotApplyText}>
                  {!currentUser
                    ? 'Login required to apply'
                    : currentUser.role === 'admin' ||
                      currentUser.role === 'guest'
                    ? 'Only farmers and consumers can apply'
                    : lease.status !== 'available'
                    ? 'This lease is no longer available'
                    : userApplication?.status === 'pending'
                    ? 'Application pending review'
                    : 'Cannot apply for this lease'}
                </Text>
              </View>
            )}
          </View>
        )}
      </ScrollView>

      {/* Apply Modal */}
      {showApplyModal && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Apply for Lease</Text>

            <Text style={styles.modalSubtitle}>
              Owner's asking price: ৳
              {lease.price != null && lease.price !== undefined
                ? Number(lease.price).toLocaleString()
                : '—'}
              /month
            </Text>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>
                Your Offered Price (৳/month)
              </Text>
              <TextInput
                style={styles.priceInput}
                value={offeredPrice}
                onChangeText={setOfferedPrice}
                placeholder="Enter your offer"
                keyboardType="numeric"
                selectTextOnFocus
              />
            </View>

            <View style={styles.inputContainer}>
              <Text style={styles.inputLabel}>Message (Optional)</Text>
              <TextInput
                style={styles.messageInput}
                value={message}
                onChangeText={setMessage}
                placeholder="Add a message to the owner..."
                multiline
                numberOfLines={3}
              />
            </View>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setShowApplyModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>

              <ModernButton
                title="Submit Application"
                onPress={handleApply}
                variant="primary"
                size="medium"
                style={styles.submitButton}
              />
            </View>
          </View>
        </View>
      )}
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8E1',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#795548',
    paddingHorizontal: 20,
    paddingVertical: 15,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  headerBackButton: {
    padding: 8,
  },
  headerBackButtonText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  headerPlaceholder: {
    width: 40,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  titleSection: {
    marginBottom: 20,
  },
  leaseTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
    lineHeight: 32,
  },
  statusContainer: {
    flexDirection: 'row',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  availableBadge: {
    backgroundColor: '#4CAF50',
  },
  leasedBadge: {
    backgroundColor: '#FF5722',
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  applicationStatus: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 20,
  },
  pendingStatus: {
    backgroundColor: '#FFF9C4',
  },
  approvedStatus: {
    backgroundColor: '#E8F5E9',
  },
  rejectedStatus: {
    backgroundColor: '#FFEBEE',
  },
  applicationStatusText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    textAlign: 'left',
  },
  detailsCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  detailIcon: {
    marginRight: 12,
    width: 24,
    textAlign: 'center',
  },
  detailLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
    width: 80,
  },
  detailValue: {
    fontSize: 16,
    color: '#333',
    flex: 1,
  },
  priceValue: {
    fontSize: 18,
    color: '#4CAF50',
    fontWeight: 'bold',
    flex: 1,
  },
  descriptionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 32,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  descriptionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  descriptionText: {
    fontSize: 16,
    color: '#666',
    lineHeight: 24,
  },
  leaseImage: {
    width: '100%',
    height: 220,
    borderRadius: 12,
    marginBottom: 16,
  },
  applySection: {
    marginBottom: 20,
    paddingBottom: 20,
  },
  cannotApplyContainer: {
    backgroundColor: '#F5F5F5',
    padding: 20,
    borderRadius: 12,
    alignItems: 'center',
  },
  cannotApplyText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 18,
    color: '#666',
    marginBottom: 20,
  },
  backButton: {
    backgroundColor: '#795548',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  modalOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    margin: 20,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 8,
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
  },
  inputContainer: {
    marginBottom: 16,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  priceInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#F9F9F9',
  },
  messageInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#F9F9F9',
    height: 80,
    textAlignVertical: 'top',
  },
  modalActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  cancelButton: {
    flex: 1,
    marginRight: 8,
    paddingVertical: 12,
    backgroundColor: '#E0E0E0',
    borderRadius: 8,
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  /* Carousel / pagination styles */
  carouselContainer: {
    marginBottom: 12,
  },
  paginationContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 6,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#CCCCCC',
    marginHorizontal: 4,
  },
  activeDot: {
    backgroundColor: '#4CAF50',
  },
  chatButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderRadius: 8,
    marginLeft: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chatButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontSize: 18,
  },
  visitButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginLeft: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  visitButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontSize: 14,
  },
  submitButton: {
    flex: 1,
    marginLeft: 8,
  },
  statusRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusIcon: {
    marginRight: 8,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  buttonIcon: {
    marginRight: 6,
  },
});

export default LandLeaseDetailsScreen;
