import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  TouchableOpacity,
  Image,
  StyleProp,
  TextStyle,
  ViewStyle,
} from 'react-native';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import ModernButton from '../../../components/ModernButton';
import { useNavigation, NavigationProp } from '@react-navigation/native';
import { useState, useEffect, useCallback } from 'react';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import { buildRoomId } from '../../../utils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const TABS = [
  { key: 'owner', label: 'As Owner' },
  { key: 'applicant', label: 'As Applicant' },
];

type RootStackParamList = {
  LandLease: undefined;
  LandLeaseDetails: {
    leaseId: string;
    fromMyLeases?: boolean;
    applicationId?: string;
  };
};

const LeaseApplicationsScreen = () => {
  const navigation = useNavigation<NavigationProp<RootStackParamList>>();
  const db = SupabaseDatabaseManager.getInstance();
  const authManager = SupabaseAuthManager.getInstance();
  const [leases, setLeases] = useState<any[]>([]);
  const [ownerApplications, setOwnerApplications] = useState<any[]>([]);
  const [applicantApplications, setApplicantApplications] = useState<any[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [_userId, setUserId] = useState<string | number | null>(null);
  const [activeTab, setActiveTab] = useState<'owner' | 'applicant'>('owner');

  // Utility functions for status badge
  const getStatusStyle = (statusValue: string) => {
    switch (statusValue) {
      case 'approved':
        return { borderColor: '#4CAF50', backgroundColor: '#E8F5E9' };
      case 'pending':
        return { borderColor: '#FF9800', backgroundColor: '#FFF3E0' };
      case 'rejected':
        return { borderColor: '#F44336', backgroundColor: '#FFEBEE' };
      default:
        return { borderColor: '#BDBDBD', backgroundColor: '#F5F5F5' };
    }
  };
  const getStatusTextColor = (statusValue: string) => {
    switch (statusValue) {
      case 'approved':
        return '#388E3C';
      case 'pending':
        return '#F57C00';
      case 'rejected':
        return '#C62828';
      default:
        return '#333';
    }
  };

  // Fetch leases and applications for both tabs
  const fetchAllApplications = useCallback(async () => {
    setRefreshing(true);
    try {
      const user = await authManager.getCurrentUser();
      setCurrentUser(user);
      setUserId(user?.id ?? null);
      const allLeases = await db.getLandLeases(
        user?.id ? String(user.id) : undefined,
      );
      setLeases(allLeases || []);

      // Owner tab: get all applications for leases owned by user
      const ownerApps = await db.getOwnerLeaseApplications(String(user?.id));
      setOwnerApplications(ownerApps || []);

      // Applicant tab: get all applications submitted by user
      const applicantApps = await db.getLeaseApplications(
        undefined,
        String(user?.id),
      );
      setApplicantApplications(applicantApps || []);
    } catch (error) {
      // Handle error
    } finally {
      setRefreshing(false);
    }
  }, [db, authManager]);

  useEffect(() => {
    fetchAllApplications();
  }, [fetchAllApplications]);

  const onRefresh = () => {
    fetchAllApplications();
  };

  // Approve/Reject actions (only for owner tab)
  const handleApplicationAction = async (
    applicationId: number,
    action: 'approved' | 'rejected',
    leaseId: number,
    applicantId: string,
  ) => {
    try {
      await db.updateLeaseApplicationStatus(applicationId, action);
      fetchAllApplications();
    } catch (error) {
      // Handle error
    }
  };

  const renderDetailRow = (
    iconName: string,
    text: string,
    options?: {
      textStyle?: StyleProp<TextStyle>;
      containerStyle?: StyleProp<ViewStyle>;
      iconColor?: string;
    },
  ) => {
    const { textStyle, containerStyle, iconColor } = options || {};
    return (
      <View style={[styles.detailRow, containerStyle]}>
        <MaterialCommunityIcons
          name={iconName}
          size={18}
          color={iconColor ?? '#795548'}
          style={styles.detailIcon}
        />
        <Text style={[styles.detailText, textStyle]}>{text}</Text>
      </View>
    );
  };

  return (
    <Layout activeTab="dashboard">
      <ModernHeader
        title="Lease Applications"
        subtitle="Manage your applications"
        leftIconName="arrow-left"
        onLeftPress={() => navigation.goBack()}
        rightIconName="home-outline"
        onRightPress={() => navigation.navigate('LandLease')}
      />

      {/* Tabs for Owner/Applicant */}
      <View style={styles.tabContainer}>
        {TABS.map(tab => (
          <TouchableOpacity
            key={tab.key}
            style={[
              styles.tabButton,
              activeTab === tab.key && styles.activeTabButton,
            ]}
            onPress={() => setActiveTab(tab.key as 'owner' | 'applicant')}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === tab.key && styles.activeTabText,
              ]}
            >
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView
        style={styles.container}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {activeTab === 'owner' ? (
          ownerApplications.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>
                No applications for your land leases
              </Text>
              <Text style={styles.emptySubtext}>
                Applications for your owned land leases will appear here
              </Text>
            </View>
          ) : (
            ownerApplications.map(application => (
              <View key={application.id} style={styles.applicationCard}>
                <View style={styles.applicationHeader}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      flex: 1,
                    }}
                  >
                    {(application.lease_image_url ||
                      application.lease_image ||
                      application.image_url) && (
                      <Image
                        source={{
                          uri:
                            application.lease_image_url ||
                            application.lease_image ||
                            application.image_url,
                        }}
                        style={styles.leaseThumb}
                      />
                    )}
                    <TouchableOpacity
                      onPress={() =>
                        navigation.navigate('LandLeaseDetails', {
                          leaseId: String(application.lease_id),
                          applicationId: String(application.id),
                          fromMyLeases: true,
                        })
                      }
                      activeOpacity={0.8}
                      style={{ flex: 1 }}
                    >
                      <Text style={styles.leaseTitle}>
                        {application.lease_title || 'Untitled Lease'}
                      </Text>
                    </TouchableOpacity>
                  </View>
                  <View
                    style={[
                      styles.statusBadge,
                      getStatusStyle(application.status),
                    ]}
                  >
                    <Text
                      style={[
                        styles.statusText,
                        { color: getStatusTextColor(application.status) },
                      ]}
                    >
                      {application.status.toUpperCase()}
                    </Text>
                  </View>
                </View>

                <View style={styles.applicationDetails}>
                  {renderDetailRow(
                    'map-marker-outline',
                    `Location: ${application.lease_location || '-'}`,
                  )}
                  {renderDetailRow(
                    'cash-multiple',
                    `Asking: ৳${application.lease_price ?? '-'} /month`,
                  )}
                  {application.offered_price &&
                    renderDetailRow(
                      'cash-check',
                      `Offered: ৳${application.offered_price}/month`,
                      { textStyle: styles.offeredPrice },
                    )}
                  {renderDetailRow(
                    'clock-outline',
                    `Duration: ${application.lease_duration ?? '-'} months`,
                  )}
                  {renderDetailRow(
                    'account-outline',
                    `Applicant: ${application.applicant?.name || '-'}`,
                  )}
                  {renderDetailRow(
                    'email-outline',
                    `Applicant Email: ${application.applicant?.email || '-'}`,
                  )}
                  {application.message &&
                    renderDetailRow(
                      'message-text-outline',
                      `"${application.message}"`,
                      {
                        containerStyle: styles.messageRow,
                        textStyle: styles.messageText,
                        iconColor: '#795548',
                      },
                    )}
                  {renderDetailRow(
                    'calendar-month',
                    `Submitted: ${new Date(
                      application.created_at,
                    ).toLocaleDateString()}`,
                  )}
                </View>
                {/* Chat button for owner to chat with applicant (owner tab) */}
                {currentUser && application.applicant_id && (
                  <TouchableOpacity
                    style={styles.chatButton}
                    onPress={() => {
                      if (!currentUser) return;
                      const otherId = String(
                        application.applicant_id || application.applicant?.id,
                      );
                      if (!otherId) return;
                      if (String(currentUser.id) === String(otherId)) return;
                      const roomId = buildRoomId(
                        String(currentUser.id),
                        String(otherId),
                      );
                      (navigation as any).navigate('ChatRoom', {
                        roomId,
                        otherUserId: otherId,
                        otherUserName:
                          application.applicant?.name ||
                          application.applicant_name ||
                          'Applicant',
                      });
                    }}
                  >
                    <MaterialCommunityIcons
                      name="message-text-outline"
                      size={18}
                      color="#FFFFFF"
                      style={styles.chatButtonIcon}
                    />
                    <Text style={styles.chatButtonText}>Chat</Text>
                  </TouchableOpacity>
                )}

                {application.status === 'pending' &&
                  _userId &&
                  application.owner_id &&
                  String(_userId) === String(application.owner_id) && (
                    <View style={styles.actionButtons}>
                      <ModernButton
                        title="Approved"
                        onPress={() =>
                          handleApplicationAction(
                            application.id,
                            'approved',
                            application.lease_id,
                            String(application.applicant_id),
                          )
                        }
                        variant="primary"
                        size="small"
                        style={styles.approveButton}
                      />
                      <ModernButton
                        title="Rejected"
                        onPress={() =>
                          handleApplicationAction(
                            application.id,
                            'rejected',
                            application.lease_id,
                            String(application.applicant_id),
                          )
                        }
                        variant="outline"
                        size="small"
                        style={styles.rejectButton}
                      />
                    </View>
                  )}
              </View>
            ))
          )
        ) : applicantApplications.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>
              No lease applications submitted
            </Text>
            <Text style={styles.emptySubtext}>
              Your submitted lease applications will appear here
            </Text>
          </View>
        ) : (
          applicantApplications.map(application => (
            <View key={application.id} style={styles.applicationCard}>
              <View style={styles.applicationHeader}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    flex: 1,
                  }}
                >
                  {(application.lease_image_url ||
                    application.lease_image ||
                    application.image_url) && (
                    <Image
                      source={{
                        uri:
                          application.lease_image_url ||
                          application.lease_image ||
                          application.image_url,
                      }}
                      style={styles.leaseThumb}
                    />
                  )}
                  <TouchableOpacity
                    onPress={() =>
                      navigation.navigate('LandLeaseDetails', {
                        leaseId: String(application.lease_id),
                        applicationId: String(application.id),
                        fromMyLeases: true,
                      })
                    }
                    activeOpacity={0.8}
                    style={{ flex: 1 }}
                  >
                    <Text style={styles.leaseTitle}>
                      {application.lease_title || 'Untitled Lease'}
                    </Text>
                  </TouchableOpacity>
                </View>
                <View
                  style={[
                    styles.statusBadge,
                    getStatusStyle(application.status),
                  ]}
                >
                  <Text
                    style={[
                      styles.statusText,
                      { color: getStatusTextColor(application.status) },
                    ]}
                  >
                    {application.status.toUpperCase()}
                  </Text>
                </View>
              </View>

              <View style={styles.applicationDetails}>
                {renderDetailRow(
                  'map-marker-outline',
                  `Location: ${application.lease_location || '-'}`,
                )}
                {renderDetailRow(
                  'cash-multiple',
                  `Asking: ৳${application.lease_price ?? '-'} /month`,
                )}
                {application.offered_price &&
                  renderDetailRow(
                    'cash-check',
                    `Offered: ৳${application.offered_price}/month`,
                    { textStyle: styles.offeredPrice },
                  )}
                {renderDetailRow(
                  'clock-outline',
                  `Duration: ${application.lease_duration ?? '-'} months`,
                )}
                {renderDetailRow(
                  'home-outline',
                  `Owner: ${application.owner?.name || '-'}`,
                )}
                {renderDetailRow(
                  'email-outline',
                  `Owner Email: ${application.owner?.email || '-'}`,
                )}
                {application.message &&
                  renderDetailRow(
                    'message-text-outline',
                    `"${application.message}"`,
                    {
                      containerStyle: styles.messageRow,
                      textStyle: styles.messageText,
                      iconColor: '#795548',
                    },
                  )}
                {renderDetailRow(
                  'calendar-month',
                  `Submitted: ${new Date(
                    application.created_at,
                  ).toLocaleDateString()}`,
                )}
              </View>

              {/* Chat button for applicant to chat with owner (applicant tab) */}
              {currentUser &&
                (application.owner_id || application.owner?.id) && (
                  <TouchableOpacity
                    style={styles.chatButton}
                    onPress={() => {
                      if (!currentUser) return;
                      const otherId = String(
                        application.owner_id || application.owner?.id,
                      );
                      if (!otherId) return;
                      if (String(currentUser.id) === String(otherId)) return;
                      const roomId = buildRoomId(
                        String(currentUser.id),
                        String(otherId),
                      );
                      (navigation as any).navigate('ChatRoom', {
                        roomId,
                        otherUserId: otherId,
                        otherUserName:
                          application.owner?.name ||
                          application.owner_name ||
                          'Owner',
                      });
                    }}
                  >
                    <MaterialCommunityIcons
                      name="message-text-outline"
                      size={18}
                      color="#FFFFFF"
                      style={styles.chatButtonIcon}
                    />
                    <Text style={styles.chatButtonText}>Chat</Text>
                  </TouchableOpacity>
                )}
            </View>
          ))
        )}
      </ScrollView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  tabContainer: {
    flexDirection: 'row',
    marginHorizontal: 16,
    marginTop: 16,
    marginBottom: 8,
    backgroundColor: '#EEE8DC',
    borderRadius: 8,
    overflow: 'hidden',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    backgroundColor: '#EEE8DC',
  },
  activeTabButton: {
    backgroundColor: '#795548',
  },
  tabText: {
    color: '#795548',
    fontWeight: 'bold',
    fontSize: 16,
  },
  activeTabText: {
    color: '#FFF',
  },
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 8,
    textAlign: 'center',
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
  applicationCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  applicationHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  leaseTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginRight: 12,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  applicationDetails: {
    marginBottom: 6,
  },
  detailText: {
    fontSize: 14,
    color: '#666',
    flex: 1,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  detailIcon: {
    marginRight: 8,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  approveButton: {
    flex: 1,
  },
  rejectButton: {
    flex: 1,
  },
  offeredPrice: {
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  messageText: {
    fontStyle: 'italic',
    color: '#795548',
  },
  messageRow: {
    backgroundColor: '#F5F5F5',
    padding: 8,
    borderRadius: 4,
  },
  chatButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'flex-start',
    marginTop: 8,
    marginBottom: 16,
    flexDirection: 'row',
  },
  chatButtonIcon: {
    marginRight: 6,
  },
  chatButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontSize: 14,
  },
  leaseThumb: {
    width: 56,
    height: 56,
    borderRadius: 8,
    marginRight: 12,
    backgroundColor: '#EEE',
  },
});

export default LeaseApplicationsScreen;
