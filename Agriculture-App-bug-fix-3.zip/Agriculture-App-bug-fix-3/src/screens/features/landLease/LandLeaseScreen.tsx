import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  RefreshControl,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../../types';
import ModernLoading from '../../../components/ModernLoading';
import ModernButton from '../../../components/ModernButton';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type LandLeaseScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'LandLease'
>;

const LandLeaseScreen: React.FC = () => {
  // Fallback: if not logged in, any action button goes to SignIn
  const handleRequireAuth = () => {
    navigation.navigate('SignIn');
  };

  // Handler for Details button: if not logged in, go to SignIn, else LandLeaseDetails
  const handleDetailsPress = (leaseId: string) => {
    if (!currentUser) {
      handleRequireAuth();
    } else {
      navigation.navigate('LandLeaseDetails', {
        leaseId,
        fromMyLeases: false,
      });
    }
  };

  // Handler for Apply button: if not logged in, go to SignIn, else run original logic
  const handleApplyPress = (leaseId: number) => {
    if (!currentUser) {
      handleRequireAuth();
    } else {
      handleApplyForLease(leaseId);
    }
  };

  // Handler for List Your Land button: if not logged in, go to SignIn, else run original logic
  const handleListYourLandPress = () => {
    if (!currentUser) {
      handleRequireAuth();
    } else {
      handleListYourLand();
    }
  };
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<LandLeaseScreenNavigationProp>();
  const [activeTab, setActiveTab] = useState<'browse' | 'list' | 'my-leases'>(
    'browse',
  );
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<
    'all' | 'available' | 'unavailable'
  >('all');
  const [isLoading, _setIsLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [databaseLeases, setDatabaseLeases] = useState<any[]>([]);
  const [userApplications, setUserApplications] = useState<any[]>([]);

  const db = dbManager;

  const loadUserAndLeases = useCallback(async () => {
    try {
      const user = await authManager.getCurrentUser();
      setCurrentUser(user);

      // Load all available leases from database
      const leases = await db.getLandLeases();
      const leaseList = leases || [];

      // Fetch owner names for leases (cached)
      const ownerIds = Array.from(
        new Set(leaseList.map((l: any) => String(l.owner_id)).filter(Boolean)),
      );
      const ownersMap: Record<string, string> = {};
      await Promise.all(
        ownerIds.map(async id => {
          try {
            const u = await db.getUserById(String(id));
            if (u) ownersMap[String(id)] = u.name || u.email || '';
          } catch (e) {
            // ignore
          }
        }),
      );

      // Attach owner_name to leases for display
      const leasesWithOwner = leaseList.map((l: any) => ({
        ...l,
        owner_name: ownersMap[String(l.owner_id)] || null,
      }));

      setDatabaseLeases(leasesWithOwner);

      // Load user's applications if logged in
      if (user && user.id) {
        const applications = await db.getLeaseApplications(
          undefined,
          String(user.id),
        );
        setUserApplications(applications || []);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    }
  }, [db, authManager]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadUserAndLeases();
    setRefreshing(false);
  }, [loadUserAndLeases]);

  useEffect(() => {
    loadUserAndLeases();
  }, [loadUserAndLeases]);

  const handleApplyForLease = async (leaseId: number) => {
    if (!currentUser) {
      Alert.alert('Login Required', 'Please login to apply for leases', [
        { text: 'Cancel' },
        { text: 'Login', onPress: () => navigation.navigate('SignIn') },
      ]);
      return;
    }

    // Check user role restrictions
    if (currentUser.role === 'admin' || currentUser.role === 'guest') {
      Alert.alert(
        'Access Restricted',
        'Only farmers and consumers can apply for land leases.',
        [{ text: 'OK' }],
      );
      return;
    }

    // Check if user already applied
    const existingApplication = userApplications.find(
      app => app.lease_id === leaseId,
    );
    if (existingApplication && existingApplication.status === 'pending') {
      Alert.alert(
        'Already Applied',
        `You have already applied for this lease. Status: ${existingApplication.status}`,
      );
      return;
    }

    // Navigate to details screen for application
    navigation.navigate('LandLeaseDetails', {
      leaseId: leaseId.toString(),
      fromMyLeases: false,
    });
  };

  // Only use database leases for browsing
  const allLeases = databaseLeases.map(lease => ({
    id: lease.id.toString(),
    title: lease.title,
    location: lease.location,
    area: lease.area || 2.5, // Use database value or default
    price: lease.price,
    soilType: lease.soil_type || 'Fertile Soil', // Use database value or default
    waterSource: lease.water_source || 'Tube well', // Use database value or default
    cropSuitability: lease.crop_suitability
      ? lease.crop_suitability.split(',').map((crop: string) => crop.trim())
      : ['Rice', 'Vegetables'], // Parse CSV or default
    available: lease.status === 'available',
    rating: lease.rating || 4.5, // Use database value or default
    distance: lease.distance || Math.floor(Math.random() * 30) + 5, // Use database value or random distance
    duration: lease.duration,
    description: lease.description || '',
    imageUrl: lease.image_url || null,
    ownerId: lease.owner_id || null,
    createdAt: lease.created_at || null,
    status: lease.status || 'available',
    isFromDatabase: true,
  }));

  const filteredListings = allLeases.filter(land => {
    const matchesSearch =
      land.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      land.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter =
      filterType === 'all' ||
      (filterType === 'available' && land.available) ||
      (filterType === 'unavailable' && !land.available);
    return matchesSearch && matchesFilter;
  });

  const getUserApplicationStatus = (leaseId: string) => {
    const application = userApplications.find(
      app => app.lease_id.toString() === leaseId,
    );
    return application ? application.status : null;
  };

  const handleContactOwner = (_landId: string) => {
    Alert.alert(
      'Contact Owner',
      'This feature will connect you with the land owner. Coming soon!',
      [{ text: 'OK' }],
    );
  };

  const handleListYourLand = () => {
    if (!currentUser) {
      Alert.alert('Login Required', 'Please login to list your land', [
        { text: 'Cancel' },
        { text: 'Login', onPress: () => navigation.navigate('SignIn') },
      ]);
      return;
    }

    navigation.navigate('LandLeaseManagement');
  };

  const renderBrowseTab = () => (
    <>
      {/* Search and Filters */}
      <View style={[styles.searchSection, { marginBottom: 8 }]}>
        <View style={styles.searchContainer}>
          <View style={styles.searchIconWrapper}>
            <MaterialCommunityIcons name="magnify" size={22} color="#795548" />
          </View>
          <TextInput
            style={styles.searchInput}
            placeholder="Search by location or crop type..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#BDBDBD"
          />
        </View>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={{ marginTop: 10 }}
        >
          <View style={styles.filterContainer}>
            {(['all', 'available', 'unavailable'] as const).map(filter => (
              <TouchableOpacity
                key={filter}
                style={[
                  styles.filterButton,
                  filterType === filter && styles.filterButtonActive,
                ]}
                onPress={() => setFilterType(filter)}
                activeOpacity={0.8}
              >
                <Text
                  style={[
                    styles.filterButtonText,
                    filterType === filter && styles.filterButtonTextActive,
                  ]}
                >
                  {filter === 'all'
                    ? 'All'
                    : filter === 'available'
                    ? 'Available'
                    : 'Unavailable'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </View>

      {/* Featured Stats - horizontal scrollable cards */}
      <View style={{ marginBottom: 16 }}></View>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          marginBottom: 12,
        }}
      >
        <View style={[styles.statCard, { flex: 1, marginRight: 8 }]}>
          <Text style={styles.statValue}>{databaseLeases.length}</Text>
          <Text style={styles.statLabel}>Total Listings</Text>
        </View>
        <View style={[styles.statCard, { flex: 1, marginLeft: 8 }]}>
          <Text style={styles.statValue}>
            {databaseLeases.filter(l => l.status === 'available').length}
          </Text>
          <Text style={styles.statLabel}>Available</Text>
        </View>
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <View style={[styles.statCard, { flex: 1, marginRight: 8 }]}>
          <Text style={styles.statValue}>
            {databaseLeases.filter(l => l.status === 'unavailable').length}
          </Text>
          <Text style={styles.statLabel}>Booked</Text>
        </View>
        <View style={[styles.statCard, { flex: 1, marginLeft: 8 }]}>
          <Text style={styles.statValue}>
            {databaseLeases.length > 0
              ? `৳${Math.round(
                  databaseLeases.reduce((sum, l) => sum + l.price, 0) /
                    databaseLeases.length,
                )}`
              : '৳0'}
          </Text>
          <Text style={styles.statLabel}>Avg. Price/Month</Text>
        </View>
      </View>

      {/* Land Listings */}
      <View style={styles.section}>
        <Text
          style={[styles.sectionTitle, { marginBottom: 12, marginTop: 16 }]}
        >
          Land Listings ({filteredListings.length})
        </Text>
        <View style={{ gap: 16 }}>
          {filteredListings.map(land => {
            const applicationStatus = getUserApplicationStatus(land.id);
            // Find the lease in databaseLeases to get owner_id and status
            const dbLease = databaseLeases.find(
              l => l.id.toString() === land.id,
            );
            const isOwner =
              currentUser &&
              dbLease &&
              dbLease.owner_id &&
              String(dbLease.owner_id) === String(currentUser.id);
            return (
              <View
                key={land.id}
                style={[
                  styles.landCard,
                  {
                    borderRadius: 18,
                    padding: 18,
                    shadowOpacity: 0.13,
                    elevation: 4,
                  },
                ]}
              >
                {/* Lease image */}
                {land.imageUrl ? (
                  <Image
                    source={{ uri: land.imageUrl }}
                    style={styles.leaseImage}
                    resizeMode="cover"
                  />
                ) : null}

                <View style={[styles.landCardHeader, { marginBottom: 10 }]}>
                  <Text
                    style={[styles.landTitle, { fontSize: 19 }]}
                    numberOfLines={1}
                  >
                    {land.title}
                  </Text>
                  <View style={styles.badgeContainer}>
                    {land.isFromDatabase && (
                      <View style={styles.databaseBadge}>
                        <Text style={styles.databaseBadgeText}>VERIFIED</Text>
                      </View>
                    )}
                    <View
                      style={[
                        styles.availabilityBadge,
                        land.available
                          ? styles.availableBadge
                          : styles.leasedBadge,
                      ]}
                    >
                      <Text style={styles.availabilityText}>
                        {land.available ? 'Available' : 'Leased'}
                      </Text>
                    </View>
                  </View>
                </View>

                <View style={styles.ownerRow}>
                  <TouchableOpacity
                    onPress={() =>
                      dbLease && dbLease.owner_id
                        ? navigation.navigate('UserProfile', {
                            userId: String(dbLease.owner_id),
                          })
                        : null
                    }
                  >
                    <Text style={styles.ownerText}>
                      Owner:{' '}
                      {dbLease?.owner_name ||
                        (dbLease?.owner_id
                          ? String(dbLease.owner_id).slice(0, 8)
                          : '—')}
                    </Text>
                  </TouchableOpacity>
                  {land.createdAt ? (
                    <Text style={styles.createdText}>
                      {new Date(land.createdAt).toLocaleDateString()}
                    </Text>
                  ) : null}
                </View>

                <View style={[styles.landDetails, { marginBottom: 10 }]}>
                  <View style={styles.landDetailRow}>
                    <MaterialCommunityIcons
                      name="map-marker"
                      size={18}
                      color="#795548"
                      style={styles.landDetailIcon}
                    />
                    <Text style={styles.landDetailText}>{land.location}</Text>
                    <Text style={styles.landDistance}>{land.distance} km</Text>
                  </View>
                  <View style={styles.landDetailRow}>
                    <MaterialCommunityIcons
                      name="ruler-square"
                      size={18}
                      color="#795548"
                      style={styles.landDetailIcon}
                    />
                    <Text style={styles.landDetailText}>{land.area} acres</Text>
                    <Text style={styles.landPrice}>
                      ৳{land.price.toLocaleString()}/
                      {land.isFromDatabase ? 'month' : 'year'}
                    </Text>
                  </View>
                  <View style={styles.landDetailRow}>
                    <MaterialCommunityIcons
                      name="sprout"
                      size={18}
                      color="#795548"
                      style={styles.landDetailIcon}
                    />
                    <Text style={styles.landDetailText}>{land.soilType}</Text>
                    <View style={styles.ratingContainer}>
                      <MaterialCommunityIcons
                        name="star"
                        size={16}
                        color="#FFB300"
                        style={styles.ratingIcon}
                      />
                      <Text style={styles.ratingText}>{land.rating}</Text>
                    </View>
                  </View>
                  <View style={styles.landDetailRow}>
                    <MaterialCommunityIcons
                      name="water"
                      size={18}
                      color="#795548"
                      style={styles.landDetailIcon}
                    />
                    <Text style={styles.landDetailText}>
                      {land.waterSource}
                    </Text>
                  </View>
                  {land.isFromDatabase && land.duration && (
                    <View style={styles.landDetailRow}>
                      <MaterialCommunityIcons
                        name="timer-sand"
                        size={18}
                        color="#795548"
                        style={styles.landDetailIcon}
                      />
                      <Text style={styles.landDetailText}>
                        {land.duration} months
                      </Text>
                    </View>
                  )}
                </View>

                <View style={styles.cropSuitability}>
                  <Text style={styles.cropSuitabilityLabel}>Suitable for:</Text>
                  <View style={styles.cropTags}>
                    {land.cropSuitability.map((crop: string, index: number) => (
                      <View key={index} style={styles.cropTag}>
                        <Text style={styles.cropTagText}>{crop}</Text>
                      </View>
                    ))}
                  </View>
                </View>

                {/* Short description */}
                {land.description ? (
                  <Text
                    numberOfLines={2}
                    style={{ color: '#555', marginBottom: 8 }}
                  >
                    {land.description}
                  </Text>
                ) : null}

                {/* Application status banner, only if user is not owner and has applied */}
                {applicationStatus && !isOwner && (
                  <View
                    style={[
                      styles.applicationStatusBanner,
                      applicationStatus === 'pending'
                        ? styles.pendingBanner
                        : applicationStatus === 'approved'
                        ? styles.approvedBanner
                        : styles.rejectedBanner,
                    ]}
                  >
                    <Text
                      style={[
                        styles.applicationStatusText,
                        applicationStatus === 'pending'
                          ? styles.pendingText
                          : applicationStatus === 'approved'
                          ? styles.approvedText
                          : styles.rejectedText,
                      ]}
                    >
                      Application {applicationStatus.toUpperCase()}
                    </Text>
                  </View>
                )}

                <View style={[styles.landCardActions, { marginTop: 6 }]}>
                  <ModernButton
                    title="View Details"
                    onPress={() => handleDetailsPress(land.id)}
                    variant="outline"
                    size="small"
                    style={{ flex: 1, marginRight: 8 }}
                  />
                  {/* Button logic: */}
                  {/* 1. If user is owner, show nothing (except View Details) */}
                  {/* 2. If not owner and land is available and user can apply, show Apply */}
                  {/* 3. If not owner and already applied, show status button */}
                  {/* 4. If not owner and not available, show Not Available */}
                  {!isOwner &&
                  land.isFromDatabase &&
                  land.available &&
                  !applicationStatus ? (
                    <ModernButton
                      title="Apply"
                      onPress={() => handleApplyPress(Number(land.id))}
                      variant="primary"
                      size="small"
                      style={styles.applyButton}
                    />
                  ) : !isOwner && land.isFromDatabase && applicationStatus ? (
                    <ModernButton
                      title={
                        applicationStatus === 'approved'
                          ? 'Approved'
                          : applicationStatus === 'pending'
                          ? 'Applied'
                          : 'Rejected'
                      }
                      onPress={handleRequireAuth}
                      variant="outline"
                      size="small"
                      style={styles.applyButton}
                      disabled
                    />
                  ) : !isOwner && (!land.available || !land.isFromDatabase) ? (
                    <ModernButton
                      title="Not Available"
                      onPress={handleRequireAuth}
                      variant="outline"
                      size="small"
                      style={styles.applyButton}
                      disabled
                    />
                  ) : null}
                </View>
              </View>
            );
          })}
        </View>
      </View>
    </>
  );

  const renderListTab = () => (
    <View style={styles.listYourLandContainer}>
      <View style={styles.listYourLandCard}>
        <MaterialCommunityIcons
          name="image-filter-hdr"
          size={56}
          color="#795548"
          style={styles.listYourLandIcon}
        />
        <Text style={styles.listYourLandTitle}>List Your Land for Lease</Text>
        <Text style={styles.listYourLandDescription}>
          Connect with farmers looking for quality agricultural land. List your
          property and earn consistent rental income.
        </Text>

        <View style={styles.benefitsList}>
          <View style={styles.benefitItem}>
            <MaterialCommunityIcons
              name="check-decagram"
              size={20}
              color="#4CAF50"
              style={styles.benefitIcon}
            />
            <Text style={styles.benefitText}>Verified tenant matching</Text>
          </View>
          <View style={styles.benefitItem}>
            <MaterialCommunityIcons
              name="check-decagram"
              size={20}
              color="#4CAF50"
              style={styles.benefitIcon}
            />
            <Text style={styles.benefitText}>Secure document processing</Text>
          </View>
          <View style={styles.benefitItem}>
            <MaterialCommunityIcons
              name="check-decagram"
              size={20}
              color="#4CAF50"
              style={styles.benefitIcon}
            />
            <Text style={styles.benefitText}>Legal documentation support</Text>
          </View>
          <View style={styles.benefitItem}>
            <MaterialCommunityIcons
              name="check-decagram"
              size={20}
              color="#4CAF50"
              style={styles.benefitIcon}
            />
            <Text style={styles.benefitText}>Property monitoring</Text>
          </View>
        </View>

        <TouchableOpacity
          style={styles.listLandButton}
          onPress={handleListYourLandPress}
        >
          <Text style={styles.listLandButtonText}>List Your Land</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const getApplicationStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return '#4CAF50';
      case 'pending':
        return '#FF9800';
      default:
        return '#F44336';
    }
  };

  const renderMyLeasesTab = () => {
    if (!currentUser) {
      return (
        <View style={styles.listYourLandContainer}>
          <View style={styles.listYourLandCard}>
            <MaterialCommunityIcons
              name="lock-outline"
              size={56}
              color="#795548"
              style={styles.listYourLandIcon}
            />
            <Text style={styles.listYourLandTitle}>Login Required</Text>
            <Text style={styles.listYourLandDescription}>
              Please login to view your lease applications and contracts.
            </Text>
            <TouchableOpacity
              style={styles.listLandButton}
              onPress={() => navigation.navigate('SignIn')}
            >
              <Text style={styles.listLandButtonText}>Login</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }

    return (
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>
          My Applications ({userApplications.length})
        </Text>
        {userApplications.length === 0 ? (
          <View style={styles.listYourLandContainer}>
            <Text style={styles.listYourLandTitle}>No Applications Yet</Text>
            <Text style={styles.listYourLandDescription}>
              Browse available land leases and submit applications to get
              started.
            </Text>
          </View>
        ) : (
          userApplications.map(application => {
            const leaseInfo = databaseLeases.find(
              l => String(l.id) === String(application.lease_id),
            );

            // Prefer live lease info, otherwise fall back to application snapshot fields
            const title =
              leaseInfo?.title || application.lease_title || 'Lease';
            const location =
              leaseInfo?.location ||
              application.lease_location ||
              application.location ||
              '—';

            // Owner asking price (snapshot) vs offered price by applicant
            const ownerPriceRaw =
              leaseInfo?.price ?? application.lease_price ?? null;
            const offeredPriceRaw = application.offered_price ?? null;
            const duration =
              leaseInfo?.duration ?? application.lease_duration ?? null;
            const applicantName =
              application.applicant?.name || application.applicant_name || '-';

            const fmt = (v: any) => {
              if (v == null || v === '') return '—';
              const n = Number(v);
              return !isNaN(n) ? `৳${n.toLocaleString()}` : String(v);
            };

            return (
              <View key={application.id} style={styles.leaseCard}>
                <View style={styles.leaseHeader}>
                  <Text style={styles.leaseTitle}>{title}</Text>
                  <View
                    style={[
                      styles.leaseStatusBadge,
                      {
                        backgroundColor: getApplicationStatusColor(
                          application.status,
                        ),
                      },
                    ]}
                  >
                    <Text style={styles.leaseStatusText}>
                      {application.status.toUpperCase()}
                    </Text>
                  </View>
                </View>

                {/* Snapshot / summary info */}
                <View style={styles.leaseInfoRow}>
                  <MaterialCommunityIcons
                    name="map-marker"
                    size={18}
                    color="#795548"
                    style={styles.leaseInfoIcon}
                  />
                  <Text style={styles.leaseDuration}>{location}</Text>
                </View>
                <Text style={styles.leasePayment}>
                  Owner asking: {fmt(ownerPriceRaw)}/month
                </Text>
                <Text style={styles.leaseDuration}>
                  Offered: {fmt(offeredPriceRaw)}/month
                </Text>
                {duration ? (
                  <Text style={styles.leaseDuration}>
                    Duration: {duration} months
                  </Text>
                ) : null}
                <Text style={styles.leaseDuration}>
                  Applicant: {applicantName}
                </Text>
                {application.message ? (
                  <Text style={[styles.leaseDuration, { fontStyle: 'italic' }]}>
                    "{application.message}"
                  </Text>
                ) : null}

                <Text style={styles.leaseDuration}>
                  Applied:{' '}
                  {application.created_at
                    ? new Date(application.created_at).toLocaleDateString()
                    : '—'}
                </Text>

                <View style={styles.leaseActions}>
                  <TouchableOpacity
                    style={styles.leaseActionButton}
                    onPress={() =>
                      navigation.navigate('LandLeaseDetails', {
                        leaseId: String(application.lease_id),
                        applicationId: String(application.id),
                        fromMyLeases: true,
                      })
                    }
                  >
                    <Text style={styles.leaseActionButtonText}>
                      View Details
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            );
          })
        )}
      </View>
    );
  };

  return (
    <Layout
      activeTab="dashboard"
      backgroundColor="#FFF8E1"
      barStyle="dark-content"
    >
      <ModernLoading visible={isLoading} message="Processing application..." />

      {/* Header */}

      <ModernHeader
        title="Land Lease"
        leftIconName="arrow-left"
        onLeftPress={() => navigation.goBack()}
        rightIconName="file-document-edit-outline"
        rightIconColor="#795548"
        onRightPress={() => navigation.navigate('LeaseApplicationList')}
      />

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        {(['browse', 'list', 'my-leases'] as const).map(tab => (
          <TouchableOpacity
            key={tab}
            style={[
              styles.tabButton,
              activeTab === tab && styles.tabButtonActive,
            ]}
            onPress={() => setActiveTab(tab)}
          >
            <Text
              style={[
                styles.tabButtonText,
                activeTab === tab && styles.tabButtonTextActive,
              ]}
            >
              {tab === 'browse'
                ? 'Browse'
                : tab === 'list'
                ? 'List Land'
                : 'My Leases'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {activeTab === 'browse' && renderBrowseTab()}
        {activeTab === 'list' && renderListTab()}
        {activeTab === 'my-leases' && renderMyLeasesTab()}
      </ScrollView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF8E1',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#795548',
    paddingTop: 40,
    paddingBottom: 20,
    paddingHorizontal: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#554f4fff',
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  filterIconButton: {
    padding: 8,
  },
  filterIconButtonText: {
    fontSize: 20,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 16,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabButtonActive: {
    borderBottomColor: '#795548',
  },
  tabButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#666',
  },
  tabButtonTextActive: {
    color: '#795548',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  searchSection: {
    marginBottom: 20,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  searchIconWrapper: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    paddingVertical: 14,
    color: '#333',
  },
  filterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  filterButton: {
    flex: 1,
    marginHorizontal: 4,
    paddingVertical: 10,
    paddingHorizontal: 16,
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  filterButtonActive: {
    backgroundColor: '#795548',
    borderColor: '#795548',
  },
  filterButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  filterButtonTextActive: {
    color: '#FFFFFF',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  statCard: {
    backgroundColor: '#FFFFFF',
    flex: 1,
    marginHorizontal: 4,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#795548',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
  },
  landCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  landCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  landTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginRight: 12,
  },
  availabilityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  availableBadge: {
    backgroundColor: '#4CAF50',
  },
  leasedBadge: {
    backgroundColor: '#FF5722',
  },
  availabilityText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  landDetails: {
    marginBottom: 16,
  },
  landDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  landDetailIcon: {
    marginRight: 12,
    width: 20,
  },
  landDetailText: {
    flex: 1,
    fontSize: 14,
    color: '#666',
  },
  landDistance: {
    fontSize: 14,
    color: '#795548',
    fontWeight: '600',
  },
  landPrice: {
    fontSize: 16,
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingIcon: {
    marginRight: 4,
  },
  ratingText: {
    fontSize: 14,
    color: '#FF9800',
    fontWeight: '600',
  },
  cropSuitability: {
    marginBottom: 16,
  },
  cropSuitabilityLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  cropTags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  cropTag: {
    backgroundColor: '#E8F5E8',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    marginRight: 8,
    marginBottom: 4,
  },
  cropTagText: {
    fontSize: 12,
    color: '#2E7D32',
    fontWeight: '500',
  },
  leaseImage: {
    width: '100%',
    height: 160,
    borderRadius: 12,
    marginBottom: 12,
  },
  ownerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  ownerText: {
    fontSize: 12,
    color: '#333',
  },
  createdText: {
    fontSize: 12,
    color: '#666',
  },
  landCardActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  viewDetailsButton: {
    flex: 1,
    marginRight: 8,
    paddingVertical: 12,
    backgroundColor: '#E0E0E0',
    borderRadius: 8,
    alignItems: 'center',
  },
  viewDetailsButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  contactButton: {
    flex: 1,
    marginLeft: 8,
    paddingVertical: 12,
    backgroundColor: '#795548',
    borderRadius: 8,
    alignItems: 'center',
  },
  contactButtonDisabled: {
    backgroundColor: '#BDBDBD',
  },
  contactButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  listYourLandContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listYourLandCard: {
    backgroundColor: '#FFFFFF',
    padding: 32,
    borderRadius: 20,
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    maxWidth: 350,
  },
  listYourLandIcon: {
    marginBottom: 20,
  },
  listYourLandTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 16,
  },
  listYourLandDescription: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 24,
  },
  benefitsList: {
    alignSelf: 'stretch',
    marginBottom: 32,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  benefitIcon: {
    marginRight: 12,
  },
  benefitText: {
    fontSize: 16,
    color: '#333',
  },
  listLandButton: {
    backgroundColor: '#795548',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    alignSelf: 'stretch',
    alignItems: 'center',
  },
  listLandButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  leaseCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 20,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.22,
    shadowRadius: 2.22,
  },
  leaseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  leaseTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
  },
  leaseStatusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  leaseStatusText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  leaseDuration: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  leasePayment: {
    fontSize: 16,
    color: '#795548',
    fontWeight: '600',
    marginBottom: 16,
  },
  leaseInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  leaseInfoIcon: {
    marginRight: 8,
  },
  leaseActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  leaseActionButton: {
    flex: 1,
    marginHorizontal: 4,
    paddingVertical: 12,
    backgroundColor: '#E0E0E0',
    borderRadius: 8,
    alignItems: 'center',
  },
  leaseActionButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  badgeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  databaseBadge: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  databaseBadgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: 'bold',
  },
  applicationStatusBanner: {
    padding: 8,
    borderRadius: 6,
    marginBottom: 12,
  },
  pendingBanner: {
    backgroundColor: '#FFF9C4',
  },
  approvedBanner: {
    backgroundColor: '#E8F5E9',
  },
  rejectedBanner: {
    backgroundColor: '#FFEBEE',
  },
  applicationStatusText: {
    fontSize: 12,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  pendingText: {
    color: '#F57C00',
  },
  approvedText: {
    color: '#2E7D32',
  },
  rejectedText: {
    color: '#C62828',
  },
  applyButton: {
    flex: 1,
    marginLeft: 8,
  },
});

export default LandLeaseScreen;
