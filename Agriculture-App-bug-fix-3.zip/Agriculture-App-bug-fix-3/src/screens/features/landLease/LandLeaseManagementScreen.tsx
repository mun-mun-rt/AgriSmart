import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../../types';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import ModernInput from '../../../components/ModernInput';
import ModernButton from '../../../components/ModernButton';
import ModernLoading from '../../../components/ModernLoading';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type LandLeaseManagementScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'LandLeaseManagement'
>;

interface LandLeaseInterface {
  id: number;
  owner_id: number;
  title: string;
  description: string;
  price: number;
  duration: number;
  location: string;
  status: 'available' | 'unavailable' | 'booked' | 'maintenance';
  image_url?: string;
  multiple_image_url?: string[];
  area?: number;
  soil_type?: string;
  water_source?: string;
  crop_suitability?: string;
  distance?: number;
  rating?: number;
  created_at: string;
}

const LandLeaseManagementScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<LandLeaseManagementScreenNavigationProp>();
  const [isLoading, setIsLoading] = useState(true);
  const [leases, setLeases] = useState<LandLeaseInterface[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentLease, setCurrentLease] = useState<LandLeaseInterface | null>(
    null,
  );

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [duration, setDuration] = useState('');
  const [location, setLocation] = useState('');
  const [status, setStatus] = useState<
    'available' | 'unavailable' | 'booked' | 'maintenance'
  >('available');
  const [imageUrl, setImageUrl] = useState('');
  const [multipleImageUrls, setMultipleImageUrls] = useState<string[]>(['']);
  const [area, setArea] = useState('');
  const [soilType, setSoilType] = useState('');
  const [waterSource, setWaterSource] = useState('');
  const [cropSuitability, setCropSuitability] = useState('');
  const [distance, setDistance] = useState('');
  const [rating, setRating] = useState('');

  const db = dbManager;

  // Use useCallback to prevent dependency cycle
  const loadLeases = useCallback(async () => {
    setIsLoading(true);
    try {
      const currentUser = await authManager.getCurrentUser();
      if (
        !currentUser ||
        (currentUser.role !== 'farmer' && currentUser.role !== 'consumer')
      ) {
        Alert.alert(
          'Error',
          'Only farmers and consumers can manage land leases',
        );
        navigation.goBack();
        return;
      }

      // Making sure database is properly initialized
      if (!db) {
        Alert.alert('Error', 'Database not initialized');
        return;
      }

      // Load land leases from database
      if (currentUser.id) {
        try {
          const dbLeases = await db.getLandLeases(String(currentUser.id));
          console.log('Loaded land leases:', JSON.stringify(dbLeases, null, 2));
          setLeases(dbLeases || []);
        } catch (dbError: any) {
          console.error('Database error when loading land leases:', dbError);
          Alert.alert(
            'Error',
            `Failed to load land leases: ${
              dbError?.message || 'Unknown error'
            }`,
          );
        }
      }
    } catch (error: any) {
      console.error('Error loading land leases:', error);
      Alert.alert(
        'Error',
        `Failed to load land leases: ${error?.message || 'Unknown error'}`,
      );
    } finally {
      setIsLoading(false);
    }
  }, [navigation, db, authManager]);

  useEffect(() => {
    loadLeases();
  }, [loadLeases]);

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setPrice('');
    setDuration('');
    setLocation('');
    setStatus('available');
    setCurrentLease(null);
    setImageUrl('');
    setMultipleImageUrls(['']);
    setArea('');
    setSoilType('');
    setWaterSource('');
    setCropSuitability('');
    setDistance('');
    setRating('');
  };

  // Multiple image URL management functions
  const addImageUrlField = () => {
    setMultipleImageUrls([...multipleImageUrls, '']);
  };

  const removeImageUrlField = (index: number) => {
    if (multipleImageUrls.length > 1) {
      const newUrls = multipleImageUrls.filter((_, i) => i !== index);
      setMultipleImageUrls(newUrls);
    }
  };

  const updateImageUrl = (index: number, value: string) => {
    const newUrls = [...multipleImageUrls];
    newUrls[index] = value;
    setMultipleImageUrls(newUrls);
  };

  const handleAddLease = () => {
    setIsAdding(true);
    setIsEditing(false);
    resetForm();
  };

  const handleEditLease = async (lease: LandLeaseInterface) => {
    console.log('Editing lease:', lease);

    // Check if lease is under active contract (status = 'booked')
    if (lease.status === 'booked') {
      try {
        // Use the existing method from DatabaseManager to check contracts
        const contracts = await db.getLeaseContracts();
        const activeContract = contracts.find(
          contract =>
            contract.lease_id === lease.id && contract.status === 'active',
        );

        if (activeContract) {
          Alert.alert(
            'Lease Under Contract',
            'This lease is currently under an active contract and cannot be edited. The lease will become editable again when the contract is completed or terminated by the tenant.',
            [{ text: 'OK' }],
          );
          return;
        }
      } catch (error) {
        console.error('Error checking contract status:', error);
      }
    }

    setIsEditing(true);
    setIsAdding(false);
    setCurrentLease(lease);

    // Populate form with lease data
    setTitle(lease.title);
    setDescription(lease.description || '');
    setPrice(lease.price.toString());
    setDuration(lease.duration.toString());
    setLocation(lease.location);
    setStatus(
      lease.status as 'available' | 'unavailable' | 'booked' | 'maintenance',
    );
    // Populate new fields
    setImageUrl(lease.image_url || '');
    const multipleImages = lease.multiple_image_url || [];
    setMultipleImageUrls(multipleImages.length > 0 ? multipleImages : ['']);
    setArea(lease.area ? String(lease.area) : '');
    setSoilType(lease.soil_type || '');
    setWaterSource(lease.water_source || '');
    setCropSuitability(lease.crop_suitability || '');
    setDistance(lease.distance ? String(lease.distance) : '');
    setRating(lease.rating ? String(lease.rating) : '');
  };

  const handleDeleteLease = async (leaseId: number) => {
    // First, check if the lease is under an active contract
    try {
      const contracts = await db.getLeaseContracts();
      const activeContract = contracts.find(
        contract =>
          contract.lease_id === leaseId && contract.status === 'active',
      );

      if (activeContract) {
        Alert.alert(
          'Cannot Delete',
          'This lease is currently under an active contract and cannot be deleted. Please wait for the contract to be completed or terminated.',
          [{ text: 'OK' }],
        );
        return;
      }
    } catch (error) {
      console.error('Error checking contract status for deletion:', error);
    }

    Alert.alert(
      'Confirm Delete',
      'Are you sure you want to delete this land lease?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            setIsLoading(true);
            try {
              await db.deleteLandLease(leaseId);
              await loadLeases(); // Reload leases after deletion
              Alert.alert('Success', 'Land lease deleted successfully');
            } catch (error) {
              console.error('Error deleting land lease:', error);
              const msg =
                (error as any)?.message ||
                (error as any)?.details ||
                'Failed to delete land lease';
              Alert.alert('Error', msg);
            } finally {
              setIsLoading(false);
            }
          },
        },
      ],
    );
  };

  const validateForm = () => {
    if (!title.trim()) {
      Alert.alert('Error', 'Title is required');
      return false;
    }
    if (!description.trim()) {
      Alert.alert('Error', 'Description is required');
      return false;
    }
    if (!price || isNaN(Number(price)) || Number(price) <= 0) {
      Alert.alert('Error', 'Please enter a valid price');
      return false;
    }
    if (!duration || isNaN(Number(duration)) || Number(duration) <= 0) {
      Alert.alert('Error', 'Please enter a valid duration in months');
      return false;
    }
    // Rating must be numeric and between 0 and 5 (inclusive)
    if (rating && rating !== '') {
      const r = Number(rating);
      if (isNaN(r) || r < 0 || r > 5) {
        Alert.alert('Error', 'Rating must be a number between 0 and 5');
        return false;
      }
    }
    if (!location.trim()) {
      Alert.alert('Error', 'Location is required');
      return false;
    }
    return true;
  };

  const handleSaveLease = async () => {
    if (!validateForm()) return;

    setIsLoading(true);
    try {
      const currentUser = await authManager.getCurrentUser();
      if (!currentUser || !currentUser.id) {
        Alert.alert('Error', 'User not found');
        return;
      }

      // Making sure database is properly initialized
      if (!db) {
        Alert.alert('Error', 'Database not initialized');
        return;
      }

      const leaseData = {
        owner_id: String(currentUser.id),
        title: title,
        description: description,
        price: parseFloat(price),
        duration: parseInt(duration, 10),
        location: location,
        status: status,
        image_url: imageUrl || undefined,
        multiple_image_url: multipleImageUrls.filter(url => url.trim() !== ''),
        area: area ? parseFloat(area) : undefined,
        soil_type: soilType || undefined,
        water_source: waterSource || undefined,
        crop_suitability: cropSuitability || undefined,
        distance: distance ? parseFloat(distance) : undefined,
        // Clamp rating to [0,5] as a safe fallback to avoid DB constraint errors
        rating:
          rating && rating !== ''
            ? Math.min(5, Math.max(0, parseFloat(rating)))
            : undefined,
      };

      try {
        if (isEditing && currentLease) {
          // Update existing lease
          const updateData = {
            title: leaseData.title,
            description: leaseData.description,
            price: leaseData.price,
            duration: leaseData.duration,
            location: leaseData.location,
            status: leaseData.status,
            image_url: leaseData.image_url,
            multiple_image_url: leaseData.multiple_image_url,
            area: leaseData.area,
            soil_type: leaseData.soil_type,
            water_source: leaseData.water_source,
            crop_suitability: leaseData.crop_suitability,
            distance: leaseData.distance,
            rating: leaseData.rating,
          };

          console.log(
            'Updating lease with ID:',
            currentLease.id,
            'Data:',
            updateData,
          );

          await db.updateLandLease(currentLease.id, updateData);

          console.log('Land lease updated successfully');
          Alert.alert('Success', 'Land lease updated successfully');
          await loadLeases();
          setIsEditing(false);
          resetForm();
        } else {
          // Create new lease
          await db.createLandLease(leaseData);
          Alert.alert('Success', 'Land lease added successfully');
        }

        // Reload leases and reset form
        await loadLeases();
        setIsAdding(false);
        setIsEditing(false);
        resetForm();
      } catch (dbError: any) {
        console.error('Database operation error:', dbError);
        Alert.alert(
          'Error',
          `Database operation failed: ${dbError?.message || 'Unknown error'}`,
        );
        return;
      }
    } catch (error: any) {
      console.error('Error saving land lease:', error);
      Alert.alert(
        'Error',
        `Failed to save land lease: ${error?.message || 'Unknown error'}`,
      );
    } finally {
      setIsLoading(false);
    }
  };

  const renderLeaseForm = () => {
    return (
      <View style={styles.formContainer}>
        <Text style={[styles.formTitle, isEditing && styles.editingFormTitle]}>
          {isEditing
            ? `Edit Land Lease: ${currentLease?.title}`
            : 'Add New Land Lease'}
        </Text>

        {isEditing && (
          <View style={styles.editingBanner}>
            <Text style={styles.editingBannerText}>
              Editing Lease ID: {currentLease?.id}
            </Text>
          </View>
        )}

        <ModernInput
          label="Title"
          value={title}
          onChangeText={setTitle}
          placeholder="Enter lease title"
          editable={status !== 'booked'}
        />

        <ModernInput
          label="Description"
          value={description}
          onChangeText={setDescription}
          placeholder="Enter land description"
          multiline
          numberOfLines={3}
          editable={status !== 'booked'}
        />

        <View style={styles.rowContainer}>
          <View style={styles.halfWidth}>
            <ModernInput
              label="Price (BDT/month)"
              value={price}
              onChangeText={setPrice}
              placeholder="0.00"
              keyboardType="numeric"
              editable={status !== 'booked'}
            />
          </View>

          <View style={styles.halfWidth}>
            <ModernInput
              label="Duration (months)"
              value={duration}
              onChangeText={setDuration}
              placeholder="12"
              keyboardType="numeric"
              editable={status !== 'booked'}
            />
          </View>
        </View>

        <ModernInput
          label="Location"
          value={location}
          onChangeText={setLocation}
          placeholder="e.g. Dhaka, Bangladesh"
          editable={status !== 'booked'}
        />

        <ModernInput
          label="Cover Image URL"
          value={imageUrl}
          onChangeText={setImageUrl}
          placeholder="https://.../cover-image.jpg"
          editable={status !== 'booked'}
        />

        {/* Multiple Additional Images Section */}
        <View style={styles.multipleImagesContainer}>
          <View style={styles.sectionHeaderContainer}>
            <Text style={styles.sectionTitle}>Additional Images</Text>
            <TouchableOpacity
              style={styles.addImageButton}
              onPress={addImageUrlField}
              disabled={status === 'booked'}
            >
              <Text style={styles.addImageButtonText}>+ Add Image</Text>
            </TouchableOpacity>
          </View>

          {multipleImageUrls.map((url, index) => (
            <View key={index} style={styles.imageUrlRow}>
              <View style={styles.imageUrlInput}>
                <ModernInput
                  label={`Image ${index + 1} URL`}
                  value={url}
                  onChangeText={value => updateImageUrl(index, value)}
                  placeholder="https://.../image.jpg"
                  editable={status !== 'booked'}
                />
              </View>
              {multipleImageUrls.length > 1 && (
                <TouchableOpacity
                  style={styles.removeImageButton}
                  onPress={() => removeImageUrlField(index)}
                  disabled={status === 'booked'}
                >
                  <Text style={styles.removeImageButtonText}>×</Text>
                </TouchableOpacity>
              )}
            </View>
          ))}
        </View>

        <View style={styles.rowContainer}>
          <View style={styles.halfWidth}>
            <ModernInput
              label="Area (acres)"
              value={area}
              onChangeText={setArea}
              placeholder="e.g. 1.25"
              keyboardType="numeric"
              editable={status !== 'booked'}
            />
          </View>

          <View style={styles.halfWidth}>
            <ModernInput
              label="Distance (km)"
              value={distance}
              onChangeText={setDistance}
              placeholder="e.g. 2.5"
              keyboardType="numeric"
              editable={status !== 'booked'}
            />
          </View>
        </View>

        <ModernInput
          label="Soil Type"
          value={soilType}
          onChangeText={setSoilType}
          placeholder="e.g. Loamy"
          editable={status !== 'booked'}
        />

        <ModernInput
          label="Water Source"
          value={waterSource}
          onChangeText={setWaterSource}
          placeholder="e.g. Canal"
          editable={status !== 'booked'}
        />

        <ModernInput
          label="Crop Suitability"
          value={cropSuitability}
          onChangeText={setCropSuitability}
          placeholder="e.g. Rice, Vegetables"
          editable={status !== 'booked'}
        />

        <ModernInput
          label="Rating"
          value={rating}
          onChangeText={setRating}
          placeholder="e.g. 4.5"
          keyboardType="numeric"
          editable={status !== 'booked'}
        />

        <Text style={styles.inputLabel}>Status</Text>
        <View style={styles.statusContainer}>
          {/* Only allow certain status options - exclude 'booked' as it should only be set through contract approval */}
          {['available', 'unavailable', 'maintenance'].map(statusOption => (
            <TouchableOpacity
              key={statusOption}
              style={[
                styles.statusOption,
                status === statusOption && styles.selectedStatus,
              ]}
              onPress={() =>
                status !== 'booked' &&
                setStatus(
                  statusOption as 'available' | 'unavailable' | 'maintenance',
                )
              }
              disabled={status === 'booked'}
            >
              <Text
                style={[
                  styles.statusText,
                  status === statusOption && styles.selectedStatusText,
                ]}
              >
                {statusOption.charAt(0).toUpperCase() + statusOption.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}

          {/* Show 'booked' status as read-only if currently booked */}
          {status === 'booked' && (
            <View style={[styles.statusOption, styles.leasedStatusReadonly]}>
              <Text style={styles.leasedStatusText}>
                Booked (Under Contract)
              </Text>
            </View>
          )}
        </View>

        {status === 'booked' && (
          <View style={styles.contractWarning}>
            <MaterialCommunityIcons
              name="alert-circle-outline"
              size={18}
              color="#E65100"
              style={styles.contractWarningIcon}
            />
            <Text style={styles.contractWarningText}>
              This lease is under contract. Status will automatically change to
              'Available' or 'Maintenance' when the contract is completed or
              terminated.
            </Text>
          </View>
        )}

        <View style={styles.buttonContainer}>
          <View style={styles.halfWidth}>
            <ModernButton
              title={isEditing ? 'Cancel Edit' : 'Cancel'}
              variant="outline"
              onPress={() => {
                setIsAdding(false);
                setIsEditing(false);
                resetForm();
              }}
              disabled={status === 'booked'}
            />
          </View>

          <View style={styles.halfWidth}>
            <ModernButton
              title={isEditing ? 'Update Lease' : 'Save Lease'}
              onPress={handleSaveLease}
              variant={isEditing ? 'secondary' : 'primary'}
              disabled={status === 'booked'}
            />
          </View>
        </View>
      </View>
    );
  };

  const renderLeaseList = () => {
    if (leases.length === 0) {
      return (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>
            You don't have any land leases yet. Add your first land lease!
          </Text>
          <ModernButton title="Add Land Lease" onPress={handleAddLease} />
        </View>
      );
    }

    return (
      <>
        <View style={styles.headerRow}>
          <Text style={styles.sectionTitle}>Your Land Leases</Text>
          <TouchableOpacity style={styles.addButton} onPress={handleAddLease}>
            <Text style={styles.addButtonText}>+ Add Lease</Text>
          </TouchableOpacity>
        </View>

        {leases.map(lease => (
          <View key={lease.id} style={styles.leaseCard}>
            {(lease as any).image_url ? (
              <Image
                source={{ uri: (lease as any).image_url }}
                style={styles.leaseImage}
                resizeMode="cover"
              />
            ) : null}
            <View style={styles.leaseHeader}>
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate('LandLeaseDetails', {
                    leaseId: lease.id ? String(lease.id) : '',
                    fromMyLeases: true,
                  })
                }
                disabled={!lease.id}
              >
                <Text style={styles.leaseTitle}>{lease.title}</Text>
              </TouchableOpacity>

              <View style={[styles.statusBadge, getStatusStyle(lease.status)]}>
                <Text style={styles.statusBadgeText}>
                  {lease.status.charAt(0).toUpperCase() + lease.status.slice(1)}
                </Text>
              </View>
            </View>

            <Text style={styles.leaseDescription}>{lease.description}</Text>

            <View style={styles.leaseDetails}>
              <Text style={styles.leaseInfo}>
                Price: ৳{lease.price.toFixed(2)}/month
              </Text>
              <Text style={styles.leaseInfo}>
                Duration: {lease.duration} months
              </Text>
              <Text style={styles.leaseInfo}>Location: {lease.location}</Text>
            </View>

            {lease.status === 'booked' && (
              <View style={styles.contractNotice}>
                <MaterialCommunityIcons
                  name="lock-outline"
                  size={18}
                  color="#E65100"
                  style={styles.contractNoticeIcon}
                />
                <Text style={styles.contractNoticeText}>
                  Under Active Contract - Limited actions available
                </Text>
              </View>
            )}

            <View style={styles.actionButtons}>
              <TouchableOpacity
                style={[
                  styles.actionButton,
                  styles.editButton,
                  lease.status === 'booked' && styles.disabledButton,
                ]}
                onPress={() => handleEditLease(lease)}
                disabled={lease.status === 'booked'}
              >
                <Text
                  style={[
                    styles.actionButtonText,
                    lease.status === 'booked' && styles.disabledButtonText,
                  ]}
                >
                  {lease.status === 'booked' ? 'Locked' : 'Edit'}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.actionButton,
                  styles.deleteButton,
                  lease.status === 'booked' && styles.disabledButton,
                ]}
                onPress={() => handleDeleteLease(lease.id)}
                disabled={lease.status === 'booked'}
              >
                <Text
                  style={[
                    styles.actionButtonText,
                    lease.status === 'booked' && styles.disabledButtonText,
                  ]}
                >
                  {lease.status === 'booked' ? 'Locked' : 'Delete'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </>
    );
  };

  const getStatusStyle = (statusValue: string) => {
    switch (statusValue) {
      case 'available':
        return styles.statusAvailable;
      case 'unavailable':
        return styles.statusUnavailable;
      case 'booked':
        return styles.statusBooked;
      case 'maintenance':
        return styles.statusMaintenance;
      default:
        return {};
    }
  };

  return (
    <Layout activeTab="dashboard">
      <ModernHeader
        title="Land Management"
        subtitle="Manage your lands"
        leftIconName="arrow-left"
        onLeftPress={() => navigation.goBack()}
        rightIconName="home-outline"
        onRightPress={() => navigation.navigate('LandLease')}
      />

      <ScrollView style={styles.container}>
        {isLoading ? (
          <ModernLoading visible={true} message="Loading land leases..." />
        ) : isAdding || isEditing ? (
          renderLeaseForm()
        ) : (
          renderLeaseList()
        )}
      </ScrollView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
  },
  addButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
  leaseCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 10,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  leaseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  leaseTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333333',
    flex: 1,
  },
  leaseDescription: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 12,
  },
  leaseDetails: {
    backgroundColor: '#F9F9F9',
    padding: 10,
    borderRadius: 6,
    marginBottom: 12,
  },
  leaseImage: {
    width: '100%',
    height: 160,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    marginBottom: 12,
    backgroundColor: '#EEEEEE',
  },
  leaseInfo: {
    fontSize: 14,
    color: '#666666',
    marginBottom: 4,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 15,
    marginLeft: 8,
  },
  statusAvailable: {
    backgroundColor: '#E8F5E9',
    borderColor: '#4CAF50',
    borderWidth: 1,
  },
  statusUnavailable: {
    backgroundColor: '#ECECEC',
    borderColor: '#BDBDBD',
    borderWidth: 1,
  },
  statusBooked: {
    backgroundColor: '#E3F2FD',
    borderColor: '#2196F3',
    borderWidth: 1,
  },
  statusMaintenance: {
    backgroundColor: '#FFEBEE',
    borderColor: '#F44336',
    borderWidth: 1,
  },
  statusBadgeText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  actionButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 6,
    marginLeft: 8,
  },
  editButton: {
    backgroundColor: '#2196F3',
  },
  deleteButton: {
    backgroundColor: '#F44336',
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 16,
    color: '#666666',
    textAlign: 'center',
    marginBottom: 20,
  },
  formContainer: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 10,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  formTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333333',
    marginBottom: 16,
    textAlign: 'center',
  },
  rowContainer: {
    flexDirection: 'row',
    marginBottom: 15,
    justifyContent: 'space-between',
  },
  halfWidth: {
    width: '48%',
  },
  inputLabel: {
    fontSize: 14,
    color: '#555555',
    marginBottom: 6,
  },
  statusContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginBottom: 15,
  },
  statusOption: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#EEEEEE',
    marginRight: 10,
    marginBottom: 10,
  },
  selectedStatus: {
    backgroundColor: '#4CAF50',
  },
  statusText: {
    fontSize: 14,
    color: '#555555',
  },
  selectedStatusText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
  buttonContainer: {
    flexDirection: 'row',
    marginTop: 20,
    justifyContent: 'space-between',
  },
  editingFormTitle: {
    color: '#2196F3', // Blue color to indicate editing
  },
  editingBanner: {
    backgroundColor: '#E3F2FD', // Light blue background
    padding: 8,
    borderRadius: 4,
    marginBottom: 16,
    borderLeftWidth: 4,
    borderLeftColor: '#2196F3',
  },
  editingBannerText: {
    color: '#0D47A1',
    fontSize: 14,
    fontWeight: 'bold',
  },
  leasedStatusReadonly: {
    backgroundColor: '#FFE0B2',
    borderWidth: 1,
    borderColor: '#FF9800',
  },
  leasedStatusText: {
    color: '#E65100',
    fontWeight: 'bold',
  },
  contractWarning: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  contractWarningIcon: {
    marginRight: 6,
  },
  contractWarningText: {
    color: '#E65100',
    fontSize: 12,
    fontStyle: 'italic',
    textAlign: 'center',
    flex: 1,
  },
  contractNotice: {
    backgroundColor: '#FFF3E0',
    padding: 8,
    borderRadius: 4,
    marginBottom: 12,
    borderLeftWidth: 3,
    borderLeftColor: '#FF9800',
    flexDirection: 'row',
    alignItems: 'center',
  },
  contractNoticeIcon: {
    marginRight: 8,
  },
  contractNoticeText: {
    color: '#E65100',
    fontSize: 12,
    fontWeight: 'bold',
    textAlign: 'left',
    flex: 1,
  },
  disabledButton: {
    backgroundColor: '#E0E0E0',
    opacity: 0.6,
  },
  disabledButtonText: {
    color: '#9E9E9E',
  },
  // Multiple images styles
  multipleImagesContainer: {
    marginVertical: 16,
  },
  sectionHeaderContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  addImageButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  addImageButtonText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  imageUrlRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginBottom: 8,
  },
  imageUrlInput: {
    flex: 1,
    marginRight: 8,
  },
  removeImageButton: {
    backgroundColor: '#F44336',
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 26,
  },
  removeImageButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default LandLeaseManagementScreen;
