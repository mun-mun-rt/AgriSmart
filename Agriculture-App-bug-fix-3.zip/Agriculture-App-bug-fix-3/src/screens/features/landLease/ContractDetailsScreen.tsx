import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert, Image } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList, LeaseContract } from '../../../types';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import ModernButton from '../../../components/ModernButton';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import { buildRoomId } from '../../../utils';

type ContractDetailsScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'ContractDetails'
>;

type ContractDetailsScreenRouteProp = RouteProp<
  RootStackParamList,
  'ContractDetails'
>;

const ContractDetailsScreen: React.FC = () => {
  const dbManager = SupabaseDatabaseManager.getInstance();
  const authManager = SupabaseAuthManager.getInstance();

  const navigation = useNavigation<ContractDetailsScreenNavigationProp>();
  const route = useRoute<ContractDetailsScreenRouteProp>();
  const { contractId } = route.params;

  const [isLoading, setIsLoading] = useState(true);
  const [contract, setContract] = useState<LeaseContract | null>(null);
  const [lease, setLease] = useState<any | null>(null);
  const [ownerUser, setOwnerUser] = useState<any | null>(null);
  const [tenantUser, setTenantUser] = useState<any | null>(null);
  const [currentUser, setCurrentUser] = useState<any | null>(null);

  const db = dbManager;

  useEffect(() => {
    const loadContractDetails = async () => {
      try {
        // Get current user first
        const user = await authManager.getCurrentUser();
        setCurrentUser(user);

        const contractData = await db.getLeaseContractById(contractId);
        if (!contractData) {
          Alert.alert('Error', 'Contract not found');
          navigation.goBack();
          return;
        }

        setContract(contractData);

        // Fetch lease details
        try {
          const leaseData = await db.getLandLeaseById(contractData.lease_id);
          setLease(leaseData || null);
        } catch (leaseErr) {
          console.warn('Failed to load lease for contract:', leaseErr);
        }

        // Fetch owner and tenant profiles to show images and contact info
        try {
          const [owner, tenant] = await Promise.all([
            db.getUserById(contractData.owner_id),
            db.getUserById(contractData.tenant_id),
          ]);
          setOwnerUser(owner || null);
          setTenantUser(tenant || null);
        } catch (userErr) {
          console.warn('Failed to load owner/tenant users:', userErr);
        }
      } catch (error) {
        console.error('Error loading contract details:', error);
        Alert.alert('Error', 'Failed to load contract details');
        navigation.goBack();
      } finally {
        setIsLoading(false);
      }
    };

    loadContractDetails();
  }, [contractId, db, navigation, authManager]);

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'active':
        return { backgroundColor: '#E8F5E9', color: '#2E7D32' };
      case 'completed':
        return { backgroundColor: '#E3F2FD', color: '#1976D2' };
      case 'terminated':
        return { backgroundColor: '#FFEBEE', color: '#C62828' };
      case 'expired':
        return { backgroundColor: '#FFF9C4', color: '#F57C00' };
      default:
        return { backgroundColor: '#F5F5F5', color: '#424242' };
    }
  };

  const handleChatPress = () => {
    if (!contract || !currentUser) {
      Alert.alert('Error', 'Unable to open chat. Please try again.');
      return;
    }

    let otherUserId: string;
    let otherUserName: string;

    // Check if current user is the owner or tenant
    if (String(currentUser.id) === String(contract.owner_id)) {
      // Current user is owner, chat with tenant
      otherUserId = String(contract.tenant_id);
      otherUserName = tenantUser?.name || contract.tenant_name || 'Tenant';
    } else if (String(currentUser.id) === String(contract.tenant_id)) {
      // Current user is tenant, chat with owner
      otherUserId = String(contract.owner_id);
      otherUserName = ownerUser?.name || contract.owner_name || 'Owner';
    } else {
      Alert.alert('Error', 'You are not authorized to chat for this contract.');
      return;
    }

    const participantRoomId = buildRoomId(
      String(contract.owner_id),
      String(contract.tenant_id),
    );
    const roomId = `contract_${contract.id}_${participantRoomId}`;

    navigation.navigate('ChatRoom', {
      roomId,
      otherUserId,
      otherUserName,
    });
  };

  if (isLoading) {
    return (
      <Layout activeTab="dashboard">
        <ModernLoading visible={true} message="Loading contract details..." />
      </Layout>
    );
  }

  if (!contract) {
    return (
      <Layout activeTab="dashboard">
        <ModernHeader
          title="Contract Details"
          leftIconName="arrow-left"
          onLeftPress={() => navigation.goBack()}
        />
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Contract not found</Text>
        </View>
      </Layout>
    );
  }

  const statusStyle = getStatusStyle(contract.status);

  return (
    <Layout activeTab="dashboard">
      <ModernHeader
        title="Contract Details"
        subtitle={`Contract #${contract.id}`}
        leftIconName="arrow-left"
        onLeftPress={() => navigation.goBack()}
        rightIconName="clipboard-text-outline"
        onRightPress={() => navigation.navigate('LeaseApplicationList')}
      />

      <ScrollView style={styles.container}>
        <View style={styles.contractCard}>
          <View style={styles.contractHeader}>
            <View style={styles.headerLeft}>
              <Text style={styles.contractTitle}>
                {lease?.title || contract.lease_title || 'Lease'}
              </Text>
              <Text style={styles.subTitleText}>
                {lease?.location || contract.location || ''}
              </Text>
            </View>
            <View
              style={[
                styles.statusBadge,
                { backgroundColor: statusStyle.backgroundColor },
              ]}
            >
              <Text style={[styles.statusText, { color: statusStyle.color }]}>
                {contract.status.toUpperCase()}
              </Text>
            </View>
          </View>

          {/* Lease image - use snapshot image first, fallback to live lease */}
          {(contract as any).lease_image_url || lease?.image_url ? (
            <Image
              source={{
                uri: (contract as any).lease_image_url || lease.image_url,
              }}
              style={styles.leaseImage}
            />
          ) : (
            <View style={styles.leaseImagePlaceholder}>
              <Text style={styles.placeholderText}>No property image</Text>
            </View>
          )}

          {/* Multiple images carousel (from contract snapshot if present) */}
          {contract &&
            (contract as any).multiple_image_url &&
            (contract as any).multiple_image_url.length > 0 && (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={styles.multipleCarousel}
              >
                {(contract as any).multiple_image_url.map(
                  (img: string, idx: number) => (
                    <Image
                      key={idx}
                      source={{ uri: img }}
                      style={styles.carouselImage}
                    />
                  ),
                )}
              </ScrollView>
            )}

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Property Details</Text>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Location:</Text>
              <Text style={styles.detailValue}>
                {(contract as any).lease_location || contract.location || '-'}
              </Text>
            </View>
            {(contract as any)?.lease_area != null && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Area (acres):</Text>
                <Text style={styles.detailValue}>
                  {(contract as any).lease_area}
                </Text>
              </View>
            )}
            {(contract as any)?.lease_duration != null && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Duration:</Text>
                <Text style={styles.detailValue}>
                  {(contract as any).lease_duration} months
                </Text>
              </View>
            )}
            {(contract as any)?.lease_soil_type && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Soil Type:</Text>
                <Text style={styles.detailValue}>
                  {(contract as any).lease_soil_type}
                </Text>
              </View>
            )}
            {(contract as any)?.lease_water_source && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Water Source:</Text>
                <Text style={styles.detailValue}>
                  {(contract as any).lease_water_source}
                </Text>
              </View>
            )}
            {(contract as any)?.lease_crop_suitability && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Suitable Crops:</Text>
                <Text style={styles.detailValue}>
                  {(contract as any).lease_crop_suitability}
                </Text>
              </View>
            )}
            {(contract as any)?.lease_distance != null && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Distance (km):</Text>
                <Text style={styles.detailValue}>
                  {(contract as any).lease_distance}
                </Text>
              </View>
            )}
            {(contract as any)?.lease_rating != null && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Rating:</Text>
                <Text style={styles.detailValue}>
                  {(contract as any).lease_rating}/5
                </Text>
              </View>
            )}
            {((contract as any)?.lease_description || contract.description) && (
              <View style={styles.detailRow}>
                <Text style={styles.detailLabel}>Description:</Text>
                <Text style={styles.detailValue}>
                  {(contract as any).lease_description || contract.description}
                </Text>
              </View>
            )}
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Contract Details</Text>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Monthly Amount:</Text>
              <Text style={[styles.detailValue, styles.priceText]}>
                ৳{contract.contract_amount}
              </Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Start Date:</Text>
              <Text style={styles.detailValue}>
                {new Date(contract.start_date).toLocaleDateString()}
              </Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>End Date:</Text>
              <Text style={styles.detailValue}>
                {new Date(contract.end_date).toLocaleDateString()}
              </Text>
            </View>
            <View style={styles.detailRow}>
              <Text style={styles.detailLabel}>Signed Date:</Text>
              <Text style={styles.detailValue}>
                {new Date(
                  contract.signed_date || contract.created_at || '',
                ).toLocaleDateString()}
              </Text>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Parties</Text>
            <View style={[styles.detailRow, styles.partyRow]}>
              <Text style={styles.detailLabel}>Tenant:</Text>
              <View style={styles.partyInfo}>
                {tenantUser?.profile_image_url ? (
                  <Image
                    source={{ uri: tenantUser.profile_image_url }}
                    style={styles.smallAvatar}
                  />
                ) : null}
                <View style={styles.partyTextWrap}>
                  <Text style={styles.detailValue}>
                    {tenantUser?.name || contract.tenant_name || 'Tenant'}
                  </Text>
                  <Text style={styles.smallMeta}>
                    {tenantUser?.email || contract.tenant_email || ''}
                  </Text>
                </View>
              </View>
            </View>

            <View style={[styles.detailRow, styles.partyRow]}>
              <Text style={styles.detailLabel}>Owner:</Text>
              <View style={styles.partyInfo}>
                {ownerUser?.profile_image_url ? (
                  <Image
                    source={{ uri: ownerUser.profile_image_url }}
                    style={styles.smallAvatar}
                  />
                ) : null}
                <View style={styles.partyTextWrap}>
                  <Text style={styles.detailValue}>
                    {ownerUser?.name || contract.owner_name || 'Owner'}
                  </Text>
                  <Text style={styles.smallMeta}>
                    {ownerUser?.email || contract.owner_email || ''}
                  </Text>
                </View>
              </View>
            </View>
          </View>

          {(contract as any).terms_conditions && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Terms & Conditions</Text>
              <Text style={styles.termsText}>
                {(contract as any).terms_conditions}
              </Text>
            </View>
          )}

          <View style={styles.actionSection}>
            <ModernButton
              title="Chat with Other Party"
              iconName="message-text-outline"
              onPress={handleChatPress}
              variant="primary"
              style={styles.chatButton}
            />
            <ModernButton
              title="Back to Contracts"
              onPress={() => navigation.goBack()}
              variant="outline"
            />
          </View>
        </View>
      </ScrollView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 18,
    color: '#666',
    textAlign: 'center',
  },
  contractCard: {
    backgroundColor: '#FFFFFF',
    margin: 16,
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  headerLeft: {
    flex: 1,
  },
  subTitleText: {
    fontSize: 13,
    color: '#666',
    marginTop: 4,
  },
  leaseImage: {
    width: '100%',
    height: 180,
    borderRadius: 10,
    marginBottom: 16,
    resizeMode: 'cover',
  },
  leaseImagePlaceholder: {
    width: '100%',
    height: 180,
    borderRadius: 10,
    backgroundColor: '#F0F0F0',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  placeholderText: {
    color: '#999',
    fontSize: 14,
  },
  partyRow: {
    alignItems: 'center',
  },
  partyInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  smallAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    marginRight: 8,
    backgroundColor: '#EEE',
  },
  partyTextWrap: {
    flex: 1,
  },
  smallMeta: {
    fontSize: 12,
    color: '#777',
  },
  contractHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  multipleCarousel: {
    marginTop: 12,
    marginBottom: 12,
  },
  carouselImage: {
    width: 200,
    height: 120,
    borderRadius: 8,
    marginRight: 8,
    resizeMode: 'cover',
    backgroundColor: '#EEE',
  },
  contractTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginRight: 12,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    marginBottom: 8,
    alignItems: 'flex-start',
  },
  detailLabel: {
    fontSize: 14,
    color: '#666',
    fontWeight: '600',
    width: 120,
    flexShrink: 0,
  },
  detailValue: {
    fontSize: 14,
    color: '#333',
    flex: 1,
  },
  priceText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  termsText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
    backgroundColor: '#F9F9F9',
    padding: 12,
    borderRadius: 8,
  },
  actionSection: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
  chatButton: {
    marginBottom: 12,
  },
});

export default ContractDetailsScreen;
