import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  RefreshControl,
  Image,
  StyleProp,
  TextStyle,
  ViewStyle,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../../types';

interface LeaseContractWithDetails {
  id: number;
  lease_id: number;
  tenant_id: string;
  owner_id: string;
  contract_amount: number;
  start_date: string;
  end_date: string;
  terms_conditions?: string;
  status: 'active' | 'completed' | 'terminated' | 'expired';
  signed_date?: string;
  created_at?: string;
  // Snapshot fields for lease data
  lease_title?: string;
  lease_location?: string;
  lease_description?: string;
  lease_area?: number;
  lease_soil_type?: string;
  lease_water_source?: string;
  lease_crop_suitability?: string;
  lease_distance?: number;
  lease_rating?: number;
  lease_image_url?: string;
  multiple_image_url?: string[];
  lease_duration?: number | null;
  lease_current_status?:
    | 'available'
    | 'active'
    | 'completed'
    | 'terminated'
    | 'expired'
    | null;
  // User information
  tenant_name?: string;
  tenant_email?: string;
  owner_name?: string;
  owner_email?: string;
  // Backward compatibility
  leases?: {
    title?: string;
    location?: string;
    description?: string;
    status?: string;
  };
  tenant?: {
    name?: string;
    email?: string;
  };
  owner?: {
    name?: string;
    email?: string;
  };
}
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import ModernButton from '../../../components/ModernButton';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type MyContractsScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'MyContracts'
>;

const MyContractsScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<MyContractsScreenNavigationProp>();
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [contracts, setContracts] = useState<LeaseContractWithDetails[]>([]);
  const [userId, setUserId] = useState<number>(0);

  const db = dbManager;

  const loadContracts = useCallback(async () => {
    try {
      const currentUser = await authManager.getCurrentUser();
      if (!currentUser || !currentUser.id) {
        Alert.alert('Error', 'User not found');
        navigation.goBack();
        return;
      }

      setUserId(currentUser.id);
      const contractsList = await db.getLeaseContracts(
        currentUser.id,
        currentUser.role,
      );

      // Fetch live lease status for each contract to decide reclaim button visibility
      const withLeaseStatus = await Promise.all(
        (contractsList || []).map(async (c: any) => {
          try {
            const lease = await db.getLandLeaseById(c.lease_id);
            return { ...c, lease_current_status: lease?.status || null };
          } catch (e) {
            return { ...c, lease_current_status: null };
          }
        }),
      );

      setContracts(withLeaseStatus);
    } catch (error) {
      console.error('Error loading contracts:', error);
      Alert.alert('Error', 'Failed to load lease contracts');
    }
  }, [db, navigation, authManager]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadContracts();
    setRefreshing(false);
  }, [loadContracts]);

  useEffect(() => {
    const loadData = async () => {
      setIsLoading(true);
      await loadContracts();
      setIsLoading(false);
    };
    loadData();
  }, [loadContracts]);

  const handleStatusUpdate = async (
    contractId: number,
    newStatus: 'active' | 'completed' | 'terminated' | 'expired',
  ) => {
    console.log('[DEBUG] handleStatusUpdate called', { contractId, newStatus });
    try {
      console.log('[DEBUG] Calling db.updateLeaseContract', {
        contractId,
        newStatus,
      });
      // Fetch contract before update
      const before = await db.getLeaseContractById(contractId);
      console.log('[DEBUG] Contract before update:', before);
      const updateResult = await db.updateLeaseContract(contractId, {
        status: newStatus,
      });
      console.log('[DEBUG] updateLeaseContract result:', updateResult);
      // Fetch contract after update
      const after = await db.getLeaseContractById(contractId);
      console.log('[DEBUG] Contract after update:', after);
      Alert.alert('Success', `Contract status updated to ${newStatus}`);
      await loadContracts();
    } catch (error) {
      console.error('[DEBUG] Error updating contract status:', error);
      Alert.alert('Error', 'Failed to update contract status');
    }
  };

  // Handler to reclaim property (set land lease status to 'available')
  const handleReclaimProperty = async (leaseId: number) => {
    try {
      console.log('[DEBUG] handleReclaimProperty called', { leaseId });
      await db.updateLandLease(leaseId, { status: 'available' });
      Alert.alert(
        'Success',
        'Property reclaimed and available for new leases.',
      );
      await loadContracts();
    } catch (error) {
      console.error('[DEBUG] Error reclaiming property:', error);
      Alert.alert('Error', 'Failed to reclaim property');
    }
  };

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'active':
        return { backgroundColor: '#E8F5E9', borderColor: '#4CAF50' };
      case 'completed':
        return { backgroundColor: '#E3F2FD', borderColor: '#2196F3' };
      case 'terminated':
        return { backgroundColor: '#FFEBEE', borderColor: '#F44336' };
      case 'expired':
        return { backgroundColor: '#FFF9C4', borderColor: '#FF9800' };
      default:
        return { backgroundColor: '#F5F5F5', borderColor: '#9E9E9E' };
    }
  };

  const getStatusTextColor = (status: string) => {
    switch (status) {
      case 'active':
        return '#2E7D32';
      case 'completed':
        return '#1976D2';
      case 'terminated':
        return '#C62828';
      case 'expired':
        return '#F57C00';
      default:
        return '#424242';
    }
  };

  const isContractOwner = (contract: LeaseContractWithDetails) => {
    return contract.owner_id === String(userId);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const renderDetailRow = (
    iconName: string,
    text: string,
    options?: {
      textStyle?: StyleProp<TextStyle>;
      containerStyle?: StyleProp<ViewStyle>;
      iconColor?: string;
    },
  ) => {
    const { textStyle, containerStyle, iconColor } = options || {};
    return (
      <View style={[styles.detailRow, containerStyle]}>
        <MaterialCommunityIcons
          name={iconName}
          size={18}
          color={iconColor ?? '#795548'}
          style={styles.detailIcon}
        />
        <Text style={[styles.detailText, textStyle]}>{text}</Text>
      </View>
    );
  };

  if (isLoading) {
    return (
      <Layout activeTab="dashboard">
        <ModernLoading visible={true} message="Loading contracts..." />
      </Layout>
    );
  }

  return (
    <Layout activeTab="dashboard">
      <ModernHeader
        title="My Contracts"
        subtitle="Manage your lease contracts"
        leftIconName="arrow-left"
        onLeftPress={() => navigation.goBack()}
        rightIconName="clipboard-text-outline"
        onRightPress={() => navigation.navigate('LeaseApplicationList')}
      />

      <ScrollView
        style={styles.container}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {contracts.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No lease contracts found</Text>
            <Text style={styles.emptySubtext}>
              Your lease contracts will appear here
            </Text>
          </View>
        ) : (
          contracts.map(contract => (
            <View key={contract.id} style={styles.contractCard}>
              <View style={styles.contractHeader}>
                <Text style={styles.leaseTitle}>
                  {contract.lease_title || 'Untitled Lease'}
                </Text>
                <View
                  style={[styles.statusBadge, getStatusStyle(contract.status)]}
                >
                  <Text
                    style={[
                      styles.statusText,
                      { color: getStatusTextColor(contract.status) },
                    ]}
                  >
                    {contract.status.toUpperCase()}
                  </Text>
                </View>
              </View>

              <View style={styles.contractDetails}>
                {renderDetailRow(
                  'map-marker-outline',
                  `Location: ${contract.lease_location || '-'}`,
                )}
                {renderDetailRow(
                  'cash-multiple',
                  `Monthly Amount: ৳${contract.contract_amount}/month`,
                )}
                {contract.lease_duration != null &&
                  renderDetailRow(
                    'clock-outline',
                    `Duration: ${contract.lease_duration} months`,
                  )}
                {renderDetailRow(
                  'account-outline',
                  `${isContractOwner(contract) ? 'Tenant' : 'Owner'}: ${
                    isContractOwner(contract)
                      ? contract.tenant_name || contract.tenant?.name || '-'
                      : contract.owner_name || contract.owner?.name || '-'
                  }`,
                )}
                {renderDetailRow(
                  'calendar-range',
                  `Dates: ${formatDate(contract.start_date)} - ${formatDate(
                    contract.end_date,
                  )}`,
                )}
                {renderDetailRow(
                  'file-document-edit-outline',
                  `Signed: ${formatDate(
                    contract.signed_date || contract.created_at || '',
                  )}`,
                )}
                {contract.terms_conditions && (
                  <Text style={styles.termsText}>
                    Terms: {contract.terms_conditions}
                  </Text>
                )}
              </View>

              {/* Only tenant (applicant) can mark contract as completed or terminated */}
              {contract.status === 'active' &&
                contract.tenant_id === String(userId) && (
                  <View style={styles.actionButtons}>
                    <ModernButton
                      title="Mark Completed"
                      onPress={() =>
                        handleStatusUpdate(contract.id!, 'completed')
                      }
                      variant="primary"
                      size="small"
                      style={styles.actionButton}
                    />
                    <ModernButton
                      title="Terminate"
                      onPress={() => {
                        Alert.alert(
                          'Terminate Contract',
                          'Are you sure you want to terminate this contract?',
                          [
                            { text: 'Cancel', style: 'cancel' },
                            {
                              text: 'Terminate',
                              style: 'destructive',
                              onPress: () =>
                                handleStatusUpdate(contract.id!, 'terminated'),
                            },
                          ],
                        );
                      }}
                      variant="outline"
                      size="small"
                      style={styles.actionButton}
                    />
                  </View>
                )}

              <View style={styles.viewDetailsSection}>
                <ModernButton
                  title="View Details"
                  onPress={() =>
                    navigation.navigate('ContractDetails', {
                      contractId: contract.id!,
                    })
                  }
                  variant="outline"
                  size="small"
                />
                {/* Show small multiple images preview if available */}
                {contract.multiple_image_url &&
                  contract.multiple_image_url.length > 0 && (
                    <ScrollView
                      horizontal
                      showsHorizontalScrollIndicator={false}
                      style={styles.multiplePreview}
                    >
                      {contract.multiple_image_url.map((img, idx) => (
                        <View key={idx} style={styles.previewImageWrap}>
                          <Image
                            source={{ uri: img }}
                            style={styles.previewImage}
                          />
                        </View>
                      ))}
                    </ScrollView>
                  )}
                {/* Show Reclaim Property button for completed/terminated contracts where user is owner */}
                {(contract.status === 'completed' ||
                  contract.status === 'terminated') &&
                  isContractOwner(contract) &&
                  // Show reclaim only when the live lease record exists and
                  // its status is not 'available'. If the lease record is
                  // missing (deleted), do not show the reclaim button.
                  contract.lease_current_status !== null &&
                  contract.lease_current_status !== undefined &&
                  contract.lease_current_status !== 'available' && (
                    <ModernButton
                      title="Reclaim Property"
                      onPress={() => handleReclaimProperty(contract.lease_id)}
                      variant="primary"
                      size="small"
                      style={{ marginTop: 10 }}
                    />
                  )}
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 8,
    textAlign: 'center',
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
    textAlign: 'center',
  },
  contractCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 16,
    marginBottom: 16,
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  contractHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  leaseTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    flex: 1,
    marginRight: 12,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  contractDetails: {
    marginBottom: 16,
  },
  detailText: {
    fontSize: 14,
    color: '#666',
    flex: 1,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  detailIcon: {
    marginRight: 8,
  },
  termsText: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
    fontStyle: 'italic',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 12,
  },
  actionButton: {
    flex: 1,
  },
  viewDetailsSection: {
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    paddingTop: 12,
  },
  multiplePreview: {
    marginTop: 10,
    flexDirection: 'row',
  },
  previewImageWrap: {
    marginRight: 8,
  },
  previewImage: {
    width: 64,
    height: 64,
    borderRadius: 8,
    backgroundColor: '#EEE',
  },
});

export default MyContractsScreen;
