import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
  Image,
} from 'react-native';
import {
  useNavigation,
  useRoute,
  RouteProp,
  useFocusEffect,
} from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, Message } from '../../../types';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import ModernLoading from '../../../components/ModernLoading';
import Layout from '../../../components/Layout';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import { useMessageNotifications } from '../../../contexts/MessageNotificationContext';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type ChatRoomNavigationProp = StackNavigationProp<
  RootStackParamList,
  'ChatRoom'
>;

type ChatRoomRouteProp = RouteProp<RootStackParamList, 'ChatRoom'>;

const ChatRoomScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<ChatRoomNavigationProp>();
  const route = useRoute<ChatRoomRouteProp>();
  const { otherUserId, otherUserName, roomId } = route.params;

  // Use string for UUIDs (Supabase uses UUID strings)
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(true);
  const [sending, setSending] = useState<boolean>(false);
  const [otherProfileImage, setOtherProfileImage] = useState<string | null>(
    null,
  );

  const flatListRef = useRef<FlatList>(null);
  const { setActiveRoom, markRoomRead } = useMessageNotifications();

  const { width: SCREEN_WIDTH } = Dimensions.get('window');
  const basePadding = SCREEN_WIDTH < 400 ? 10 : 16;
  const baseFont = SCREEN_WIDTH < 400 ? 14 : 16;
  const loadMessages = useCallback(async () => {
    try {
      const user = await authManager.getCurrentUser();
      if (!user?.id) {
        Alert.alert('Error', 'Please log in to view messages');
        navigation.goBack();
        return;
      }

      // Alert: ensure route provided otherUserId is valid
      if (
        otherUserId === undefined ||
        otherUserId === null ||
        String(otherUserId).trim() === '' ||
        String(otherUserId) === 'undefined' ||
        String(otherUserId) === 'null'
      ) {
        Alert.alert('Error', 'Invalid chat user.');
        navigation.goBack();
        return;
      }

      setCurrentUserId(String(user.id));
      const conversation = await dbManager.getConversation(
        String(user.id),
        String(otherUserId),
      );
      setMessages(conversation); // Sorting order: old messages first, new messages last
      if (roomId) {
        markRoomRead(roomId).catch(error =>
          console.warn('ChatRoomScreen: markRoomRead failed', error),
        );
      }

      // Fetch other user's profile image for header avatar
      try {
        const otherUser = await dbManager.getUserById(String(otherUserId));
        setOtherProfileImage(otherUser?.profile_image_url || null);
      } catch (err) {
        console.error('Error fetching other user profile:', err);
        setOtherProfileImage(null);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
      Alert.alert('Error', 'Failed to load messages');
    } finally {
      setLoading(false);
    }
  }, [authManager, dbManager, markRoomRead, navigation, otherUserId, roomId]);
  useFocusEffect(
    useCallback(() => {
      if (roomId) {
        setActiveRoom(roomId);
        markRoomRead(roomId).catch(error =>
          console.warn('ChatRoomScreen: markRoomRead on focus failed', error),
        );
      }
      return () => {
        setActiveRoom(null);
      };
    }, [markRoomRead, roomId, setActiveRoom]),
  );

  useEffect(() => {
    loadMessages();
  }, [loadMessages]);

  // Auto-scroll to bottom when messages are loaded initially
  useEffect(() => {
    if (!loading && messages.length > 0 && flatListRef.current) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: false });
      }, 200);
    }
  }, [loading, messages.length]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (messages.length > 0 && flatListRef.current) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !currentUserId || sending) return;

    const messageText = newMessage.trim();
    try {
      setSending(true);
      setNewMessage('');

      // otherUserId was validated in loadMessages so we can safely assert it's non-null here
      await dbManager.createMessage(
        String(currentUserId),
        String(otherUserId),
        messageText,
      );

      // Reload messages to get the new one
      await loadMessages();
    } catch (error) {
      console.error('Error sending message:', error);
      Alert.alert('Error', 'Failed to send message');
      setNewMessage(messageText); // Restore the message
    } finally {
      setSending(false);
    }
  };

  const formatMessageTime = (timestamp: string): string => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      });
    } else if (diffInHours < 48) {
      return `Yesterday ${date.toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      })}`;
    } else {
      return date.toLocaleDateString();
    }
  };

  const renderMessage = ({ item }: { item: Message }) => {
    // Compare as strings since currentUserId is stored as a string UUID
    const isMyMessage = String(item.sender_id) === String(currentUserId);
    return (
      <View
        style={[
          styles.messageRow,
          isMyMessage ? styles.myMessageRow : styles.otherMessageRow,
        ]}
      >
        <View
          style={[
            styles.messageCard,
            isMyMessage ? styles.myMessageCard : styles.otherMessageCard,
          ]}
        >
          <Text
            style={[
              styles.messageText,
              isMyMessage ? styles.myMessageText : styles.otherMessageText,
            ]}
          >
            {item.content}
          </Text>
          <Text
            style={[
              styles.messageTime,
              isMyMessage ? styles.myMessageTime : styles.otherMessageTime,
            ]}
          >
            {formatMessageTime(item.timestamp || item.created_at || '')}
          </Text>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Loading messages..." />
      </Layout>
    );
  }

  return (
    <Layout activeTab="chat" showBottomNavigation={false}>
      {/* Custom Header to match reference screens */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
            activeOpacity={0.7}
          >
            <MaterialCommunityIcons
              name="arrow-left"
              size={20}
              color="#4CAF50"
            />
          </TouchableOpacity>
          <Text style={styles.headerTitle} numberOfLines={1}>
            {otherUserName || 'Chat'}
          </Text>
          <TouchableOpacity
            style={styles.storeButton}
            onPress={() => {
              navigation.navigate('UserProfile', {
                userId: otherUserId,
              });
            }}
            activeOpacity={0.7}
          >
            {otherProfileImage ? (
              <Image
                source={{ uri: otherProfileImage }}
                style={styles.profileSmall}
              />
            ) : (
              <View style={styles.profileSmallFallback}>
                <Text style={styles.profileSmallFallbackText}>
                  {otherUserName ? otherUserName.charAt(0).toUpperCase() : 'U'}
                </Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 88 : 0}
      >
        <View style={styles.messagesContainer}>
          {messages.length === 0 ? (
            <View style={styles.emptyState}>
              <MaterialCommunityIcons
                name="chat-outline"
                size={54}
                color="#E0E0E0"
                style={styles.emptyStateIcon}
              />
              <Text style={styles.emptyStateText}>No messages yet</Text>
              <Text style={styles.emptyStateSubtext}>
                Start a conversation with {otherUserName || 'this user'}
              </Text>
            </View>
          ) : (
            <FlatList
              ref={flatListRef}
              data={messages}
              renderItem={renderMessage}
              keyExtractor={(item, index) => `${item.id || index}`}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={styles.messagesList}
              onContentSizeChange={() =>
                flatListRef.current?.scrollToEnd({ animated: false })
              }
            />
          )}
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.textInput}
            placeholder={`Message ${otherUserName || 'user'}...`}
            placeholderTextColor="#888"
            value={newMessage}
            onChangeText={setNewMessage}
            multiline
            maxLength={1000}
            returnKeyType="send"
            onSubmitEditing={handleSendMessage}
            blurOnSubmit={false}
          />
          <TouchableOpacity
            style={[
              styles.sendButton,
              (!newMessage.trim() || sending) && styles.sendButtonDisabled,
            ]}
            onPress={handleSendMessage}
            disabled={!newMessage.trim() || sending}
            activeOpacity={0.7}
          >
            <MaterialCommunityIcons
              name={sending ? 'progress-clock' : 'send'}
              size={20}
              color={!newMessage.trim() || sending ? '#999999' : '#FFFFFF'}
              style={styles.sendButtonIcon}
            />
          </TouchableOpacity>
        </View>
        <View style={styles.bottomPadding} />
      </KeyboardAvoidingView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  storeButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  storeButtonIcon: {
    fontSize: 22,
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  profileSmall: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  profileSmallFallback: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileSmallFallbackText: {
    color: '#fff',
    fontWeight: '700',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1A',
    textAlign: 'center',
    flex: 1,
    marginHorizontal: 8,
  },
  messagesContainer: {
    flex: 1,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyStateIcon: {
    marginBottom: 10,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#999',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
  messagesList: {
    padding: 16,
    paddingBottom: 8,
  },
  messageRow: {
    flexDirection: 'row',
    marginBottom: 14,
    width: '100%',
  },
  myMessageRow: {
    justifyContent: 'flex-end',
  },
  otherMessageRow: {
    justifyContent: 'flex-start',
  },
  messageCard: {
    maxWidth: '80%',
    borderRadius: 16,
    paddingVertical: 12,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
    minWidth: 60,
  },
  myMessageCard: {
    backgroundColor: '#4CAF50',
    borderTopRightRadius: 4,
    alignSelf: 'flex-end',
  },
  otherMessageCard: {
    backgroundColor: '#fff',
    borderTopLeftRadius: 4,
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  messageText: {
    fontSize: 15,
    lineHeight: 20,
    marginBottom: 4,
  },
  myMessageText: {
    color: '#fff',
  },
  otherMessageText: {
    color: '#333',
  },
  messageTime: {
    fontSize: 11,
    opacity: 0.7,
    marginTop: 2,
  },
  myMessageTime: {
    color: '#fff',
    textAlign: 'right',
  },
  otherMessageTime: {
    color: '#666',
    textAlign: 'left',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginRight: 12,
    maxHeight: 100,
    fontSize: 16,
    backgroundColor: '#f9f9f9',
    color: '#222',
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 2,
    elevation: 2,
  },
  sendButtonDisabled: {
    backgroundColor: '#ccc',
  },
  sendButtonIcon: {
    marginTop: 0,
  },
  bottomPadding: {
    height: 24,
  },
});

export default ChatRoomScreen;
