import React, { useEffect, useState, useMemo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import Layout from '../../../components/Layout';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import { RootStackParamList } from '../../../types';
import BrowseFarmersScreen from './BrowseFarmersScreen';
import BrowseConsumersScreen from './BrowseConsumersScreen';

type FarmersToConsumersNavProp = StackNavigationProp<
  RootStackParamList,
  'FarmersToConsumers'
>;

type DirectoryTab = 'farmers' | 'consumers';

const FarmersToConsumersScreen: React.FC = () => {
  const navigation = useNavigation<FarmersToConsumersNavProp>();
  const authManager = SupabaseAuthManager.getInstance();

  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [activeTab, setActiveTab] = useState<DirectoryTab>('farmers');
  const [loadingUser, setLoadingUser] = useState<boolean>(true);

  useEffect(() => {
    let isMounted = true;

    const loadUser = async () => {
      try {
        const user = await authManager.getCurrentUser();
        if (isMounted) {
          setCurrentUser(user || null);
        }
      } catch (error) {
        console.warn(
          'FarmersToConsumersScreen: failed to load current user',
          error,
        );
      } finally {
        if (isMounted) {
          setLoadingUser(false);
        }
      }
    };

    loadUser();

    return () => {
      isMounted = false;
    };
  }, [authManager]);

  const renderActiveDirectory = useMemo(() => {
    if (activeTab === 'farmers') {
      return <BrowseFarmersScreen embedded />;
    }
    return <BrowseConsumersScreen embedded />;
  }, [activeTab]);

  const handleAvatarPress = () => {
    if (!currentUser?.id) return;
    navigation.navigate('UserProfile', { userId: String(currentUser.id) });
  };

  const handleBackPress = () => {
    navigation.goBack();
  };

  return (
    <Layout activeTab="dashboard">
      <ModernHeader
        title="Farmers & Consumers"
        leftIconName="arrow-left"
        onLeftPress={handleBackPress}
        rightAvatarUrl={currentUser?.profile_image_url}
        rightAvatarName={currentUser?.name}
        onRightPress={handleAvatarPress}
      />

      <View style={styles.container}>
        <View style={styles.tabBar}>
          <TouchableOpacity
            style={[
              styles.tabButton,
              activeTab === 'farmers' && styles.tabButtonActive,
            ]}
            onPress={() => setActiveTab('farmers')}
            activeOpacity={0.85}
          >
            <Text
              style={[
                styles.tabButtonText,
                activeTab === 'farmers' && styles.tabButtonTextActive,
              ]}
            >
              Farmers
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.tabButton,
              activeTab === 'consumers' && styles.tabButtonActive,
            ]}
            onPress={() => setActiveTab('consumers')}
            activeOpacity={0.85}
          >
            <Text
              style={[
                styles.tabButtonText,
                activeTab === 'consumers' && styles.tabButtonTextActive,
              ]}
            >
              Consumers
            </Text>
          </TouchableOpacity>
        </View>

        {loadingUser ? (
          <View style={styles.loaderContainer}>
            <ModernLoading visible message="Preparing directory..." />
          </View>
        ) : (
          <View style={styles.directoryContainer}>{renderActiveDirectory}</View>
        )}
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  tabBar: {
    flexDirection: 'row',
    marginHorizontal: 20,
    marginTop: 20,
    backgroundColor: '#E3F2FD',
    borderRadius: 16,
    padding: 4,
    marginBottom: 10,
  },
  tabButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 12,
    alignItems: 'center',
  },
  tabButtonActive: {
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 2,
  },
  tabButtonText: {
    fontSize: 15,
    fontWeight: '600',
    color: '#0D47A1',
  },
  tabButtonTextActive: {
    color: '#1A237E',
  },
  tabDescriptionContainer: {
    paddingHorizontal: 24,
    paddingVertical: 16,
  },
  tabDescription: {
    fontSize: 14,
    color: '#546E7A',
    lineHeight: 20,
  },
  directoryContainer: {
    flex: 1,
    paddingHorizontal: 0,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 24,
  },
});

export default FarmersToConsumersScreen;
