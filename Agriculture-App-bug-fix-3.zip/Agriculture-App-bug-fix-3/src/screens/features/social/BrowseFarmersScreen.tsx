import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Image,
  TextInput,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, User } from '../../../types';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import Layout from '../../../components/Layout';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import SupabaseDatabaseManager, {
  FarmerAggregateStats,
} from '../../../api/SupabaseDatabaseManager';
import { buildRoomId } from '../../../utils';

type BrowseFarmersNavigationProp = StackNavigationProp<
  RootStackParamList,
  'BrowseFarmers'
>;

type FarmerMetrics = FarmerAggregateStats & {
  score: number;
  rank: number;
};

type FarmerWithMetrics = User & {
  metrics: FarmerMetrics;
};

interface BrowseFarmersScreenProps {
  embedded?: boolean;
  [key: string]: unknown;
}

const BrowseFarmersScreen: React.FC<BrowseFarmersScreenProps> = ({
  embedded = false,
}) => {
  const authManager = SupabaseAuthManager.getInstance();

  const navigation = useNavigation<BrowseFarmersNavigationProp>();
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [farmers, setFarmers] = useState<FarmerWithMetrics[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [followingStatus, setFollowingStatus] = useState<
    Record<string, boolean>
  >({});
  const [expandedFarmers, setExpandedFarmers] = useState<
    Record<string, boolean>
  >({});

  // DB manager instance
  const dbManager = SupabaseDatabaseManager.getInstance();

  const computeRankings = useCallback(
    (entries: FarmerWithMetrics[]): FarmerWithMetrics[] => {
      if (entries.length === 0) return [];

      const productMax = Math.max(
        ...entries.map(f => f.metrics.productCount),
        0,
      );
      const leaseMax = Math.max(...entries.map(f => f.metrics.leaseCount), 0);
      const followerMax = Math.max(
        ...entries.map(f => f.metrics.followerCount),
        0,
      );
      const salesMax = Math.max(
        ...entries.map(f => f.metrics.totalSoldQuantity),
        0,
      );

      const normalize = (value: number, max: number, weight: number) => {
        if (!Number.isFinite(value) || value <= 0 || max <= 0) return 0;
        return (value / max) * weight;
      };

      const weightedEntries = entries
        .map(farmer => {
          const { metrics } = farmer;
          const rawScore =
            normalize(metrics.productCount, productMax, 20) +
            normalize(metrics.leaseCount, leaseMax, 15) +
            normalize(metrics.followerCount, followerMax, 35) +
            normalize(metrics.totalSoldQuantity, salesMax, 30);

          const safeScore = Number.isFinite(rawScore) ? rawScore : 0;
          const roundedScore = Math.round(safeScore * 10) / 10;

          return {
            ...farmer,
            metrics: { ...metrics, score: roundedScore, rank: 0 },
          };
        })
        .sort((a, b) => {
          if (b.metrics.score === a.metrics.score) {
            const nameA = (a.name || '').toLowerCase();
            const nameB = (b.name || '').toLowerCase();
            return nameA.localeCompare(nameB);
          }
          return b.metrics.score - a.metrics.score;
        });

      return weightedEntries.map((farmer, index) => ({
        ...farmer,
        metrics: { ...farmer.metrics, rank: index + 1 },
      }));
    },
    [],
  );

  const loadFarmers = useCallback(async () => {
    try {
      setLoading(true);
      const user = await authManager.getCurrentUser();
      if (!user) {
        Alert.alert('Error', 'Please log in to browse farmers');
        navigation.goBack();
        return;
      }

      setCurrentUser(user || null);

      // Get all farmers except the current user
      const allFarmers = await dbManager.getUsersByRole('farmer');
      const otherFarmers = allFarmers.filter(
        (farmer: User) => farmer.id !== user.id,
      );

      const defaultStats: FarmerAggregateStats = {
        productCount: 0,
        leaseCount: 0,
        followerCount: 0,
        followingCount: 0,
        totalSoldQuantity: 0,
        topProductName: null,
        topProductQuantity: 0,
      };

      const farmerEntriesPromises = otherFarmers.map(async farmer => {
        const farmerId =
          typeof farmer.id === 'string'
            ? farmer.id
            : farmer.id?.toString() || '';

        let aggregatedStats: FarmerAggregateStats = { ...defaultStats };
        if (farmerId) {
          try {
            aggregatedStats = await dbManager.getFarmerAggregateStats(farmerId);
          } catch (err) {
            console.warn('loadFarmers metric fetch failed', err);
            aggregatedStats = { ...defaultStats };
          }
        }

        return {
          ...farmer,
          metrics: { ...aggregatedStats, score: 0, rank: 0 },
        } as FarmerWithMetrics;
      });

      const farmersWithMetricsRaw = await Promise.all(farmerEntriesPromises);
      const rankedFarmers = computeRankings(farmersWithMetricsRaw);
      setFarmers(rankedFarmers);

      const followStatusEntries = await Promise.all(
        rankedFarmers.map(async farmer => {
          const farmerId =
            typeof farmer.id === 'string'
              ? farmer.id
              : farmer.id?.toString() || '';
          if (!farmerId) return [farmerId, false] as [string, boolean];
          try {
            const status = await dbManager.isFollowing(farmerId);
            return [farmerId, status] as [string, boolean];
          } catch (err) {
            console.warn('loadFarmers follow status error', err);
            return [farmerId, false] as [string, boolean];
          }
        }),
      );

      const statusMap = Object.fromEntries(
        followStatusEntries.filter(([farmerId]) => farmerId),
      );
      setFollowingStatus(statusMap);
    } catch (error) {
      console.error('Error loading farmers:', error);
      Alert.alert('Error', 'Failed to load farmers');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [authManager, dbManager, navigation, computeRankings]);

  useEffect(() => {
    loadFarmers();
  }, [loadFarmers]);

  // Filtered list based on search query (name, email)
  const filteredFarmers = farmers.filter(f => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    const name = (f.name || '').toLowerCase();
    const email = (f.email || '').toLowerCase();
    return name.includes(q) || email.includes(q);
  });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadFarmers();
  }, [loadFarmers]);

  const toggleFarmerExpansion = (farmerId: string) => {
    if (!farmerId) return;
    setExpandedFarmers(prev => ({
      ...prev,
      [farmerId]: !prev[farmerId],
    }));
  };

  const handleFollow = async (farmer: FarmerWithMetrics) => {
    if (!currentUser || !farmer.id) return;

    const currentUserId =
      typeof currentUser.id === 'string'
        ? currentUser.id
        : currentUser.id?.toString() || '';
    const farmerId =
      typeof farmer.id === 'string' ? farmer.id : farmer.id?.toString() || '';
    if (!currentUserId || !farmerId) return;

    try {
      const isCurrentlyFollowing = followingStatus[farmerId];
      if (isCurrentlyFollowing) {
        await dbManager.unfollowFarmer(farmerId);
        setFollowingStatus(prev => ({ ...prev, [farmerId]: false }));
        setFarmers(prev => {
          const updated = prev.map(entry => {
            const entryId =
              typeof entry.id === 'string'
                ? entry.id
                : entry.id?.toString() || '';
            if (entryId !== farmerId) return entry;
            const newFollowerCount = Math.max(
              0,
              entry.metrics.followerCount - 1,
            );
            return {
              ...entry,
              metrics: { ...entry.metrics, followerCount: newFollowerCount },
            };
          });
          return computeRankings(updated);
        });
        Alert.alert('Success', `You unfollowed ${farmer.name}`);
      } else {
        await dbManager.followFarmer(farmerId);
        setFollowingStatus(prev => ({ ...prev, [farmerId]: true }));
        setFarmers(prev => {
          const updated = prev.map(entry => {
            const entryId =
              typeof entry.id === 'string'
                ? entry.id
                : entry.id?.toString() || '';
            if (entryId !== farmerId) return entry;
            return {
              ...entry,
              metrics: {
                ...entry.metrics,
                followerCount: entry.metrics.followerCount + 1,
              },
            };
          });
          return computeRankings(updated);
        });
        Alert.alert('Success', `You are now following ${farmer.name}`);
      }
    } catch (error) {
      console.error('Error updating follow status:', error);
      Alert.alert('Error', 'Failed to update follow status');
    }
  };

  const handleChat = (farmer: FarmerWithMetrics) => {
    if (!currentUser || !farmer.id) return;

    const currentUserId =
      typeof currentUser.id === 'string'
        ? currentUser.id
        : currentUser.id?.toString() || '';
    const farmerId =
      typeof farmer.id === 'string' ? farmer.id : farmer.id?.toString() || '';
    if (!currentUserId || !farmerId) return;

    const roomId = buildRoomId(currentUserId, farmerId);
    navigation.navigate('ChatRoom', {
      roomId,
      otherUserId: farmerId, // always string
      otherUserName: farmer.name,
    });
  };

  const handleViewProducts = (farmer: FarmerWithMetrics) => {
    if (farmer.id) {
      const farmerId =
        typeof farmer.id === 'string' ? farmer.id : farmer.id?.toString() || '';
      navigation.navigate('UserProfile', { userId: farmerId });
    }
  };

  const renderFarmerItem = ({ item }: { item: FarmerWithMetrics }) => {
    const itemId =
      typeof item.id === 'string' ? item.id : item.id?.toString() || '';
    if (!itemId) {
      return null;
    }
    const isFollowing = followingStatus[itemId] || false;
    const isExpanded = !!expandedFarmers[itemId];
    const { metrics } = item;

    const formatMetric = (value: number) => {
      if (!Number.isFinite(value)) return '0';
      return Math.round(value).toLocaleString();
    };

    return (
      <View
        style={[
          styles.farmerCard,
          metrics.rank === 1 && styles.topFarmerCardGold,
          metrics.rank === 2 && styles.topFarmerCardSilver,
          metrics.rank === 3 && styles.topFarmerCardBronze,
        ]}
      >
        <TouchableOpacity
          style={styles.cardSummary}
          onPress={() => toggleFarmerExpansion(itemId)}
          activeOpacity={0.85}
        >
          <View style={styles.summaryContent}>
            <View style={styles.rankRow}>
              <View
                style={[
                  styles.rankBadge,
                  metrics.rank === 1 && styles.rankBadgeGold,
                  metrics.rank === 2 && styles.rankBadgeSilver,
                  metrics.rank === 3 && styles.rankBadgeBronze,
                ]}
              >
                <Text style={styles.rankText}>#{metrics.rank}</Text>
              </View>
              <View style={styles.scoreContainer}>
                <Text style={styles.scoreLabel}>Score</Text>
                <Text style={styles.scoreValue}>
                  {metrics.score.toFixed(1)}
                </Text>
                <Text style={styles.scoreOutOf}>/100</Text>
              </View>
            </View>

            <View style={styles.farmerHeader}>
              {item.profile_image_url ? (
                <Image
                  source={{ uri: item.profile_image_url }}
                  style={styles.avatarImage}
                />
              ) : (
                <View style={styles.avatar}>
                  <Text style={styles.avatarText}>
                    {item.name.charAt(0).toUpperCase()}
                  </Text>
                </View>
              )}
              <View style={styles.farmerInfo}>
                <Text style={styles.farmerName}>{item.name}</Text>
                <Text style={styles.farmerLabel}>Farmer</Text>
                {item.email && (
                  <Text style={styles.farmerEmail}>{item.email}</Text>
                )}
              </View>
            </View>
          </View>

          <MaterialCommunityIcons
            name={isExpanded ? 'chevron-up' : 'chevron-down'}
            size={24}
            color="#4CAF50"
            style={styles.expandIcon}
          />
        </TouchableOpacity>

        {isExpanded && (
          <View style={styles.detailsContainer}>
            <View style={styles.metricsRow}>
              <View style={styles.metricCard}>
                <Text style={styles.metricValue}>
                  {formatMetric(metrics.productCount)}
                </Text>
                <Text style={styles.metricLabel}>Products</Text>
              </View>
              <View style={styles.metricCard}>
                <Text style={styles.metricValue}>
                  {formatMetric(metrics.leaseCount)}
                </Text>
                <Text style={styles.metricLabel}>Lease Lands</Text>
              </View>
              <View style={styles.metricCard}>
                <Text style={styles.metricValue}>
                  {formatMetric(metrics.followerCount)}
                </Text>
                <Text style={styles.metricLabel}>Followers</Text>
              </View>
              <View style={styles.metricCard}>
                <Text style={styles.metricValue}>
                  {formatMetric(metrics.followingCount)}
                </Text>
                <Text style={styles.metricLabel}>Following</Text>
              </View>
              <View style={styles.metricCard}>
                <Text style={styles.metricValue}>
                  {formatMetric(metrics.totalSoldQuantity)}
                </Text>
                <Text style={styles.metricLabel}>Units Sold</Text>
              </View>
            </View>

            <View
              style={[
                styles.topProductContainer,
                metrics.topProductQuantity <= 0 &&
                  styles.topProductContainerMuted,
              ]}
            >
              <Text
                style={[
                  styles.topProductLabel,
                  metrics.topProductQuantity <= 0 &&
                    styles.topProductLabelMuted,
                ]}
              >
                Top Product
              </Text>
              <Text
                style={[
                  styles.topProductValue,
                  metrics.topProductQuantity <= 0 &&
                    styles.topProductValueMuted,
                ]}
              >
                {metrics.topProductQuantity > 0 && metrics.topProductName
                  ? `${metrics.topProductName} · ${formatMetric(
                      metrics.topProductQuantity,
                    )} sold`
                  : 'No sales yet'}
              </Text>
            </View>

            <View style={styles.farmerActions}>
              <TouchableOpacity
                style={styles.productsButton}
                onPress={() => handleViewProducts(item)}
              >
                <Text style={styles.productsButtonText}>View Profile</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.chatButton}
                onPress={() => handleChat(item)}
              >
                <MaterialCommunityIcons
                  name="chat-processing"
                  size={16}
                  color="#FFFFFF"
                  style={styles.chatButtonIcon}
                />
                <Text style={styles.chatButtonText}>Chat</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.actionButton,
                  isFollowing ? styles.unfollowButton : styles.followButton,
                ]}
                onPress={() => handleFollow(item)}
              >
                <Text style={styles.actionButtonText}>
                  {isFollowing ? 'Unfollow' : 'Follow'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
    );
  };

  const content = (
    <View style={styles.content}>
      {farmers.length === 0 ? (
        <View style={styles.emptyState}>
          <MaterialCommunityIcons
            name="account-multiple-outline"
            size={60}
            color="#BDBDBD"
            style={styles.emptyStateIcon}
          />
          <Text style={styles.emptyStateText}>No other farmers found</Text>
          <Text style={styles.emptyStateSubtext}>
            More farmers may join the platform soon
          </Text>
        </View>
      ) : (
        <View style={{ flex: 1 }}>
          <View style={styles.sectionHeader}>
            <View style={styles.searchRow}>
              <TextInput
                style={styles.searchInput}
                placeholder="Search farmers by name or email..."
                value={searchQuery}
                onChangeText={setSearchQuery}
                returnKeyType="search"
              />
            </View>

            <View style={{ height: 8 }} />

            <View>
              <Text style={styles.countText}>
                {filteredFarmers.length} farmer
                {filteredFarmers.length !== 1 ? 's' : ''} available
              </Text>
            </View>
          </View>

          <FlatList
            data={filteredFarmers}
            renderItem={renderFarmerItem}
            keyExtractor={item =>
              typeof item.id === 'string' ? item.id : item.id?.toString() || ''
            }
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={onRefresh}
                colors={['#4CAF50']}
                tintColor="#4CAF50"
              />
            }
            contentContainerStyle={styles.listContainer}
          />
          <View style={styles.bottomPadding} />
        </View>
      )}
    </View>
  );

  if (loading) {
    const loader = (
      <ModernLoading visible={true} message="Loading farmers..." />
    );

    if (embedded) {
      return <View style={styles.embeddedLoadingContainer}>{loader}</View>;
    }

    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        {loader}
      </Layout>
    );
  }

  if (embedded) {
    return <View style={styles.embeddedContainer}>{content}</View>;
  }

  return (
    <Layout activeTab="dashboard">
      <ModernHeader
        title="Browse Farmers"
        leftIconName="arrow-left"
        onLeftPress={() => navigation.goBack()}
        rightAvatarUrl={currentUser?.profile_image_url}
        rightAvatarName={currentUser?.name}
        onRightPress={() =>
          navigation.navigate('UserProfile', {
            userId: String(currentUser?.id),
          })
        }
      />

      {content}
    </Layout>
  );
};

const styles = StyleSheet.create({
  topHeader: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  topHeaderContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  searchInput: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    fontSize: 20,
    color: '#4CAF50',
  },
  topHeaderTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1A',
    textAlign: 'center',
    flex: 1,
  },
  rankRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  rankBadge: {
    minWidth: 50,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#E0E0E0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankBadgeGold: {
    backgroundColor: '#FFD700',
  },
  rankBadgeSilver: {
    backgroundColor: '#C0C0C0',
  },
  rankBadgeBronze: {
    backgroundColor: '#CD7F32',
  },
  rankText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#1A1A1A',
  },
  scoreContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 4,
  },
  scoreLabel: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
  },
  scoreValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1A1A1A',
    lineHeight: 26,
  },
  scoreOutOf: {
    fontSize: 12,
    color: '#999',
    paddingBottom: 3,
  },
  content: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  sectionHeader: {
    backgroundColor: '#E8F5E9',
    borderRadius: 16,
    padding: 20,
    marginBottom: 18,
    marginHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  countText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 4,
    textAlign: 'center',
  },
  headerSubtext: {
    fontSize: 14,
    color: '#388E3C',
    lineHeight: 20,
    textAlign: 'center',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyStateIcon: {
    marginBottom: 16,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#999',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    lineHeight: 20,
  },
  listContainer: {
    padding: 16,
  },
  embeddedContainer: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  embeddedLoadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 24,
  },
  farmerCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 18,
    marginBottom: 14,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  cardSummary: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  summaryContent: {
    flex: 1,
  },
  expandIcon: {
    alignSelf: 'flex-start',
  },
  detailsContainer: {
    marginTop: 16,
  },
  farmerHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  avatarImage: {
    width: 52,
    height: 52,
    borderRadius: 26,
    marginRight: 14,
    backgroundColor: '#F5F5F5',
  },
  avatarText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 20,
  },
  farmerInfo: {
    flex: 1,
  },
  topFarmerCardGold: {
    borderColor: '#FFD700',
    borderWidth: 1.5,
    shadowColor: '#FFD700',
    shadowOpacity: 0.18,
    shadowRadius: 8,
    elevation: 4,
  },
  topFarmerCardSilver: {
    borderColor: '#C0C0C0',
    borderWidth: 1.5,
    shadowColor: '#C0C0C0',
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 3,
  },
  topFarmerCardBronze: {
    borderColor: '#CD7F32',
    borderWidth: 1.5,
    shadowColor: '#CD7F32',
    shadowOpacity: 0.12,
    shadowRadius: 5,
    elevation: 3,
  },
  metricsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  metricCard: {
    flexGrow: 1,
    flexBasis: '45%',
    backgroundColor: '#F5F5F5',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
  },
  metricValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A',
  },
  metricLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  topProductContainer: {
    backgroundColor: '#FFF3E0',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 12,
  },
  topProductContainerMuted: {
    backgroundColor: '#F5F5F5',
  },
  topProductLabel: {
    fontSize: 12,
    color: '#FB8C00',
    fontWeight: '600',
    marginBottom: 4,
  },
  topProductLabelMuted: {
    color: '#757575',
  },
  topProductValue: {
    fontSize: 14,
    color: '#BF360C',
    fontWeight: '600',
  },
  topProductValueMuted: {
    color: '#616161',
    fontWeight: '500',
  },
  farmerName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A1A1A',
    marginBottom: 2,
  },
  farmerLabel: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: '500',
    marginBottom: 2,
  },
  farmerEmail: {
    fontSize: 12,
    color: '#666',
  },
  farmerActions: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  actionButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    alignItems: 'center',
    minWidth: 80,
  },
  followButton: {
    backgroundColor: '#4CAF50',
  },
  unfollowButton: {
    backgroundColor: '#FF5722',
  },
  actionButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  chatButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 44,
    flexDirection: 'row',
    gap: 6,
  },
  chatButtonIcon: {
    marginTop: 1,
  },
  chatButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  productsButton: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    alignItems: 'center',
  },
  productsButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  bottomPadding: {
    height: 32,
  },
});

export default BrowseFarmersScreen;
