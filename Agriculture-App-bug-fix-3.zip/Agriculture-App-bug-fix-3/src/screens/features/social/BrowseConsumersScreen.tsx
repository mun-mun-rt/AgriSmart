import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Image,
  TextInput,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, User } from '../../../types';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import Layout from '../../../components/Layout';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import SupabaseDatabaseManager, {
  ConsumerAggregateStats,
} from '../../../api/SupabaseDatabaseManager';
import { buildRoomId } from '../../../utils';

type BrowseConsumersNavigationProp = StackNavigationProp<
  RootStackParamList,
  'BrowseConsumers'
>;

type ConsumerMetrics = ConsumerAggregateStats & {
  score: number;
  rank: number;
};

type ConsumerWithMetrics = User & {
  metrics: ConsumerMetrics;
};

interface BrowseConsumersScreenProps {
  embedded?: boolean;
  [key: string]: unknown;
}

const BrowseConsumersScreen: React.FC<BrowseConsumersScreenProps> = ({
  embedded = false,
}) => {
  const authManager = SupabaseAuthManager.getInstance();

  const navigation = useNavigation<BrowseConsumersNavigationProp>();
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [consumers, setConsumers] = useState<ConsumerWithMetrics[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [followingStatus, setFollowingStatus] = useState<
    Record<string, boolean>
  >({});
  const [expandedConsumers, setExpandedConsumers] = useState<
    Record<string, boolean>
  >({});

  const dbManager = SupabaseDatabaseManager.getInstance();

  const computeRankings = useCallback(
    (entries: ConsumerWithMetrics[]): ConsumerWithMetrics[] => {
      if (entries.length === 0) return [];

      const orderMax = Math.max(...entries.map(c => c.metrics.orderCount), 0);
      const spentMax = Math.max(...entries.map(c => c.metrics.totalSpent), 0);
      const leaseAppMax = Math.max(
        ...entries.map(c => c.metrics.leaseApplicationCount),
        0,
      );
      const leaseContractMax = Math.max(
        ...entries.map(c => c.metrics.leaseContractCount),
        0,
      );
      const followingMax = Math.max(
        ...entries.map(c => c.metrics.followingCount),
        0,
      );

      const normalize = (value: number, max: number, weight: number) => {
        if (!Number.isFinite(value) || value <= 0 || max <= 0) return 0;
        return (value / max) * weight;
      };

      const weightedEntries = entries
        .map(consumer => {
          const { metrics } = consumer;
          const rawScore =
            normalize(metrics.orderCount, orderMax, 30) +
            normalize(metrics.totalSpent, spentMax, 30) +
            normalize(metrics.leaseApplicationCount, leaseAppMax, 10) +
            normalize(metrics.leaseContractCount, leaseContractMax, 15) +
            normalize(metrics.followingCount, followingMax, 15);

          const safeScore = Number.isFinite(rawScore) ? rawScore : 0;
          const roundedScore = Math.round(safeScore * 10) / 10;

          return {
            ...consumer,
            metrics: { ...metrics, score: roundedScore, rank: 0 },
          };
        })
        .sort((a, b) => {
          if (b.metrics.score === a.metrics.score) {
            const nameA = (a.name || '').toLowerCase();
            const nameB = (b.name || '').toLowerCase();
            return nameA.localeCompare(nameB);
          }
          return b.metrics.score - a.metrics.score;
        });

      return weightedEntries.map((consumer, index) => ({
        ...consumer,
        metrics: { ...consumer.metrics, rank: index + 1 },
      }));
    },
    [],
  );

  const loadConsumers = useCallback(async () => {
    try {
      setLoading(true);
      const user = await authManager.getCurrentUser();
      if (!user) {
        Alert.alert('Error', 'Please log in to browse consumers');
        navigation.goBack();
        return;
      }

      setCurrentUser(user || null);

      const allConsumers = await dbManager.getUsersByRole('consumer');
      const otherConsumers = allConsumers.filter(
        (consumer: User) => consumer.id !== user.id,
      );

      const defaultStats: ConsumerAggregateStats = {
        orderCount: 0,
        totalSpent: 0,
        leaseApplicationCount: 0,
        leaseContractCount: 0,
        followingCount: 0,
        followerCount: 0,
        topProductName: null,
        topProductQuantity: 0,
      };

      const consumerEntriesPromises = otherConsumers.map(async consumer => {
        const consumerId =
          typeof consumer.id === 'string'
            ? consumer.id
            : consumer.id?.toString() || '';

        let aggregatedStats: ConsumerAggregateStats = { ...defaultStats };
        if (consumerId) {
          try {
            aggregatedStats = await dbManager.getConsumerAggregateStats(
              consumerId,
            );
          } catch (err) {
            console.warn('loadConsumers metric fetch failed', err);
            aggregatedStats = { ...defaultStats };
          }
        }

        return {
          ...consumer,
          metrics: { ...aggregatedStats, score: 0, rank: 0 },
        } as ConsumerWithMetrics;
      });

      const consumersWithMetricsRaw = await Promise.all(
        consumerEntriesPromises,
      );
      const rankedConsumers = computeRankings(consumersWithMetricsRaw);
      setConsumers(rankedConsumers);

      if (rankedConsumers.length === 0) {
        setFollowingStatus({});
      } else {
        const followStatusEntries = await Promise.all(
          rankedConsumers.map(async consumer => {
            const consumerId =
              typeof consumer.id === 'string'
                ? consumer.id
                : consumer.id?.toString() || '';
            if (!consumerId) return [consumerId, false] as [string, boolean];
            try {
              const status = await dbManager.isFollowing(consumerId);
              return [consumerId, status] as [string, boolean];
            } catch (err) {
              console.warn('loadConsumers follow status error', err);
              return [consumerId, false] as [string, boolean];
            }
          }),
        );

        const statusMap = Object.fromEntries(
          followStatusEntries.filter(([consumerId]) => consumerId),
        );
        setFollowingStatus(statusMap);
      }
    } catch (error) {
      console.error('Error loading consumers:', error);
      Alert.alert('Error', 'Failed to load consumers');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [authManager, dbManager, navigation, computeRankings]);

  useEffect(() => {
    loadConsumers();
  }, [loadConsumers]);

  const filteredConsumers = consumers.filter(c => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    const name = (c.name || '').toLowerCase();
    const email = (c.email || '').toLowerCase();
    return name.includes(q) || email.includes(q);
  });

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadConsumers();
  }, [loadConsumers]);

  const toggleConsumerExpansion = (consumerId: string) => {
    if (!consumerId) return;
    setExpandedConsumers(prev => ({
      ...prev,
      [consumerId]: !prev[consumerId],
    }));
  };

  const handleChat = (consumer: ConsumerWithMetrics) => {
    if (!currentUser || !consumer.id) return;

    const currentUserId =
      typeof currentUser.id === 'string'
        ? currentUser.id
        : currentUser.id?.toString() || '';
    const consumerId =
      typeof consumer.id === 'string'
        ? consumer.id
        : consumer.id?.toString() || '';
    if (!currentUserId || !consumerId) return;

    const roomId = buildRoomId(currentUserId, consumerId);
    navigation.navigate('ChatRoom', {
      roomId,
      otherUserId: consumerId,
      otherUserName: consumer.name,
    });
  };

  const handleViewProfile = (consumer: ConsumerWithMetrics) => {
    if (consumer.id) {
      const consumerId =
        typeof consumer.id === 'string'
          ? consumer.id
          : consumer.id?.toString() || '';
      navigation.navigate('UserProfile', { userId: consumerId });
    }
  };

  const handleFollow = async (consumer: ConsumerWithMetrics) => {
    if (!currentUser || !consumer.id) return;

    const currentUserId =
      typeof currentUser.id === 'string'
        ? currentUser.id
        : currentUser.id?.toString() || '';
    const consumerId =
      typeof consumer.id === 'string'
        ? consumer.id
        : consumer.id?.toString() || '';
    if (!currentUserId || !consumerId) return;

    const displayName = consumer.name || 'this user';
    const isCurrentlyFollowing = followingStatus[consumerId] || false;

    try {
      if (isCurrentlyFollowing) {
        await dbManager.unfollowUser(consumerId);
        setFollowingStatus(prev => ({ ...prev, [consumerId]: false }));
        setConsumers(prev =>
          prev.map(entry => {
            const entryId =
              typeof entry.id === 'string'
                ? entry.id
                : entry.id?.toString() || '';
            if (entryId !== consumerId) return entry;
            const newCount = Math.max(0, entry.metrics.followerCount - 1);
            return {
              ...entry,
              metrics: { ...entry.metrics, followerCount: newCount },
            };
          }),
        );
        Alert.alert('Success', `You unfollowed ${displayName}`);
      } else {
        await dbManager.followUser(consumerId);
        setFollowingStatus(prev => ({ ...prev, [consumerId]: true }));
        setConsumers(prev =>
          prev.map(entry => {
            const entryId =
              typeof entry.id === 'string'
                ? entry.id
                : entry.id?.toString() || '';
            if (entryId !== consumerId) return entry;
            return {
              ...entry,
              metrics: {
                ...entry.metrics,
                followerCount: entry.metrics.followerCount + 1,
              },
            };
          }),
        );
        Alert.alert('Success', `You are now following ${displayName}`);
      }
    } catch (error) {
      console.error('Error updating follow status:', error);
      Alert.alert('Error', 'Failed to update follow status');
    }
  };

  const formatNumber = (value: number) => {
    if (!Number.isFinite(value)) return '0';
    return Math.round(value).toLocaleString();
  };

  const formatCurrency = (value: number) => {
    if (!Number.isFinite(value) || value <= 0) return 'BDT 0';
    return `BDT ${value.toLocaleString(undefined, {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    })}`;
  };

  const renderConsumerItem = ({ item }: { item: ConsumerWithMetrics }) => {
    const { metrics } = item;
    const displayName = item.name || 'Consumer';
    const displayInitial = displayName.charAt(0).toUpperCase();
    const itemId =
      typeof item.id === 'string' ? item.id : item.id?.toString() || '';
    if (!itemId) {
      return null;
    }
    const isFollowing = followingStatus[itemId] || false;
    const isExpanded = !!expandedConsumers[itemId];

    const metricsToDisplay = [
      { label: 'Orders', value: formatNumber(metrics.orderCount) },
      { label: 'Total Spent', value: formatCurrency(metrics.totalSpent) },
      {
        label: 'Lease Applications',
        value: formatNumber(metrics.leaseApplicationCount),
      },
      {
        label: 'Active Leases',
        value: formatNumber(metrics.leaseContractCount),
      },
      { label: 'Followers', value: formatNumber(metrics.followerCount) },
      { label: 'Following', value: formatNumber(metrics.followingCount) },
    ];

    return (
      <View
        style={[
          styles.card,
          metrics.rank === 1 && styles.topCardGold,
          metrics.rank === 2 && styles.topCardSilver,
          metrics.rank === 3 && styles.topCardBronze,
        ]}
      >
        <TouchableOpacity
          style={styles.cardSummary}
          onPress={() => toggleConsumerExpansion(itemId)}
          activeOpacity={0.85}
        >
          <View style={styles.summaryContent}>
            <View style={styles.rankRow}>
              <View
                style={[
                  styles.rankBadge,
                  metrics.rank === 1 && styles.rankBadgeGold,
                  metrics.rank === 2 && styles.rankBadgeSilver,
                  metrics.rank === 3 && styles.rankBadgeBronze,
                ]}
              >
                <Text style={styles.rankText}>#{metrics.rank}</Text>
              </View>
              <View style={styles.scoreContainer}>
                <Text style={styles.scoreLabel}>Score</Text>
                <Text style={styles.scoreValue}>
                  {metrics.score.toFixed(1)}
                </Text>
                <Text style={styles.scoreOutOf}>/100</Text>
              </View>
            </View>

            <View style={styles.headerRow}>
              {item.profile_image_url ? (
                <Image
                  source={{ uri: item.profile_image_url }}
                  style={styles.avatarImage}
                />
              ) : (
                <View style={styles.avatarFallback}>
                  <Text style={styles.avatarFallbackText}>
                    {displayInitial}
                  </Text>
                </View>
              )}
              <View style={{ flex: 1 }}>
                <Text style={styles.consumerName}>{displayName}</Text>
                <Text style={styles.consumerRole}>Consumer</Text>
                {item.email ? (
                  <Text style={styles.consumerEmail}>{item.email}</Text>
                ) : null}
              </View>
            </View>
          </View>

          <MaterialCommunityIcons
            name={isExpanded ? 'chevron-up' : 'chevron-down'}
            size={24}
            color="#1E88E5"
            style={styles.expandIcon}
          />
        </TouchableOpacity>

        {isExpanded && (
          <View style={styles.detailsContainer}>
            <View style={styles.metricsGrid}>
              {metricsToDisplay.map(metric => (
                <View key={metric.label} style={styles.metricCard}>
                  <Text style={styles.metricValue}>{metric.value}</Text>
                  <Text style={styles.metricLabel}>{metric.label}</Text>
                </View>
              ))}
            </View>

            <View
              style={[
                styles.favoriteProductContainer,
                metrics.topProductQuantity <= 0 &&
                  styles.favoriteProductContainerMuted,
              ]}
            >
              <Text
                style={[
                  styles.favoriteProductLabel,
                  metrics.topProductQuantity <= 0 &&
                    styles.favoriteProductLabelMuted,
                ]}
              >
                Favorite Product
              </Text>
              <Text
                style={[
                  styles.favoriteProductValue,
                  metrics.topProductQuantity <= 0 &&
                    styles.favoriteProductValueMuted,
                ]}
              >
                {metrics.topProductQuantity > 0 && metrics.topProductName
                  ? `${metrics.topProductName} · ${formatNumber(
                      metrics.topProductQuantity,
                    )} purchased`
                  : 'No purchases recorded yet'}
              </Text>
            </View>

            <View style={styles.actionsRow}>
              <TouchableOpacity
                style={styles.profileButton}
                onPress={() => handleViewProfile(item)}
              >
                <Text style={styles.profileButtonText}>View Profile</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.chatButton}
                onPress={() => handleChat(item)}
              >
                <MaterialCommunityIcons
                  name="chat-processing"
                  size={16}
                  color="#FFFFFF"
                  style={styles.chatButtonIcon}
                />
                <Text style={styles.chatButtonText}>Chat</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.followToggleButton,
                  isFollowing ? styles.unfollowButton : styles.followButton,
                ]}
                onPress={() => handleFollow(item)}
              >
                <Text style={styles.followToggleText}>
                  {isFollowing ? 'Unfollow' : 'Follow'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
    );
  };

  const content = (
    <View style={styles.content}>
      {consumers.length === 0 ? (
        <View style={styles.emptyState}>
          <MaterialCommunityIcons
            name="cart-off"
            size={60}
            color="#BDBDBD"
            style={styles.emptyStateIcon}
          />
          <Text style={styles.emptyStateTitle}>No consumers to show</Text>
          <Text style={styles.emptyStateSubtitle}>
            Encourage more users to join and participate
          </Text>
        </View>
      ) : (
        <View style={{ flex: 1 }}>
          <View style={styles.sectionHeader}>
            <TextInput
              style={styles.searchInput}
              placeholder="Search consumers by name or email..."
              value={searchQuery}
              onChangeText={setSearchQuery}
              returnKeyType="search"
            />
            <Text style={styles.sectionSubtext}>
              {filteredConsumers.length} consumer
              {filteredConsumers.length !== 1 ? 's' : ''} available
            </Text>
          </View>

          <FlatList
            data={filteredConsumers}
            renderItem={renderConsumerItem}
            keyExtractor={item =>
              typeof item.id === 'string' ? item.id : item.id?.toString() || ''
            }
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={onRefresh}
                colors={['#4CAF50']}
                tintColor="#4CAF50"
              />
            }
            contentContainerStyle={styles.listContent}
          />
          <View style={styles.bottomSpacer} />
        </View>
      )}
    </View>
  );

  if (loading) {
    const loader = (
      <ModernLoading visible={true} message="Loading consumers..." />
    );

    if (embedded) {
      return <View style={styles.embeddedLoadingContainer}>{loader}</View>;
    }

    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        {loader}
      </Layout>
    );
  }

  if (embedded) {
    return <View style={styles.embeddedContainer}>{content}</View>;
  }

  return (
    <Layout activeTab="dashboard">
      <ModernHeader
        title="Browse Consumers"
        leftIconName="arrow-left"
        onLeftPress={() => navigation.goBack()}
        rightAvatarUrl={currentUser?.profile_image_url}
        rightAvatarName={currentUser?.name}
        onRightPress={() =>
          navigation.navigate('UserProfile', {
            userId: String(currentUser?.id),
          })
        }
      />

      {content}
    </Layout>
  );
};

const styles = StyleSheet.create({
  content: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  sectionHeader: {
    backgroundColor: '#E3F2FD',
    borderRadius: 16,
    padding: 20,
    marginHorizontal: 16,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 1,
  },
  searchInput: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginBottom: 12,
  },
  sectionSubtext: {
    fontSize: 14,
    color: '#1565C0',
    textAlign: 'center',
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  embeddedContainer: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  embeddedLoadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 24,
  },
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 18,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#F0F0F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
  },
  cardSummary: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  summaryContent: {
    flex: 1,
  },
  expandIcon: {
    alignSelf: 'flex-start',
  },
  detailsContainer: {
    marginTop: 16,
  },
  topCardGold: {
    borderColor: '#FFD700',
    borderWidth: 1.5,
    shadowColor: '#FFD700',
    shadowOpacity: 0.16,
    shadowRadius: 8,
    elevation: 4,
  },
  topCardSilver: {
    borderColor: '#C0C0C0',
    borderWidth: 1.5,
    shadowColor: '#C0C0C0',
    shadowOpacity: 0.14,
    shadowRadius: 6,
    elevation: 3,
  },
  topCardBronze: {
    borderColor: '#CD7F32',
    borderWidth: 1.5,
    shadowColor: '#CD7F32',
    shadowOpacity: 0.12,
    shadowRadius: 5,
    elevation: 3,
  },
  rankRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  rankBadge: {
    minWidth: 50,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: '#ECEFF1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankBadgeGold: {
    backgroundColor: '#FFD700',
  },
  rankBadgeSilver: {
    backgroundColor: '#C0C0C0',
  },
  rankBadgeBronze: {
    backgroundColor: '#CD7F32',
  },
  rankText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#1A1A1A',
  },
  scoreContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 4,
  },
  scoreLabel: {
    fontSize: 12,
    color: '#546E7A',
    fontWeight: '600',
  },
  scoreValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#0D47A1',
    lineHeight: 26,
  },
  scoreOutOf: {
    fontSize: 12,
    color: '#90A4AE',
    paddingBottom: 3,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatarImage: {
    width: 52,
    height: 52,
    borderRadius: 26,
    marginRight: 14,
    backgroundColor: '#E0E0E0',
  },
  avatarFallback: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: '#1565C0',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  avatarFallbackText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '700',
  },
  consumerName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1A1A1A',
  },
  consumerRole: {
    fontSize: 14,
    color: '#1E88E5',
    fontWeight: '500',
    marginTop: 2,
  },
  consumerEmail: {
    fontSize: 12,
    color: '#607D8B',
    marginTop: 2,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  metricCard: {
    flexGrow: 1,
    flexBasis: '45%',
    backgroundColor: '#F5F5F5',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
  },
  metricValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0D47A1',
  },
  metricLabel: {
    fontSize: 12,
    color: '#546E7A',
    marginTop: 2,
  },
  favoriteProductContainer: {
    backgroundColor: '#E8F5E9',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 12,
  },
  favoriteProductContainerMuted: {
    backgroundColor: '#F5F5F5',
  },
  favoriteProductLabel: {
    fontSize: 12,
    color: '#2E7D32',
    fontWeight: '600',
    marginBottom: 4,
  },
  favoriteProductLabelMuted: {
    color: '#757575',
  },
  favoriteProductValue: {
    fontSize: 14,
    color: '#1B5E20',
    fontWeight: '600',
  },
  favoriteProductValueMuted: {
    color: '#616161',
    fontWeight: '500',
  },
  actionsRow: {
    flexDirection: 'row',
    gap: 10,
    flexWrap: 'wrap',
  },
  followToggleButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    alignItems: 'center',
    minWidth: 96,
  },
  followButton: {
    backgroundColor: '#4CAF50',
  },
  unfollowButton: {
    backgroundColor: '#FF7043',
  },
  followToggleText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  profileButton: {
    backgroundColor: '#1E88E5',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    alignItems: 'center',
  },
  profileButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  chatButton: {
    backgroundColor: '#43A047',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    alignItems: 'center',
    flexDirection: 'row',
    gap: 6,
  },
  chatButtonIcon: {
    marginTop: 1,
  },
  chatButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyStateIcon: {
    marginBottom: 16,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#757575',
    marginBottom: 8,
    textAlign: 'center',
  },
  emptyStateSubtitle: {
    fontSize: 14,
    color: '#9E9E9E',
    textAlign: 'center',
    lineHeight: 20,
  },
  bottomSpacer: {
    height: 32,
  },
});

export default BrowseConsumersScreen;
