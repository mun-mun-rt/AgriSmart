import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, User } from '../../../types';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
// import ModernHeader from '../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import Layout from '../../../components/Layout';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import { getRoleDisplayName } from '../../../utils/authUtils';
import ModernInput from '../../../components/ModernInput';
import { buildRoomId } from '../../../utils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type FollowersListNavigationProp = StackNavigationProp<
  RootStackParamList,
  'FollowersList'
>;

const FollowersListScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<FollowersListNavigationProp>();
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const [followers, setFollowers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Use new robust schema-accurate method for followers list
  const loadFollowers = useCallback(async () => {
    try {
      const user = await authManager.getCurrentUser();
      if (!user) {
        Alert.alert('Error', 'Please log in to view your followers');
        navigation.goBack();
        return;
      }
      setCurrentUser(user);
      // Get list of user IDs who follow the current user
      const followerIds = await dbManager.getFollowersList();
      // Fetch user details for each follower
      const userMap = await dbManager.getUsersByIds(followerIds);
      const followerUsers = followerIds.map(id => userMap[id]).filter(Boolean);
      setFollowers(followerUsers);
    } catch (error) {
      console.error('Error loading followers list:', error);
      Alert.alert('Error', 'Failed to load followers list');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [authManager, dbManager, navigation]);

  useEffect(() => {
    loadFollowers();
  }, [loadFollowers]);

  const filteredFollowers = useMemo(() => {
    const q = (searchQuery || '').trim().toLowerCase();
    if (!q) return followers;
    return followers.filter(f => {
      const name = (f.name || '').toLowerCase();
      const email = (f.email || '').toLowerCase();
      return name.includes(q) || email.includes(q);
    });
  }, [followers, searchQuery]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadFollowers();
  }, [loadFollowers]);

  const handleViewProfile = (user: User) => {
    navigation.navigate('UserProfile', { userId: user.id!.toString() });
  };

  const handleChat = (userId: string, userName: string) => {
    if (!currentUser) return;
    navigation.navigate('ChatRoom', {
      roomId: buildRoomId(currentUser.id!, userId),
      otherUserId: userId,
      otherUserName: userName,
    });
  };

  const handleViewTheirProducts = (userId: string) => {
    navigation.navigate('UserProfile', { userId });
  };

  const renderFollowerItem = ({ item }: { item: User }) => (
    <View style={styles.followerCardModern}>
      <View style={styles.followerCardHeader}>
        {item.profile_image_url ? (
          <Image
            source={{ uri: item.profile_image_url }}
            style={styles.followerAvatarImage}
          />
        ) : (
          <View style={styles.followerAvatar}>
            <Text style={styles.followerAvatarText}>
              {item.name.charAt(0).toUpperCase()}
            </Text>
          </View>
        )}
        <View style={styles.followerCardInfo}>
          <Text style={styles.followerName}>{item.name}</Text>
          <Text
            style={[
              styles.followerRole,
              item.role === 'farmer' ? styles.farmerRole : styles.consumerRole,
            ]}
          >
            {getRoleDisplayName(item.role)}
          </Text>
          {item.email && <Text style={styles.followerEmail}>{item.email}</Text>}
        </View>
      </View>
      <View style={styles.followerDetailsRow}>
        {/* Add more details if needed, e.g. address, farm name, etc. */}
      </View>
      <View style={styles.followerActionsModern}>
        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => handleViewProfile(item)}
        >
          <Text style={styles.actionButtonText}>View Profile</Text>
        </TouchableOpacity>
        {item.role === 'farmer' && (
          <TouchableOpacity
            style={styles.actionButtonAlt}
            onPress={() => handleViewTheirProducts(item.id!.toString())}
          >
            <Text style={styles.actionButtonText}>View Profile</Text>
          </TouchableOpacity>
        )}
        <TouchableOpacity
          style={styles.actionButtonChat}
          onPress={() => handleChat(item.id!.toString(), item.name)}
        >
          <MaterialCommunityIcons
            name="chat-processing"
            size={16}
            color="#FFFFFF"
            style={styles.actionButtonIcon}
          />
          <Text style={styles.actionButtonText}>Chat</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Loading followers..." />
      </Layout>
    );
  }

  return (
    <Layout activeTab="dashboard">
      <View style={styles.headerModern}>
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
            activeOpacity={0.7}
          >
            <MaterialCommunityIcons
              name="arrow-left"
              size={20}
              color="#333333"
            />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Followers</Text>
          <View style={{ width: 44 }} />
        </View>
      </View>

      <View style={styles.content}>
        <View style={{ paddingHorizontal: 4, paddingVertical: 8 }}>
          <ModernInput
            placeholder="Search by name or email"
            value={searchQuery}
            onChangeText={text => setSearchQuery(text)}
            style={{ backgroundColor: '#fff', borderRadius: 12 }}
            rightIcon={searchQuery ? '✖' : undefined}
            onRightIconPress={() => setSearchQuery('')}
          />
        </View>
        {followers.length === 0 ? (
          <View style={styles.emptyState}>
            <MaterialCommunityIcons
              name="account-group-outline"
              size={64}
              color="#BDBDBD"
              style={styles.emptyStateIcon}
            />
            <Text style={styles.emptyStateText}>No followers yet</Text>
            <Text style={styles.emptyStateSubtext}>
              Share your products to attract more followers
            </Text>
          </View>
        ) : (
          <>
            <View style={styles.countHeaderModern}>
              <Text style={styles.countText}>
                {followers.length} follower{followers.length !== 1 ? 's' : ''}
              </Text>
            </View>
            <FlatList
              data={filteredFollowers}
              renderItem={renderFollowerItem}
              keyExtractor={item => item.id!.toString()}
              showsVerticalScrollIndicator={false}
              refreshControl={
                <RefreshControl
                  refreshing={refreshing}
                  onRefresh={onRefresh}
                  colors={['#4CAF50']}
                  tintColor="#4CAF50"
                />
              }
              contentContainerStyle={styles.listContainer}
            />
          </>
        )}
        <View style={styles.bottomPadding} />
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  headerModern: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    fontSize: 20,
    color: '#333',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1A',
    textAlign: 'center',
    flex: 1,
  },
  content: {
    flex: 1,
    backgroundColor: '#FAFAFA',
    paddingHorizontal: 16,
  },
  countHeaderModern: {
    backgroundColor: '#fff',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    marginBottom: 2,
  },
  countText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyStateIcon: {
    marginBottom: 16,
  },
  bottomPadding: {
    height: 32,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#999',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
  listContainer: {
    padding: 16,
  },
  followerCardModern: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 18,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  followerCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  followerAvatar: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  followerAvatarImage: {
    width: 54,
    height: 54,
    borderRadius: 27,
    marginRight: 16,
    backgroundColor: '#F5F5F5',
  },
  followerAvatarText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 26,
  },
  followerCardInfo: {
    flex: 1,
  },
  followerDetailsRow: {
    flexDirection: 'column',
    gap: 4,
    marginBottom: 6,
  },
  followerName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  followerRole: {
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 2,
  },
  farmerRole: {
    color: '#4CAF50',
  },
  consumerRole: {
    color: '#2196F3',
  },
  followerEmail: {
    fontSize: 12,
    color: '#666',
  },
  followerActionsModern: {
    flexDirection: 'row',
    gap: 10,
    flexWrap: 'wrap',
    marginTop: 4,
  },
  actionButton: {
    backgroundColor: '#4CAF50',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignItems: 'center',
    minWidth: 80,
  },
  actionButtonAlt: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignItems: 'center',
    minWidth: 80,
  },
  actionButtonChat: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignItems: 'center',
    minWidth: 80,
    flexDirection: 'row',
    gap: 6,
  },
  actionButtonIcon: {
    marginTop: 1,
  },
  actionButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
});

export default FollowersListScreen;
