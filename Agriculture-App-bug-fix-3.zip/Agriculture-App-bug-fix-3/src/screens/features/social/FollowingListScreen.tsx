import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, User } from '../../../types';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
// import ModernHeader from '../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import Layout from '../../../components/Layout';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import { getRoleDisplayName } from '../../../utils/authUtils';
import ModernInput from '../../../components/ModernInput';
import { buildRoomId } from '../../../utils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type FollowingListNavigationProp = StackNavigationProp<
  RootStackParamList,
  'FollowingList'
>;

const FollowingListScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<FollowingListNavigationProp>();
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [following, setFollowing] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const loadFollowing = useCallback(async () => {
    try {
      const user = await authManager.getCurrentUser();
      if (!user) {
        Alert.alert('Error', 'Please log in to view your following list');
        navigation.goBack();
        return;
      }

      setCurrentUser(user);
      // Get list of user IDs the current user is following
      const followingIds = await dbManager.getFollowingList();
      // Fetch user details for each following user
      const userMap = await dbManager.getUsersByIds(followingIds);
      const followingUsers = followingIds
        .map(id => userMap[id])
        .filter(Boolean);
      setFollowing(followingUsers);
    } catch (error) {
      console.error('Error loading following list:', error);
      Alert.alert('Error', 'Failed to load following list');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [authManager, dbManager, navigation]);

  useEffect(() => {
    loadFollowing();
  }, [loadFollowing]);

  const filteredFollowing = useMemo(() => {
    const q = (searchQuery || '').trim().toLowerCase();
    if (!q) return following;
    return following.filter(f => {
      const name = (f.name || '').toLowerCase();
      const email = (f.email || '').toLowerCase();
      return name.includes(q) || email.includes(q);
    });
  }, [following, searchQuery]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadFollowing();
  }, [loadFollowing]);

  const handleUnfollow = async (userId: number, userName: string) => {
    if (!currentUser) return;

    Alert.alert(
      'Unfollow User',
      `Are you sure you want to unfollow ${userName}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Unfollow',
          style: 'destructive',
          onPress: async () => {
            try {
              await dbManager.unfollowFarmer(userId.toString());
              setFollowing(prev => prev.filter(user => user.id !== userId));
              Alert.alert('Success', `You unfollowed ${userName}`);
            } catch (error) {
              console.error('Error unfollowing user:', error);
              Alert.alert('Error', 'Failed to unfollow user');
            }
          },
        },
      ],
    );
  };

  const handleViewProducts = (userId: number) => {
    navigation.navigate('UserProfile', { userId: userId.toString() });
  };

  const handleChat = (userId: number, userName: string) => {
    if (!currentUser) return;

    navigation.navigate('ChatRoom', {
      roomId: buildRoomId(currentUser.id!, userId),
      otherUserId: userId.toString(),
      otherUserName: userName,
    });
  };

  const renderUserItem = ({ item }: { item: User }) => (
    <View style={styles.userCardModern}>
      <View style={styles.userCardHeader}>
        {item.profile_image_url ? (
          <Image
            source={{ uri: item.profile_image_url }}
            style={styles.userAvatarImage}
          />
        ) : (
          <View style={styles.userAvatar}>
            <Text style={styles.userAvatarText}>
              {item.name.charAt(0).toUpperCase()}
            </Text>
          </View>
        )}
        <View style={styles.userCardInfo}>
          <Text style={styles.userName}>{item.name}</Text>
          <Text style={styles.userRole}>{getRoleDisplayName(item.role)}</Text>
          {item.email && <Text style={styles.userEmail}>{item.email}</Text>}
        </View>
      </View>
      <View style={styles.userActionsModern}>
        <TouchableOpacity
          style={styles.actionButtonAlt}
          onPress={() => handleViewProducts(item.id!)}
        >
          <Text style={styles.actionButtonText}>View Profile</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.actionButtonChat}
          onPress={() => handleChat(item.id!, item.name)}
        >
          <MaterialCommunityIcons
            name="chat-processing"
            size={16}
            color="#FFFFFF"
            style={styles.actionButtonIcon}
          />
          <Text style={styles.actionButtonText}>Chat</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.actionButtonUnfollow}
          onPress={() => handleUnfollow(item.id!, item.name)}
        >
          <Text style={styles.actionButtonText}>Unfollow</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Loading following list..." />
      </Layout>
    );
  }

  return (
    <Layout activeTab="dashboard">
      <View style={styles.headerModern}>
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
            activeOpacity={0.7}
          >
            <MaterialCommunityIcons
              name="arrow-left"
              size={20}
              color="#333333"
            />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Following</Text>
          <View style={{ width: 44 }} />
        </View>
      </View>

      <View style={styles.content}>
        <View style={{ paddingHorizontal: 4, paddingVertical: 8 }}>
          <ModernInput
            placeholder="Search by name or email"
            value={searchQuery}
            onChangeText={text => setSearchQuery(text)}
            style={{ backgroundColor: '#fff', borderRadius: 12 }}
            rightIconName={searchQuery ? 'close-circle' : undefined}
            rightIconColor="#9E9E9E"
            onRightIconPress={() => setSearchQuery('')}
          />
        </View>
        {following.length === 0 ? (
          <View style={styles.emptyState}>
            <MaterialCommunityIcons
              name="account-plus-outline"
              size={64}
              color="#BDBDBD"
              style={styles.emptyStateIcon}
            />
            <Text style={styles.emptyStateText}>
              You're not following anyone yet
            </Text>
            <Text style={styles.emptyStateSubtext}>
              Follow farmers to see their products and updates
            </Text>
          </View>
        ) : (
          <>
            <View style={styles.countHeaderModern}>
              <Text style={styles.countText}>
                Following {following.length} user
                {following.length !== 1 ? 's' : ''}
              </Text>
            </View>
            <FlatList
              data={filteredFollowing}
              renderItem={renderUserItem}
              keyExtractor={item => item.id!.toString()}
              showsVerticalScrollIndicator={false}
              refreshControl={
                <RefreshControl
                  refreshing={refreshing}
                  onRefresh={onRefresh}
                  colors={['#4CAF50']}
                  tintColor="#4CAF50"
                />
              }
              contentContainerStyle={styles.listContainer}
            />
          </>
        )}
        <View style={styles.bottomPadding} />
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  headerModern: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    fontSize: 20,
    color: '#333',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1A',
    textAlign: 'center',
    flex: 1,
  },
  content: {
    flex: 1,
    backgroundColor: '#FAFAFA',
    paddingHorizontal: 16,
  },
  countHeaderModern: {
    backgroundColor: '#fff',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    marginBottom: 2,
  },
  countText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#999',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
  listContainer: {
    padding: 16,
  },
  userCardModern: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 18,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  userCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  userAvatar: {
    width: 54,
    height: 54,
    borderRadius: 27,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  userAvatarImage: {
    width: 54,
    height: 54,
    borderRadius: 27,
    marginRight: 16,
    backgroundColor: '#F5F5F5',
  },
  userAvatarText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 26,
  },
  userCardInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  userRole: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: '500',
    marginBottom: 2,
  },
  userEmail: {
    fontSize: 12,
    color: '#666',
  },
  userActionsModern: {
    flexDirection: 'row',
    gap: 10,
    flexWrap: 'wrap',
    marginTop: 4,
  },
  actionButtonAlt: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignItems: 'center',
    minWidth: 80,
  },
  actionButtonChat: {
    backgroundColor: '#FF9800',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignItems: 'center',
    minWidth: 80,
    flexDirection: 'row',
    gap: 6,
  },
  actionButtonIcon: {
    marginTop: 1,
  },
  actionButtonUnfollow: {
    backgroundColor: '#FF5722',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignItems: 'center',
    minWidth: 80,
  },
  actionButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  bottomPadding: {
    height: 32,
  },
  emptyStateIcon: {
    marginBottom: 16,
  },
});

export default FollowingListScreen;
