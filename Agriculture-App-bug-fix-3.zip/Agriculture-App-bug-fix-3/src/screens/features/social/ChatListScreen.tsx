import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  RefreshControl,
  Image,
} from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../../types';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import ModernHeader from '../../../components/ModernHeader';
import ModernLoading from '../../../components/ModernLoading';
import Layout from '../../../components/Layout';
import SupabaseAuthManager from '../../../api/SupabaseAuthManager';
import SupabaseDatabaseManager from '../../../api/SupabaseDatabaseManager';
import { useMessageNotifications } from '../../../contexts/MessageNotificationContext';
import { buildRoomId } from '../../../utils';

type ChatListNavigationProp = StackNavigationProp<
  RootStackParamList,
  'ChatList'
>;

interface ChatItem {
  other_user_id: string;
  other_user_name: string;
  userRole?: string;
  last_message: string;
  last_message_time: string;
  profile_image_url?: string | null;
  unreadCount?: number;
}

const ChatListScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();

  const navigation = useNavigation<ChatListNavigationProp>();
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [chatList, setChatList] = useState<ChatItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const { setActiveRoom } = useMessageNotifications();

  // DB manager instance
  const dbManager = SupabaseDatabaseManager.getInstance();

  const loadChatList = useCallback(async () => {
    try {
      const user = await authManager.getCurrentUser();
      if (!user?.id) {
        Alert.alert('Error', 'Please log in to view your chats');
        navigation.goBack();
        return;
      }

      setCurrentUserId(String(user.id));
      setCurrentUser(user || null);
      const chats = await dbManager.getUserChatList(user.id.toString());
      setChatList(chats);
    } catch (error) {
      console.error('Error loading chat list:', error);
      Alert.alert('Error', 'Failed to load chat list');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [authManager, dbManager, navigation]);

  useEffect(() => {
    loadChatList();
  }, [loadChatList]);

  // Refresh chat list when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      setActiveRoom(null);
      if (currentUserId) {
        loadChatList();
      }
      return () => {
        setActiveRoom(null);
      };
    }, [currentUserId, loadChatList, setActiveRoom]),
  );

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadChatList();
  }, [loadChatList]);

  const handleChatPress = (chatItem: ChatItem) => {
    if (!currentUserId) return;

    const roomId = buildRoomId(currentUserId, chatItem.other_user_id);

    navigation.navigate('ChatRoom', {
      roomId,
      otherUserId: chatItem.other_user_id.toString(),
      otherUserName: chatItem.other_user_name,
    });
  };

  const formatTime = (timestamp: string): string => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

    if (diffInHours < 1) {
      const diffInMinutes = Math.floor(diffInHours * 60);
      return diffInMinutes < 1 ? 'Just now' : `${diffInMinutes}m ago`;
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else if (diffInHours < 48) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString();
    }
  };

  const renderChatItem = ({ item }: { item: ChatItem }) => (
    <TouchableOpacity
      style={styles.chatCard}
      onPress={() => handleChatPress(item)}
    >
      <View style={styles.avatarContainer}>
        {item.profile_image_url ? (
          <Image
            source={{ uri: item.profile_image_url }}
            style={styles.avatar}
          />
        ) : (
          <View
            style={[
              styles.avatar,
              item.userRole === 'farmer'
                ? styles.farmerAvatar
                : styles.consumerAvatar,
            ]}
          >
            <Text style={styles.avatarText}>
              {item.other_user_name.charAt(0).toUpperCase()}
            </Text>
          </View>
        )}
      </View>

      <View style={styles.chatInfo}>
        <View style={styles.chatHeader}>
          <Text
            style={[
              styles.userName,
              item.unreadCount ? styles.unreadUserName : null,
            ]}
          >
            {item.other_user_name}
          </Text>
          <View style={styles.chatMeta}>
            {item.unreadCount ? (
              <View style={styles.unreadBadge}>
                <Text style={styles.unreadBadgeText}>
                  {item.unreadCount > 99 ? '99+' : item.unreadCount}
                </Text>
              </View>
            ) : null}
            <Text style={styles.timeText}>
              {formatTime(item.last_message_time)}
            </Text>
          </View>
        </View>

        <View style={styles.chatDetails}>
          <Text
            style={[
              styles.userRole,
              item.userRole === 'farmer'
                ? styles.farmerRole
                : styles.consumerRole,
            ]}
          >
            {item.userRole
              ? item.userRole.charAt(0).toUpperCase() + item.userRole.slice(1)
              : 'User'}
          </Text>
        </View>

        <Text
          style={[
            styles.lastMessage,
            item.unreadCount ? styles.unreadLastMessage : null,
          ]}
          numberOfLines={2}
        >
          {item.last_message || 'No messages yet'}
        </Text>
      </View>

      <View style={styles.chevron}>
        <MaterialCommunityIcons
          name="chevron-right"
          size={22}
          color="#CCCCCC"
          style={styles.chevronIcon}
        />
      </View>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Loading chats..." />
      </Layout>
    );
  }

  return (
    <Layout activeTab="chat">
      <ModernHeader
        title="Messages"
        leftIconName="arrow-left"
        onLeftPress={() => navigation.goBack()}
        rightAvatarUrl={currentUser?.profile_image_url}
        rightAvatarName={currentUser?.name}
        onRightPress={() =>
          navigation.navigate('UserProfile', {
            userId: String(currentUser?.id),
          })
        }
      />

      <View style={styles.content}>
        {chatList.length === 0 ? (
          <View style={styles.emptyState}>
            <MaterialCommunityIcons
              name="chat-outline"
              size={64}
              color="#BDBDBD"
              style={styles.emptyStateIcon}
            />
            <Text style={styles.emptyStateText}>No conversations yet</Text>
            <Text style={styles.emptyStateSubtext}>
              Start chatting with farmers or consumers to see your conversations
              here
            </Text>
          </View>
        ) : (
          <FlatList
            data={chatList}
            renderItem={renderChatItem}
            keyExtractor={item => item.other_user_id.toString()}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl
                refreshing={refreshing}
                onRefresh={onRefresh}
                colors={['#4CAF50']}
                tintColor="#4CAF50"
              />
            }
            contentContainerStyle={styles.listContainer}
          />
        )}
        <View style={styles.bottomPadding} />
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backIcon: {
    fontSize: 20,
    color: '#333',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1A',
    textAlign: 'center',
    flex: 1,
  },
  content: {
    flex: 1,
    backgroundColor: '#FAFAFA',
    paddingHorizontal: 16,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyStateIcon: {
    marginBottom: 16,
  },
  emptyStateText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#999',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptyStateSubtext: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    lineHeight: 20,
  },
  listContainer: {
    paddingVertical: 16,
  },
  chatCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 18,
    marginBottom: 14,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 80,
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 14,
  },
  avatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    justifyContent: 'center',
    alignItems: 'center',
  },
  farmerAvatar: {
    backgroundColor: '#4CAF50',
  },
  consumerAvatar: {
    backgroundColor: '#2196F3',
  },
  avatarText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 20,
  },
  chatInfo: {
    flex: 1,
  },
  chatHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  chatMeta: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    flex: 1,
  },
  unreadUserName: {
    fontWeight: '700',
    color: '#1A1A1A',
  },
  timeText: {
    fontSize: 12,
    color: '#999',
    marginLeft: 8,
    minWidth: 60,
    textAlign: 'right',
  },
  unreadBadge: {
    backgroundColor: '#FF3B30',
    borderRadius: 10,
    minWidth: 20,
    paddingHorizontal: 6,
    paddingVertical: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 8,
  },
  unreadBadgeText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '700',
  },
  chatDetails: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  userRole: {
    fontSize: 12,
    fontWeight: '500',
    marginRight: 8,
  },
  farmerRole: {
    color: '#4CAF50',
  },
  consumerRole: {
    color: '#2196F3',
  },
  lastMessage: {
    fontSize: 14,
    color: '#666',
    lineHeight: 18,
  },
  unreadLastMessage: {
    color: '#2E7D32',
    fontWeight: '600',
  },

  chevron: {
    marginLeft: 10,
  },
  chevronIcon: {
    marginTop: 0,
  },
  bottomPadding: {
    height: 32,
  },
});

export default ChatListScreen;
