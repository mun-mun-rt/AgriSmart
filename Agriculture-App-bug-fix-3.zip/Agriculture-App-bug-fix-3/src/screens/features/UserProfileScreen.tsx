import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Alert,
  RefreshControl,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList, Product, User } from '../../types';
import SupabaseDatabaseManager, {
  CartConstraintError,
} from '../../api/SupabaseDatabaseManager';
import ModernHeader from '../../components/ModernHeader';
import ModernLoading from '../../components/ModernLoading';
import Layout from '../../components/Layout';
import SupabaseAuthManager from '../../api/SupabaseAuthManager';
import { getRoleDisplayName } from '../../utils/authUtils';
import { buildRoomId } from '../../utils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type FarmerProductsNavigationProp = StackNavigationProp<
  RootStackParamList,
  'UserProfile'
>;

type FarmerProductsRouteProp = RouteProp<RootStackParamList, 'UserProfile'>;

const UserProfileScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation = useNavigation<FarmerProductsNavigationProp>();
  const route = useRoute<FarmerProductsRouteProp>();
  const { userId } = route.params;

  const [user, setUser] = useState<User | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [isFollowing, setIsFollowing] = useState<boolean>(false);
  const [followLoading, setFollowLoading] = useState<boolean>(false);
  const [followerCount, setFollowerCount] = useState<number>(0);
  const [followStatusLoaded, setFollowStatusLoaded] = useState<boolean>(false);
  const [followButtonLabel, setFollowButtonLabel] = useState<string>('Follow');
  const [orderCount, setOrderCount] = useState<number>(0);
  const [recentOrders, setRecentOrders] = useState<any[]>([]);
  const [followingCount, setFollowingCount] = useState<number>(0);
  const [leases, setLeases] = useState<any[]>([]);
  const [leasesLoading, setLeasesLoading] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>(
    userId ? 'products' : 'leases',
  );
  const [cartItemCount, setCartItemCount] = useState<number>(0);

  const loadData = useCallback(async () => {
    try {
      setLoading(true);

      // Get user details
      const userData = await dbManager.getUserById(userId.toString());
      if (!userData) {
        Alert.alert('Error', 'User not found');
        navigation.goBack();
        return;
      }
      setUser(userData);

      // Get current user
      const me = await authManager.getCurrentUser();
      if (me) {
        setCurrentUser(me);
        try {
          const count = await dbManager.getCartItemCount(String(me.id));
          setCartItemCount(count);
        } catch (cartError) {
          console.error('Error fetching cart item count:', cartError);
          setCartItemCount(0);
        }
      } else {
        setCurrentUser(null);
        setCartItemCount(0);
      }

      // Get follower count
      const count = await dbManager.getFollowerCount(userId.toString());
      setFollowerCount(count);

      // Get following count
      const followingTotal = await dbManager.getFollowingCount(
        userId.toString(),
      );
      setFollowingCount(followingTotal);

      // If farmer, get products and leases
      if (userData.role === 'farmer') {
        const farmerProducts = await dbManager.getAllFarmerProducts(
          userId.toString(),
        );
        setProducts(farmerProducts || []);

        setLeasesLoading(true);
        try {
          // Pass UUID string to getLandLeases (owner_id is a UUID in DB)
          const ownerLeases = await dbManager.getLandLeases(userId.toString());
          setLeases(ownerLeases || []);
        } catch (err) {
          console.error('Error fetching leases for farmer profile:', err);
          setLeases([]);
        } finally {
          setLeasesLoading(false);
        }
      } else if (userData.role === 'consumer') {
        // Consumer profile: show leases owned by the consumer (owner_id = userId)
        // Assumption: consumer leases means leases the user owns. Consumers do not have products.
        setProducts([]);
        setLeasesLoading(true);
        try {
          // Pass UUID string to getLandLeases (owner_id is a UUID in DB)
          const ownerLeases = await dbManager.getLandLeases(userId.toString());
          setLeases(ownerLeases || []);
        } catch (err) {
          console.error('Error fetching leases for consumer profile:', err);
          setLeases([]);
        } finally {
          setLeasesLoading(false);
        }
        // Keep orderCount and recentOrders for backward compatibility
        const orders = await dbManager.getUserOrders(userId.toString());
        setOrderCount(orders.length);
        setRecentOrders(orders.slice(0, 3));
      } else {
        // admin or other roles: clear role-specific lists
        setProducts([]);
        setLeases([]);
        setOrderCount(0);
        setRecentOrders([]);
      }

      // If the viewer is the owner, load their orders so Orders tab is available
      if (me && String(me.id) === String(userData.id)) {
        try {
          const ownerOrders = await dbManager.getUserOrders(
            userData.id!.toString(),
          );
          setOrderCount(ownerOrders.length || 0);
          setRecentOrders(ownerOrders.slice(0, 3) || []);
        } catch (err) {
          console.error('Error fetching owner orders:', err);
        }
      }
    } catch (error) {
      console.error('Error loading user profile:', error);
      Alert.alert('Error', 'Failed to load user information');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [userId, dbManager, authManager, navigation]);

  // Always fetch follow status and follower count before rendering the button
  useEffect(() => {
    const fetchFollowStatusAndCount = async () => {
      setFollowStatusLoaded(false);
      if (!user) {
        setIsFollowing(false);
        setFollowerCount(0);
        setFollowButtonLabel('Follow');
        setFollowStatusLoaded(true);
        return;
      }
      try {
        const [following, count] = await Promise.all([
          dbManager.isFollowing(user.id!.toString()),
          dbManager.getFollowerCount(user.id!.toString()),
        ]);
        setIsFollowing(following);
        setFollowerCount(count);
        setFollowButtonLabel(following ? 'Unfollow' : 'Follow');
      } catch (error) {
        setIsFollowing(false);
        setFollowerCount(0);
        setFollowButtonLabel('Follow');
        console.error('Error fetching follow status/count:', error);
      } finally {
        setFollowStatusLoaded(true);
      }
    };
    fetchFollowStatusAndCount();
  }, [user]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await loadData();
  }, [loadData]);

  // Determine if the current viewer is the owner of this profile
  const isOwner =
    currentUser !== null &&
    user !== null &&
    String(currentUser.id) === String(user.id);

  const farmSizeDisplay = (() => {
    const rawFarmSize = user?.farm_size;
    if (
      user?.role === 'farmer' &&
      rawFarmSize !== undefined &&
      rawFarmSize !== null &&
      `${rawFarmSize}`.trim() !== ''
    ) {
      const numericValue = Number(rawFarmSize);
      if (Number.isFinite(numericValue)) {
        const formattedValue = Number.isInteger(numericValue)
          ? numericValue
          : Number(numericValue.toFixed(1));
        return `${formattedValue} acre${numericValue === 1 ? '' : 's'}`;
      }
      return String(rawFarmSize);
    }
    return null;
  })();

  const farmingExperienceDisplay = (() => {
    const rawExperience = user?.farming_experience;
    if (
      user?.role === 'farmer' &&
      rawExperience !== undefined &&
      rawExperience !== null &&
      `${rawExperience}`.trim() !== ''
    ) {
      const numericValue = Number(rawExperience);
      if (Number.isFinite(numericValue)) {
        return `${numericValue} year${numericValue === 1 ? '' : 's'}`;
      }
      return String(rawExperience);
    }
    return null;
  })();

  const farmerSpecialization = (() => {
    const rawSpecialization = user?.specialization;
    if (
      user?.role === 'farmer' &&
      rawSpecialization &&
      `${rawSpecialization}`.trim() !== ''
    ) {
      return String(rawSpecialization);
    }
    return null;
  })();

  // Ensure sensible default tab when user or ownership changes
  useEffect(() => {
    if (!user) return;
    if (isOwner) {
      // Owner: farmers see products first, consumers see leases
      if (user.role === 'farmer') setActiveTab('products');
      else setActiveTab('leases');
    } else {
      // Non-owner: farmers see products, consumers/others see leases
      if (user.role === 'farmer') setActiveTab('products');
      else setActiveTab('leases');
    }
  }, [user, isOwner]);

  const handleFollow = async () => {
    if (!user) return;

    setFollowLoading(true);
    try {
      if (isFollowing) {
        await dbManager.unfollowFarmer(user.id!.toString());
        setIsFollowing(false);
        setFollowButtonLabel('Follow');
        setFollowerCount(prev => Math.max(0, prev - 1));
        Alert.alert('Success', `You unfollowed ${user.name}`);
      } else {
        await dbManager.followFarmer(user.id!.toString());
        setIsFollowing(true);
        setFollowButtonLabel('Unfollow');
        setFollowerCount(prev => prev + 1);
        Alert.alert('Success', `You are now following ${user.name}`);
      }
      // Always re-fetch follow status and follower count from backend after action
      if (user) {
        const [following, count] = await Promise.all([
          dbManager.isFollowing(user.id!.toString()),
          dbManager.getFollowerCount(user.id!.toString()),
        ]);
        setIsFollowing(following);
        setFollowButtonLabel(following ? 'Unfollow' : 'Follow');
        setFollowerCount(count);
      }
    } catch (error: any) {
      // Handle duplicate follow error gracefully
      if (error && error.code === '23505') {
        setIsFollowing(true);
        setFollowButtonLabel('Unfollow');
        Alert.alert(
          'Already following',
          `You are already following ${user.name}`,
        );
      } else {
        setFollowButtonLabel('Follow');
        console.error('Error updating follow status:', error);
        Alert.alert('Error', 'Failed to update follow status');
      }
    } finally {
      setFollowLoading(false);
    }
  };

  const handleChat = () => {
    if (!currentUser || !user) {
      Alert.alert('Error', 'Please log in to chat');
      return;
    }

    if (currentUser.id === user.id) {
      Alert.alert('Error', 'You cannot chat with yourself');
      return;
    }

    navigation.navigate('ChatRoom', {
      roomId: buildRoomId(currentUser.id!, user.id!),
      otherUserId: user.id!.toString(),
      otherUserName: user.name,
    });
  };

  const handleAddToCart = async (product: Product) => {
    if (!currentUser) {
      Alert.alert(
        'Login Required',
        'You need to log in to add items to your cart',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Login', onPress: () => navigation.navigate('SignIn') },
        ],
      );
      return;
    }

    try {
      const result = await dbManager.addToCart({
        user_id: currentUser.id!.toString(),
        product_id: product.id!,
        quantity: 1,
      });
      try {
        const updatedCount = await dbManager.getCartItemCount(
          String(currentUser.id),
        );
        setCartItemCount(updatedCount);
      } catch (countError) {
        console.error('Error refreshing cart count after add:', countError);
        setCartItemCount(prev => prev + 1);
      }
      if (result.adjustedToMin) {
        Alert.alert(
          'Minimum Order Applied',
          `${product.name} added with the minimum order quantity of ${result.minPurchase}.`,
        );
        return;
      }
      if (result.adjustedToStock) {
        Alert.alert(
          'Limited Stock',
          `${product.name} added, but only ${result.quantity} unit(s) are currently available.`,
        );
        return;
      }
      if (result.adjustedToMax) {
        const maxLabel =
          result.maxPurchase !== null ? result.maxPurchase : result.quantity;
        Alert.alert(
          'Order Limit Applied',
          `${product.name} added up to the maximum per order of ${maxLabel}.`,
        );
        return;
      }
      Alert.alert('Success', `${product.name} added to cart`);
    } catch (error) {
      if (error instanceof CartConstraintError) {
        const { reason, minPurchase, maxPurchase, availableStock } =
          error.details;
        if (reason === 'min') {
          Alert.alert(
            'Minimum Order Required',
            `You must order at least ${minPurchase} unit(s) of ${product.name}.`,
          );
        } else if (reason === 'max' && maxPurchase !== null) {
          Alert.alert(
            'Order Limit Reached',
            `You can order up to ${maxPurchase} unit(s) of ${product.name} per purchase.`,
          );
        } else if (reason === 'stock') {
          const stockMessage =
            typeof availableStock === 'number'
              ? `Only ${availableStock} unit(s) of ${product.name} are currently available.`
              : 'Not enough stock available right now.';
          Alert.alert('Insufficient Stock', stockMessage);
        }
        return;
      }
      console.error('Error adding to cart:', error);
      Alert.alert('Error', 'Failed to add item to cart');
    }
  };

  if (loading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Loading user profile..." />
      </Layout>
    );
  }

  if (!user) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>User not found</Text>
        </View>
      </Layout>
    );
  }

  return (
    <Layout activeTab="dashboard">
      {/* Header - match ProductDetailsScreen */}

      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialCommunityIcons name="arrow-left" size={22} color="#4CAF50" />
        </TouchableOpacity>
        <Text style={styles.topHeaderTitle}>{`${user.name}'s Profile`}</Text>
        {currentUser &&
        (currentUser.role === 'farmer' || currentUser.role === 'consumer') ? (
          <TouchableOpacity
            style={styles.cartButton}
            onPress={() => navigation.navigate('Cart')}
          >
            <MaterialCommunityIcons name="cart" size={22} color="#4CAF50" />
            {cartItemCount > 0 && (
              <View style={styles.cartBadge}>
                <Text style={styles.cartBadgeText}>
                  {cartItemCount > 99 ? '99+' : cartItemCount}
                </Text>
              </View>
            )}
          </TouchableOpacity>
        ) : (
          <View style={styles.cartButton}>
            <MaterialCommunityIcons name="account" size={22} color="#757575" />
          </View>
        )}
      </View>

      <ScrollView
        style={styles.container}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#4CAF50']}
            tintColor="#4CAF50"
          />
        }
      >
        {/* User Info Card - show for both farmer and consumer */}
        <View style={styles.farmerCardSection}>
          <View style={styles.farmerCard}>
            <View style={styles.farmerCardHeader}>
              <View style={styles.farmerAvatar}>
                {user.profile_image_url ? (
                  <Image
                    source={{ uri: user.profile_image_url }}
                    style={styles.farmerAvatarImage}
                    resizeMode="cover"
                  />
                ) : (
                  <Text style={styles.farmerAvatarText}>
                    {user.name.charAt(0).toUpperCase()}
                  </Text>
                )}
              </View>
              <View style={styles.farmerCardInfo}>
                <Text style={styles.farmerName}>{user.name}</Text>
                <Text style={styles.farmerRole}>
                  {getRoleDisplayName(user.role)}
                </Text>
                <Text style={styles.farmerStats}>
                  {followerCount} follower{followerCount !== 1 ? 's' : ''} •{' '}
                  {followingCount} following •{' '}
                  {user.role === 'farmer'
                    ? `${products.length} product${
                        products.length !== 1 ? 's' : ''
                      }`
                    : `${orderCount} order${orderCount !== 1 ? 's' : ''}`}
                </Text>
              </View>
            </View>
            {/* Additional Info */}
            <View style={styles.farmerDetailsRow}>
              {user.email ? (
                <View style={styles.farmerDetailItem}>
                  <MaterialCommunityIcons
                    name="email"
                    size={16}
                    color="#888"
                    style={styles.farmerDetailIcon}
                  />
                  <Text style={styles.farmerDetailLabel}>Email:</Text>
                  <Text style={styles.farmerDetailValue}>{user.email}</Text>
                </View>
              ) : null}
              {user.phone ? (
                <View style={styles.farmerDetailItem}>
                  <MaterialCommunityIcons
                    name="phone"
                    size={16}
                    color="#888"
                    style={styles.farmerDetailIcon}
                  />
                  <Text style={styles.farmerDetailLabel}>Phone:</Text>
                  <Text style={styles.farmerDetailValue}>{user.phone}</Text>
                </View>
              ) : null}
              {user.role === 'farmer' && user.farm_name ? (
                <View style={styles.farmerDetailItem}>
                  <MaterialCommunityIcons
                    name="home-variant"
                    size={16}
                    color="#888"
                    style={styles.farmerDetailIcon}
                  />
                  <Text style={styles.farmerDetailLabel}>Farm:</Text>
                  <Text style={styles.farmerDetailValue}>
                    {String(user.farm_name)}
                  </Text>
                </View>
              ) : null}
              {farmSizeDisplay && (
                <View style={styles.farmerDetailItem}>
                  <MaterialCommunityIcons
                    name="sprout"
                    size={16}
                    color="#888"
                    style={styles.farmerDetailIcon}
                  />
                  <Text style={styles.farmerDetailLabel}>Farm Size:</Text>
                  <Text style={styles.farmerDetailValue}>
                    {farmSizeDisplay}
                  </Text>
                </View>
              )}
              {farmingExperienceDisplay && (
                <View style={styles.farmerDetailItem}>
                  <MaterialCommunityIcons
                    name="clock-outline"
                    size={16}
                    color="#888"
                    style={styles.farmerDetailIcon}
                  />
                  <Text style={styles.farmerDetailLabel}>Experience:</Text>
                  <Text style={styles.farmerDetailValue}>
                    {farmingExperienceDisplay}
                  </Text>
                </View>
              )}
              {farmerSpecialization && (
                <View style={styles.farmerDetailItem}>
                  <MaterialCommunityIcons
                    name="leaf"
                    size={16}
                    color="#888"
                    style={styles.farmerDetailIcon}
                  />
                  <Text style={styles.farmerDetailLabel}>Focus:</Text>
                  <Text style={styles.farmerDetailValue}>
                    {farmerSpecialization}
                  </Text>
                </View>
              )}
              {/* Consumer/Farmer: show gender */}
              {user.gender && (
                <View style={styles.farmerDetailItem}>
                  <MaterialCommunityIcons
                    name="gender-male-female"
                    size={16}
                    color="#888"
                    style={styles.farmerDetailIcon}
                  />
                  <Text style={styles.farmerDetailLabel}>Gender:</Text>
                  <Text style={styles.farmerDetailValue}>{user.gender}</Text>
                </View>
              )}
              {/* Address for both roles */}
              {(() => {
                const addressParts = [
                  user.address_line1,
                  user.address_line2,
                  user.city,
                  user.state,
                  user.postal_code,
                  user.country,
                ].filter(Boolean);
                const formattedAddress = addressParts.join(', ');
                return (
                  <View style={styles.farmerDetailItem}>
                    <MaterialCommunityIcons
                      name="map-marker"
                      size={16}
                      color="#888"
                      style={styles.farmerDetailIcon}
                    />
                    <Text style={styles.farmerDetailLabel}>Address:</Text>
                    <Text style={styles.farmerDetailValue}>
                      {formattedAddress ? formattedAddress : 'N/A'}
                    </Text>
                  </View>
                );
              })()}
            </View>
            {currentUser &&
              String(currentUser.id) !== String(user.id) &&
              followStatusLoaded && (
                <View style={styles.farmerActions}>
                  <TouchableOpacity
                    style={[
                      styles.actionButton,
                      isFollowing ? styles.unfollowButton : styles.followButton,
                    ]}
                    onPress={handleFollow}
                    disabled={loading || followLoading || !followStatusLoaded}
                  >
                    <Text style={styles.actionButtonText}>
                      {followButtonLabel}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.chatButton}
                    onPress={handleChat}
                  >
                    <View style={styles.chatButtonContent}>
                      <MaterialCommunityIcons
                        name="message-text"
                        size={16}
                        color="#fff"
                        style={styles.chatButtonIcon}
                      />
                      <Text style={styles.chatButtonText}>Chat</Text>
                    </View>
                  </TouchableOpacity>
                </View>
              )}
          </View>
        </View>

        {/* Products/Leases/Orders Section with role-based tabs */}
        <View style={styles.productsSection}>
          {/* If the profile owner is an admin, do not show tabs or any lists - show a single message */}
          {isOwner && currentUser?.role === 'admin' ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateText}>
                Admin profile: No public items to show
              </Text>
            </View>
          ) : (
            <>
              {/* Non-admin-owner or non-owner: show the normal tabs and content */}
              {/* Tabs for farmer: Products / Leases; consumer: Leases only */}
              {/* If viewer is the profile owner, show Products / Leases / Orders */}
              {isOwner ? (
                <View style={styles.tabRow}>
                  {user?.role === 'farmer' && (
                    <TouchableOpacity
                      style={[
                        styles.tabButton,
                        activeTab === 'products' && styles.tabButtonActive,
                      ]}
                      onPress={() => setActiveTab('products')}
                    >
                      <Text
                        style={
                          activeTab === 'products'
                            ? styles.tabTextActive
                            : styles.tabText
                        }
                      >
                        Products
                      </Text>
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity
                    style={[
                      styles.tabButton,
                      activeTab === 'leases' && styles.tabButtonActive,
                    ]}
                    onPress={() => setActiveTab('leases')}
                  >
                    <Text
                      style={
                        activeTab === 'leases'
                          ? styles.tabTextActive
                          : styles.tabText
                      }
                    >
                      Leases
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[
                      styles.tabButton,
                      activeTab === 'orders' && styles.tabButtonActive,
                    ]}
                    onPress={() => setActiveTab('orders')}
                  >
                    <Text
                      style={
                        activeTab === 'orders'
                          ? styles.tabTextActive
                          : styles.tabText
                      }
                    >
                      Orders
                    </Text>
                  </TouchableOpacity>
                </View>
              ) : (
                user.role === 'farmer' && (
                  <View style={styles.tabRow}>
                    <TouchableOpacity
                      style={[
                        styles.tabButton,
                        activeTab === 'products' && styles.tabButtonActive,
                      ]}
                      onPress={() => setActiveTab('products')}
                    >
                      <Text
                        style={
                          activeTab === 'products'
                            ? styles.tabTextActive
                            : styles.tabText
                        }
                      >
                        Products
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[
                        styles.tabButton,
                        activeTab === 'leases' && styles.tabButtonActive,
                      ]}
                      onPress={() => setActiveTab('leases')}
                    >
                      <Text
                        style={
                          activeTab === 'leases'
                            ? styles.tabTextActive
                            : styles.tabText
                        }
                      >
                        Leases
                      </Text>
                    </TouchableOpacity>
                  </View>
                )
              )}

              {/* Farmer - Products tab */}
              {user.role === 'farmer' && activeTab === 'products' && (
                <>
                  <Text style={styles.sectionTitle}>Products</Text>
                  {products.length === 0 ? (
                    <View style={styles.emptyState}>
                      <Text style={styles.emptyStateText}>
                        No products available from this farmer
                      </Text>
                    </View>
                  ) : (
                    <View style={styles.productsGrid}>
                      {products.map(product => (
                        <View key={product.id} style={styles.productCard}>
                          <TouchableOpacity
                            onPress={() =>
                              navigation.navigate('ProductDetails', {
                                productId: product.id!,
                              })
                            }
                          >
                            <Image
                              source={
                                product.image_url
                                  ? { uri: product.image_url }
                                  : require('../../assets/placeholder.png')
                              }
                              style={styles.productImage}
                              resizeMode="cover"
                            />
                          </TouchableOpacity>
                          <View style={styles.productInfo}>
                            <Text style={styles.productName}>
                              {product.name}
                            </Text>
                            <Text style={styles.productCategory}>
                              {product.category}
                            </Text>
                            <Text style={styles.productPrice}>
                              ৳{product.price.toFixed(2)}
                            </Text>
                            <Text style={styles.productStock}>
                              Stock: {product.quantity} {product.unit}
                            </Text>
                            <View style={styles.productActions}>
                              <TouchableOpacity
                                style={styles.detailsButton}
                                onPress={() =>
                                  navigation.navigate('ProductDetails', {
                                    productId: product.id!,
                                  })
                                }
                              >
                                <Text style={styles.detailsButtonText}>
                                  Details
                                </Text>
                              </TouchableOpacity>
                              {/* Hide Add to Cart for owner and for admin users */}
                              {(!currentUser ||
                                String(currentUser.id) !== String(user.id)) &&
                                currentUser?.role !== 'admin' && (
                                  <TouchableOpacity
                                    style={[
                                      styles.addToCartButton,
                                      product.quantity === 0 &&
                                        styles.addToCartButtonDisabled,
                                    ]}
                                    onPress={() => handleAddToCart(product)}
                                    disabled={product.quantity === 0}
                                  >
                                    <Text style={styles.addToCartButtonText}>
                                      {product.quantity > 0
                                        ? 'Buy'
                                        : 'Out of Stock'}
                                    </Text>
                                  </TouchableOpacity>
                                )}
                            </View>
                          </View>
                        </View>
                      ))}
                    </View>
                  )}
                </>
              )}

              {/* Leases tab for farmer and consumer (consumer shows leases only) */}
              {activeTab === 'leases' &&
                (user.role === 'farmer' || user.role === 'consumer') && (
                  <>
                    <Text style={styles.sectionTitle}>Leases</Text>
                    {leasesLoading ? (
                      <ModernLoading
                        visible={true}
                        message="Loading leases..."
                      />
                    ) : leases.length === 0 ? (
                      <View style={styles.emptyState}>
                        <Text style={styles.emptyStateText}>
                          No leases found
                        </Text>
                      </View>
                    ) : (
                      <View>
                        {leases.map(lease => (
                          <TouchableOpacity
                            key={lease.id}
                            style={styles.leaseCard}
                            onPress={() =>
                              navigation.navigate('LandLeaseDetails', {
                                leaseId: String(lease.id),
                              })
                            }
                          >
                            {/* Lease Image */}
                            <Image
                              source={
                                lease.image_url
                                  ? { uri: lease.image_url }
                                  : require('../../assets/placeholder.png')
                              }
                              style={{
                                width: '100%',
                                height: 120,
                                borderRadius: 8,
                                marginBottom: 8,
                                backgroundColor: '#EEEEEE',
                              }}
                              resizeMode="cover"
                            />
                            <Text style={styles.leaseTitle}>
                              {lease.title || 'Lease'}
                            </Text>
                            <Text style={styles.leaseDetail}>
                              Owner:{' '}
                              {lease.owner_name || lease.owner_email || 'N/A'}
                            </Text>
                            <Text style={styles.leaseDetail}>
                              Status: {lease.status || 'N/A'}
                            </Text>
                            <Text style={styles.leaseDetail}>
                              Price: {lease.price || 'N/A'}
                            </Text>
                            <TouchableOpacity
                              style={styles.detailsButton}
                              onPress={() =>
                                navigation.navigate('LandLeaseDetails', {
                                  leaseId: String(lease.id),
                                })
                              }
                            >
                              <Text style={styles.detailsButtonText}>View</Text>
                            </TouchableOpacity>
                          </TouchableOpacity>
                        ))}
                      </View>
                    )}
                  </>
                )}

              {/* Consumer - if not showing leases tab, as fallback show recent orders */}
              {user.role === 'consumer' &&
                !isOwner &&
                activeTab !== 'leases' && (
                  <>
                    <Text style={styles.sectionTitle}>Recent Orders</Text>
                    {orderCount === 0 ? (
                      <View style={styles.emptyState}>
                        <Text style={styles.emptyStateText}>
                          No orders placed yet
                        </Text>
                      </View>
                    ) : (
                      <View>
                        {recentOrders.map(order => (
                          <View key={order.id} style={styles.orderCard}>
                            <View style={styles.orderTitleRow}>
                              <MaterialCommunityIcons
                                name="cart"
                                size={16}
                                color="#4CAF50"
                                style={styles.orderTitleIcon}
                              />
                              <Text style={styles.orderTitle}>
                                Order #{order.id}
                              </Text>
                            </View>
                            <Text style={styles.orderDetail}>
                              Product: {order.product_id}
                            </Text>
                            <Text style={styles.orderDetail}>
                              Quantity: {order.quantity}
                            </Text>
                            <Text style={styles.orderDetail}>
                              Total: ৳{order.total_price}
                            </Text>
                            <Text style={styles.orderDetail}>
                              Status: {order.status}
                            </Text>
                          </View>
                        ))}
                      </View>
                    )}
                  </>
                )}

              {/* Orders tab for profile owner */}
              {isOwner && activeTab === 'orders' && (
                <>
                  <Text style={styles.sectionTitle}>Orders</Text>
                  {orderCount === 0 ? (
                    <View style={styles.emptyState}>
                      <Text style={styles.emptyStateText}>No orders yet</Text>
                    </View>
                  ) : (
                    <View>
                      {recentOrders.map(order => (
                        <View key={order.id} style={styles.orderCard}>
                          <View style={styles.orderTitleRow}>
                            <MaterialCommunityIcons
                              name="cart"
                              size={16}
                              color="#4CAF50"
                              style={styles.orderTitleIcon}
                            />
                            <Text style={styles.orderTitle}>
                              Order #{order.id}
                            </Text>
                          </View>
                          <Text style={styles.orderDetail}>
                            Product: {order.product_id}
                          </Text>
                          <Text style={styles.orderDetail}>
                            Quantity: {order.quantity}
                          </Text>
                          <Text style={styles.orderDetail}>
                            Total: ৳{order.total_price}
                          </Text>
                          <Text style={styles.orderDetail}>
                            Status: {order.status}
                          </Text>
                        </View>
                      ))}
                    </View>
                  )}
                </>
              )}

              {/* Admin or roles with no public content show nothing */}
              {user.role === 'admin' && (
                <View style={styles.emptyState}>
                  <Text style={styles.emptyStateText}>
                    No public items to show
                  </Text>
                </View>
              )}
            </>
          )}
        </View>
        <View style={styles.bottomPadding} />
      </ScrollView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  farmerDetailsRow: {
    marginTop: 10,
    marginBottom: 6,
    flexDirection: 'column',
    gap: 4,
  },
  farmerDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
  },
  farmerDetailIcon: {
    marginRight: 6,
  },
  farmerDetailLabel: {
    fontSize: 13,
    color: '#888',
    marginRight: 4,
    fontWeight: '500',
  },
  farmerDetailValue: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
    flexShrink: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  backButtonText: {
    fontSize: 20,
    color: '#4CAF50',
    fontWeight: 'bold',
  },
  topHeaderTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1A',
    textAlign: 'center',
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 18,
    color: '#999',
    textAlign: 'center',
  },
  // Farmer Card Section (outer)
  farmerCardSection: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  // Farmer Card (inner)
  farmerCard: {
    backgroundColor: '#f8f9fa',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  farmerCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  farmerAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  farmerAvatarImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  farmerAvatarText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 28,
  },
  farmerCardInfo: {
    flex: 1,
  },
  farmerName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  farmerRole: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  farmerStats: {
    fontSize: 14,
    color: '#4CAF50',
    fontWeight: '500',
  },
  farmerActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  actionButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    minWidth: 80,
    alignItems: 'center',
  },
  followButton: {
    backgroundColor: '#4CAF50',
  },
  unfollowButton: {
    backgroundColor: '#FF5722',
  },
  actionButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  chatButton: {
    backgroundColor: '#2196F3',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    alignItems: 'center',
  },
  chatButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  chatButtonIcon: {
    marginRight: 4,
  },
  chatButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  // Products Section
  productsSection: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  emptyState: {
    padding: 40,
    alignItems: 'center',
  },
  emptyStateText: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  productCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    overflow: 'hidden',
    width: '48%',
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
    borderWidth: 1,
    borderColor: '#F0F0F0',
    minHeight: 230,
    maxHeight: 260,
  },
  productImage: {
    width: '100%',
    height: 100,
    backgroundColor: '#EEEEEE',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  cartButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
    position: 'relative',
  },
  cartBadge: {
    position: 'absolute',
    top: 2,
    right: 2,
    backgroundColor: '#FF5722',
    borderRadius: 10,
    minWidth: 18,
    height: 18,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
  },
  cartBadgeText: {
    color: '#fff',
    fontSize: 10,
    fontWeight: '700',
  },
  productInfo: {
    padding: 14,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  productCategory: {
    fontSize: 13,
    color: '#666',
    marginBottom: 4,
  },
  productPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginBottom: 4,
  },
  productStock: {
    fontSize: 13,
    color: '#999',
    marginBottom: 8,
  },
  productActions: {
    flexDirection: 'row',
    gap: 6,
  },
  detailsButton: {
    backgroundColor: '#2196F3',
    borderRadius: 16,
    paddingVertical: 8,
    paddingHorizontal: 10,
    flex: 1,
    alignItems: 'center',
  },
  detailsButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  addToCartButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 16,
    paddingVertical: 8,
    paddingHorizontal: 10,
    flex: 1,
    alignItems: 'center',
  },
  orderCard: {
    backgroundColor: '#f8f9fa',
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#F0F0F0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  orderTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  orderTitleIcon: {
    marginRight: 4,
  },
  orderTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  orderDetail: {
    fontSize: 13,
    color: '#333',
    marginBottom: 2,
  },
  addToCartButtonDisabled: {
    backgroundColor: '#ccc',
  },
  addToCartButtonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  bottomPadding: {
    height: 32,
  },
  tabRow: {
    flexDirection: 'row',
    marginBottom: 12,
    gap: 8,
  },
  tabButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
  },
  tabButtonActive: {
    backgroundColor: '#4CAF50',
  },
  tabText: {
    color: '#333',
    fontWeight: '600',
  },
  tabTextActive: {
    color: '#fff',
    fontWeight: '700',
  },
  leaseCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#F0F0F0',
  },
  leaseTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
    marginBottom: 6,
  },
  leaseDetail: {
    fontSize: 13,
    color: '#555',
    marginBottom: 4,
  },
});

export default UserProfileScreen;
