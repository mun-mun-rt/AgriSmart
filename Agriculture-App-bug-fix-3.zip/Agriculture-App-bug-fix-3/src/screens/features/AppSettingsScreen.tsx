import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Alert,
  TouchableOpacity,
  Modal,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, User, AppInfo } from '../../types';
import Layout from '../../components/Layout';
import ModernHeader from '../../components/ModernHeader';
import ModernInput from '../../components/ModernInput';
import ModernButton from '../../components/ModernButton';
import ModernLoading from '../../components/ModernLoading';
import SupabaseAuthManager from '../../api/SupabaseAuthManager';
import SupabaseDatabaseManager from '../../api/SupabaseDatabaseManager';
import { useAppInfo } from '../../contexts/AppInfoContext';
import { getRoleDisplayName } from '../../utils/index';

type AppSettingsNavigationProp = StackNavigationProp<
  RootStackParamList,
  'AppSettings'
>;

const AppSettingsScreen = () => {
  const navigation = useNavigation<AppSettingsNavigationProp>();

  // Initialize managers
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager = SupabaseDatabaseManager.getInstance();

  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { appInfo: contextAppInfo, refreshAppInfo } = useAppInfo();

  // Profile update states
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [profileData, setProfileData] = useState({
    // Basic info
    name: '',
    email: '',
    phone: '',

    // Address
    address_line1: '',
    address_line2: '',
    city: '',
    state: '',
    postal_code: '',
    country: '',

    // Personal
    date_of_birth: '',
    gender: '' as '' | 'male' | 'female' | 'other',
    profile_image_url: '',
    bio: '',

    // Farmer-specific
    farm_name: '',
    farm_size: '',
    farming_experience: '',
    specialization: '',
    mobile_banking_bkash: '',
    mobile_banking_nagad: '',
    mobile_banking_rocket: '',

    // Password change
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const [profileErrors, setProfileErrors] = useState<Record<string, string>>(
    {},
  );

  // App info update states (for admin)
  const [showAppInfoModal, setShowAppInfoModal] = useState(false);
  const [appInfo, setAppInfo] = useState<AppInfo>({
    app_name: 'AgriSmart Bangladesh',
    app_logo_url: '',
    welcome_message: 'Welcome to AgriSmart Bangladesh',
    contact_email: 'support@AgriSmart.bd',
    version: '1.0.0',
  });
  const [appInfoErrors, setAppInfoErrors] = useState<Record<string, string>>(
    {},
  );

  useEffect(() => {
    loadUserData();
    setAppInfo(contextAppInfo);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contextAppInfo]);

  const loadUserData = async () => {
    try {
      const user = await authManager.getCurrentUser();
      setCurrentUser(user);
      setIsAdmin(user?.role === 'admin');

      if (user) {
        setProfileData({
          // Basic info
          name: user.name || '',
          email: user.email || '',
          phone: user.phone || '',

          // Address
          address_line1: user.address_line1 || '',
          address_line2: user.address_line2 || '',
          city: user.city || '',
          state: user.state || '',
          postal_code: user.postal_code || '',
          country: user.country || '',

          // Personal
          date_of_birth: user.date_of_birth || '',
          gender: user.gender || '',
          profile_image_url: user.profile_image_url || '',
          bio: user.bio || '',

          // Farmer-specific
          farm_name: user.farm_name || '',
          farm_size: user.farm_size?.toString() || '',
          farming_experience: user.farming_experience?.toString() || '',
          specialization: user.specialization || '',
          mobile_banking_bkash: user.mobile_banking_bkash || '',
          mobile_banking_nagad: user.mobile_banking_nagad || '',
          mobile_banking_rocket: user.mobile_banking_rocket || '',

          // Password fields
          currentPassword: '',
          newPassword: '',
          confirmPassword: '',
        });
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const validateProfileForm = (): boolean => {
    const errors: Record<string, string> = {};

    // Basic validation
    if (!profileData.name.trim()) {
      errors.name = 'Name is required';
    }
    if (!profileData.email.trim()) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(profileData.email)) {
      errors.email = 'Please enter a valid email';
    }

    // Password validation (only if trying to change password)
    if (profileData.newPassword) {
      if (!profileData.currentPassword) {
        errors.currentPassword =
          'Current password is required to change password';
      }
      if (profileData.newPassword.length < 6) {
        errors.newPassword = 'New password must be at least 6 characters';
      }
      if (profileData.newPassword !== profileData.confirmPassword) {
        errors.confirmPassword = 'Passwords do not match';
      }
    }

    if (currentUser?.role === 'farmer') {
      const bkash = profileData.mobile_banking_bkash.trim();
      const nagad = profileData.mobile_banking_nagad.trim();
      const rocket = profileData.mobile_banking_rocket.trim();
      if (!bkash && !nagad && !rocket) {
        errors.mobile_banking =
          'Add at least one mobile banking account number so customers can pay you.';
      }
    }

    setProfileErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleUpdateProfile = async () => {
    if (!validateProfileForm()) return;

    setIsLoading(true);
    try {
      // Prepare profile updates
      const updates: Partial<User> = {
        name: profileData.name,
        email: profileData.email,
        phone: profileData.phone || undefined,
        profile_image_url: profileData.profile_image_url || undefined,
        address_line1: profileData.address_line1 || undefined,
        address_line2: profileData.address_line2 || undefined,
        city: profileData.city || undefined,
        state: profileData.state || undefined,
        postal_code: profileData.postal_code || undefined,
        country: profileData.country || undefined,
        date_of_birth: profileData.date_of_birth || undefined,
        gender: profileData.gender || undefined,
        bio: profileData.bio || undefined,
      };

      // Add farmer-specific fields if user is a farmer
      if (currentUser?.role === 'farmer') {
        updates.farm_name = profileData.farm_name || undefined;
        updates.farm_size = profileData.farm_size
          ? parseFloat(profileData.farm_size)
          : undefined;
        updates.farming_experience = profileData.farming_experience
          ? parseInt(profileData.farming_experience)
          : undefined;
        updates.specialization = profileData.specialization || undefined;
        const sanitizeMobile = (value: string) => {
          const trimmed = value.trim();
          return trimmed.length > 0 ? trimmed : null;
        };
        updates.mobile_banking_bkash = sanitizeMobile(
          profileData.mobile_banking_bkash,
        );
        updates.mobile_banking_nagad = sanitizeMobile(
          profileData.mobile_banking_nagad,
        );
        updates.mobile_banking_rocket = sanitizeMobile(
          profileData.mobile_banking_rocket,
        );
      }

      // Update profile
      const profileResponse = await authManager.updateProfile(updates);
      if (!profileResponse.success) {
        throw new Error(profileResponse.message);
      }

      // Handle password change if requested
      if (profileData.newPassword && profileData.currentPassword) {
        const passwordResponse = await authManager.updateAuthCredentials(
          profileData.email,
          profileData.newPassword,
        );
        if (!passwordResponse.success) {
          throw new Error(
            'Profile updated but password change failed: ' +
              passwordResponse.message,
          );
        }
      }

      Alert.alert('Success', 'Profile updated successfully!');
      setShowProfileModal(false);

      // Clear password fields
      setProfileData(prev => ({
        ...prev,
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      }));

      // Reload user data
      await loadUserData();
    } catch (error) {
      console.error('Error updating profile:', error);
      Alert.alert(
        'Error',
        error instanceof Error ? error.message : 'Failed to update profile',
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    Alert.alert('Logout', 'Are you sure you want to logout?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Logout',
        style: 'destructive',
        onPress: async () => {
          try {
            await authManager.signOut();
            navigation.replace('Welcome'); // Navigation handled by AuthAwareNavigator
          } catch (error) {
            console.error('Logout error:', error);
            Alert.alert('Error', 'Failed to logout');
          }
        },
      },
    ]);
  };

  const handleDeleteAccount = async () => {
    Alert.alert(
      'Delete Account',
      'This action cannot be undone. All your data including products, orders, messages, and account information will be permanently deleted.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete Account',
          style: 'destructive',
          onPress: () => {
            // Second confirmation
            Alert.alert(
              'Final Confirmation',
              'Are you absolutely sure you want to delete your account? This action is permanent and cannot be reversed.',
              [
                { text: 'Cancel', style: 'cancel' },
                {
                  text: 'Yes, Delete My Account',
                  style: 'destructive',
                  onPress: async () => {
                    setIsLoading(true);
                    try {
                      const result = await authManager.deleteAccount();
                      if (result.success) {
                        Alert.alert(
                          'Account Deleted',
                          'Your account has been permanently deleted.',
                          [
                            {
                              text: 'OK',
                              onPress: () => {
                                navigation.reset({
                                  index: 0,
                                  routes: [{ name: 'Welcome' }],
                                });
                              },
                            },
                          ],
                        );
                      } else {
                        Alert.alert('Error', result.message);
                      }
                    } catch (error) {
                      console.error('Delete account error:', error);
                      Alert.alert('Error', 'Failed to delete account');
                    } finally {
                      setIsLoading(false);
                    }
                  },
                },
              ],
            );
          },
        },
      ],
    );
  };

  const validateAppInfoForm = (): boolean => {
    const errors: Record<string, string> = {};

    // Basic validation
    if (!appInfo.app_name.trim()) {
      errors.app_name = 'App name is required';
    }
    if (appInfo.app_logo_url && appInfo.app_logo_url.trim()) {
      const urlPattern = /^https?:\/\/.+/i;
      if (!urlPattern.test(appInfo.app_logo_url.trim())) {
        errors.app_logo_url =
          'Please enter a valid URL starting with http:// or https://';
      }
    }
    if (!appInfo.welcome_message.trim()) {
      errors.welcome_message = 'Welcome message is required';
    }
    if (!appInfo.contact_email.trim()) {
      errors.contact_email = 'Contact email is required';
    } else if (!/\S+@\S+\.\S+/.test(appInfo.contact_email)) {
      errors.contact_email = 'Please enter a valid email';
    }
    if (!appInfo.version.trim()) {
      errors.version = 'Version is required';
    }

    setAppInfoErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleUpdateAppInfo = async () => {
    if (!validateAppInfoForm()) return;

    setIsLoading(true);
    try {
      await dbManager.updateAppInfo(appInfo);

      // Refresh the app info context
      await refreshAppInfo();

      Alert.alert('Success', 'App information updated successfully!');
      setShowAppInfoModal(false);
    } catch (error) {
      console.error('Error updating app info:', error);
      Alert.alert(
        'Error',
        error instanceof Error
          ? error.message
          : 'Failed to update app information',
      );
    } finally {
      setIsLoading(false);
    }
  };

  const renderProfileModal = () => (
    <Modal
      visible={showProfileModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowProfileModal(false)}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <ModernHeader
            title="Edit Profile"
            leftIconName="close"
            onLeftPress={() => setShowProfileModal(false)}
          />

          <ScrollView
            style={styles.modalScroll}
            showsVerticalScrollIndicator={false}
          >
            {/* Basic Information */}
            <Text style={styles.sectionTitle}>Basic Information</Text>
            <ModernInput
              label="Full Name *"
              value={profileData.name}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, name: text }))
              }
              error={profileErrors.name}
            />
            <ModernInput
              label="Email *"
              value={profileData.email}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, email: text }))
              }
              error={profileErrors.email}
              keyboardType="email-address"
            />
            <ModernInput
              label="Phone"
              value={profileData.phone}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, phone: text }))
              }
              keyboardType="phone-pad"
            />

            {/* Address Information */}
            <View style={styles.divider} />
            <Text style={styles.sectionTitle}>Address</Text>
            <ModernInput
              label="Address Line 1"
              value={profileData.address_line1}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, address_line1: text }))
              }
            />
            <ModernInput
              label="Address Line 2"
              value={profileData.address_line2}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, address_line2: text }))
              }
            />
            <ModernInput
              label="City"
              value={profileData.city}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, city: text }))
              }
            />
            <ModernInput
              label="State/Province"
              value={profileData.state}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, state: text }))
              }
            />
            <ModernInput
              label="Postal Code"
              value={profileData.postal_code}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, postal_code: text }))
              }
            />
            <ModernInput
              label="Country"
              value={profileData.country}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, country: text }))
              }
            />

            {/* Personal Information */}
            <View style={styles.divider} />
            <Text style={styles.sectionTitle}>Personal Information</Text>
            <ModernInput
              label="Date of Birth (YYYY-MM-DD)"
              value={profileData.date_of_birth}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, date_of_birth: text }))
              }
              placeholder="1990-01-01"
            />
            <View style={styles.genderContainer}>
              <Text style={styles.inputLabel}>Gender</Text>
              <View style={styles.genderButtons}>
                {[
                  { label: 'Male', value: 'male' },
                  { label: 'Female', value: 'female' },
                  { label: 'Other', value: 'other' },
                ].map(option => (
                  <TouchableOpacity
                    key={option.value}
                    style={[
                      styles.genderButton,
                      profileData.gender === option.value &&
                        styles.selectedGenderButton,
                    ]}
                    onPress={() =>
                      setProfileData(prev => ({
                        ...prev,
                        gender: option.value as any,
                      }))
                    }
                  >
                    <Text
                      style={[
                        styles.genderButtonText,
                        profileData.gender === option.value &&
                          styles.selectedGenderButtonText,
                      ]}
                    >
                      {option.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            <ModernInput
              label="Profile Image URL"
              value={profileData.profile_image_url}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, profile_image_url: text }))
              }
              placeholder="https://..."
            />
            <ModernInput
              label="Bio"
              value={profileData.bio}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, bio: text }))
              }
              multiline
              numberOfLines={3}
            />

            {/* Farmer-specific fields */}
            {currentUser?.role === 'farmer' && (
              <>
                <View style={styles.divider} />
                <Text style={styles.sectionTitle}>Farm Information</Text>
                <ModernInput
                  label="Farm Name"
                  value={profileData.farm_name}
                  onChangeText={text =>
                    setProfileData(prev => ({ ...prev, farm_name: text }))
                  }
                />
                <ModernInput
                  label="Farm Size (acres)"
                  value={profileData.farm_size}
                  onChangeText={text =>
                    setProfileData(prev => ({ ...prev, farm_size: text }))
                  }
                  keyboardType="numeric"
                />
                <ModernInput
                  label="Farming Experience (years)"
                  value={profileData.farming_experience}
                  onChangeText={text =>
                    setProfileData(prev => ({
                      ...prev,
                      farming_experience: text,
                    }))
                  }
                  keyboardType="numeric"
                />
                <ModernInput
                  label="Specialization"
                  value={profileData.specialization}
                  onChangeText={text =>
                    setProfileData(prev => ({ ...prev, specialization: text }))
                  }
                />
                <Text style={styles.helperText}>
                  Update the mobile banking numbers that customers can use to
                  pay you. Provide at least one provider to allow checkout.
                </Text>
                <ModernInput
                  label="bKash Account Number"
                  value={profileData.mobile_banking_bkash}
                  onChangeText={text =>
                    setProfileData(prev => ({
                      ...prev,
                      mobile_banking_bkash: text,
                    }))
                  }
                  keyboardType="phone-pad"
                  error={profileErrors.mobile_banking}
                />
                <ModernInput
                  label="Nagad Account Number"
                  value={profileData.mobile_banking_nagad}
                  onChangeText={text =>
                    setProfileData(prev => ({
                      ...prev,
                      mobile_banking_nagad: text,
                    }))
                  }
                  keyboardType="phone-pad"
                />
                <ModernInput
                  label="Rocket Account Number"
                  value={profileData.mobile_banking_rocket}
                  onChangeText={text =>
                    setProfileData(prev => ({
                      ...prev,
                      mobile_banking_rocket: text,
                    }))
                  }
                  keyboardType="phone-pad"
                />
              </>
            )}

            {/* Password Change */}
            <View style={styles.divider} />
            <Text style={styles.sectionTitle}>Change Password</Text>
            <ModernInput
              label="Current Password"
              value={profileData.currentPassword}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, currentPassword: text }))
              }
              secureTextEntry
              error={profileErrors.currentPassword}
            />
            <ModernInput
              label="New Password"
              value={profileData.newPassword}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, newPassword: text }))
              }
              secureTextEntry
              error={profileErrors.newPassword}
            />
            <ModernInput
              label="Confirm New Password"
              value={profileData.confirmPassword}
              onChangeText={text =>
                setProfileData(prev => ({ ...prev, confirmPassword: text }))
              }
              secureTextEntry
              error={profileErrors.confirmPassword}
            />

            <ModernButton
              title="Update Profile"
              onPress={handleUpdateProfile}
              disabled={isLoading}
              style={styles.updateButton}
            />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  const renderAppInfoModal = () => (
    <Modal
      visible={showAppInfoModal}
      animationType="slide"
      transparent={true}
      onRequestClose={() => setShowAppInfoModal(false)}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <ModernHeader
            title="Edit App Information"
            leftIconName="close"
            onLeftPress={() => setShowAppInfoModal(false)}
          />

          <ScrollView
            style={styles.modalScroll}
            showsVerticalScrollIndicator={false}
          >
            <Text style={styles.sectionTitle}>Application Settings</Text>

            <ModernInput
              label="App Name *"
              value={appInfo.app_name}
              onChangeText={text =>
                setAppInfo(prev => ({ ...prev, app_name: text }))
              }
              error={appInfoErrors.app_name}
              placeholder="Enter application name"
            />

            <ModernInput
              label="App Logo URL"
              value={appInfo.app_logo_url || ''}
              onChangeText={text =>
                setAppInfo(prev => ({ ...prev, app_logo_url: text }))
              }
              error={appInfoErrors.app_logo_url}
              placeholder="Enter logo image URL (https://...)"
            />

            <ModernInput
              label="Welcome Message *"
              value={appInfo.welcome_message}
              onChangeText={text =>
                setAppInfo(prev => ({ ...prev, welcome_message: text }))
              }
              error={appInfoErrors.welcome_message}
              placeholder="Enter welcome message"
              multiline
              numberOfLines={3}
              style={{ height: 80 }}
            />

            <ModernInput
              label="Contact Email *"
              value={appInfo.contact_email}
              onChangeText={text =>
                setAppInfo(prev => ({ ...prev, contact_email: text }))
              }
              error={appInfoErrors.contact_email}
              placeholder="Enter contact email"
              keyboardType="email-address"
            />

            <ModernInput
              label="App Version *"
              value={appInfo.version}
              onChangeText={text =>
                setAppInfo(prev => ({ ...prev, version: text }))
              }
              error={appInfoErrors.version}
              placeholder="e.g., 1.0.0"
            />

            <ModernButton
              title="Update App Information"
              onPress={handleUpdateAppInfo}
              disabled={isLoading}
              style={styles.updateButton}
            />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  return (
    <Layout activeTab="settings">
      {/* Header Section */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
            activeOpacity={0.7}
          >
            <MaterialCommunityIcons name="arrow-left" size={22} color="#333" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Settings</Text>
          <View style={styles.headerPlaceholder} />
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* User Profile Section */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionTitleRow}>
            <MaterialCommunityIcons
              name="account-circle-outline"
              size={22}
              color="#4CAF50"
              style={styles.sectionTitleIcon}
            />
            <Text style={styles.sectionTitleText}>Profile</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Name:</Text>
            <Text style={styles.infoValue}>
              {currentUser?.name || 'Not set'}
            </Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Email:</Text>
            <Text style={styles.infoValue}>
              {currentUser?.email || 'Not set'}
            </Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Role:</Text>
            <Text style={styles.infoValue}>
              {getRoleDisplayName(currentUser?.role)}
            </Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Phone:</Text>
            <Text style={styles.infoValue}>
              {currentUser?.phone || 'Not set'}
            </Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Profile Image:</Text>
            <Text
              style={styles.infoValue}
              numberOfLines={1}
              ellipsizeMode="middle"
            >
              {currentUser?.profile_image_url || 'Not set'}
            </Text>
          </View>

          <TouchableOpacity
            style={styles.settingItem}
            onPress={() => setShowProfileModal(true)}
            activeOpacity={0.7}
          >
            <View style={styles.settingItemLeft}>
              <View style={styles.settingIconWrapper}>
                <MaterialCommunityIcons
                  name="account-edit"
                  size={20}
                  color="#4CAF50"
                />
              </View>
              <View style={styles.settingContent}>
                <Text style={styles.settingTitle}>Edit Profile</Text>
                <Text style={styles.settingDescription}>
                  Update your personal information and settings
                </Text>
              </View>
            </View>
            <MaterialCommunityIcons
              name="chevron-right"
              size={22}
              color="#9E9E9E"
            />
          </TouchableOpacity>
        </View>

        {/* App Information */}
        <View style={styles.sectionCard}>
          <View style={styles.sectionTitleRow}>
            <MaterialCommunityIcons
              name="information-outline"
              size={22}
              color="#4CAF50"
              style={styles.sectionTitleIcon}
            />
            <Text style={styles.sectionTitleText}>App Information</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Version:</Text>
            <Text style={styles.infoValue}>{contextAppInfo.version}</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>Support:</Text>
            <Text style={styles.infoValue}>{contextAppInfo.contact_email}</Text>
          </View>
          <View style={styles.infoItem}>
            <Text style={styles.infoLabel}>App Logo:</Text>
            <Text
              style={styles.infoValue}
              numberOfLines={1}
              ellipsizeMode="middle"
            >
              {contextAppInfo.app_logo_url || 'Not set'}
            </Text>
          </View>
        </View>

        {/* Admin Section */}
        {isAdmin && (
          <View style={styles.sectionCard}>
            <View style={styles.sectionTitleRow}>
              <MaterialCommunityIcons
                name="shield-cog"
                size={22}
                color="#4CAF50"
                style={styles.sectionTitleIcon}
              />
              <Text style={styles.sectionTitleText}>Admin Settings</Text>
            </View>
            <TouchableOpacity
              style={styles.settingItem}
              onPress={() => setShowAppInfoModal(true)}
              activeOpacity={0.7}
            >
              <View style={styles.settingItemLeft}>
                <View style={styles.settingIconWrapper}>
                  <MaterialCommunityIcons
                    name="application-cog"
                    size={20}
                    color="#4CAF50"
                  />
                </View>
                <View style={styles.settingContent}>
                  <Text style={styles.settingTitle}>App Information</Text>
                  <Text style={styles.settingDescription}>
                    Edit app name, welcome message, and contact info
                  </Text>
                </View>
              </View>
              <MaterialCommunityIcons
                name="chevron-right"
                size={22}
                color="#9E9E9E"
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.settingItem}
              onPress={() => navigation.navigate('UserManagement')}
              activeOpacity={0.7}
            >
              <View style={styles.settingItemLeft}>
                <View style={styles.settingIconWrapper}>
                  <MaterialCommunityIcons
                    name="account-group-outline"
                    size={20}
                    color="#4CAF50"
                  />
                </View>
                <View style={styles.settingContent}>
                  <Text style={styles.settingTitle}>User Management</Text>
                  <Text style={styles.settingDescription}>
                    Manage user accounts
                  </Text>
                </View>
              </View>
              <MaterialCommunityIcons
                name="chevron-right"
                size={22}
                color="#9E9E9E"
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.settingItem}
              onPress={() => navigation.navigate('FertilizerManagement')}
              activeOpacity={0.7}
            >
              <View style={styles.settingItemLeft}>
                <View style={styles.settingIconWrapper}>
                  <MaterialCommunityIcons
                    name="sprout"
                    size={20}
                    color="#4CAF50"
                  />
                </View>
                <View style={styles.settingContent}>
                  <Text style={styles.settingTitle}>Fertilizer Management</Text>
                  <Text style={styles.settingDescription}>
                    Manage fertilizer recommendations
                  </Text>
                </View>
              </View>
              <MaterialCommunityIcons
                name="chevron-right"
                size={22}
                color="#9E9E9E"
              />
            </TouchableOpacity>
          </View>
        )}

        {/* Delete Account Button - Only for authenticated users (not guests) */}
        {currentUser && currentUser.role !== 'guest' && (
          <TouchableOpacity
            style={styles.deleteAccountButton}
            onPress={handleDeleteAccount}
            activeOpacity={0.8}
          >
            <MaterialCommunityIcons
              name="delete-forever"
              size={20}
              color="#FFFFFF"
            />
            <Text style={styles.deleteAccountText}>Delete Account</Text>
          </TouchableOpacity>
        )}

        {/* Logout */}
        <TouchableOpacity
          style={styles.logoutButton}
          onPress={handleLogout}
          activeOpacity={0.8}
        >
          <MaterialCommunityIcons name="logout" size={20} color="#FFFFFF" />
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
        <View style={styles.bottomPadding} />
      </ScrollView>

      {renderProfileModal()}
      {renderAppInfoModal()}
      <ModernLoading
        visible={isLoading}
        message={
          showAppInfoModal
            ? 'Updating app information...'
            : 'Updating profile...'
        }
      />
    </Layout>
  );
};

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 18,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerPlaceholder: {
    width: 44,
    height: 44,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#1A1A1A',
    textAlign: 'center',
    flex: 1,
  },
  content: {
    flex: 1,
    backgroundColor: '#FAFAFA',
    paddingHorizontal: 16,
  },
  sectionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  sectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitleIcon: {
    marginRight: 10,
  },
  sectionTitleText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
    gap: 12,
  },
  settingItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  settingIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  settingDescription: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  infoItem: {
    flexDirection: 'row',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  infoLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    width: 100,
  },
  infoValue: {
    fontSize: 16,
    color: '#666',
    flex: 1,
  },
  logoutButton: {
    backgroundColor: '#FF5252',
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 12,
    marginVertical: 18,
    shadowColor: '#FF5252',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
  },
  logoutText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  deleteAccountButton: {
    backgroundColor: '#D32F2F',
    borderRadius: 12,
    padding: 18,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 12,
    marginVertical: 8,
    marginTop: 18,
    shadowColor: '#D32F2F',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 6,
    elevation: 2,
  },
  deleteAccountText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },
  bottomPadding: {
    height: 32,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    height: '90%',
    marginTop: 'auto',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  },
  modalScroll: {
    padding: 16,
  },
  updateButton: {
    marginTop: 24,
    marginBottom: 40,
  },
  divider: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginVertical: 16,
  },
  helperText: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
    marginBottom: 4,
    lineHeight: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 8,
  },
  genderContainer: {
    marginBottom: 16,
  },
  genderButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  genderButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    alignItems: 'center',
  },
  selectedGenderButton: {
    backgroundColor: '#4CAF50',
    borderColor: '#4CAF50',
  },
  genderButtonText: {
    fontSize: 14,
    color: '#666',
  },
  selectedGenderButtonText: {
    color: '#FFFFFF',
    fontWeight: '500',
  },
});

export default AppSettingsScreen;
