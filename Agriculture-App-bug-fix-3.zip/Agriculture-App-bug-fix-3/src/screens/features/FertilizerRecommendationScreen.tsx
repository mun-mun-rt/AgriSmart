import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  TextInput,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../types';
import SupabaseDatabaseManager from '../../api/SupabaseDatabaseManager';
import { FertilizerGuide } from '../../types';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

type FertilizerRecommendationScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'FertilizerRecommendation'
>;

interface CropData {
  name: string;
  soilType: string;
  season: string;
  area: number;
}

const FertilizerRecommendationScreen: React.FC = () => {
  const dbManager = SupabaseDatabaseManager.getInstance();

  const navigation =
    useNavigation<FertilizerRecommendationScreenNavigationProp>();
  const [activeTab, setActiveTab] = useState<'recommend' | 'guide'>(
    'recommend',
  );
  const [cropData, setCropData] = useState<CropData>({
    name: '',
    soilType: '',
    season: '',
    area: 0,
  });
  const [fertilizerGuides, setFertilizerGuides] = useState<FertilizerGuide[]>(
    [],
  );
  const [loading, setLoading] = useState(true);
  const [guideSearchQuery, setGuideSearchQuery] = useState('');

  const fetchFertilizerGuides = useCallback(async () => {
    try {
      setLoading(true);
      const guides = await dbManager.getAllFertilizerGuidesWithProducts();
      setFertilizerGuides(guides || []);
    } catch (error) {
      console.error('Error fetching fertilizer guides:', error);
      Alert.alert('Error', 'Failed to fetch fertilizer guides');
    } finally {
      setLoading(false);
    }
  }, [dbManager]);

  useEffect(() => {
    fetchFertilizerGuides();
  }, [fetchFertilizerGuides]);

  const getFilteredGuides = () => {
    if (!cropData.name) return fertilizerGuides;
    return fertilizerGuides.filter(guide =>
      guide.crop_name.toLowerCase().includes(cropData.name.toLowerCase()),
    );
  };

  const getFilteredGuidesForTab = () => {
    if (!guideSearchQuery) return fertilizerGuides;
    return fertilizerGuides.filter(
      guide =>
        guide.crop_name
          .toLowerCase()
          .includes(guideSearchQuery.toLowerCase()) ||
        guide.fertilizer_type
          .toLowerCase()
          .includes(guideSearchQuery.toLowerCase()),
    );
  };

  const handleProductPress = (productId: number) => {
    try {
      navigation.navigate('ProductDetails', { productId });
    } catch (error) {
      console.error('Error navigating to product details:', error);
      Alert.alert('Error', 'Unable to navigate to product details');
    }
  };

  const getTypeColor = () => '#4CAF50';

  const handleGenerateRecommendation = () => {
    if (!cropData.name || !cropData.soilType || !cropData.season) {
      Alert.alert(
        'Incomplete Data',
        'Please fill all crop details to get recommendations.',
      );
      return;
    }

    const filteredGuides = getFilteredGuides();
    const guideCount = filteredGuides.length;

    Alert.alert(
      'Recommendations Generated',
      `Found ${guideCount} fertilizer guide${guideCount !== 1 ? 's' : ''} for ${
        cropData.name
      }. ${
        guideCount > 0
          ? 'Check the recommendations below.'
          : 'Try adjusting your crop name for better results.'
      }`,
      [{ text: 'OK' }],
    );
  };

  const renderRecommendTab = () => (
    <>
      {/* Crop Information Form */}
      <View style={styles.formSection}>
        <Text style={styles.sectionTitle}>Crop Information</Text>
        <View style={styles.formCard}>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Crop Name</Text>
            <TextInput
              style={styles.textInput}
              placeholder="e.g., Wheat, Rice, Cotton"
              value={cropData.name}
              onChangeText={text => setCropData({ ...cropData, name: text })}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Soil Type</Text>
            <TextInput
              style={styles.textInput}
              placeholder="e.g., Clay, Sandy, Loamy"
              value={cropData.soilType}
              onChangeText={text =>
                setCropData({ ...cropData, soilType: text })
              }
            />
          </View>

          <View style={styles.inputRow}>
            <View style={styles.inputGroupHalf}>
              <Text style={styles.inputLabel}>Season</Text>
              <TextInput
                style={styles.textInput}
                placeholder="e.g., Kharif, Rabi"
                value={cropData.season}
                onChangeText={text =>
                  setCropData({ ...cropData, season: text })
                }
              />
            </View>
            <View style={styles.inputGroupHalf}>
              <Text style={styles.inputLabel}>Area (acres)</Text>
              <TextInput
                style={styles.textInput}
                placeholder="0"
                value={cropData.area.toString()}
                onChangeText={text =>
                  setCropData({ ...cropData, area: parseFloat(text) || 0 })
                }
                keyboardType="numeric"
              />
            </View>
          </View>

          <TouchableOpacity
            style={styles.generateButton}
            onPress={handleGenerateRecommendation}
          >
            <Text style={styles.generateButtonText}>
              Generate Recommendations
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Fertilizer Guides */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Fertilizer Guides</Text>
        {loading ? (
          <Text style={styles.loadingText}>Loading fertilizer guides...</Text>
        ) : getFilteredGuides().length === 0 ? (
          <Text style={styles.emptyText}>
            No fertilizer guides found. Try adjusting your search criteria.
          </Text>
        ) : (
          getFilteredGuides().map(guide => (
            <View key={guide.id} style={styles.fertilizerCard}>
              <View style={styles.fertilizerHeader}>
                <View style={styles.fertilizerTitleSection}>
                  <Text style={styles.fertilizerName}>{guide.crop_name}</Text>
                  <View
                    style={[
                      styles.typeTag,
                      { backgroundColor: getTypeColor() },
                    ]}
                  >
                    <Text style={styles.typeTagText}>
                      {guide.fertilizer_type}
                    </Text>
                  </View>
                </View>
              </View>

              <View style={styles.fertilizerDetails}>
                <View style={styles.fertilizerDetailRow}>
                  <Text style={styles.fertilizerDetailLabel}>Amount:</Text>
                  <Text style={styles.fertilizerDetailValue}>
                    {guide.amount}
                  </Text>
                </View>
                <View style={styles.fertilizerDetailRow}>
                  <Text style={styles.fertilizerDetailLabel}>Timing:</Text>
                  <Text style={styles.fertilizerDetailValue}>
                    {guide.timing}
                  </Text>
                </View>
                {guide.instructions && (
                  <View style={styles.fertilizerDetailRow}>
                    <Text style={styles.fertilizerDetailLabel}>
                      Instructions:
                    </Text>
                    <Text style={styles.fertilizerDetailValue}>
                      {guide.instructions}
                    </Text>
                  </View>
                )}
              </View>

              {guide.related_products && guide.related_products.length > 0 && (
                <View style={styles.benefitsSection}>
                  <Text style={styles.benefitsTitle}>Related Products:</Text>
                  <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    {guide.related_products.map((product: any) => (
                      <TouchableOpacity
                        key={product.id}
                        style={styles.productCard}
                        onPress={() =>
                          navigation.navigate('ProductDetails', {
                            productId: product.id,
                          })
                        }
                      >
                        <Text style={styles.productCardName}>
                          {product.name}
                        </Text>
                        <Text style={styles.productCardPrice}>
                          ৳{product.price}
                        </Text>
                        <Text style={styles.productCardCategory}>
                          {product.category}
                        </Text>
                        <Text style={styles.productCardTap}>Tap to view</Text>
                      </TouchableOpacity>
                    ))}
                  </ScrollView>
                </View>
              )}

              <View style={styles.fertilizerActions}>
                <TouchableOpacity
                  style={styles.moreInfoButton}
                  onPress={() => {
                    Alert.alert(
                      guide.crop_name,
                      `Fertilizer Type: ${guide.fertilizer_type}\nAmount: ${
                        guide.amount
                      }\nTiming: ${guide.timing}${
                        guide.instructions
                          ? `\n\nInstructions: ${guide.instructions}`
                          : ''
                      }`,
                      [{ text: 'OK' }],
                    );
                  }}
                >
                  <Text style={styles.moreInfoButtonText}>View Details</Text>
                </TouchableOpacity>
              </View>
            </View>
          ))
        )}
      </View>
    </>
  );

  const renderGuideTab = () => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Crop-wise Fertilizer Guide</Text>

      {/* Search Input */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search by crop name or fertilizer type..."
          value={guideSearchQuery}
          onChangeText={setGuideSearchQuery}
          autoCapitalize="none"
        />
        {guideSearchQuery ? (
          <TouchableOpacity
            style={styles.clearSearchButton}
            onPress={() => setGuideSearchQuery('')}
          >
            <MaterialCommunityIcons
              name="close-circle"
              size={20}
              color="#666666"
            />
          </TouchableOpacity>
        ) : null}
      </View>

      {loading ? (
        <Text style={styles.loadingText}>Loading fertilizer guides...</Text>
      ) : getFilteredGuidesForTab().length === 0 ? (
        <Text style={styles.emptyText}>
          {guideSearchQuery
            ? `No guides found for "${guideSearchQuery}". Try different keywords.`
            : 'No fertilizer guides available. Please contact admin to add guides.'}
        </Text>
      ) : (
        getFilteredGuidesForTab().map(guide => (
          <View key={guide.id} style={styles.guideCard}>
            <View style={styles.guideHeader}>
              <Text style={styles.guideCropName}>{guide.crop_name}</Text>
              <View
                style={[styles.typeTag, { backgroundColor: getTypeColor() }]}
              >
                <Text style={styles.typeTagText}>{guide.fertilizer_type}</Text>
              </View>
            </View>

            <View style={styles.guideSection}>
              <Text style={styles.guideLabel}>Amount:</Text>
              <Text style={styles.guideValue}>{guide.amount}</Text>
            </View>

            <View style={styles.guideSection}>
              <Text style={styles.guideLabel}>Application Schedule:</Text>
              <Text style={styles.guideValue}>{guide.timing}</Text>
            </View>

            {guide.instructions && (
              <View style={styles.guideSection}>
                <Text style={styles.guideLabel}>Instructions:</Text>
                <Text style={styles.guideValue}>{guide.instructions}</Text>
              </View>
            )}

            {guide.related_products && guide.related_products.length > 0 && (
              <View style={styles.benefitsSection}>
                <Text style={styles.benefitsTitle}>Related Products:</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  {guide.related_products.map((product: any) =>
                    product ? (
                      <TouchableOpacity
                        key={product.id}
                        style={styles.productCard}
                        onPress={() => handleProductPress(product.id)}
                      >
                        <Text style={styles.productCardName}>
                          {product.name}
                        </Text>
                        <Text style={styles.productCardPrice}>
                          ৳{product.price}
                        </Text>
                        <Text style={styles.productCardCategory}>
                          {product.category}
                        </Text>
                        <Text style={styles.productCardTap}>Tap to view</Text>
                      </TouchableOpacity>
                    ) : null,
                  )}
                </ScrollView>
              </View>
            )}

            <View style={styles.fertilizerActions}>
              <TouchableOpacity
                style={styles.moreInfoButton}
                onPress={() => {
                  Alert.alert(
                    guide.crop_name + ' - ' + guide.fertilizer_type,
                    `Amount: ${guide.amount}\nTiming: ${guide.timing}${
                      guide.instructions
                        ? `\n\nInstructions: ${guide.instructions}`
                        : ''
                    }${
                      guide.related_products &&
                      guide.related_products.length > 0
                        ? `\n\nRelated Products: ${guide.related_products.length} available`
                        : ''
                    }`,
                    [{ text: 'OK' }].filter(Boolean) as any,
                  );
                }}
              >
                <Text style={styles.moreInfoButtonText}>View Full Guide</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))
      )}

      <View style={styles.tipCard}>
        <MaterialCommunityIcons
          name="lightbulb-on-outline"
          size={28}
          color="#FFB74D"
          style={styles.tipIcon}
        />
        <View style={styles.tipContent}>
          <Text style={styles.tipTitle}>Pro Tip</Text>
          <Text style={styles.tipText}>
            Always conduct soil tests before applying fertilizers. This helps
            determine the exact nutrient requirements and prevents
            over-application.
          </Text>
        </View>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#388E3C" />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialCommunityIcons name="arrow-left" size={22} color="#222" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Fertilizer Guide</Text>
        <TouchableOpacity
          style={styles.helpButton}
          onPress={() => {
            navigation.navigate('Dashboard');
          }}
        >
          <MaterialCommunityIcons
            name="view-dashboard-outline"
            size={22}
            color="#388E3C"
          />
        </TouchableOpacity>
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[
            styles.tabButton,
            activeTab === 'recommend' && styles.tabButtonActive,
          ]}
          onPress={() => setActiveTab('recommend')}
        >
          <Text
            style={[
              styles.tabButtonText,
              activeTab === 'recommend' && styles.tabButtonTextActive,
            ]}
          >
            Recommend
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.tabButton,
            activeTab === 'guide' && styles.tabButtonActive,
          ]}
          onPress={() => setActiveTab('guide')}
        >
          <Text
            style={[
              styles.tabButtonText,
              activeTab === 'guide' && styles.tabButtonTextActive,
            ]}
          >
            Guide
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {activeTab === 'recommend' && renderRecommendTab()}
        {activeTab === 'guide' && renderGuideTab()}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#f7faff',
    paddingHorizontal: 24,
    paddingTop: 40,
    paddingBottom: 30,
    elevation: 4,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 6,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  backButton: {
    height: 40,
    width: 40,
    padding: 10,
    backgroundColor: '#e3e8f0',
    borderRadius: 20,
    elevation: 2,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    color: '#222',
    fontSize: 22,
    fontWeight: 'bold',
    letterSpacing: 1,
    textShadowColor: '#b2e0ff',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 1,
  },
  helpButton: {
    height: 40,
    width: 40,
    padding: 10,
    backgroundColor: '#e3e8f0',
    borderRadius: 999,
    elevation: 2,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#f7faff',
    borderRadius: 16,
    marginHorizontal: 16,
    marginTop: -20,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 2,
    overflow: 'hidden',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderBottomWidth: 0,
  },
  tabButtonActive: {
    backgroundColor: '#e3f6ff',
  },
  tabButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#388E3C',
    opacity: 0.7,
  },
  tabButtonTextActive: {
    color: '#005BEA',
    opacity: 1,
    textShadowColor: '#b2e0ff',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 1,
  },
  content: {
    flex: 1,
    padding: 20,
    paddingTop: 8,
    backgroundColor: '#fff',
  },
  formSection: {
    marginBottom: 28,
  },
  section: {
    marginBottom: 28,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#388E3C',
    marginBottom: 18,
    letterSpacing: 0.5,
  },
  searchContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  searchInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    backgroundColor: '#FFFFFF',
    paddingRight: 45,
  },
  clearSearchButton: {
    position: 'absolute',
    right: 12,
    top: 12,
    padding: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  formCard: {
    backgroundColor: '#f7faff',
    borderRadius: 20,
    padding: 22,
    elevation: 3,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: '#e3f6ff',
  },
  inputGroup: {
    marginBottom: 16,
  },
  inputRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  inputGroupHalf: {
    flex: 1,
    marginHorizontal: 4,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#222',
    marginBottom: 8,
  },
  textInput: {
    borderWidth: 1,
    borderColor: '#e3f6ff',
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 13,
    fontSize: 16,
    backgroundColor: '#f7faff',
    marginBottom: 2,
    color: '#005BEA',
  },
  generateButton: {
    backgroundColor: '#00C6FB',
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: 'center',
    marginTop: 10,
    elevation: 2,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  generateButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    letterSpacing: 0.5,
    textShadowColor: '#b2e0ff',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 1,
  },
  loadingText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#666',
    marginTop: 20,
  },
  emptyText: {
    textAlign: 'center',
    fontSize: 16,
    color: '#666',
    marginTop: 20,
    fontStyle: 'italic',
  },
  fertilizerCard: {
    backgroundColor: '#f7faff',
    borderRadius: 18,
    padding: 22,
    marginBottom: 18,
    elevation: 3,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: '#e3f6ff',
  },
  fertilizerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  fertilizerTitleSection: {
    flex: 1,
    marginRight: 12,
  },
  fertilizerName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#005BEA',
    marginBottom: 8,
  },
  typeTag: {
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: '#43e97b',
  },
  typeTagText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  fertilizerDetails: {
    marginBottom: 16,
  },
  fertilizerDetailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  fertilizerDetailLabel: {
    fontSize: 14,
    color: '#555',
    flex: 1,
  },
  fertilizerDetailValue: {
    fontSize: 14,
    color: '#222',
    fontWeight: '600',
    flex: 2,
    textAlign: 'right',
  },
  benefitsSection: {
    marginBottom: 16,
  },
  benefitsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#005BEA',
    marginBottom: 8,
  },
  productCard: {
    backgroundColor: '#e3f6ff',
    borderRadius: 14,
    padding: 14,
    marginRight: 14,
    alignItems: 'center',
    minWidth: 110,
    elevation: 2,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    borderWidth: 1,
    borderColor: '#00C6FB',
  },
  productCardName: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#005BEA',
    textAlign: 'center',
    marginBottom: 4,
  },
  productCardPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#43e97b',
    marginBottom: 2,
  },
  productCardCategory: {
    fontSize: 10,
    color: '#555',
    textAlign: 'center',
    marginBottom: 2,
  },
  productCardTap: {
    fontSize: 8,
    color: '#005BEA',
    textAlign: 'center',
    fontStyle: 'italic',
  },
  fertilizerActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  moreInfoButton: {
    flex: 1,
    paddingVertical: 13,
    backgroundColor: '#43e97b',
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 6,
    elevation: 1,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 1,
  },
  moreInfoButtonText: {
    fontSize: 15,
    fontWeight: '700',
    color: '#fff',
    letterSpacing: 0.2,
    textShadowColor: '#b2e0ff',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 1,
  },
  guideCard: {
    backgroundColor: '#f7faff',
    borderRadius: 16,
    padding: 22,
    marginBottom: 18,
    elevation: 2,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    borderWidth: 1,
    borderColor: '#e3f6ff',
  },
  guideHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  guideCropName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#005BEA',
    flex: 1,
  },
  guideSection: {
    marginBottom: 12,
  },
  guideLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#555',
    marginBottom: 4,
  },
  guideValue: {
    fontSize: 16,
    color: '#222',
    lineHeight: 22,
  },
  guideButton: {
    backgroundColor: '#E8F5E8',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginTop: 8,
  },
  guideButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#388E3C',
  },
  tipCard: {
    backgroundColor: '#f7faff',
    padding: 22,
    borderRadius: 14,
    flexDirection: 'row',
    borderLeftWidth: 5,
    borderLeftColor: '#00C6FB',
    marginTop: 10,
    elevation: 1,
    shadowColor: '#b2e0ff',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 1,
  },
  tipIcon: {
    marginRight: 14,
    alignSelf: 'flex-start',
  },
  tipContent: {
    flex: 1,
  },
  tipTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#005BEA',
    marginBottom: 8,
  },
  tipText: {
    fontSize: 15,
    color: '#555',
    lineHeight: 21,
  },
});

export default FertilizerRecommendationScreen;
