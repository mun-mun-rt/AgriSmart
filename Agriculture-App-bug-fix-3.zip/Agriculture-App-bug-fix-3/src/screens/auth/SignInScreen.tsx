import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Dimensions,
  TouchableOpacity,
  Animated,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, LoginCredentials } from '../../types';
import ModernHeader from '../../components/ModernHeader';
import ModernInput from '../../components/ModernInput';
import ModernButton from '../../components/ModernButton';
import ModernLoading from '../../components/ModernLoading';
import { useAuth } from '../../contexts/AuthContext';

const { width, height } = Dimensions.get('window');
const isTablet = width > 768;

type SignInScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'SignIn'
>;

const SignInScreen: React.FC = () => {
  const { signIn } = useAuth(); // Use the AuthContext signIn method
  const navigation = useNavigation<SignInScreenNavigationProp>();

  const [credentials, setCredentials] = useState<LoginCredentials>({
    email: '',
    password: '',
  });

  const [errors, setErrors] = useState<Partial<LoginCredentials>>({});
  const [showPassword, setShowPassword] = useState(false);
  const [isSigningIn, setIsSigningIn] = useState(false); // Local loading state
  const [signInError, setSignInError] = useState<string>(''); // Local error state

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const validateForm = (): boolean => {
    const newErrors: Partial<LoginCredentials> = {};

    if (!credentials.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(credentials.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!credentials.password) {
      newErrors.password = 'Password is required';
    } else if (credentials.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSignIn = async () => {
    if (!validateForm()) return;

    setSignInError(''); // Clear previous error
    setIsSigningIn(true); // Use local loading state to prevent AuthAwareNavigator re-renders

    try {
      // Use AuthContext signIn method which properly handles authentication and state
      const result = await signIn(
        credentials.email.trim().toLowerCase(),
        credentials.password,
      );

      if (result.success) {
        // Success! Get user role from the sign-in response
        console.log('Sign in successful, navigating to dashboard...');

        // Get the user role from the response
        const userRole = result.user?.role || 'consumer'; // default to consumer if no role
        console.log('User role:', userRole);

        // Navigate to Dashboard with the user's role
        navigation.replace('Dashboard', {
          role: userRole as 'farmer' | 'consumer' | 'admin',
        });
        console.log('Navigated to Dashboard with role:', userRole);
      } else {
        // Handle failed login - show error message inline
        const errorMessage =
          result.error || 'Please check your credentials and try again.';

        // Handle common error messages clearly
        if (errorMessage.toLowerCase().includes('invalid login credentials')) {
          setSignInError(
            'Invalid email or password. Please check your credentials.',
          );
        } else if (errorMessage.toLowerCase().includes('email not confirmed')) {
          setSignInError(
            'Please check your email and confirm your account first.',
          );
        } else if (errorMessage.toLowerCase().includes('too many requests')) {
          setSignInError(
            'Too many attempts. Please wait a moment and try again.',
          );
        } else {
          setSignInError(errorMessage);
        }

        // Clear password field for security
        setCredentials(prev => ({ ...prev, password: '' }));
      }
    } catch (e: any) {
      console.error('Sign in error caught in component:', e);
      // Handle any unexpected errors
      setSignInError('An unexpected error occurred. Please try again.');
      // Clear password field for security
      setCredentials(prev => ({ ...prev, password: '' }));
    } finally {
      setIsSigningIn(false); // Reset local loading state
    }
  };

  const updateCredentials = (field: keyof LoginCredentials, value: string) => {
    setCredentials(prev => ({
      ...prev,
      [field]: value,
    }));

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: undefined,
      }));
    }

    // Clear sign in error when user starts typing
    if (signInError) {
      setSignInError('');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#FFFFFF"
        translucent
      />

      {/* Subtle Background Elements */}
      <View style={styles.backgroundElements}>
        <View style={styles.circle1} />
        <View style={styles.circle2} />
      </View>

      {/* Header */}
      <Animated.View
        style={[
          styles.header,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            justifyContent: 'center',
            paddingTop: Platform.OS === 'ios' ? 60 : 80, // more spacing from top
          },
        ]}
      >
        <View style={{ flex: 1, alignItems: 'center' }}>
          <Text style={styles.headerTitle}>Welcome Back</Text>
          <Text style={styles.headerSubtitle}>Sign in to continue</Text>
        </View>
      </Animated.View>

      <KeyboardAvoidingView
        style={styles.keyboardAvoid}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Animated.View
            style={[
              styles.formContainer,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            {/* Main Form */}
            <View style={styles.form}>
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Email Address</Text>
                <View style={styles.inputWrapper}>
                  <MaterialCommunityIcons
                    name="email-outline"
                    size={20}
                    color="#2E7D32"
                    style={styles.inputLeftIcon}
                  />
                  <ModernInput
                    placeholder="Enter your email"
                    value={credentials.email}
                    onChangeText={text => updateCredentials('email', text)}
                    error={errors.email}
                    keyboardType="email-address"
                    style={styles.input}
                  />
                </View>
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Password</Text>
                <View
                  style={[
                    styles.inputWrapper,
                    { flexDirection: 'row', alignItems: 'center' },
                  ]}
                >
                  <ModernInput
                    placeholder="Enter your password"
                    value={credentials.password}
                    onChangeText={text => updateCredentials('password', text)}
                    error={errors.password}
                    secureTextEntry={!showPassword}
                    style={{ ...styles.input, flex: 1 }}
                  />
                  <TouchableOpacity
                    onPress={() => setShowPassword(v => !v)}
                    style={{ marginLeft: 8 }}
                  >
                    <Text
                      style={{
                        color: '#007AFF',
                        fontWeight: 'bold',
                        paddingBottom: 16,
                      }}
                    >
                      {showPassword ? 'Hide' : 'Show'}
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Error Display */}
              {signInError ? (
                <View style={styles.errorContainer}>
                  <Text style={styles.errorText}>{signInError}</Text>
                </View>
              ) : null}

              {/* Sign In Button */}
              <TouchableOpacity
                style={[
                  styles.signInButton,
                  isSigningIn && styles.signInButtonDisabled,
                ]}
                onPress={handleSignIn}
                disabled={isSigningIn}
                activeOpacity={0.9}
              >
                <Text style={styles.signInButtonText}>
                  {isSigningIn ? 'Signing In...' : 'Sign In'}
                </Text>
              </TouchableOpacity>

              {/* Divider */}
              <View style={styles.divider}>
                <View style={styles.dividerLine} />
                <Text style={styles.dividerText}>or</Text>
                <View style={styles.dividerLine} />
              </View>

              {/* Quick Actions */}
              <View style={styles.quickActions}>
                <TouchableOpacity
                  style={styles.guestButton}
                  onPress={() => navigation.replace('Menu')}
                  activeOpacity={0.8}
                >
                  <MaterialCommunityIcons
                    name="account"
                    size={20}
                    color="#757575"
                  />
                  <Text style={styles.guestButtonText}>Continue as Guest</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Footer */}
            <View style={styles.footer}>
              <Text style={styles.footerText}>
                Don't have an account?{' '}
                <Text
                  style={styles.footerLink}
                  onPress={() => navigation.navigate('SignUp')}
                >
                  Sign Up
                </Text>
              </Text>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>

      <ModernLoading visible={isSigningIn} message="Signing you in..." />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  backgroundElements: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    pointerEvents: 'none',
  },
  circle1: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#F1F8E9',
    top: 60,
    right: -30,
    opacity: 0.5,
  },
  circle2: {
    position: 'absolute',
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#E8F5E8',
    bottom: 150,
    left: -20,
    opacity: 0.3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'ios' ? 20 : 40,
    paddingBottom: 20,
    zIndex: 10,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F8F9FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 3,
  },
  backButtonText: {
    fontSize: 18,
    color: '#4CAF50',
    fontWeight: '600',
  },
  headerContent: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#2E7D32',
    marginBottom: 2,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#9E9E9E',
    fontWeight: '400',
  },
  keyboardAvoid: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 40,
  },
  formContainer: {
    flex: 1,
    paddingHorizontal: isTablet ? width * 0.15 : 24,
    paddingTop: 20,
    maxWidth: isTablet ? 600 : '100%',
    alignSelf: 'center',
    width: '100%',
  },
  form: {
    flex: 1,
  },
  inputContainer: {
    marginBottom: 24,
  },
  inputLabel: {
    fontSize: 15,
    fontWeight: '500',
    color: '#2E7D32',
    marginBottom: 8,
    marginLeft: 4,
    letterSpacing: 0.1,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F7FAF7',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E0EAE0',
    paddingTop: 16,
    paddingHorizontal: 16,
    shadowColor: '#B2DFDB',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 1,
  },
  inputLeftIcon: {
    marginRight: 8,
    marginBottom: 16,
  },
  input: {
    flex: 1,
    backgroundColor: 'transparent',
    borderWidth: 0,
    paddingVertical: 14,
    fontSize: 16,
    color: '#222',
    fontWeight: '400',
    borderRadius: 10,
    letterSpacing: 0.1,
  },
  signInButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 32,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 6,
  },
  signInButtonDisabled: {
    backgroundColor: '#A5D6A7',
    shadowOpacity: 0.1,
  },
  signInButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    letterSpacing: 0.3,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 32,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#E8F5E8',
  },
  dividerText: {
    marginHorizontal: 16,
    fontSize: 14,
    color: '#BDBDBD',
    fontWeight: '400',
  },
  quickActions: {
    flexDirection: isTablet ? 'row' : 'column',
    gap: 16,
  },
  guestButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F8F9FA',
    borderRadius: 16,
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderWidth: 1,
    borderColor: '#E8F5E8',
    flex: isTablet ? 1 : undefined,
  },
  guestButtonIcon: {
    fontSize: 16,
    marginRight: 8,
  },
  guestButtonText: {
    fontSize: 15,
    fontWeight: '500',
    color: '#66BB6A',
  },
  footer: {
    alignItems: 'center',
    marginTop: 40,
    paddingTop: 24,
    borderTopWidth: 1,
    borderTopColor: '#F1F8E9',
  },
  footerText: {
    fontSize: 15,
    color: '#757575',
    fontWeight: '400',
  },
  footerLink: {
    color: '#4CAF50',
    fontWeight: '600',
  },
  errorContainer: {
    backgroundColor: '#FFEBEE',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#FFCDD2',
  },
  errorText: {
    color: '#C62828',
    fontSize: 14,
    textAlign: 'center',
    fontWeight: '500',
  },
});

export default SignInScreen;
