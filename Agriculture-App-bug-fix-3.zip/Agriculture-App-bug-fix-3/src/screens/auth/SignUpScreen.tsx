import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Dimensions,
  TouchableOpacity,
  Animated,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, SignUpData } from '../../types/index';

import ModernInput from '../../components/ModernInput';
import ModernLoading from '../../components/ModernLoading';
import { useAuth } from '../../contexts/AuthContext';

const { width, height } = Dimensions.get('window');
const isTablet = width > 768;

type SignUpScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'SignUp'
>;

const SignUpScreen: React.FC = () => {
  const { signUp, isLoading } = useAuth();
  const navigation = useNavigation<SignUpScreenNavigationProp>();

  const [formData, setFormData] = useState<SignUpData>({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [errors, setErrors] = useState<Partial<SignUpData>>({});

  // Show / hide password toggles
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [showConfirmPassword, setShowConfirmPassword] =
    useState<boolean>(false);

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const validateForm = (): boolean => {
    const newErrors: Partial<SignUpData> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    } else if (formData.name.trim().length < 2) {
      newErrors.name = 'Name must be at least 2 characters';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSignUp = async () => {
    if (!validateForm()) return;

    const result = await signUp(
      formData.name.trim(),
      formData.email.trim().toLowerCase(),
      formData.password,
    );

    if (result.success) {
      Alert.alert(
        'Account Created!',
        "You're now logged in. Let's set up your profile to get started.",
        [
          {
            text: 'Continue',
            onPress: () => {
              // Navigation will be handled by AuthGuard
            },
          },
        ],
      );
    } else {
      Alert.alert('Sign Up Failed', result.error || 'Please try again.');
    }
  };

  const updateFormData = (field: keyof SignUpData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
    }));

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({
        ...prev,
        [field]: undefined,
      }));
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#FFFFFF"
        translucent
      />

      {/* Subtle Background Elements */}
      <View style={styles.backgroundElements}>
        <View style={styles.circle1} />
        <View style={styles.circle2} />
      </View>

      {/* Header */}
      <Animated.View
        style={[
          styles.header,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            justifyContent: 'center',
            paddingTop: Platform.OS === 'ios' ? 60 : 80,
          },
        ]}
      >
        <View style={{ flex: 1, alignItems: 'center' }}>
          <Text style={styles.headerTitle}>Create Account</Text>
          <Text style={styles.headerSubtitle}>Join AgriSmart Bangladesh</Text>
        </View>
      </Animated.View>

      <KeyboardAvoidingView
        style={styles.keyboardAvoid}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Animated.View
            style={[
              styles.formContainer,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            {/* Main Form */}
            <View style={styles.form}>
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Full Name</Text>
                <View style={styles.inputWrapper}>
                  <MaterialCommunityIcons
                    name="account-outline"
                    size={20}
                    color="#2E7D32"
                    style={styles.inputLeftIcon}
                  />
                  <ModernInput
                    placeholder="Enter your full name"
                    value={formData.name}
                    onChangeText={text => updateFormData('name', text)}
                    error={errors.name}
                    style={styles.inputControl}
                    inputStyle={styles.input}
                  />
                </View>
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Email Address</Text>
                <View style={styles.inputWrapper}>
                  <MaterialCommunityIcons
                    name="email-outline"
                    size={20}
                    color="#2E7D32"
                    style={styles.inputLeftIcon}
                  />
                  <ModernInput
                    placeholder="Enter your email"
                    value={formData.email}
                    onChangeText={text => updateFormData('email', text)}
                    error={errors.email}
                    keyboardType="email-address"
                    style={styles.inputControl}
                    inputStyle={styles.input}
                  />
                </View>
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Password</Text>
                <View style={styles.inputWrapper}>
                  <MaterialCommunityIcons
                    name="lock-outline"
                    size={20}
                    color="#2E7D32"
                    style={styles.inputLeftIcon}
                  />
                  <ModernInput
                    placeholder="Create a password"
                    value={formData.password}
                    onChangeText={text => updateFormData('password', text)}
                    error={errors.password}
                    secureTextEntry={!showPassword}
                    rightIconName={
                      showPassword ? 'visibility-off' : 'visibility'
                    }
                    rightIconColor="#2E7D32"
                    onRightIconPress={() => setShowPassword(s => !s)}
                    style={styles.inputControl}
                    inputStyle={styles.input}
                  />
                </View>
              </View>

              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Confirm Password</Text>
                <View style={styles.inputWrapper}>
                  <MaterialCommunityIcons
                    name="lock-check-outline"
                    size={20}
                    color="#2E7D32"
                    style={styles.inputLeftIcon}
                  />
                  <ModernInput
                    placeholder="Confirm your password"
                    value={formData.confirmPassword || ''}
                    onChangeText={text =>
                      updateFormData('confirmPassword', text)
                    }
                    error={errors.confirmPassword}
                    secureTextEntry={!showConfirmPassword}
                    rightIconName={
                      showConfirmPassword ? 'visibility-off' : 'visibility'
                    }
                    rightIconColor="#2E7D32"
                    onRightIconPress={() => setShowConfirmPassword(s => !s)}
                    style={styles.inputControl}
                    inputStyle={styles.input}
                  />
                </View>
              </View>

              {/* Sign Up Button */}
              <TouchableOpacity
                style={[
                  styles.signUpButton,
                  isLoading && styles.signUpButtonDisabled,
                ]}
                onPress={handleSignUp}
                disabled={isLoading}
                activeOpacity={0.9}
              >
                <Text style={styles.signUpButtonText}>
                  {isLoading ? 'Creating Account...' : 'Create Account'}
                </Text>
              </TouchableOpacity>

              {/* Footer */}
              <View style={styles.footer}>
                <Text style={styles.footerText}>
                  Already have an account?{' '}
                  <Text
                    style={styles.footerLink}
                    onPress={() => navigation.navigate('SignIn')}
                  >
                    Sign In
                  </Text>
                </Text>
              </View>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>

      <ModernLoading visible={isLoading} message="Creating your account..." />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  backgroundElements: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    pointerEvents: 'none',
  },
  circle1: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#F1F8E9',
    top: 60,
    right: -30,
    opacity: 0.5,
  },
  circle2: {
    position: 'absolute',
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#E8F5E8',
    bottom: 150,
    left: -20,
    opacity: 0.3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'ios' ? 20 : 40,
    paddingBottom: 20,
    zIndex: 10,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#2E7D32',
    marginBottom: 2,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#9E9E9E',
    fontWeight: '400',
  },
  keyboardAvoid: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 40,
  },
  formContainer: {
    flex: 1,
    paddingHorizontal: isTablet ? width * 0.15 : 24,
    paddingTop: 20,
    maxWidth: isTablet ? 600 : '100%',
    alignSelf: 'center',
    width: '100%',
  },
  form: {
    flex: 1,
  },
  inputContainer: {
    marginBottom: 24,
  },
  inputLabel: {
    fontSize: 15,
    fontWeight: '500',
    color: '#2E7D32',
    marginBottom: 8,
    marginLeft: 4,
    letterSpacing: 0.1,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F7FAF7',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E0EAE0',
    paddingTop: 16,
    paddingHorizontal: 16,
    shadowColor: '#B2DFDB',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 1,
  },
  inputLeftIcon: {
    marginRight: 8,
  },
  inputControl: {
    flex: 1,
    marginBottom: 0,
  },
  input: {
    flex: 1,
    backgroundColor: 'transparent',
    borderWidth: 0,
    paddingVertical: 14,
    fontSize: 16,
    color: '#222',
    fontWeight: '400',
    borderRadius: 10,
    letterSpacing: 0.1,
  },
  signUpButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 32,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 6,
  },
  signUpButtonDisabled: {
    backgroundColor: '#A5D6A7',
    shadowOpacity: 0.1,
  },
  signUpButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    letterSpacing: 0.3,
  },
  footer: {
    alignItems: 'center',
    marginTop: 40,
    paddingTop: 24,
    borderTopWidth: 1,
    borderTopColor: '#F1F8E9',
  },
  footerText: {
    fontSize: 15,
    color: '#757575',
    fontWeight: '400',
  },
  footerLink: {
    color: '#4CAF50',
    fontWeight: '600',
  },
});

export default SignUpScreen;
