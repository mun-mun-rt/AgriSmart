import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  Alert,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
  Animated,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
const { width, height } = Dimensions.get('window');
const isTablet = width > 768;
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, User } from '../../types/index';
import ModernButton from '../../components/ModernButton';
import ModernInput from '../../components/ModernInput';
import ModernLoading from '../../components/ModernLoading';
import { useAuth } from '../../contexts/AuthContext';

type OnboardingScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'Onboarding'
>;

interface OnboardingData {
  // Role
  role: 'farmer' | 'consumer' | null;

  // Contact Info
  phone: string;
  contact_email: string;

  // Address
  address_line1: string;
  address_line2: string;
  city: string;
  state: string;
  postal_code: string;

  // Profile
  date_of_birth: string;
  gender: 'male' | 'female' | 'other' | null;
  bio: string;
  profile_image_url: string;

  // Farmer-specific fields
  farm_name: string;
  farm_size: string;
  farming_experience: string;
  specialization: string;
  mobile_banking_bkash: string;
  mobile_banking_nagad: string;
  mobile_banking_rocket: string;
}

const OnboardingScreen: React.FC = () => {
  const { updateProfile, isLoading, refreshUser, signOut } = useAuth();
  const handleCancel = async () => {
    await signOut();
    navigation.reset({ index: 0, routes: [{ name: 'SignIn' }] });
  };
  const navigation = useNavigation<OnboardingScreenNavigationProp>();

  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<OnboardingData>({
    role: null,
    phone: '',
    contact_email: '',
    address_line1: '',
    address_line2: '',
    city: '',
    state: '',
    postal_code: '',
    date_of_birth: '',
    gender: null,
    bio: '',
    profile_image_url: '',
    farm_name: '',
    farm_size: '',
    farming_experience: '',
    specialization: '',
    mobile_banking_bkash: '',
    mobile_banking_nagad: '',
    mobile_banking_rocket: '',
  });
  const [errors, setErrors] = useState<Partial<OnboardingData>>({});

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const updateFormData = (field: keyof OnboardingData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleRoleSelection = (role: 'farmer' | 'consumer') => {
    updateFormData('role', role);
    setCurrentStep(2);
  };

  const validateCurrentStep = (): boolean => {
    switch (currentStep) {
      case 1:
        return !!formData.role;
      case 2:
        return !!(
          formData.phone &&
          formData.contact_email &&
          formData.address_line1 &&
          formData.city &&
          formData.state
        );
      case 3:
        if (formData.role === 'farmer') {
          const hasMobileBankingInfo = Boolean(
            formData.mobile_banking_bkash.trim() ||
              formData.mobile_banking_nagad.trim() ||
              formData.mobile_banking_rocket.trim(),
          );

          return !!(
            formData.farm_name &&
            formData.specialization &&
            hasMobileBankingInfo
          );
        }
        return true;
      default:
        return true;
    }
  };

  const handleNext = () => {
    if (!validateCurrentStep()) {
      Alert.alert('Missing Information', 'Please fill in all required fields.');
      return;
    }

    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
    } else {
      handleCompleteOnboarding();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleCompleteOnboarding = async () => {
    if (!formData.role) {
      Alert.alert('Error', 'Please select a role to continue.');
      return;
    }

    try {
      console.log('Starting onboarding completion...');

      // Prepare user profile data
      const profileData: Partial<User> = {
        role: formData.role,
        phone: formData.phone,
        email: formData.contact_email, // Contact email
        address_line1: formData.address_line1,
        address_line2: formData.address_line2 || undefined,
        city: formData.city,
        state: formData.state,
        postal_code: formData.postal_code || undefined,
        country: 'Bangladesh',
        date_of_birth: formData.date_of_birth || undefined,
        gender: formData.gender || undefined,
        bio: formData.bio || undefined,
        profile_image_url: formData.profile_image_url || undefined,
        onboarding_completed: true,
      };

      // Add farmer-specific data if applicable
      if (formData.role === 'farmer') {
        profileData.farm_name = formData.farm_name;
        profileData.farm_size = formData.farm_size
          ? parseFloat(formData.farm_size)
          : undefined;
        profileData.farming_experience = formData.farming_experience
          ? parseInt(formData.farming_experience)
          : undefined;
        profileData.specialization = formData.specialization;
        profileData.mobile_banking_bkash = formData.mobile_banking_bkash.trim()
          ? formData.mobile_banking_bkash.trim()
          : null;
        profileData.mobile_banking_nagad = formData.mobile_banking_nagad.trim()
          ? formData.mobile_banking_nagad.trim()
          : null;
        profileData.mobile_banking_rocket =
          formData.mobile_banking_rocket.trim()
            ? formData.mobile_banking_rocket.trim()
            : null;
      }

      console.log('Profile data to update:', profileData);

      const success = await updateProfile(profileData);

      if (success) {
        console.log('Profile update successful, refreshing user...');
        // Refresh user data to update auth context
        await refreshUser();

        // Small delay to ensure state updates are processed
        await new Promise(resolve => setTimeout(resolve, 500));

        console.log('User refreshed, onboarding should be complete');

        Alert.alert('Welcome!', 'Your profile has been set up successfully.', [
          {
            text: 'Get Started',
            onPress: () => {
              console.log(
                'Alert dismissed, navigation should happen automatically',
              );
              // Navigation will be handled by AuthAwareNavigator based on needsOnboarding state
            },
          },
        ]);
      } else {
        console.error('Profile update failed');
      }
    } catch (error) {
      console.error('Onboarding error:', error);
      Alert.alert('Error', 'Something went wrong. Please try again.');
    }
  };

  const renderStepIndicator = () => (
    <View style={styles.stepIndicator}>
      {[1, 2, 3].map(step => (
        <View key={step} style={styles.stepContainer}>
          <View
            style={[
              styles.stepCircle,
              currentStep >= step && styles.activeStep,
              currentStep > step && styles.completedStep,
            ]}
          >
            {currentStep > step ? (
              <MaterialCommunityIcons name="check" size={20} color="#FFFFFF" />
            ) : (
              <Text
                style={[
                  styles.stepText,
                  currentStep >= step && styles.activeStepText,
                ]}
              >
                {step}
              </Text>
            )}
          </View>
          {step < 3 && (
            <View
              style={[
                styles.stepLine,
                currentStep > step && styles.completedStepLine,
              ]}
            />
          )}
        </View>
      ))}
    </View>
  );

  const renderRoleSelection = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Choose Your Role</Text>
      <Text style={styles.stepSubtitle}>
        Tell us who you are so we can personalize your experience
      </Text>

      <View style={styles.roleContainer}>
        <TouchableOpacity
          style={[
            styles.roleCard,
            formData.role === 'farmer' && styles.selectedCard,
          ]}
          onPress={() => handleRoleSelection('farmer')}
        >
          <View style={styles.roleIcon}>
            <MaterialCommunityIcons name="sprout" size={28} color="#48BB78" />
          </View>
          <Text style={styles.roleTitle}>I'm a Farmer</Text>
          <Text style={styles.roleDescription}>
            I grow crops and want to sell my produce, lease land, and connect
            with buyers
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.roleCard,
            formData.role === 'consumer' && styles.selectedCard,
          ]}
          onPress={() => handleRoleSelection('consumer')}
        >
          <View style={styles.roleIcon}>
            <MaterialCommunityIcons name="cart" size={28} color="#2D3748" />
          </View>
          <Text style={styles.roleTitle}>I'm a Consumer</Text>
          <Text style={styles.roleDescription}>
            I want to buy fresh produce, rent farming land, and connect with
            farmers
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderPersonalInfo = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>Personal Information</Text>
      <Text style={styles.stepSubtitle}>
        Please provide your contact and address details
      </Text>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.form}>
          <ModernInput
            label="Phone Number *"
            placeholder="Enter your phone number"
            value={formData.phone}
            onChangeText={text => updateFormData('phone', text)}
            keyboardType="phone-pad"
          />

          <ModernInput
            label="Contact Email *"
            placeholder="Contact email (can be different from login email)"
            value={formData.contact_email}
            onChangeText={text => updateFormData('contact_email', text)}
            keyboardType="email-address"
          />

          <ModernInput
            label="Address Line 1 *"
            placeholder="Street address, house number"
            value={formData.address_line1}
            onChangeText={text => updateFormData('address_line1', text)}
          />

          <ModernInput
            label="Address Line 2"
            placeholder="Apartment, suite, unit (optional)"
            value={formData.address_line2}
            onChangeText={text => updateFormData('address_line2', text)}
          />

          <View style={styles.row}>
            <View style={styles.halfWidth}>
              <ModernInput
                label="City *"
                placeholder="City"
                value={formData.city}
                onChangeText={text => updateFormData('city', text)}
              />
            </View>
            <View style={styles.halfWidth}>
              <ModernInput
                label="State/Division *"
                placeholder="State"
                value={formData.state}
                onChangeText={text => updateFormData('state', text)}
              />
            </View>
          </View>

          <ModernInput
            label="Postal Code"
            placeholder="Postal/ZIP code"
            value={formData.postal_code}
            onChangeText={text => updateFormData('postal_code', text)}
            keyboardType="numeric"
          />

          <ModernInput
            label="Date of Birth"
            placeholder="YYYY-MM-DD (optional)"
            value={formData.date_of_birth}
            onChangeText={text => updateFormData('date_of_birth', text)}
          />

          <Text style={styles.fieldLabel}>Gender</Text>
          <View style={styles.genderContainer}>
            {['male', 'female', 'other'].map(gender => (
              <TouchableOpacity
                key={gender}
                style={[
                  styles.genderButton,
                  formData.gender === gender && styles.selectedGender,
                ]}
                onPress={() => updateFormData('gender', gender)}
              >
                <Text
                  style={[
                    styles.genderText,
                    formData.gender === gender && styles.selectedGenderText,
                  ]}
                >
                  {gender.charAt(0).toUpperCase() + gender.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <ModernInput
            label="Bio"
            placeholder="Tell us about yourself (optional)"
            value={formData.bio}
            onChangeText={text => updateFormData('bio', text)}
            multiline
            numberOfLines={3}
          />

          <ModernInput
            label="Profile Image URL"
            placeholder="https://example.com/your-photo.jpg (optional)"
            value={formData.profile_image_url}
            onChangeText={text => updateFormData('profile_image_url', text)}
          />
        </View>
      </ScrollView>
    </View>
  );

  const renderFarmerInfo = () => (
    <View style={styles.stepContent}>
      <Text style={styles.stepTitle}>
        {formData.role === 'farmer'
          ? 'Farm Information'
          : 'Additional Information'}
      </Text>
      <Text style={styles.stepSubtitle}>
        {formData.role === 'farmer'
          ? 'Tell us about your farming background'
          : "Any additional information you'd like to share"}
      </Text>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.form}>
          {formData.role === 'farmer' && (
            <>
              <ModernInput
                label="Farm Name *"
                placeholder="Name of your farm"
                value={formData.farm_name}
                onChangeText={text => updateFormData('farm_name', text)}
              />

              <ModernInput
                label="Farm Size (acres)"
                placeholder="Size of your farm in acres"
                value={formData.farm_size}
                onChangeText={text => updateFormData('farm_size', text)}
                keyboardType="numeric"
              />

              <ModernInput
                label="Farming Experience (years)"
                placeholder="Years of farming experience"
                value={formData.farming_experience}
                onChangeText={text =>
                  updateFormData('farming_experience', text)
                }
                keyboardType="numeric"
              />

              <ModernInput
                label="Specialization *"
                placeholder="e.g., Rice, Vegetables, Fruits, Mixed crops"
                value={formData.specialization}
                onChangeText={text => updateFormData('specialization', text)}
              />

              <Text style={styles.helperText}>
                Add the mobile banking numbers customers can use to pay you.
                Provide at least one provider for checkout to work.
              </Text>

              <ModernInput
                label="bKash Account Number"
                placeholder="e.g., 017XXXXXXXX"
                value={formData.mobile_banking_bkash}
                onChangeText={text =>
                  updateFormData('mobile_banking_bkash', text)
                }
                keyboardType="phone-pad"
              />

              <ModernInput
                label="Nagad Account Number"
                placeholder="e.g., 018XXXXXXXX"
                value={formData.mobile_banking_nagad}
                onChangeText={text =>
                  updateFormData('mobile_banking_nagad', text)
                }
                keyboardType="phone-pad"
              />

              <ModernInput
                label="Rocket Account Number"
                placeholder="e.g., 019XXXXXXXX"
                value={formData.mobile_banking_rocket}
                onChangeText={text =>
                  updateFormData('mobile_banking_rocket', text)
                }
                keyboardType="phone-pad"
              />
            </>
          )}

          <View style={styles.completionNote}>
            <MaterialCommunityIcons
              name="party-popper"
              size={24}
              color="#48BB78"
              style={{ marginRight: 8 }}
            />
            <Text style={styles.completionNoteText}>
              You're almost done! Review your information and complete your
              profile setup.
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );

  if (isLoading) {
    return (
      <ModernLoading visible={true} message="Setting up your profile..." />
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#FFFFFF"
        translucent
      />

      {/* Subtle Background Elements */}
      <View style={styles.backgroundElements}>
        <View style={styles.circle1} />
        <View style={styles.circle2} />
      </View>

      {/* Header */}
      <Animated.View
        style={[
          styles.header,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            justifyContent: 'center',
            paddingTop: Platform.OS === 'ios' ? 60 : 80,
          },
        ]}
      >
        <View style={{ flex: 1, alignItems: 'center' }}>
          <Text style={styles.headerTitle}>Complete Your Profile</Text>
          <Text
            style={styles.headerSubtitle}
          >{`Step ${currentStep} of 3`}</Text>
        </View>
      </Animated.View>

      <KeyboardAvoidingView
        style={styles.keyboardAvoid}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Animated.View
            style={[
              styles.formContainer,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            {renderStepIndicator()}
            {currentStep === 1 && renderRoleSelection()}
            {currentStep === 2 && renderPersonalInfo()}
            {currentStep === 3 && renderFarmerInfo()}
            <View style={styles.buttonRow}>
              {currentStep === 1 && (
                <ModernButton
                  title="Cancel"
                  onPress={handleCancel}
                  variant="outline"
                  style={StyleSheet.flatten([
                    styles.button,
                    styles.cancelButton,
                  ])}
                />
              )}
              {currentStep > 1 && (
                <ModernButton
                  title="Previous"
                  onPress={handlePrevious}
                  variant="outline"
                  style={StyleSheet.flatten([
                    styles.button,
                    styles.previousButton,
                  ])}
                />
              )}
              <ModernButton
                title={currentStep === 3 ? 'Complete Setup' : 'Next'}
                onPress={handleNext}
                disabled={!validateCurrentStep()}
                style={
                  currentStep === 3
                    ? StyleSheet.flatten([
                        styles.button,
                        styles.nextButton,
                        styles.completeButton,
                      ])
                    : StyleSheet.flatten([styles.button, styles.nextButton])
                }
              />
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  backgroundElements: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    pointerEvents: 'none',
  },
  circle1: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#F1F8E9',
    top: 60,
    right: -30,
    opacity: 0.5,
  },
  circle2: {
    position: 'absolute',
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#E8F5E8',
    bottom: 150,
    left: -20,
    opacity: 0.3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: Platform.OS === 'ios' ? 20 : 40,
    paddingBottom: 20,
    zIndex: 10,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#2E7D32',
    marginBottom: 2,
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#9E9E9E',
    fontWeight: '400',
  },
  keyboardAvoid: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    paddingBottom: 40,
  },
  formContainer: {
    flex: 1,
    paddingHorizontal: isTablet ? width * 0.15 : 24,
    paddingTop: 20,
    maxWidth: isTablet ? 600 : '100%',
    alignSelf: 'center',
    width: '100%',
  },
  form: {
    flex: 1,
    gap: 16,
  },
  inputContainer: {
    marginBottom: 24,
  },
  inputLabel: {
    fontSize: 15,
    fontWeight: '500',
    color: '#2E7D32',
    marginBottom: 8,
    marginLeft: 4,
    letterSpacing: 0.1,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F7FAF7',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E0EAE0',
    paddingTop: 16,
    paddingHorizontal: 16,
    shadowColor: '#B2DFDB',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 1,
  },
  input: {
    flex: 1,
    backgroundColor: 'transparent',
    borderWidth: 0,
    paddingVertical: 14,
    fontSize: 16,
    color: '#222',
    fontWeight: '400',
    borderRadius: 10,
    letterSpacing: 0.1,
  },
  signUpButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 32,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 6,
  },
  signUpButtonDisabled: {
    backgroundColor: '#A5D6A7',
    shadowOpacity: 0.1,
  },
  signUpButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    letterSpacing: 0.3,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 24,
    marginBottom: 40,
    gap: 12,
    width: '100%',
  },
  button: {
    flex: 1,
    minWidth: 120,
    maxWidth: isTablet ? 220 : 180,
    paddingVertical: 16,
    borderRadius: 14,
    elevation: 2,
  },
  cancelButton: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#BDBDBD',
  },
  previousButton: {
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#48BB78',
  },
  nextButton: {
    backgroundColor: '#48BB78',
    borderWidth: 0,
  },
  completeButton: {
    backgroundColor: '#2E7D32',
    borderWidth: 0,
  },
  // ...existing step/role styles...
  stepIndicator: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 20,
    marginBottom: 20,
  },
  stepContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E2E8F0',
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeStep: {
    backgroundColor: '#48BB78',
  },
  completedStep: {
    backgroundColor: '#38A169',
  },
  stepText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#718096',
  },
  activeStepText: {
    color: '#FFFFFF',
  },
  stepLine: {
    width: 40,
    height: 2,
    backgroundColor: '#E2E8F0',
    marginHorizontal: 8,
  },
  completedStepLine: {
    backgroundColor: '#48BB78',
  },
  stepContent: {
    flex: 1,
  },
  stepTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2D3748',
    marginBottom: 8,
    textAlign: 'center',
  },
  stepSubtitle: {
    fontSize: 16,
    color: '#718096',
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 24,
  },
  roleContainer: {
    gap: 16,
    flex: 1,
  },
  roleCard: {
    backgroundColor: '#F7FAFC',
    padding: 20,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#E2E8F0',
    alignItems: 'center',
  },
  selectedCard: {
    borderColor: '#48BB78',
    backgroundColor: '#F0FFF4',
  },
  roleIcon: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  roleTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2D3748',
    marginBottom: 8,
    textAlign: 'center',
  },
  roleDescription: {
    fontSize: 14,
    color: '#718096',
    textAlign: 'center',
    lineHeight: 20,
  },
  row: {
    flexDirection: 'row',
    gap: 12,
  },
  halfWidth: {
    flex: 1,
  },
  fieldLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2D3748',
    marginBottom: 8,
  },
  genderContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  genderButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
  },
  selectedGender: {
    borderColor: '#48BB78',
    backgroundColor: '#F0FFF4',
  },
  genderText: {
    fontSize: 14,
    color: '#718096',
    fontWeight: '500',
  },
  selectedGenderText: {
    color: '#48BB78',
    fontWeight: '600',
  },
  helperText: {
    fontSize: 14,
    color: '#718096',
    marginTop: 12,
    marginBottom: 4,
    lineHeight: 20,
  },
  completionNote: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    padding: 16,
    backgroundColor: '#F0FFF4',
    borderRadius: 12,
    marginTop: 20,
  },
  completionNoteText: {
    fontSize: 16,
    color: '#48BB78',
    fontWeight: '500',
    flex: 1,
  },
});

export default OnboardingScreen;
