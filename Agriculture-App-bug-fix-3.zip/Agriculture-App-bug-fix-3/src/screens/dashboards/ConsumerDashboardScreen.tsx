import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Platform,
  Dimensions,
  Image,
} from 'react-native';
const { width } = Dimensions.get('window');
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { RootStackParamList, User } from '../../types';
import Layout from '../../components/Layout';
import ModernLoading from '../../components/ModernLoading';
import SupabaseAuthManager from '../../api/SupabaseAuthManager';
import SupabaseDatabaseManager from '../../api/SupabaseDatabaseManager';
import { useAppInfo } from '../../contexts/AppInfoContext';

type ConsumerDashboardNavigationProp = StackNavigationProp<
  RootStackParamList,
  'ConsumerDashboard'
>;

const ConsumerDashboardScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();

  const navigation = useNavigation<ConsumerDashboardNavigationProp>();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [approvedOrderCount, setApprovedOrderCount] = useState<number>(0);
  const [walletBalance, setWalletBalance] = useState<number>(0);
  const [cartItemCount, setCartItemCount] = useState<number>(0);
  const { appInfo } = useAppInfo();

  const loadUserData = React.useCallback(async () => {
    try {
      const currentUser = await authManager.getCurrentUser();
      if (currentUser) {
        setUser(currentUser);
        // fetch orders and wallet balance
        const dbManager = SupabaseDatabaseManager.getInstance();
        try {
          const orders = await dbManager.getUserOrders(String(currentUser.id));
          console.log(
            '🔍 Consumer Dashboard - Total orders fetched:',
            orders?.length,
          );
          if (Array.isArray(orders)) {
            const approvedTotal = orders.reduce((count, order) => {
              const status = (order?.status || '').toString().toLowerCase();
              console.log(
                '📦 Order status:',
                status,
                'Is approved?',
                status === 'approved',
              );
              return status === 'approved' ? count + 1 : count;
            }, 0);
            console.log(
              '✅ Consumer Dashboard - Approved orders count:',
              approvedTotal,
            );
            setApprovedOrderCount(approvedTotal);
          } else {
            console.log('❌ Consumer Dashboard - Orders is not an array');
            setApprovedOrderCount(0);
          }
        } catch (e) {
          console.error('Error fetching user orders for dashboard:', e);
          setApprovedOrderCount(0);
        }

        try {
          const bal = await dbManager.getUserWalletBalance(
            String(currentUser.id),
          );
          setWalletBalance(
            typeof bal === 'number' ? bal : parseFloat(String(bal)) || 0,
          );
        } catch (e) {
          console.error('Error fetching wallet balance for dashboard:', e);
          setWalletBalance(0);
        }

        // Get cart item count
        try {
          const cartItems = await dbManager.getUserCart(String(currentUser.id));
          setCartItemCount(Array.isArray(cartItems) ? cartItems.length : 0);
        } catch (e) {
          console.error('Error fetching cart items:', e);
          setCartItemCount(0);
        }
      }
    } catch (error) {
      console.error('Error loading user data:', error);
      Alert.alert('Error', 'Failed to load user data');
    } finally {
      setLoading(false);
    }
  }, [authManager]);

  useEffect(() => {
    loadUserData();
  }, [loadUserData]);

  if (loading) {
    return (
      <Layout activeTab="dashboard">
        <ModernLoading visible={true} message="Loading dashboard..." />
      </Layout>
    );
  }

  return (
    <Layout activeTab="dashboard">
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.headerText}>
            <Text style={styles.appName}>{appInfo.app_name}</Text>
            <Text style={styles.welcomeText}>
              Welcome, {user?.name || 'Consumer'}
            </Text>
          </View>
          {/* Profile avatar: navigate to user's public profile */}
          <TouchableOpacity
            style={styles.profileButton}
            onPress={() => {
              if (user && user.id) {
                navigation.navigate('UserProfile', { userId: String(user.id) });
              } else {
                navigation.navigate('UserProfile', { userId: '' });
              }
            }}
          >
            {user && user.profile_image_url ? (
              <Image
                source={{ uri: user.profile_image_url }}
                style={styles.profileImage}
              />
            ) : (
              <View style={styles.profileAvatar}>
                <Text style={styles.profileAvatarText}>
                  {user && user.name ? user.name.charAt(0).toUpperCase() : 'U'}
                </Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.contentContainer}
      >
        {/* Stats Overview */}
        <View style={styles.statsSection}>
          <Text style={styles.overviewTitle}>Overview</Text>
          <View style={styles.statsContainer}>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>{approvedOrderCount}</Text>
              <Text style={styles.statLabel}>Approved Orders</Text>
              <TouchableOpacity onPress={() => navigation.navigate('MyOrders')}>
                <Text style={styles.statTrend}>
                  {approvedOrderCount > 0
                    ? 'View Approved Orders'
                    : 'No Approved Orders'}
                </Text>
              </TouchableOpacity>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>৳ {walletBalance.toFixed(2)}</Text>
              <Text style={styles.statLabel}>Wallet Balance</Text>
              <TouchableOpacity onPress={() => navigation.navigate('Wallet')}>
                <Text style={styles.statTrend}>Check Balance</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Main Actions</Text>
        <View style={styles.actionGrid}>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('ECommerce')}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons name="cart" size={28} color="#4CAF50" />
            </View>
            <Text style={styles.actionTitle}>Browse Products</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('LandLeaseManagement')}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons
                name="home-city"
                size={28}
                color="#4CAF50"
              />
            </View>
            <Text style={styles.actionTitle}>Manage Land Leases</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('LandLease')}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons
                name="magnify"
                size={28}
                color="#4CAF50"
              />
            </View>
            <Text style={styles.actionTitle}>Browse Land Leases</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('LeaseApplicationList')}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons
                name="file-document-edit"
                size={28}
                color="#4CAF50"
              />
            </View>
            <Text style={styles.actionTitle}>Lease Applications</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('MyContracts')}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons
                name="clipboard-text"
                size={28}
                color="#4CAF50"
              />
            </View>
            <Text style={styles.actionTitle}>My Contracts</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => {
              console.log(
                '🎯 My Orders clicked - approvedOrderCount:',
                approvedOrderCount,
              );
              navigation.navigate('MyOrders');
            }}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons
                name="package-variant"
                size={28}
                color="#4CAF50"
              />
              {(() => {
                console.log(
                  '🔔 Badge render check - approvedOrderCount:',
                  approvedOrderCount,
                  'Show badge?',
                  approvedOrderCount > 0,
                );
                return approvedOrderCount > 0 ? (
                  <View style={styles.notificationBadge}>
                    <Text style={styles.notificationBadgeText}>
                      {approvedOrderCount > 9 ? '9+' : approvedOrderCount}
                    </Text>
                  </View>
                ) : null;
              })()}
            </View>
            <Text style={styles.actionTitle}>My Orders</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('Wallet')}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons name="wallet" size={28} color="#4CAF50" />
            </View>
            <Text style={styles.actionTitle}>My Wallet</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('FollowingList')}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons
                name="account-group"
                size={28}
                color="#4CAF50"
              />
            </View>
            <Text style={styles.actionTitle}>Following Farmers</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('ChatList')}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons
                name="message-text"
                size={28}
                color="#4CAF50"
              />
            </View>
            <Text style={styles.actionTitle}>Messages</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('FarmersToConsumers')}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons name="earth" size={28} color="#4CAF50" />
            </View>
            <Text style={styles.actionTitle}>Farmers & Consumers</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.actionCard}
            onPress={() => navigation.navigate('Cart')}
            activeOpacity={0.7}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons name="cart" size={28} color="#4CAF50" />
              {cartItemCount > 0 && (
                <View style={styles.notificationBadge}>
                  <Text style={styles.notificationBadgeText}>
                    {cartItemCount > 9 ? '9+' : cartItemCount}
                  </Text>
                </View>
              )}
            </View>
            <Text style={styles.actionTitle}>Shopping Cart</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.bottomPadding} />
      </ScrollView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    paddingBottom: 20,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  appName: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  welcomeText: {
    fontSize: 16,
    color: '#666666',
    fontWeight: '400',
  },
  settingsButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingsIcon: {
    fontSize: 20,
  },
  profileButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    backgroundColor: '#F5F5F5',
  },
  profileImage: {
    width: 44,
    height: 44,
    borderRadius: 22,
  },
  profileAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileAvatarText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 24,
  },
  statsSection: {
    marginTop: 32,
    marginBottom: 40,
  },
  overviewTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: '#666666',
    fontWeight: '500',
    marginBottom: 8,
  },
  statTrend: {
    fontSize: 12,
    color: '#10B981',
    fontWeight: '500',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  actionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
  },
  actionCard: {
    width: (width - 60) / 2,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 1,
    marginBottom: 8,
  },
  actionIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F8F9FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    position: 'relative',
  },
  actionIcon: {
    fontSize: 24,
  },
  notificationBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#F44336',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 6,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  notificationBadgeText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '700',
  },
  actionTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1A1A1A',
    textAlign: 'center',
    lineHeight: 18,
  },
  bottomPadding: {
    height: 40,
  },
});

export default ConsumerDashboardScreen;
