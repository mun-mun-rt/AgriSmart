import React, { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Platform,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { RootStackParamList, User } from '../../types';
import SupabaseAuthManager from '../../api/SupabaseAuthManager';
import Layout from '../../components/Layout';
import ModernHeader from '../../components/ModernHeader';
import ModernLoading from '../../components/ModernLoading';
import { useAppInfo } from '../../contexts/AppInfoContext';

const { width } = Dimensions.get('window');

type FarmerDashboardNavigationProp = StackNavigationProp<
  RootStackParamList,
  'FarmerDashboard'
>;

interface QuickAction {
  id: string;
  title: string;
  icon: string;
  route: string;
  params?: any;
  category: 'core' | 'business' | 'social';
}

const FarmerDashboardScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const dbManager =
    require('../../api/SupabaseDatabaseManager').default.getInstance();
  const navigation = useNavigation<FarmerDashboardNavigationProp>();
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeCrops, setActiveCrops] = useState<number>(0);
  const [monthlyRevenue, setMonthlyRevenue] = useState<number>(0);
  const [monthlyOrdersCount, setMonthlyOrdersCount] = useState<number>(0);
  const [pendingOrdersCount, setPendingOrdersCount] = useState<number>(0);
  const [approvedOrdersCount, setApprovedOrdersCount] = useState<number>(0);
  const [cartItemCount, setCartItemCount] = useState<number>(0);
  const { appInfo } = useAppInfo();

  const quickActions: QuickAction[] = [
    // Core farming operations
    {
      id: '1',
      title: 'Land Management',
      icon: 'home-city',
      route: 'LandLeaseManagement',
      category: 'core',
    },
    {
      id: '2',
      title: 'Lease Applications',
      icon: 'file-document-edit',
      route: 'LeaseApplicationList',
      category: 'core',
    },
    {
      id: '3',
      title: 'My Contracts',
      icon: 'clipboard-text',
      route: 'MyContracts',
      category: 'core',
    },
    {
      id: '4',
      title: 'Product Management',
      icon: 'package-variant',
      route: 'ProductManagement',
      category: 'core',
    },

    // Business operations
    {
      id: '5',
      title: 'Inventory',
      icon: 'chart-bar',
      route: 'InventoryManagement',
      category: 'business',
    },
    {
      id: '6',
      title: 'Orders Management',
      icon: 'clipboard-check',
      route: 'OrdersManagement',
      category: 'business',
    },
    {
      id: '7',
      title: 'My Orders',
      icon: 'cart',
      route: 'MyOrders',
      category: 'business',
    },
    {
      id: '8',
      title: 'Wallet',
      icon: 'wallet',
      route: 'Wallet',
      category: 'business',
    },
    {
      id: '9',
      title: 'Market Analysis',
      icon: 'chart-line',
      route: 'MarketAnalysis',
      category: 'business',
    },
    {
      id: '10',
      title: 'Shopping Cart',
      icon: 'cart-outline',
      route: 'Cart',
      category: 'business',
    },
    // {
    //   id: '11',
    //   title: 'Browse Products',
    //   icon: 'barley',
    //   route: 'ECommerce',
    //   category: 'business',
    // },

    // Social features
    {
      id: '12',
      title: 'Messages',
      icon: 'message-text',
      route: 'ChatList',
      category: 'social',
    },
    {
      id: '13',
      title: 'My Followers',
      icon: 'account-group',
      route: 'FollowersList',
      category: 'social',
    },
    {
      id: '14',
      title: 'Following',
      icon: 'account-multiple',
      route: 'FollowingList',
      category: 'social',
    },
    {
      id: '15',
      title: 'Farmers & Consumers',
      icon: 'earth',
      route: 'FarmersToConsumers',
      category: 'social',
    },
  ];

  const loadUserData = useCallback(async () => {
    try {
      const currentUser = await authManager.getCurrentUser();
      if (currentUser && currentUser.role === 'farmer') {
        setUser(currentUser);

        // Use the id as a string (UUID) directly
        const farmerId =
          typeof currentUser.id === 'string'
            ? currentUser.id
            : String(currentUser.id);
        const products = await dbManager.getAllFarmerProducts(farmerId);
        setActiveCrops(Array.isArray(products) ? products.length : 0);

        // For "My Orders" badge: get orders the farmer PLACED (as a buyer)
        const myOrders = await dbManager.getUserOrders(farmerId);
        console.log(
          '🔍 Farmer Dashboard - My Orders (as buyer) fetched:',
          myOrders?.length,
        );
        const approvedOrders = Array.isArray(myOrders)
          ? myOrders.filter((order: any) => {
              const status = (order.status || '').toString().toLowerCase();
              console.log(
                '📦 Farmer Order status:',
                status,
                'Is approved?',
                status === 'approved',
              );
              return status === 'approved';
            })
          : [];
        console.log(
          '✅ Farmer Dashboard - Approved orders count:',
          approvedOrders.length,
        );
        setApprovedOrdersCount(approvedOrders.length);

        // For monthly revenue: get orders placed ON the farmer's products (as a seller)
        const farmerSales = await dbManager.getFarmerOrders(farmerId);
        console.log(
          '📊 Farmer Dashboard - Total farmer sales:',
          farmerSales?.length,
        );
        console.log(
          '📊 Farmer sales data:',
          JSON.stringify(farmerSales, null, 2),
        );

        // Include both approved and delivered orders in revenue calculation
        const completedSales = Array.isArray(farmerSales)
          ? farmerSales.filter((order: any) => {
              const status = (order.status || '').toString().toLowerCase();
              const isCompleted =
                status === 'approved' || status === 'delivered';
              console.log(
                `📦 Order #${order.id} - Status: ${status}, Completed: ${isCompleted}, Price: ${order.total_price}`,
              );
              return isCompleted;
            })
          : [];
        console.log('✅ Completed sales count:', completedSales.length);

        const now = new Date();
        const thirtyDaysAgo = new Date(
          now.getTime() - 30 * 24 * 60 * 60 * 1000,
        );
        console.log(`📅 Current date: ${now.toISOString()}`);
        console.log(`📅 30 days ago: ${thirtyDaysAgo.toISOString()}`);

        const monthlyOrders = completedSales.filter((order: any) => {
          const created = new Date(order.created_at);
          const isLast30Days = created >= thirtyDaysAgo && created <= now;
          console.log(
            `📦 Order #${order.id} - Created: ${order.created_at}, Is last 30 days: ${isLast30Days}`,
          );
          return isLast30Days;
        });
        console.log('📅 Orders in last 30 days count:', monthlyOrders.length);

        const revenue = monthlyOrders.reduce((sum: number, order: any) => {
          const price = Number(order.total_price || 0);
          console.log(
            `💰 Adding order #${order.id} price: ${price} to sum: ${sum}`,
          );
          return sum + price;
        }, 0);
        console.log('💰 Final monthly revenue:', revenue);
        setMonthlyRevenue(revenue);
        setMonthlyOrdersCount(
          Array.isArray(monthlyOrders) ? monthlyOrders.length : 0,
        );

        // Count pending orders for "Orders Management" notification (orders on farmer's products)
        const pendingOrders = Array.isArray(farmerSales)
          ? farmerSales.filter(
              (order: any) => (order.status || '').toLowerCase() === 'pending',
            )
          : [];
        setPendingOrdersCount(pendingOrders.length);

        // Get cart item count
        try {
          const cartItems = await dbManager.getUserCart(farmerId);
          setCartItemCount(Array.isArray(cartItems) ? cartItems.length : 0);
        } catch (e) {
          console.error('Error fetching cart items:', e);
          setCartItemCount(0);
        }
      } else {
        navigation.replace('SignIn');
      }
    } catch (error) {
      console.error('Error loading farmer data:', error);
      navigation.replace('SignIn');
    } finally {
      setIsLoading(false);
    }
  }, [navigation, authManager, dbManager]);

  useEffect(() => {
    loadUserData();
  }, [loadUserData]);

  const handleActionPress = (action: QuickAction) => {
    if (action.params) {
      navigation.navigate(action.route as any, action.params);
    } else {
      navigation.navigate(action.route as any);
    }
  };

  const renderStatCard = (value: string, label: string, trend?: string) => (
    <View style={styles.statCard}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
      {trend && <Text style={styles.statTrend}>{trend}</Text>}
    </View>
  );

  const renderActionGrid = (actions: QuickAction[], title: string) => (
    <View style={styles.actionSection}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.actionGrid}>
        {actions.map(action => {
          // Show notification badge for Orders Management if there are pending orders
          let badgeCount = 0;
          if (action.id === '6') {
            badgeCount = pendingOrdersCount;
          } else if (action.id === '7') {
            badgeCount = approvedOrdersCount;
          } else if (action.id === '10') {
            badgeCount = cartItemCount;
          }
          const showBadge = badgeCount > 0;

          return (
            <TouchableOpacity
              key={action.id}
              style={styles.actionCard}
              onPress={() => handleActionPress(action)}
              activeOpacity={0.7}
            >
              <View style={styles.actionIconContainer}>
                <MaterialCommunityIcons
                  name={action.icon}
                  size={28}
                  color="#4CAF50"
                  style={styles.actionIcon}
                />
                {showBadge && (
                  <View style={styles.notificationBadge}>
                    <Text style={styles.notificationBadgeText}>
                      {badgeCount > 9 ? '9+' : badgeCount}
                    </Text>
                  </View>
                )}
              </View>
              <Text style={styles.actionTitle}>{action.title}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );

  if (isLoading) {
    return (
      <Layout activeTab="dashboard" showBottomNavigation={false}>
        <ModernLoading visible={true} message="Loading Dashboard..." />
      </Layout>
    );
  }

  const coreActions = quickActions.filter(action => action.category === 'core');
  const businessActions = quickActions.filter(
    action => action.category === 'business',
  );
  const socialActions = quickActions.filter(
    action => action.category === 'social',
  );

  return (
    <Layout activeTab="dashboard">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <View style={styles.headerText}>
              <Text style={styles.appName}>{appInfo.app_name}</Text>
              <Text style={styles.welcomeText}>Good day, {user?.name}</Text>
            </View>
            <TouchableOpacity
              style={styles.profileButton}
              onPress={() =>
                user
                  ? navigation.navigate('UserProfile', {
                      userId: String(user.id),
                    })
                  : navigation.navigate('SignIn')
              }
            >
              {user?.profile_image_url ? (
                <Image
                  source={{ uri: user.profile_image_url }}
                  style={styles.profileImage}
                />
              ) : (
                <View style={styles.profileAvatar}>
                  <Text style={styles.profileAvatarText}>
                    {user?.name ? user.name.charAt(0).toUpperCase() : '?'}
                  </Text>
                </View>
              )}
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView
          style={styles.content}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.contentContainer}
        >
          {/* Stats Overview */}
          <View style={styles.statsSection}>
            <Text style={styles.overviewTitle}>Overview</Text>
            <View style={styles.statsContainer}>
              {renderStatCard(
                activeCrops.toString(),
                'Active Products',
                `${activeCrops} total`,
              )}
              {renderStatCard(
                `৳${monthlyRevenue.toLocaleString()}`,
                'Revenue (Last 30 Days)',
                `${monthlyOrdersCount} orders`,
              )}
            </View>
          </View>

          {/* Core Actions */}
          {renderActionGrid(coreActions, 'Farm Operations')}

          {/* Business Actions */}
          {renderActionGrid(businessActions, 'Business')}

          {/* Social Actions */}
          {renderActionGrid(socialActions, 'Community')}

          <View style={styles.bottomPadding} />
        </ScrollView>
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    paddingBottom: 20,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  appName: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  welcomeText: {
    fontSize: 16,
    color: '#666666',
    fontWeight: '400',
  },
  settingsButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingsIcon: {
    fontSize: 20,
  },
  profileButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  profileImage: {
    width: 44,
    height: 44,
    borderRadius: 22,
  },
  profileAvatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileAvatarText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 24,
  },
  statsSection: {
    marginTop: 32,
    marginBottom: 40,
  },
  overviewTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: '#666666',
    fontWeight: '500',
    marginBottom: 8,
  },
  statTrend: {
    fontSize: 12,
    color: '#10B981',
    fontWeight: '500',
  },
  actionSection: {
    marginBottom: 40,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  actionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
  },
  actionCard: {
    width: (width - 60) / 2,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 1,
  },
  actionIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F8F9FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    position: 'relative',
  },
  actionIcon: {
    // Icon styling is now handled by MaterialCommunityIcons component
  },
  notificationBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: '#F44336',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 6,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  notificationBadgeText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '700',
  },
  actionTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1A1A1A',
    textAlign: 'center',
    lineHeight: 18,
  },
  bottomPadding: {
    height: 40,
  },
});

export default FarmerDashboardScreen;
