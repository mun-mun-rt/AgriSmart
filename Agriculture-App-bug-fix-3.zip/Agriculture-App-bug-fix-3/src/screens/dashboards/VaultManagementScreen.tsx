import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Platform,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { supabase } from '../../utils/supabase';
import { useNavigation } from '@react-navigation/native';
import Layout from '../../components/Layout';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../types';

type VaultManagementScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'VaultManagement'
>;

interface VaultBalance {
  owner_id: string;
  owner_name: string;
  owner_email: string;
  pending_amount: number;
  released_amount: number;
  total_amount: number;
  updated_at: string;
}

interface VaultTransaction {
  id: number;
  order_id: number;
  owner_id: string;
  owner_name: string;
  owner_email: string;
  buyer_id: string;
  buyer_name: string;
  buyer_email: string;
  amount: number;
  status: 'pending' | 'released' | 'refunded' | 'cancelled';
  payment_method: string;
  created_at: string;
  released_at: string | null;
}

const VaultManagementScreen = () => {
  const navigation = useNavigation<VaultManagementScreenNavigationProp>();
  const [activeTab, setActiveTab] = useState<'balances' | 'transactions'>(
    'balances',
  );
  const [balances, setBalances] = useState<VaultBalance[]>([]);
  const [transactions, setTransactions] = useState<VaultTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchData();
    checkAdminAccess();
  }, []);

  const checkAdminAccess = async () => {
    try {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      console.log('Current user ID:', user?.id);

      const { data: userData, error } = await supabase
        .from('users')
        .select('role, name, email')
        .eq('id', user?.id)
        .single();

      console.log('User role and info:', userData);
      if (error) console.error('Error fetching user role:', error);
    } catch (error) {
      console.error('Error checking admin access:', error);
    }
  };

  const fetchData = async () => {
    try {
      setLoading(true);
      await Promise.all([fetchBalances(), fetchTransactions()]);
    } catch (error) {
      console.error('Error fetching vault data:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchBalances = async () => {
    try {
      const { data, error } = await supabase.rpc('admin_get_vault_balances');

      if (error) {
        console.error('Error fetching balances via RPC:', error);
        throw error;
      }

      const formattedBalances: VaultBalance[] = (data || []).map(
        (item: any) => ({
          owner_id: item.owner_id,
          owner_name: item.owner_name || 'Unknown User',
          owner_email: item.owner_email || '',
          pending_amount: Number(item.pending_amount ?? 0),
          released_amount: Number(item.released_amount ?? 0),
          total_amount: Number(item.total_amount ?? 0),
          updated_at: item.updated_at,
        }),
      );

      setBalances(formattedBalances);
    } catch (error: any) {
      console.error('Error fetching balances:', {
        message: error?.message,
        details: error?.details,
        hint: error?.hint,
        code: error?.code,
        error,
      });
      setBalances([]);
    }
  };

  const fetchTransactions = async () => {
    try {
      const { data, error } = await supabase.rpc(
        'admin_get_vault_transactions',
      );

      if (error) {
        console.error('Error fetching transactions via RPC:', error);
        throw error;
      }

      const formattedTransactions: VaultTransaction[] = (data || []).map(
        (item: any) => ({
          id: item.id,
          order_id: item.order_id,
          owner_id: item.owner_id,
          owner_name: item.owner_name || 'Unknown Farmer',
          owner_email: item.owner_email || '',
          buyer_id: item.buyer_id,
          buyer_name: item.buyer_name || 'Unknown Buyer',
          buyer_email: item.buyer_email || '',
          amount: Number(item.amount ?? 0),
          status: item.status,
          payment_method: item.payment_method || 'Unknown',
          created_at: item.created_at,
          released_at: item.released_at,
        }),
      );

      setTransactions(formattedTransactions);
    } catch (error: any) {
      console.error('Error fetching transactions:', {
        message: error?.message,
        details: error?.details,
        hint: error?.hint,
        code: error?.code,
        error,
      });
      setTransactions([]);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchData();
    setRefreshing(false);
  };

  const formatCurrency = (amount: number) => {
    return `৳${amount.toLocaleString('en-BD', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-BD', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return '#FF9800';
      case 'released':
        return '#4CAF50';
      case 'refunded':
        return '#2196F3';
      case 'cancelled':
        return '#F44336';
      default:
        return '#757575';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return 'clock-outline';
      case 'released':
        return 'check-circle';
      case 'refunded':
        return 'cash-refund';
      case 'cancelled':
        return 'close-circle';
      default:
        return 'help-circle';
    }
  };

  const renderBalanceCard = (balance: VaultBalance, index: number) => (
    <View key={balance.owner_id} style={styles.balanceCard}>
      <View style={styles.balanceHeader}>
        <View style={styles.balanceUserInfo}>
          <View style={styles.avatarCircle}>
            <MaterialCommunityIcons name="account" size={24} color="#4CAF50" />
          </View>
          <View style={styles.userDetails}>
            <Text style={styles.userName}>{balance.owner_name}</Text>
            <Text style={styles.userEmail}>{balance.owner_email}</Text>
          </View>
        </View>
        <View style={styles.rankBadge}>
          <Text style={styles.rankText}>#{index + 1}</Text>
        </View>
      </View>

      <View style={styles.balanceAmounts}>
        <View style={styles.amountRow}>
          <View style={styles.amountItem}>
            <Text style={styles.amountLabel}>Pending</Text>
            <Text style={[styles.amountValue, { color: '#FF9800' }]}>
              {formatCurrency(balance.pending_amount)}
            </Text>
          </View>
          <View style={styles.amountDivider} />
          <View style={styles.amountItem}>
            <Text style={styles.amountLabel}>Released</Text>
            <Text style={[styles.amountValue, { color: '#4CAF50' }]}>
              {formatCurrency(balance.released_amount)}
            </Text>
          </View>
        </View>
        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>Total Processed</Text>
          <Text style={styles.totalValue}>
            {formatCurrency(balance.total_amount)}
          </Text>
        </View>
      </View>

      <View style={styles.balanceFooter}>
        <MaterialCommunityIcons name="clock-outline" size={12} color="#999" />
        <Text style={styles.lastUpdated}>
          Updated {formatDate(balance.updated_at)}
        </Text>
      </View>
    </View>
  );

  const renderTransactionCard = (transaction: VaultTransaction) => (
    <View key={transaction.id} style={styles.transactionCard}>
      <View style={styles.transactionHeader}>
        <View style={styles.transactionIdRow}>
          <MaterialCommunityIcons
            name="file-document-outline"
            size={16}
            color="#666"
          />
          <Text style={styles.transactionId}>
            Order #{transaction.order_id}
          </Text>
        </View>
        <View
          style={[
            styles.statusBadge,
            { backgroundColor: getStatusColor(transaction.status) + '20' },
          ]}
        >
          <MaterialCommunityIcons
            name={getStatusIcon(transaction.status)}
            size={14}
            color={getStatusColor(transaction.status)}
          />
          <Text
            style={[
              styles.statusText,
              { color: getStatusColor(transaction.status) },
            ]}
          >
            {transaction.status.charAt(0).toUpperCase() +
              transaction.status.slice(1)}
          </Text>
        </View>
      </View>

      <View style={styles.transactionFlow}>
        <View style={styles.transactionParty}>
          <View style={styles.partyLabel}>
            <MaterialCommunityIcons
              name="account-arrow-left"
              size={16}
              color="#666"
            />
            <Text style={styles.partyLabelText}>From (Buyer)</Text>
          </View>
          <Text style={styles.partyName}>{transaction.buyer_name}</Text>
          <Text style={styles.partyEmail}>{transaction.buyer_email}</Text>
        </View>

        <View style={styles.flowArrow}>
          <MaterialCommunityIcons
            name="arrow-right-thick"
            size={24}
            color="#4CAF50"
          />
          <Text style={styles.amountInFlow}>
            {formatCurrency(transaction.amount)}
          </Text>
        </View>

        <View style={styles.transactionParty}>
          <View style={styles.partyLabel}>
            <MaterialCommunityIcons
              name="account-arrow-right"
              size={16}
              color="#666"
            />
            <Text style={styles.partyLabelText}>To (Farmer)</Text>
          </View>
          <Text style={styles.partyName}>{transaction.owner_name}</Text>
          <Text style={styles.partyEmail}>{transaction.owner_email}</Text>
        </View>
      </View>

      <View style={styles.transactionFooter}>
        <View style={styles.paymentMethodBadge}>
          <MaterialCommunityIcons
            name="credit-card-outline"
            size={12}
            color="#666"
          />
          <Text style={styles.paymentMethodText}>
            {transaction.payment_method}
          </Text>
        </View>
        <Text style={styles.transactionDate}>
          {formatDate(transaction.created_at)}
        </Text>
      </View>

      {transaction.released_at && transaction.status !== 'pending' && (
        <View style={styles.releaseInfo}>
          <MaterialCommunityIcons
            name={
              transaction.status === 'refunded' ? 'cash-refund' : 'check-circle'
            }
            size={12}
            color={getStatusColor(transaction.status)}
          />
          <Text style={styles.releaseText}>
            {transaction.status === 'refunded'
              ? `Refunded on ${formatDate(transaction.released_at)}`
              : `Released on ${formatDate(transaction.released_at)}`}
          </Text>
        </View>
      )}
    </View>
  );

  const renderBalancesTab = () => {
    if (balances.length === 0) {
      return (
        <View style={styles.emptyState}>
          <MaterialCommunityIcons name="bank-off" size={64} color="#ccc" />
          <Text style={styles.emptyStateText}>No vault balances found</Text>
          <Text style={styles.emptyStateHint}>
            Vault balances are created when buyers use Bank Transfer or Mobile
            Banking payment methods
          </Text>
        </View>
      );
    }

    const totalPending = balances.reduce((sum, b) => sum + b.pending_amount, 0);
    const totalReleased = balances.reduce(
      (sum, b) => sum + b.released_amount,
      0,
    );

    return (
      <>
        <View style={styles.summaryCards}>
          <View style={styles.summaryCard}>
            <MaterialCommunityIcons
              name="clock-outline"
              size={24}
              color="#FF9800"
            />
            <Text style={styles.summaryValue}>
              {formatCurrency(totalPending)}
            </Text>
            <Text style={styles.summaryLabel}>Total Pending</Text>
          </View>
          <View style={styles.summaryCard}>
            <MaterialCommunityIcons
              name="check-circle"
              size={24}
              color="#4CAF50"
            />
            <Text style={styles.summaryValue}>
              {formatCurrency(totalReleased)}
            </Text>
            <Text style={styles.summaryLabel}>Total Released</Text>
          </View>
        </View>

        {balances.map((balance, index) => renderBalanceCard(balance, index))}
      </>
    );
  };

  const renderTransactionsTab = () => {
    if (transactions.length === 0) {
      return (
        <View style={styles.emptyState}>
          <MaterialCommunityIcons
            name="swap-horizontal"
            size={64}
            color="#ccc"
          />
          <Text style={styles.emptyStateText}>No transactions found</Text>
          <Text style={styles.emptyStateHint}>
            Transactions are created when orders are placed with Bank Transfer
            or Mobile Banking
          </Text>
        </View>
      );
    }

    const pendingCount = transactions.filter(
      t => t.status === 'pending',
    ).length;
    const releasedCount = transactions.filter(
      t => t.status === 'released',
    ).length;
    const cancelledCount = transactions.filter(
      t => t.status === 'cancelled',
    ).length;

    return (
      <>
        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: '#FF9800' }]}>
              {pendingCount}
            </Text>
            <Text style={styles.statLabel}>Pending</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: '#4CAF50' }]}>
              {releasedCount}
            </Text>
            <Text style={styles.statLabel}>Released</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: '#F44336' }]}>
              {cancelledCount}
            </Text>
            <Text style={styles.statLabel}>Cancelled</Text>
          </View>
        </View>

        {transactions.map(transaction => renderTransactionCard(transaction))}
      </>
    );
  };

  if (loading) {
    return (
      <Layout activeTab="dashboard">
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <MaterialCommunityIcons
              name="arrow-left"
              size={24}
              color="#1A1A1A"
            />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Vault Management</Text>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4CAF50" />
          <Text style={styles.loadingText}>Loading vault data...</Text>
        </View>
      </Layout>
    );
  }

  return (
    <Layout activeTab="dashboard">
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <MaterialCommunityIcons name="arrow-left" size={24} color="#1A1A1A" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Vault Management</Text>
        <TouchableOpacity style={styles.refreshButton} onPress={onRefresh}>
          <MaterialCommunityIcons name="refresh" size={20} color="#4CAF50" />
        </TouchableOpacity>
      </View>

      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'balances' && styles.activeTab]}
          onPress={() => setActiveTab('balances')}
        >
          <MaterialCommunityIcons
            name="bank"
            size={20}
            color={activeTab === 'balances' ? '#4CAF50' : '#999'}
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'balances' && styles.activeTabText,
            ]}
          >
            Balances
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.tab, activeTab === 'transactions' && styles.activeTab]}
          onPress={() => setActiveTab('transactions')}
        >
          <MaterialCommunityIcons
            name="swap-horizontal"
            size={20}
            color={activeTab === 'transactions' ? '#4CAF50' : '#999'}
          />
          <Text
            style={[
              styles.tabText,
              activeTab === 'transactions' && styles.activeTabText,
            ]}
          >
            Transactions
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={['#4CAF50']}
          />
        }
      >
        {activeTab === 'balances'
          ? renderBalancesTab()
          : renderTransactionsTab()}
        <View style={styles.bottomPadding} />
      </ScrollView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    paddingBottom: 16,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1A1A1A',
    flex: 1,
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FAFAFA',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666',
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingTop: 16,
    gap: 8,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#F5F5F5',
    gap: 8,
  },
  activeTab: {
    backgroundColor: '#E8F5E9',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#999',
  },
  activeTabText: {
    color: '#4CAF50',
    fontWeight: '600',
  },
  content: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  contentContainer: {
    padding: 20,
  },
  summaryCards: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  summaryCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1A1A1A',
    marginTop: 8,
  },
  summaryLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  balanceCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  balanceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  balanceUserInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatarCircle: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 2,
  },
  userEmail: {
    fontSize: 12,
    color: '#666',
  },
  rankBadge: {
    backgroundColor: '#F5F5F5',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  rankText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
  },
  balanceAmounts: {
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    paddingTop: 16,
  },
  amountRow: {
    flexDirection: 'row',
    marginBottom: 12,
  },
  amountItem: {
    flex: 1,
  },
  amountDivider: {
    width: 1,
    backgroundColor: '#F0F0F0',
    marginHorizontal: 16,
  },
  amountLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  amountValue: {
    fontSize: 18,
    fontWeight: '700',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  totalLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1A1A1A',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#4CAF50',
  },
  balanceFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    gap: 6,
  },
  lastUpdated: {
    fontSize: 11,
    color: '#999',
  },
  statsRow: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
  },
  transactionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  transactionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  transactionIdRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  transactionId: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1A1A1A',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    gap: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  transactionFlow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  transactionParty: {
    flex: 1,
  },
  partyLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 6,
  },
  partyLabelText: {
    fontSize: 11,
    color: '#666',
    fontWeight: '500',
  },
  partyName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 2,
  },
  partyEmail: {
    fontSize: 11,
    color: '#999',
  },
  flowArrow: {
    alignItems: 'center',
    paddingHorizontal: 8,
  },
  amountInFlow: {
    fontSize: 14,
    fontWeight: '700',
    color: '#4CAF50',
    marginTop: 4,
  },
  transactionFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  paymentMethodBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#F5F5F5',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
  },
  paymentMethodText: {
    fontSize: 11,
    color: '#666',
    fontWeight: '500',
  },
  transactionDate: {
    fontSize: 11,
    color: '#999',
  },
  releaseInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
  },
  releaseText: {
    fontSize: 11,
    color: '#4CAF50',
    fontWeight: '500',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#999',
    marginTop: 16,
    fontWeight: '500',
  },
  emptyStateHint: {
    fontSize: 13,
    color: '#aaa',
    marginTop: 8,
    textAlign: 'center',
    paddingHorizontal: 40,
    lineHeight: 20,
  },
  bottomPadding: {
    height: 40,
  },
});

export default VaultManagementScreen;
