import React, { useEffect, useState, useCallback } from 'react';
import {
  Text,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../types';
import SupabaseAuthManager from '../../api/SupabaseAuthManager';

type DashboardNavigationProp = StackNavigationProp<
  RootStackParamList,
  'Dashboard'
>;

const Dashboard: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();

  const navigation = useNavigation<DashboardNavigationProp>();
  const [isLoading, setIsLoading] = useState(true);

  const checkUserAndLoadDashboard = useCallback(async () => {
    try {
      const currentUser = await authManager.getCurrentUser();

      if (!currentUser) {
        // No user logged in, redirect to welcome
        return;
      }

      // Redirect to role-specific dashboard
      if (currentUser.role === 'farmer') {
        navigation.replace('FarmerDashboard');
      } else if (currentUser.role === 'consumer') {
        navigation.replace('ConsumerDashboard');
      } else if (currentUser.role === 'admin') {
        navigation.replace('AdminDashboard');
      } else {
        // Default to menu for other roles
      }
    } catch (error) {
      console.error('Error loading user:', error);
    } finally {
      setIsLoading(false);
    }
  }, [navigation, authManager]);

  useEffect(() => {
    checkUserAndLoadDashboard();
  }, [checkUserAndLoadDashboard]);

  if (isLoading) {
    return (
      <SafeAreaView style={styles.loadingContainer}>
        <StatusBar barStyle="dark-content" backgroundColor="#FFFFFF" />
        <ActivityIndicator size="large" color="#4CAF50" />
        <Text style={styles.loadingText}>Loading...</Text>
      </SafeAreaView>
    );
  }

  return null;
};

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 16,
    color: '#666666',
  },
});

export default Dashboard;
