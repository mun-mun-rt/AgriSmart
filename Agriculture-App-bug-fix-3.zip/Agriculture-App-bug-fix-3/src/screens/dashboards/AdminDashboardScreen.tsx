import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Platform,
  Dimensions,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
const { width } = Dimensions.get('window');
import SupabaseDatabaseManager from '../../api/SupabaseDatabaseManager';
import { useNavigation } from '@react-navigation/native';
import Layout from '../../components/Layout';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../types';
import { useAppInfo } from '../../contexts/AppInfoContext';

type AdminDashboardScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'AdminDashboard'
>;

const AdminDashboardScreen = () => {
  const navigation = useNavigation<AdminDashboardScreenNavigationProp>();
  const { appInfo } = useAppInfo();

  // State for stats
  const [userCount, setUserCount] = useState<number | null>(null);
  const [fertilizerCount, setFertilizerCount] = useState<number | null>(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const dbManager = SupabaseDatabaseManager.getInstance();
        const users = await dbManager.getAllUsers();
        setUserCount(users.length);
        const fertilizerGuides = await dbManager.getAllFertilizerGuides();
        setFertilizerCount(fertilizerGuides.length);
      } catch (error) {
        setUserCount(null);
        setFertilizerCount(null);
      }
    };
    fetchStats();
  }, []);

  const adminFeatures = [
    {
      id: 'fertilizer-management',
      title: 'Fertilizer Management',
      iconName: 'sprout',
      description: 'Manage fertilizer for different crops',
      onPress: () => navigation.navigate('FertilizerManagement'),
    },
    {
      id: 'user-management',
      title: 'User Management',
      iconName: 'account',
      description: 'Manage user accounts, roles and permissions',
      onPress: () => navigation.navigate('UserManagement'),
    },
    {
      id: 'app-settings',
      title: 'App Info',
      iconName: 'cog',
      description: 'Edit application information and settings',
      onPress: () => navigation.navigate('AppSettings'),
    },
    {
      id: 'system-payment-accounts',
      title: 'Payment Accounts',
      iconName: 'bank',
      description: 'Configure official bank and mobile payment details',
      onPress: () => navigation.navigate('SystemPaymentAccounts'),
    },
    {
      id: 'vault-management',
      title: 'Vault Management',
      iconName: 'safe',
      description: 'Monitor vault balances and payment transactions',
      onPress: () => navigation.navigate('VaultManagement'),
    },
  ];

  return (
    <Layout activeTab="dashboard">
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.headerText}>
            <Text style={styles.appName}>{appInfo.app_name}</Text>
            <Text style={styles.welcomeText}>Welcome, Admin</Text>
          </View>
          <TouchableOpacity
            style={styles.settingsButton}
            onPress={() => navigation.navigate('AppSettings')}
          >
            <MaterialCommunityIcons name="cog" size={20} color="#4CAF50" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.contentContainer}
      >
        {/* Stats Overview */}
        <View style={styles.statsSection}>
          <Text style={styles.overviewTitle}>Overview</Text>
          <View style={styles.statsContainer}>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>
                {userCount !== null ? userCount : '-'}
              </Text>
              <Text style={styles.statLabel}>Total Users</Text>
              <Text style={styles.statTrend}>
                {userCount !== null ? '' : 'Loading...'}
              </Text>
            </View>
            <View style={styles.statCard}>
              <Text style={styles.statValue}>
                {fertilizerCount !== null ? fertilizerCount : '-'}
              </Text>
              <Text style={styles.statLabel}>Fertilizers Added</Text>
              <Text style={styles.statTrend}>
                {fertilizerCount !== null ? '' : 'Loading...'}
              </Text>
            </View>
          </View>
        </View>

        {/* Admin Features as Action Grid */}
        <Text style={styles.sectionTitle}>Administrative Features</Text>
        <View style={styles.actionGrid}>
          {adminFeatures.map(feature => (
            <TouchableOpacity
              key={feature.id}
              style={styles.actionCard}
              onPress={feature.onPress}
              activeOpacity={0.7}
            >
              <View style={styles.actionIconContainer}>
                <MaterialCommunityIcons
                  name={feature.iconName}
                  size={28}
                  color="#4CAF50"
                />
              </View>
              <Text style={styles.actionTitle}>{feature.title}</Text>
              <Text style={styles.actionDescription}>
                {feature.description}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.bottomPadding} />
      </ScrollView>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    paddingBottom: 20,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  appName: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  welcomeText: {
    fontSize: 16,
    color: '#666666',
    fontWeight: '400',
  },
  settingsButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F5F5F5',
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingsIcon: {
    fontSize: 20,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 24,
  },
  statsSection: {
    marginTop: 32,
    marginBottom: 40,
  },
  overviewTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: '#666666',
    fontWeight: '500',
    marginBottom: 8,
  },
  statTrend: {
    fontSize: 12,
    color: '#10B981',
    fontWeight: '500',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  actionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
  },
  actionCard: {
    width: (width - 60) / 2,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 1,
    marginBottom: 8,
  },
  actionIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F8F9FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionIcon: {
    fontSize: 24,
  },
  actionTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1A1A1A',
    textAlign: 'center',
    lineHeight: 18,
    marginBottom: 6,
  },
  actionDescription: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  bottomPadding: {
    height: 40,
  },
});

export default AdminDashboardScreen;
