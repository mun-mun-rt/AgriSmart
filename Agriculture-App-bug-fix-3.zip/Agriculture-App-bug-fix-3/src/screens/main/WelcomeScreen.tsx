import React, { useEffect, useCallback, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Dimensions,
  Animated,
  Platform,
  Image,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../types';
import SupabaseAuthManager from '../../api/SupabaseAuthManager';
import ModernLoading from '../../components/ModernLoading';
import { useAppInfo } from '../../contexts/AppInfoContext';
import { needsOnboarding, getDashboardRoute } from '../../utils/authUtils';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const { width, height } = Dimensions.get('window');

type WelcomeScreenNavigationProp = StackNavigationProp<
  RootStackParamList,
  'Welcome'
>;

const WelcomeScreen: React.FC = () => {
  const authManager = SupabaseAuthManager.getInstance();
  const navigation = useNavigation<WelcomeScreenNavigationProp>();
  const [isLoading, setIsLoading] = useState(true);
  const { appInfo, isLoading: appInfoLoading } = useAppInfo();
  const featureItems = [
    { icon: 'cart-outline', title: 'E-Commerce', desc: 'Buy & sell products' },
    {
      icon: 'weather-partly-cloudy',
      title: 'Weather',
      desc: 'Real-time insights',
    },
    { icon: 'tractor', title: 'Land Lease', desc: 'Rent farmland' },
    { icon: 'flask-outline', title: 'Fertilizer', desc: 'Expert advice' },
  ];

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const scaleAnim = useRef(new Animated.Value(0.95)).current;

  const checkAuthStatus = useCallback(async () => {
    try {
      setIsLoading(true);
      const isAuthenticated = await authManager.isAuthenticated();
      if (isAuthenticated) {
        const user = await authManager.getCurrentUser();
        if (user) {
          if (needsOnboarding(user)) {
            navigation.replace('Onboarding');
            return;
          }

          const dashboardRoute = getDashboardRoute(user.role || 'consumer');
          if (dashboardRoute === 'Dashboard') {
            const roleForNavigation = (
              user.role === 'guest' ? 'consumer' : user.role
            ) as 'farmer' | 'consumer' | 'admin';
            navigation.replace('Dashboard', { role: roleForNavigation });
          } else {
            navigation.replace(dashboardRoute as any);
          }
        }
      }
    } catch (error) {
      console.error('Error checking auth status:', error);
    } finally {
      setIsLoading(false);
    }
  }, [navigation, authManager]);

  useEffect(() => {
    checkAuthStatus();

    // Start animations
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        tension: 100,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, [checkAuthStatus, fadeAnim, slideAnim, scaleAnim]);

  const handleGetStarted = () => {
    navigation.navigate('SignUp');
  };

  const handleSignIn = () => {
    navigation.navigate('SignIn');
  };

  const handleContinueAsGuest = () => {
    navigation.navigate('Menu');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#FFFFFF"
        translucent
      />

      {/* Subtle Background Elements */}
      <View style={styles.backgroundElements}>
        <View style={styles.circle1} />
        <View style={styles.circle2} />
        <View style={styles.circle3} />
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        style={styles.scrollView}
      >
        {/* Header Section */}
        <Animated.View
          style={[
            styles.headerSection,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }, { scale: scaleAnim }],
            },
          ]}
        >
          <View style={styles.logoContainer}>
            <View style={styles.logoIconContainer}>
              {appInfo.app_logo_url ? (
                <Image
                  source={{ uri: appInfo.app_logo_url }}
                  style={styles.logoImage}
                  resizeMode="contain"
                />
              ) : (
                <Image
                  source={require('../../assets/default_logo.png')}
                  style={styles.logoImage}
                  resizeMode="contain"
                />
              )}
            </View>

            <View style={styles.appTitleContainer}>
              <Text style={styles.appTitle}>{appInfo.app_name}</Text>
            </View>
          </View>

          <Text style={styles.tagline}>{appInfo.welcome_message}</Text>
        </Animated.View>

        {/* Features Section */}
        <Animated.View
          style={[
            styles.featuresSection,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View style={styles.featuresGrid}>
            {featureItems.map(feature => (
              <Animated.View
                key={feature.title}
                style={[
                  styles.featureCard,
                  {
                    transform: [
                      {
                        scale: scaleAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [0.9, 1],
                        }),
                      },
                    ],
                  },
                ]}
              >
                <View style={styles.featureIconContainer}>
                  <MaterialCommunityIcons
                    name={feature.icon}
                    size={24}
                    color="#2E7D32"
                    style={styles.featureIcon}
                  />
                </View>
                <Text style={styles.featureTitle}>{feature.title}</Text>
                <Text style={styles.featureDescription}>{feature.desc}</Text>
              </Animated.View>
            ))}
          </View>
        </Animated.View>

        {/* Action Buttons */}
        <Animated.View
          style={[
            styles.actionSection,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <TouchableOpacity
            style={styles.primaryButton}
            onPress={handleGetStarted}
            activeOpacity={0.9}
          >
            <Text style={styles.primaryButtonText}>Get Started</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.secondaryButton}
            onPress={handleSignIn}
            activeOpacity={0.9}
          >
            <Text style={styles.secondaryButtonText}>Sign In</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.guestButton}
            onPress={handleContinueAsGuest}
            activeOpacity={0.8}
          >
            <Text style={styles.guestButtonText}>Continue as Guest</Text>
          </TouchableOpacity>
        </Animated.View>

        {/* Footer */}
        <Animated.View
          style={[
            styles.footer,
            {
              opacity: fadeAnim,
            },
          ]}
        >
          <View style={styles.footerTextRow}>
            <Text style={styles.footerText}>Made with</Text>
            <MaterialCommunityIcons
              name="heart"
              size={16}
              color="#E57373"
              style={styles.footerHeartIcon}
            />
            <Text style={styles.footerText}>for Bangladesh Farmers</Text>
          </View>
          <Text style={styles.versionText}>Version {appInfo.version}</Text>
        </Animated.View>
      </ScrollView>

      <ModernLoading
        visible={isLoading || appInfoLoading}
        message={
          appInfoLoading
            ? 'Loading app information...'
            : 'Checking authentication...'
        }
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#dcfac4ff',
  },
  backgroundElements: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    pointerEvents: 'none',
  },
  circle1: {
    position: 'absolute',
    width: 200,
    height: 200,
    borderRadius: 100,
    backgroundColor: '#F1F8E9',
    top: -50,
    right: -50,
    opacity: 0.6,
  },
  circle2: {
    position: 'absolute',
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: '#E8F5E8',
    bottom: 100,
    left: -30,
    opacity: 0.4,
  },
  circle3: {
    position: 'absolute',
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#C8E6C9',
    top: '40%',
    right: 20,
    opacity: 0.3,
  },
  scrollView: {
    flex: 1,
    zIndex: 10,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 32,
    paddingTop: Platform.OS === 'ios' ? 80 : 100,
    paddingBottom: 60,
  },
  headerSection: {
    alignItems: 'center',
    marginBottom: 20,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 10,
  },
  logoIconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 16,
    elevation: 8,
    borderWidth: 2,
    borderColor: '#E8F5E8',
  },
  logoIcon: {
    fontSize: 36,
  },
  logoImage: {
    width: 60,
    height: 60,
    borderRadius: 40,
  },
  appTitleContainer: {
    alignItems: 'center',
  },
  appTitle: {
    fontSize: 36,
    fontWeight: '300',
    color: '#2E7D32',
    letterSpacing: -0.5,
    marginBottom: 2,
  },
  appSubtitle: {
    fontSize: 14,
    color: '#66BB6A',
    fontWeight: '400',
    letterSpacing: 2,
    textTransform: 'uppercase',
  },
  tagline: {
    fontSize: 18,
    color: '#4CAF50',
    textAlign: 'center',
    fontWeight: '400',
    marginBottom: 10,
    lineHeight: 26,
  },
  description: {
    fontSize: 16,
    color: '#757575',
    textAlign: 'center',
    lineHeight: 24,
    paddingHorizontal: 20,
    fontWeight: '300',
  },
  featuresSection: {
    marginBottom: 20,
  },
  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  featureCard: {
    width: (width - 80) / 2,
    backgroundColor: '#f9fff1ff',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#ffffffff',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 3,
    borderWidth: 1,
    borderColor: '#F1F8E9',
  },
  featureIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F1F8E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  featureIcon: {
    color: '#2E7D32',
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#2E7D32',
    textAlign: 'center',
    marginBottom: 8,
  },
  featureDescription: {
    fontSize: 13,
    color: '#9E9E9E',
    textAlign: 'center',
    lineHeight: 18,
    fontWeight: '300',
  },
  actionSection: {
    marginBottom: 60,
    paddingHorizontal: 8,
  },
  primaryButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 16,
    paddingVertical: 20,
    alignItems: 'center',
    marginBottom: 16,
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 6,
  },
  primaryButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#FFFFFF',
    letterSpacing: 0.3,
  },
  secondaryButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    paddingVertical: 20,
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 1.5,
    borderColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.03,
    shadowRadius: 8,
    elevation: 3,
  },
  secondaryButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#4CAF50',
    letterSpacing: 0.3,
  },
  guestButton: {
    alignItems: 'center',
    paddingVertical: 16,
  },
  guestButtonText: {
    fontSize: 15,
    color: '#9E9E9E',
    fontWeight: '400',
    textDecorationLine: 'underline',
    textDecorationColor: '#E0E0E0',
  },
  footer: {
    alignItems: 'center',
    marginTop: 20,
  },
  footerTextRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  footerText: {
    fontSize: 14,
    color: '#BDBDBD',
    textAlign: 'center',
    fontWeight: '300',
  },
  footerHeartIcon: {
    marginHorizontal: 6,
  },
  versionText: {
    fontSize: 12,
    color: '#E0E0E0',
    textAlign: 'center',
    fontWeight: '300',
  },
});

export default WelcomeScreen;
