import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  RefreshControl,
  Alert,
  Dimensions,
  TouchableOpacity,
  Image,
  Platform,
  Animated,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList, User, GuestUser, UserRole } from '../../types';
import SupabaseAuthManager from '../../api/SupabaseAuthManager';
import SupabaseDatabaseManager from '../../api/SupabaseDatabaseManager';
import { supabase } from '../../utils/supabase';
import Layout from '../../components/Layout';
import ModernHeader from '../../components/ModernHeader';
import ModernCard from '../../components/ModernCard';
import ModernButton from '../../components/ModernButton';
import ModernLoading from '../../components/ModernLoading';
import LoginRequiredModal from '../../components/LoginRequiredModal';
import { useAppInfo } from '../../contexts/AppInfoContext';

const { width } = Dimensions.get('window');

type HomeNavigationProp = StackNavigationProp<RootStackParamList, 'Menu'>;

interface AppFeature {
  id: string;
  title: string;
  iconName: string;
  description: string;
  color: string;
  requiresAuth: boolean;
  allowedRoles: UserRole[];
  route: keyof RootStackParamList;
  image_url?: string;
  // bundled image for React Native (require)
  image?: any;
}

const HomeScreen: React.FC = () => {
  const navigation = useNavigation<HomeNavigationProp>();

  // Initialize auth manager
  const authManager = SupabaseAuthManager.getInstance();

  const [user, setUser] = useState<User | GuestUser | null>(null);
  const [isGuest, setIsGuest] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [selectedFeature, setSelectedFeature] = useState<AppFeature | null>(
    null,
  );
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState({
    totalProducts: 0,
    totalLandListings: 0,
    totalFertilizerGuides: 0,
    activeUsers: 0,
  });
  // profile menu removed: tapping avatar will navigate directly to profile

  const { appInfo, isLoading: appInfoLoading } = useAppInfo();

  // Database manager instance
  const dbManager = SupabaseDatabaseManager.getInstance();

  // Hero carousel state
  const [productsList, setProductsList] = useState<Array<any>>([]);
  const [leasesList, setLeasesList] = useState<Array<any>>([]);
  const [slideIndex, setSlideIndex] = useState(0);
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const slideAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const features: AppFeature[] = [
    {
      id: 'ecommerce',
      title: 'E-Commerce Marketplace',
      iconName: 'cart',
      description: 'Buy and sell agricultural products across Bangladesh',
      color: '#FF9800',
      requiresAuth: false,
      allowedRoles: ['farmer', 'consumer', 'guest'],
      route: 'ECommerce',
      image_url: '/images/ecomerce.jpg',
      image: require('../../../public/images/ecomerce.jpg'),
    },
    {
      id: 'weather',
      title: 'Weather Forecast',
      iconName: 'weather-partly-cloudy',
      description: 'Real-time weather updates for all 8 divisions',
      color: '#2196F3',
      requiresAuth: false,
      allowedRoles: ['farmer', 'consumer', 'guest'],
      route: 'WeatherForecast',
      image_url: '/images/weather.jpg',
      image: require('../../../public/images/weather.jpg'),
    },
    {
      id: 'landlease',
      title: 'Land Lease',
      iconName: 'image-filter-hdr',
      description: 'Lease and rent agricultural land nationwide',
      color: '#4CAF50',
      requiresAuth: false,
      allowedRoles: ['farmer', 'consumer', 'guest'],
      route: 'LandLease',
      image_url: '/images/landlease.jpg',
      image: require('../../../public/images/landlease.jpg'),
    },
    {
      id: 'fertilizer',
      title: 'Fertilizer Guide',
      iconName: 'flask',
      description: 'Expert fertilizer recommendations for all crops',
      color: '#9C27B0',
      requiresAuth: false,
      allowedRoles: ['admin', 'farmer', 'consumer', 'guest'],
      route: 'FertilizerRecommendation',
      image_url: '/images/fertilizer.jpg',
      image: require('../../../public/images/fertilizer.jpg'),
    },
    {
      id: 'browse_farmers',
      title: 'Farmers to Consumer',
      iconName: 'account-group',
      description: 'Connect with farmers and consumers across Bangladesh',
      color: '#FF5722',
      requiresAuth: true,
      allowedRoles: ['admin', 'farmer', 'consumer', 'guest'],
      route: 'FarmersToConsumers',
      image_url: '/images/browse_farmers.jpg',
      image: require('../../../public/images/browse_farmers.jpg'),
    },
  ];

  const checkUserStatus = useCallback(async () => {
    try {
      setIsLoading(true);
      const currentUser = await authManager.getCurrentUser();
      if (currentUser) {
        setUser(currentUser);
        setIsGuest(false);
      } else {
        const guestUser: GuestUser = {
          id: 'guest',
          name: 'Guest User',
          role: 'guest',
        };
        setUser(guestUser);
        setIsGuest(true);
      }
    } catch (error) {
      console.error('Error checking user status:', error);
    } finally {
      setIsLoading(false);
    }
  }, [authManager]);

  const loadStats = useCallback(async () => {
    try {
      setStats({
        totalProducts: 0,
        totalLandListings: 0,
        totalFertilizerGuides: 0,
        activeUsers: 0,
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    }
  }, []);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([checkUserStatus(), loadStats()]);
    setRefreshing(false);
  }, [checkUserStatus, loadStats]);

  useEffect(() => {
    checkUserStatus();
    loadStats();
  }, [checkUserStatus, loadStats]);

  // Load top products and leases (safe fallback if methods not present)
  useEffect(() => {
    let mounted = true;
    const loadHero = async () => {
      try {
        const topProducts =
          typeof (dbManager as any).getTopProducts === 'function'
            ? await (dbManager as any).getTopProducts(5)
            : [];
        const topLeases =
          typeof (dbManager as any).getTopLeases === 'function'
            ? await (dbManager as any).getTopLeases(5)
            : [];

        // If manager didn't return items, will try direct Supabase queries as fallback
        let products = topProducts || [];
        let leases = topLeases || [];
        if (products.length === 0 || leases.length === 0) {
          try {
            if (products.length === 0) {
              const { data: prodData, error: prodError } = await supabase
                .from('products')
                .select('*')
                .order('created_at', { ascending: false })
                .limit(5);
              if (!prodError && Array.isArray(prodData)) products = prodData;
            }
            if (leases.length === 0) {
              const { data: leaseData, error: leaseError } = await supabase
                .from('leases')
                .select('*')
                .order('created_at', { ascending: false })
                .limit(5);
              if (!leaseError && Array.isArray(leaseData)) leases = leaseData;
            }
          } catch (e) {
            console.warn('Direct supabase fallback failed', e);
          }
        }

        const productsMapped = (products || []).map((p: any) => ({
          id: `product-${p.id}`,
          title: p.name || 'Product',
          price: p.price != null ? p.price : null,
          category: p.category || '',
          image: p.image_url || p.image || p.imageUrl || null,
          raw: p,
        }));

        const leasesMapped = (leases || []).map((l: any) => ({
          id: `lease-${l.id}`,
          title: l.title || 'Lease',
          location: l.location || '',
          price: l.price != null ? l.price : null,
          image: l.image_url || l.image || null,
          raw: l,
        }));

        // Set product and lease lists separately
        if (mounted) {
          setProductsList(productsMapped);
          setLeasesList(leasesMapped.slice(0, 5));
        }
      } catch (e) {
        console.warn('Failed to load hero items', e);
      }
    };

    loadHero();
    return () => {
      mounted = false;
    };
  }, [dbManager]);

  // Auto-transition effect for hero cards
  useEffect(() => {
    if (!features || features.length === 0) return;

    const transitionInterval = setInterval(() => {
      // Animate out with fade, slide up, and scale
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 400,
          useNativeDriver: true,
        }),
        Animated.timing(slideAnim, {
          toValue: -30,
          duration: 400,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 0.95,
          duration: 400,
          useNativeDriver: true,
        }),
      ]).start(() => {
        // Change slide index
        setSlideIndex(prev => (prev + 1) % features.length);

        // Reset position for slide in from bottom
        slideAnim.setValue(30);

        // Animate in with fade, slide to center, and scale back
        Animated.parallel([
          Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 400,
            useNativeDriver: true,
          }),
          Animated.timing(slideAnim, {
            toValue: 0,
            duration: 400,
            useNativeDriver: true,
          }),
          Animated.timing(scaleAnim, {
            toValue: 1,
            duration: 400,
            useNativeDriver: true,
          }),
        ]).start();
      });
    }, 5000);

    return () => clearInterval(transitionInterval);
  }, [features.length, fadeAnim, slideAnim, scaleAnim]);

  const handleFeaturePress = (feature: AppFeature) => {
    if (feature.requiresAuth && isGuest) {
      setSelectedFeature(feature);
      setShowLoginModal(true);
      return;
    }

    if (feature.route) {
      (navigation as any).navigate(feature.route);
    }
  };

  const renderFeatureGrid = (features: AppFeature[]) => (
    <View style={styles.actionGrid}>
      {features.map(feature => {
        const hasLimitedAccess = isGuest && feature.requiresAuth;
        const isAvailable = feature.allowedRoles.includes(
          user?.role || 'guest',
        );
        return (
          <TouchableOpacity
            key={feature.id}
            style={[styles.actionCard, !isAvailable && styles.disabledCard]}
            onPress={() => handleFeaturePress(feature)}
            activeOpacity={0.7}
            disabled={!isAvailable}
          >
            <View style={styles.actionIconContainer}>
              <MaterialCommunityIcons
                name={feature.iconName}
                size={28}
                color="#4CAF50"
              />
            </View>
            <Text style={styles.actionTitle}>{feature.title}</Text>
            <Text style={styles.actionDescription}>{feature.description}</Text>
            {hasLimitedAccess && (
              <View style={styles.limitedBadge}>
                <MaterialCommunityIcons name="lock" size={12} color="#FFFFFF" />
              </View>
            )}
          </TouchableOpacity>
        );
      })}
    </View>
  );

  if (isLoading || appInfoLoading) {
    return (
      <Layout activeTab="home" showBottomNavigation={false}>
        <ModernLoading
          visible={true}
          message={
            appInfoLoading ? 'Loading app information...' : 'Loading menu...'
          }
        />
      </Layout>
    );
  }

  return (
    <Layout activeTab="home">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <View style={styles.headerText}>
              <Text style={styles.appName}>{appInfo.app_name}</Text>
              <Text style={styles.welcomeText}>
                {isGuest
                  ? `Welcome to ${appInfo.app_name}`
                  : `Hello, ${user?.name}`}
              </Text>
            </View>
            {isGuest ? (
              <TouchableOpacity
                style={styles.settingsButton}
                onPress={() => navigation.navigate('SignIn')}
              >
                <MaterialCommunityIcons
                  name="login"
                  size={20}
                  color="#FFFFFF"
                />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={styles.settingsButton}
                onPress={() => {
                  try {
                    navigation.navigate('UserProfile', {
                      userId: String((user as User).id),
                    } as any);
                  } catch (err) {
                    console.error('Error navigating to profile', err);
                    Alert.alert('Error', 'Unable to open profile');
                  }
                }}
              >
                {'profile_image_url' in (user ?? {}) &&
                user &&
                (user as User).profile_image_url ? (
                  <View
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: 22,
                      overflow: 'hidden',
                      backgroundColor: '#F5F5F5',
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderWidth: 2,
                      borderColor: '#2196F3',
                      padding: 0,
                    }}
                  >
                    <Image
                      source={{ uri: (user as User).profile_image_url }}
                      style={{ width: 36, height: 36, borderRadius: 18 }}
                      resizeMode="cover"
                    />
                  </View>
                ) : (
                  <View
                    style={{
                      width: 44,
                      height: 44,
                      borderRadius: 22,
                      backgroundColor: '#E0E0E0',
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <MaterialCommunityIcons
                      name="account"
                      size={24}
                      color="#757575"
                    />
                  </View>
                )}
              </TouchableOpacity>
            )}
          </View>
        </View>

        <ScrollView
          style={styles.content}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.contentContainer}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={['#4CAF50']}
              tintColor="#4CAF50"
            />
          }
        >
          {/* Hero Card - Single Animated Transition */}
          <View style={styles.section}>
            <Animated.View
              style={[
                styles.heroContainer,
                {
                  opacity: fadeAnim,
                  transform: [{ translateY: slideAnim }, { scale: scaleAnim }],
                },
              ]}
            >
              {features.length > 0 && (
                <TouchableOpacity
                  activeOpacity={0.9}
                  onPress={() => handleFeaturePress(features[slideIndex])}
                  style={[
                    styles.productHeroCard,
                    {
                      width: '100%',
                      padding: 0,
                      justifyContent: 'center',
                      height: 200,
                    },
                  ]}
                >
                  {/* Background image covering whole card */}
                  <View style={styles.heroImageContainer} pointerEvents="none">
                    <Image
                      source={
                        features[slideIndex].image
                          ? features[slideIndex].image
                          : features[slideIndex].image_url
                          ? { uri: features[slideIndex].image_url }
                          : require('../../assets/placeholder.png')
                      }
                      style={styles.heroImage}
                      resizeMode="cover"
                    />
                  </View>
                  {/* Dark overlay to ensure legibility */}
                  <View
                    style={[
                      StyleSheet.absoluteFillObject,
                      { backgroundColor: 'rgba(0,0,0,0.45)' },
                    ]}
                  />

                  {/* Foreground content */}
                  <View style={{ padding: 16, zIndex: 2 }}>
                    <View
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        marginBottom: 8,
                      }}
                    >
                      <MaterialCommunityIcons
                        name={features[slideIndex].iconName}
                        size={28}
                        color="#FFFFFF"
                        style={{ marginRight: 12 }}
                      />
                      <Text
                        style={{
                          fontSize: 18,
                          fontWeight: '600',
                          color: '#FFFFFF',
                          flexShrink: 1,
                        }}
                        numberOfLines={2}
                      >
                        {features[slideIndex].title}
                      </Text>
                    </View>

                    <Text style={{ fontSize: 13, color: '#E0E0E0' }}>
                      {features[slideIndex].description}
                    </Text>
                    <View
                      style={{
                        marginTop: 12,
                        flexDirection: 'row',
                        alignItems: 'center',
                      }}
                    >
                      <ModernButton
                        title="Open"
                        onPress={() => handleFeaturePress(features[slideIndex])}
                        variant="outline"
                        size="small"
                        style={{ borderColor: '#FFFFFF' } as any}
                        textStyle={{ color: '#000000ff' } as any}
                      />
                      <View style={{ flex: 1 }} />
                    </View>
                  </View>
                </TouchableOpacity>
              )}
            </Animated.View>

            <View style={styles.pagerDots}>
              {features.map((_, i) => (
                <TouchableOpacity
                  key={`dot-${i}`}
                  onPress={() => {
                    // Quick smooth transition when user taps a dot
                    Animated.parallel([
                      Animated.timing(fadeAnim, {
                        toValue: 0,
                        duration: 250,
                        useNativeDriver: true,
                      }),
                      Animated.timing(slideAnim, {
                        toValue: -20,
                        duration: 250,
                        useNativeDriver: true,
                      }),
                      Animated.timing(scaleAnim, {
                        toValue: 0.97,
                        duration: 250,
                        useNativeDriver: true,
                      }),
                    ]).start(() => {
                      setSlideIndex(i);
                      slideAnim.setValue(20);

                      Animated.parallel([
                        Animated.timing(fadeAnim, {
                          toValue: 1,
                          duration: 250,
                          useNativeDriver: true,
                        }),
                        Animated.timing(slideAnim, {
                          toValue: 0,
                          duration: 250,
                          useNativeDriver: true,
                        }),
                        Animated.timing(scaleAnim, {
                          toValue: 1,
                          duration: 250,
                          useNativeDriver: true,
                        }),
                      ]).start();
                    });
                  }}
                >
                  <View
                    style={[styles.dot, i === slideIndex && styles.activeDot]}
                  />
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Exclusive Land Lease Section */}
          {/* <View style={styles.section}>{renderLeaseSection()}</View> */}

          {/* Platform Stats */}
          {/* <View style={styles.section}>{renderStatsCard()}</View> */}

          {/* Core Features */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Explore Features</Text>
            <Text style={styles.sectionDescription}>
              Essential tools for modern agriculture in Bangladesh
            </Text>
            {renderFeatureGrid(features)}
          </View>

          {/* Guest Info */}
          {isGuest && (
            <View style={styles.guestInfo}>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: 8,
                }}
              >
                <MaterialCommunityIcons
                  name="target"
                  size={24}
                  color="#1976D2"
                  style={{ marginRight: 8 }}
                />
                <Text style={styles.guestTitle}>You're in Guest Mode</Text>
              </View>
              <Text style={styles.guestDescription}>
                Sign up or login to access exclusive features including:
              </Text>
              <View style={styles.benefitsList}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginBottom: 4,
                  }}
                >
                  <MaterialCommunityIcons
                    name="check-circle"
                    size={16}
                    color="#4CAF50"
                    style={{ marginRight: 8 }}
                  />
                  <Text style={styles.benefitItem}>Personal Dashboard</Text>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginBottom: 4,
                  }}
                >
                  <MaterialCommunityIcons
                    name="check-circle"
                    size={16}
                    color="#4CAF50"
                    style={{ marginRight: 8 }}
                  />
                  <Text style={styles.benefitItem}>Community Chat</Text>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginBottom: 4,
                  }}
                >
                  <MaterialCommunityIcons
                    name="check-circle"
                    size={16}
                    color="#4CAF50"
                    style={{ marginRight: 8 }}
                  />
                  <Text style={styles.benefitItem}>Product Management</Text>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginBottom: 4,
                  }}
                >
                  <MaterialCommunityIcons
                    name="check-circle"
                    size={16}
                    color="#4CAF50"
                    style={{ marginRight: 8 }}
                  />
                  <Text style={styles.benefitItem}>Inventory Management</Text>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginBottom: 4,
                  }}
                >
                  <MaterialCommunityIcons
                    name="check-circle"
                    size={16}
                    color="#4CAF50"
                    style={{ marginRight: 8 }}
                  />
                  <Text style={styles.benefitItem}>Land Lease Management</Text>
                </View>
              </View>
              <View style={styles.guestActions}>
                <ModernButton
                  title="Sign Up"
                  onPress={() => navigation.navigate('SignUp')}
                  variant="primary"
                  size="medium"
                  style={styles.guestButton}
                />
                <ModernButton
                  title="Sign In"
                  onPress={() => navigation.navigate('SignIn')}
                  variant="outline"
                  size="medium"
                  style={styles.guestButton}
                />
              </View>
            </View>
          )}

          {/* Footer */}
          <View style={styles.footer}>
            <Text style={styles.footerText}>
              {`${appInfo?.app_name ?? 'AgriSmart'} v${
                appInfo?.version ?? '1.0.0'
              }`}
            </Text>
            <Text style={styles.footerSubtext}>
              Empowering A New Era of Farming in Bangladesh
            </Text>
          </View>
          <View style={styles.bottomPadding} />
        </ScrollView>

        <LoginRequiredModal
          visible={showLoginModal}
          onClose={() => setShowLoginModal(false)}
          onLogin={() => {
            setShowLoginModal(false);
            navigation.navigate('SignIn');
          }}
          featureName={selectedFeature?.title || 'this feature'}
        />
      </View>
    </Layout>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
  },
  ecommerceButton: {
    backgroundColor: '#FFF3E0',
    borderRadius: 16,
    padding: 16,
    marginBottom: 8,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  ecommerceButtonArrow: {
    fontSize: 22,
    color: '#212121',
    marginLeft: 8,
    fontWeight: 'bold',
  },
  ecommerceButtonTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#212121',
    marginBottom: 2,
  },
  ecommerceButtonSubtitle: {
    fontSize: 13,
    color: '#757575',
    marginTop: 2,
  },
  ecommerceButtonIcon: {
    fontSize: 28,
    marginRight: 12,
  },
  ecommerceButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingTop: 20,
    paddingBottom: 20,
    paddingHorizontal: 24,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  appName: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  welcomeText: {
    fontSize: 16,
    color: '#666666',
    fontWeight: '400',
  },
  settingsButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#4fa056ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingsIcon: {
    fontSize: 20,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 24,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#212121',
    marginBottom: 8,
  },
  overviewTitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#1A1A1A',
    marginBottom: 20,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  statValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4CAF50',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#757575',
    textAlign: 'center',
  },
  actionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  actionCard: {
    width: (width - 72) / 2,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 6,
    elevation: 1,
    marginBottom: 8,
  },
  actionIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#F8F9FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  actionIcon: {
    fontSize: 24,
  },
  actionTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1A1A1A',
    textAlign: 'center',
    lineHeight: 18,
    marginBottom: 6,
  },
  actionDescription: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    marginBottom: 4,
  },
  disabledCard: {
    opacity: 0.6,
  },
  limitedBadge: {
    backgroundColor: '#FFB74D',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    marginLeft: 8,
  },
  limitedText: {
    fontSize: 12,
    color: '#FFFFFF',
  },
  userSection: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  userIcon: {
    fontSize: 32,
    marginRight: 12,
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#212121',
  },
  userRole: {
    fontSize: 14,
    color: '#757575',
  },
  guestInfo: {
    backgroundColor: '#E3F2FD',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: '#2196F3',
    marginBottom: 32,
  },
  guestTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1976D2',
    textAlign: 'center',
  },
  guestDescription: {
    fontSize: 14,
    color: '#424242',
    textAlign: 'center',
    marginBottom: 16,
  },
  benefitsList: {
    marginBottom: 20,
  },
  benefitItem: {
    fontSize: 14,
    color: '#424242',
    flex: 1,
  },
  guestActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  guestButton: {
    flex: 0.45,
  },
  footer: {
    alignItems: 'center',
    padding: 20,
    marginTop: 20,
  },
  footerText: {
    fontSize: 14,
    color: '#757575',
    fontWeight: '600',
  },
  footerSubtext: {
    fontSize: 12,
    color: '#9E9E9E',
    marginTop: 4,
  },
  bottomPadding: {
    height: 40,
  },
  statsSection: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    marginBottom: 16,
  },
  sectionDescription: {
    fontSize: 14,
    color: '#757575',
    marginBottom: 16,
  },
  heroContainer: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 4,
    elevation: 2,
    shadowColor: '#ffffffff',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    marginTop: 16,
    backgroundColor: '#ffffff',
  },
  heroImageContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  heroImage: {
    width: '100%',
    height: '100%',
  },
  productHeroCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginRight: 12,
    backgroundColor: '#FFFFFF',
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  productHeroImage: {
    width: '100%',
    height: 120,
  },
  productOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 12,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    borderBottomLeftRadius: 16,
    borderBottomRightRadius: 16,
  },
  productOverlayTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  productOverlayPrice: {
    fontSize: 14,
    color: '#FFEB3B',
  },
  heroEmpty: {
    width: '100%',
    height: 120,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 16,
  },
  pagerDots: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 12,
    paddingVertical: 4,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#BDBDBD',
    marginHorizontal: 6,
  },
  activeDot: {
    backgroundColor: '#4CAF50',
    width: 24,
  },
  sectionCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    marginBottom: 16,
  },
  leaseCard: {
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: '#FFFFFF',
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    marginRight: 12,
  },
  leaseImage: {
    width: '100%',
    height: 100,
  },
  leaseMeta: {
    padding: 12,
  },
  leaseTitle: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1A1A1A',
    marginBottom: 4,
  },
  leaseSubtitle: {
    fontSize: 12,
    color: '#757575',
  },
  // profile menu removed
});

export default HomeScreen;
